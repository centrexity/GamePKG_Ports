extern "C" {
    fn frexp(
        __x: ::core::ffi::c_double,
        __exponent: *mut ::core::ffi::c_int,
    ) -> ::core::ffi::c_double;
    fn ldexp(
        __x: ::core::ffi::c_double,
        __exponent: ::core::ffi::c_int,
    ) -> ::core::ffi::c_double;
    fn fabs(__x: ::core::ffi::c_double) -> ::core::ffi::c_double;
    static mut g_xbox_mem_offset: ptrdiff_t;
    fn gamepkg_tls_g_ecx() -> *mut uint32_t;
    fn gamepkg_tls_g_eax() -> *mut uint32_t;
    fn gamepkg_tls_g_esp() -> *mut uint32_t;
    fn gamepkg_tls_g_edx() -> *mut uint32_t;
    fn gamepkg_tls_g_esi() -> *mut uint32_t;
    fn gamepkg_tls_g_edi() -> *mut uint32_t;
    fn gamepkg_tls_g_ebx() -> *mut uint32_t;
    fn gamepkg_tls_g_fp_stack() -> *mut [::core::ffi::c_double; 8];
    fn gamepkg_tls_g_fp_top() -> *mut ::core::ffi::c_int;
    fn gamepkg_tls_g_seh_ebp() -> *mut uint32_t;
    fn gamepkg_tls_g_ebp() -> *mut uint32_t;
    fn gamepkg_tls_g_fp_control_word() -> *mut uint16_t;
    fn gamepkg_tls_g_xmm0() -> *mut RecompXmm;
    fn gamepkg_tls_g_xmm1() -> *mut RecompXmm;
    fn gamepkg_tls_g_xmm2() -> *mut RecompXmm;
    fn sub_00017310();
    fn sub_00140480();
    fn sub_00141010();
    fn sub_00142910();
    fn sub_00142990();
    fn sub_00142B00();
    fn sub_00142C80();
    fn sub_00142CD0();
    fn sub_00142E70();
    fn sub_001AEAA0();
    fn sub_001C99D0();
    fn sub_001C9C80();
    fn sub_001C9DE0();
    fn sub_001C9E50();
    fn sub_001CD8D0();
    fn sub_001CD9F0();
    fn sub_001FB100();
    fn sub_001FB140();
}
pub type int8_t = i8;
pub type int16_t = i16;
pub type int32_t = i32;
pub type int64_t = i64;
pub type uint8_t = u8;
pub type uint16_t = u16;
pub type uint32_t = u32;
pub type uint64_t = u64;
pub type uintptr_t = usize;
pub type ptrdiff_t = isize;
#[derive(Copy, Clone)]
#[repr(C)]
pub union RecompXmm {
    pub f: [::core::ffi::c_float; 4],
    pub d: [::core::ffi::c_double; 2],
    pub u: [uint32_t; 4],
    pub i: [int32_t; 4],
    pub q: [uint64_t; 2],
}
#[inline]
unsafe extern "C" fn recomp_fp_round24(
    mut x: ::core::ffi::c_double,
) -> ::core::ffi::c_double {
    let mut ax: ::core::ffi::c_double = fabs(x);
    let mut e: ::core::ffi::c_int = 0;
    's_6: {
        if ax <= 3.4028234663852886e38f64 && ax >= 1.1754943508222875e-38f64
            || ax == 0.0f64 || x != x
            || ax == ::core::f32::INFINITY as ::core::ffi::c_double
        {
            break 's_6;
        }
        x = frexp(x, &raw mut e);
        return ldexp(x as ::core::ffi::c_float as ::core::ffi::c_double, e);
    }
    return x as ::core::ffi::c_float as ::core::ffi::c_double;
}
#[inline]
unsafe extern "C" fn XMM_ZERO() -> RecompXmm {
    let mut r: RecompXmm = RecompXmm { f: [0.; 4] };
    r.q[0usize] = 0 as uint64_t;
    r.q[1usize] = 0 as uint64_t;
    return r;
}
#[inline]
unsafe extern "C" fn XMM_SCALAR(mut v: ::core::ffi::c_float) -> RecompXmm {
    let mut r: RecompXmm = XMM_ZERO();
    r.f[0usize] = v;
    return r;
}
#[no_mangle]
pub unsafe extern "C" fn sub_00141370() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0x7c as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv: uint32_t = 0 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    let mut _pv_0: uint32_t = 0 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    let mut _pv_1: uint32_t = 0x3f800000 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    let mut _pv_2: uint32_t = 0x3e99999a as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_2,
    );
    let mut _pv_3: uint32_t = 0x87f985b7 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_3,
    );
    let mut _pv_4: uint32_t = 0x78000000 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_4,
    );
    let mut _pv_5: uint32_t = 0x141390 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_5,
    );
    sub_00141010();
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001413A0() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0x7c as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv: uint32_t = 0 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    let mut _pv_0: uint32_t = 0 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    let mut _pv_1: uint32_t = 0x3f800000 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    let mut _pv_2: uint32_t = 0x3e99999a as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_2,
    );
    let mut _pv_3: uint32_t = 0x880224a4 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_3,
    );
    let mut _pv_4: uint32_t = 0x58a40000 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_4,
    );
    let mut _pv_5: uint32_t = 0x1413c0 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_5,
    );
    sub_00141010();
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001413D0() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0x7c as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv: uint32_t = 0 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    let mut _pv_0: uint32_t = 0 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    let mut _pv_1: uint32_t = 0x3f800000 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    let mut _pv_2: uint32_t = 0x3e99999a as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_2,
    );
    let mut _pv_3: uint32_t = 0x88077e0f as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_3,
    );
    let mut _pv_4: uint32_t = 0x66d38000 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_4,
    );
    let mut _pv_5: uint32_t = 0x1413f0 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_5,
    );
    sub_00141010();
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00141400() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx) & 0xffffff00 as uint32_t
        | ::core::ptr::read_volatile::<
            uint8_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint8_t,
            >(
                ((*__gamepkg_tls_g_eax).wrapping_add(0x10 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ) as uint32_t;
    _fa = ((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t as uint32_t
        & 0xff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
    _fas = _fa as int8_t as int32_t;
    _fbs = _fb as int8_t as int32_t;
    's_188: {
        if _fa != _fb {
            break 's_188;
        }
        _fa = ::core::ptr::read_volatile::<
            uint8_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint8_t,
            >(
                ((*__gamepkg_tls_g_eax) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ) as uint32_t & 0xff as uint32_t;
        _fb = 0 as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
        _fas = _fa as int8_t as int32_t;
        _fbs = _fb as int8_t as int32_t;
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint8_t,
            >(
                ((*__gamepkg_tls_g_eax).wrapping_add(0x10 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            1 as uint8_t,
        );
        let mut _pv: uint32_t = 0 as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv,
        );
        's_116: {
            's_70: {
                if _fa != _fb {
                    break 's_70;
                }
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax).wrapping_add(0x7c as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                let mut _pv_1: uint32_t = 0 as ::core::ffi::c_int as uint32_t;
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_1,
                );
                break 's_116;
            }
            (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_eax).wrapping_add(0x78 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            let mut _pv_0: uint32_t = 1 as ::core::ffi::c_int as uint32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_0,
            );
        }
        let mut _pv_2: uint32_t = 0x3f800000 as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_2,
        );
        let mut _pv_3: uint32_t = 0x3f19999a as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_3,
        );
        let mut _pv_4: uint32_t = 0xc87df1d0 as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_4,
        );
        let mut _pv_5: uint32_t = 0xc73e0000 as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_5,
        );
        let mut _pv_6: uint32_t = 0x141437 as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_6,
        );
        sub_00141010();
    }
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00141440() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx) & 0xffffff00 as uint32_t
        | ::core::ptr::read_volatile::<
            uint8_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint8_t,
            >(
                ((*__gamepkg_tls_g_eax).wrapping_add(0x11 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ) as uint32_t;
    _fa = ((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t as uint32_t
        & 0xff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
    _fas = _fa as int8_t as int32_t;
    _fbs = _fb as int8_t as int32_t;
    's_192: {
        if _fa != _fb {
            break 's_192;
        }
        (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx) & 0xffffff00 as uint32_t
            | ::core::ptr::read_volatile::<
                uint8_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint8_t,
                >(
                    ((*__gamepkg_tls_g_eax) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            ) as uint32_t;
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint8_t,
            >(
                ((*__gamepkg_tls_g_eax).wrapping_add(0x11 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            1 as uint8_t,
        );
        (*__gamepkg_tls_g_eax) = 0 as uint32_t;
        _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fa = ((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t as uint32_t
            & 0xff as uint32_t;
        _fb = 0 as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
        _fas = _fa as int8_t as int32_t;
        _fbs = _fb as int8_t as int32_t;
        let mut _pv: uint32_t = (*__gamepkg_tls_g_eax);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv,
        );
        's_120: {
            's_102: {
                if _fa == _fb {
                    break 's_102;
                }
                let mut _pv_0: uint32_t = 1 as ::core::ffi::c_int as uint32_t;
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_0,
                );
                break 's_120;
            }
            let mut _pv_1: uint32_t = 0 as ::core::ffi::c_int as uint32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_1,
            );
        }
        let mut _pv_2: uint32_t = 0x3f800000 as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_2,
        );
        let mut _pv_3: uint32_t = 0x3ecccccd as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_3,
        );
        let mut _pv_4: uint32_t = 0xb701a7e2 as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_4,
        );
        let mut _pv_5: uint32_t = 0xa9e00000 as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_5,
        );
        let mut _pv_6: uint32_t = 0x141473 as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_6,
        );
        sub_00141010();
    }
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00141480() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx) & 0xffffff00 as uint32_t
        | ::core::ptr::read_volatile::<
            uint8_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint8_t,
            >(
                ((*__gamepkg_tls_g_eax).wrapping_add(0x12 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ) as uint32_t;
    _fa = ((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t as uint32_t
        & 0xff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
    _fas = _fa as int8_t as int32_t;
    _fbs = _fb as int8_t as int32_t;
    's_188: {
        if _fa != _fb {
            break 's_188;
        }
        _fa = ::core::ptr::read_volatile::<
            uint8_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint8_t,
            >(
                ((*__gamepkg_tls_g_eax) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ) as uint32_t & 0xff as uint32_t;
        _fb = 0 as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
        _fas = _fa as int8_t as int32_t;
        _fbs = _fb as int8_t as int32_t;
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint8_t,
            >(
                ((*__gamepkg_tls_g_eax).wrapping_add(0x12 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            1 as uint8_t,
        );
        let mut _pv: uint32_t = 0 as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv,
        );
        's_116: {
            's_70: {
                if _fa != _fb {
                    break 's_70;
                }
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax).wrapping_add(0x7c as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                let mut _pv_1: uint32_t = 0 as ::core::ffi::c_int as uint32_t;
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_1,
                );
                break 's_116;
            }
            (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_eax).wrapping_add(0x78 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            let mut _pv_0: uint32_t = 1 as ::core::ffi::c_int as uint32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_0,
            );
        }
        let mut _pv_2: uint32_t = 0x3f800000 as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_2,
        );
        let mut _pv_3: uint32_t = 0x3e4ccccd as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_3,
        );
        let mut _pv_4: uint32_t = 0x53706b33 as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_4,
        );
        let mut _pv_5: uint32_t = 0xcf000000 as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_5,
        );
        let mut _pv_6: uint32_t = 0x1414b7 as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_6,
        );
        sub_00141010();
    }
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001414C0() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0x7c as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv: uint32_t = 0 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    let mut _pv_0: uint32_t = 0 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    let mut _pv_1: uint32_t = 0x3f800000 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    let mut _pv_2: uint32_t = 0x3d75c28f as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_2,
    );
    let mut _pv_3: uint32_t = 0x735fbf16 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_3,
    );
    let mut _pv_4: uint32_t = 0x58400000 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_4,
    );
    let mut _pv_5: uint32_t = 0x1414e0 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_5,
    );
    sub_00141010();
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001414F0() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0x7c as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv: uint32_t = 0 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    let mut _pv_0: uint32_t = 0 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    let mut _pv_1: uint32_t = 0x3f800000 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    let mut _pv_2: uint32_t = 0x3f19999a as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_2,
    );
    let mut _pv_3: uint32_t = 0xb299cf5e as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_3,
    );
    let mut _pv_4: uint32_t = 0x2352b000 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_4,
    );
    let mut _pv_5: uint32_t = 0x141510 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_5,
    );
    sub_00141010();
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00141520() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0x7c as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv: uint32_t = 0 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    let mut _pv_0: uint32_t = 0 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    let mut _pv_1: uint32_t = 0x3f800000 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    let mut _pv_2: uint32_t = 0x3ca3d70a as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_2,
    );
    let mut _pv_3: uint32_t = 0x722fc1ff as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_3,
    );
    let mut _pv_4: uint32_t = 0x9b963800 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_4,
    );
    let mut _pv_5: uint32_t = 0x141540 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_5,
    );
    sub_00141010();
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00141550() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0x7c as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv: uint32_t = 0 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    let mut _pv_0: uint32_t = 0 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    let mut _pv_1: uint32_t = 0x3f800000 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    let mut _pv_2: uint32_t = 0x3ecccccd as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_2,
    );
    let mut _pv_3: uint32_t = 0xb1364c0b as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_3,
    );
    let mut _pv_4: uint32_t = 0x2e8a8000 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_4,
    );
    let mut _pv_5: uint32_t = 0x141570 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_5,
    );
    sub_00141010();
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00141580() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx) & 0xffffff00 as uint32_t
        | ::core::ptr::read_volatile::<
            uint8_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint8_t,
            >(
                ((*__gamepkg_tls_g_eax).wrapping_add(0x69 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ) as uint32_t;
    _fa = ((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t as uint32_t
        & 0xff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
    _fas = _fa as int8_t as int32_t;
    _fbs = _fb as int8_t as int32_t;
    's_145: {
        if _fa != _fb {
            break 's_145;
        }
        let mut _pv: uint32_t = 0 as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv,
        );
        let mut _pv_0: uint32_t = 0 as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_0,
        );
        let mut _pv_1: uint32_t = 0x3f800000 as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_1,
        );
        let mut _pv_2: uint32_t = 0x3ecccccd as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_2,
        );
        let mut _pv_3: uint32_t = 0x7c84febd as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_3,
        );
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint8_t,
            >(
                ((*__gamepkg_tls_g_eax).wrapping_add(0x69 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            5 as uint8_t,
        );
        (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_eax).wrapping_add(0x7c as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        let mut _pv_4: uint32_t = 0x5f43fa40 as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_4,
        );
        let mut _pv_5: uint32_t = 0x1415ab as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_5,
        );
        sub_00141010();
    }
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001415B0() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0x7c as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv: uint32_t = 0 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    let mut _pv_0: uint32_t = 0 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    let mut _pv_1: uint32_t = 0x3f800000 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    let mut _pv_2: uint32_t = 0x3e75c28f as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_2,
    );
    let mut _pv_3: uint32_t = 0x733c0c75 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_3,
    );
    let mut _pv_4: uint32_t = 0x5c900000 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_4,
    );
    let mut _pv_5: uint32_t = 0x1415d0 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_5,
    );
    sub_00141010();
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001415E0() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0x7c as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv: uint32_t = 0 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    let mut _pv_0: uint32_t = 0 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    let mut _pv_1: uint32_t = 0x3f800000 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    let mut _pv_2: uint32_t = 0x3f000000 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_2,
    );
    let mut _pv_3: uint32_t = 0x70943008 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_3,
    );
    let mut _pv_4: uint32_t = 0x8fb41000 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_4,
    );
    let mut _pv_5: uint32_t = 0x141600 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_5,
    );
    sub_00141010();
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00141610() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0x7c as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv: uint32_t = 0 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    let mut _pv_0: uint32_t = 0 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    let mut _pv_1: uint32_t = 0x3f800000 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    let mut _pv_2: uint32_t = 0x3eb33333 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_2,
    );
    let mut _pv_3: uint32_t = 0x709430f4 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_3,
    );
    let mut _pv_4: uint32_t = 0x887c8000 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_4,
    );
    let mut _pv_5: uint32_t = 0x141630 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_5,
    );
    sub_00141010();
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00141640() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0x7c as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv: uint32_t = 0 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    let mut _pv_0: uint32_t = 0 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    let mut _pv_1: uint32_t = 0x3f800000 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    let mut _pv_2: uint32_t = 0x3f000000 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_2,
    );
    let mut _pv_3: uint32_t = 0x84108e68 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_3,
    );
    let mut _pv_4: uint32_t = 0x19ec2440 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_4,
    );
    let mut _pv_5: uint32_t = 0x141660 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_5,
    );
    sub_00141010();
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00141670() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0x7c as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv: uint32_t = 0 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    let mut _pv_0: uint32_t = 0 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    let mut _pv_1: uint32_t = 0x3f800000 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    let mut _pv_2: uint32_t = 0x3f000000 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_2,
    );
    let mut _pv_3: uint32_t = 0xa6864cce as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_3,
    );
    let mut _pv_4: uint32_t = 0x3352d480 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_4,
    );
    let mut _pv_5: uint32_t = 0x141690 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_5,
    );
    sub_00141010();
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001416A0() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0x7c as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv: uint32_t = 0 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    let mut _pv_0: uint32_t = 0 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    let mut _pv_1: uint32_t = 0x3f800000 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    let mut _pv_2: uint32_t = 0x3f000000 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_2,
    );
    let mut _pv_3: uint32_t = 0xa6864cce as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_3,
    );
    let mut _pv_4: uint32_t = 0x3dfe6c00 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_4,
    );
    let mut _pv_5: uint32_t = 0x1416c0 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_5,
    );
    sub_00141010();
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001416D0() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0x7c as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv: uint32_t = 0 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    let mut _pv_0: uint32_t = 0 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    let mut _pv_1: uint32_t = 0x3f800000 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    let mut _pv_2: uint32_t = 0x3f000000 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_2,
    );
    let mut _pv_3: uint32_t = 0x709430ff as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_3,
    );
    let mut _pv_4: uint32_t = 0x7feba000 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_4,
    );
    let mut _pv_5: uint32_t = 0x1416f0 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_5,
    );
    sub_00141010();
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00141700() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let mut ebp: uint32_t = 0 as uint32_t;
    ebp = (*__gamepkg_tls_g_ebp);
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _pv: uint32_t = ebp;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    ebp = (*__gamepkg_tls_g_esp);
    (*__gamepkg_tls_g_ebp) = ebp;
    (*__gamepkg_tls_g_seh_ebp) = ebp;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp) & 0xfffffff0 as uint32_t;
    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fb = 0x10 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(0x10 as uint32_t);
    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_edx).wrapping_add(0x204 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    _fb = 0x30 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax).wrapping_add(0x30 as uint32_t);
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_ecx),
    );
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_ecx),
    );
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0xc as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_ecx),
    );
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (ebp.wrapping_add(0xc as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_eax),
    );
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (ebp.wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv_0: uint32_t = (*__gamepkg_tls_g_ecx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    let mut _pv_1: uint32_t = (*__gamepkg_tls_g_eax);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t);
    (*__gamepkg_tls_g_ebp) = ebp;
    (*__gamepkg_tls_g_seh_ebp) = ebp;
    let mut _pv_2: uint32_t = 0x14173d as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_2,
    );
    sub_00140480();
    (*__gamepkg_tls_g_esp) = ebp;
    ebp = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(12 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00141750() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0x78 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv: uint32_t = 0 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    let mut _pv_0: uint32_t = 0 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    let mut _pv_1: uint32_t = 0x3f800000 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    let mut _pv_2: uint32_t = 0x3f800000 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_2,
    );
    let mut _pv_3: uint32_t = 0x96695b99 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_3,
    );
    let mut _pv_4: uint32_t = 0x36200000 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_4,
    );
    let mut _pv_5: uint32_t = 0x141770 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_5,
    );
    sub_00141010();
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00141780() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0x78 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv: uint32_t = 0 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    let mut _pv_0: uint32_t = 0 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    let mut _pv_1: uint32_t = 0x3f800000 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    let mut _pv_2: uint32_t = 0x3f800000 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_2,
    );
    let mut _pv_3: uint32_t = 0x9b19a72e as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_3,
    );
    let mut _pv_4: uint32_t = 0x3af40000 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_4,
    );
    let mut _pv_5: uint32_t = 0x1417a0 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_5,
    );
    sub_00141010();
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001417B0() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0x78 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv: uint32_t = 0 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    let mut _pv_0: uint32_t = 0 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    let mut _pv_1: uint32_t = 0x3f800000 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    let mut _pv_2: uint32_t = 0x3f800000 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_2,
    );
    let mut _pv_3: uint32_t = 0xb929d77b as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_3,
    );
    let mut _pv_4: uint32_t = 0x9c000000 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_4,
    );
    let mut _pv_5: uint32_t = 0x1417d0 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_5,
    );
    sub_00141010();
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001417E0() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 0xffffff00 as uint32_t
        | ::core::ptr::read_volatile::<
            uint8_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint8_t,
            >(
                ((*__gamepkg_tls_g_esi).wrapping_add(0x69 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ) as uint32_t;
    _fa = ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t as uint32_t
        & 0xff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
    _fas = _fa as int8_t as int32_t;
    _fbs = _fb as int8_t as int32_t;
    's_149: {
        if _fa != _fb {
            break 's_149;
        }
        (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi).wrapping_add(0x78 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        let mut _pv: uint32_t = 0 as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv,
        );
        let mut _pv_0: uint32_t = 0 as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_0,
        );
        let mut _pv_1: uint32_t = 0x3f800000 as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_1,
        );
        let mut _pv_2: uint32_t = 0x3f800000 as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_2,
        );
        let mut _pv_3: uint32_t = 0x59515dbe as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_3,
        );
        let mut _pv_4: uint32_t = 0xac000000 as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_4,
        );
        let mut _pv_5: uint32_t = 0x141807 as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_5,
        );
        sub_00141010();
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint8_t,
            >(
                ((*__gamepkg_tls_g_esi).wrapping_add(0x69 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            1 as uint8_t,
        );
    }
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00141810() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 0xffffff00 as uint32_t
        | ::core::ptr::read_volatile::<
            uint8_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint8_t,
            >(
                ((*__gamepkg_tls_g_esi).wrapping_add(0x69 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ) as uint32_t;
    _fa = ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t as uint32_t
        & 0xff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
    _fas = _fa as int8_t as int32_t;
    _fbs = _fb as int8_t as int32_t;
    's_149: {
        if _fa != _fb {
            break 's_149;
        }
        (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi).wrapping_add(0x78 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        let mut _pv: uint32_t = 0 as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv,
        );
        let mut _pv_0: uint32_t = 0 as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_0,
        );
        let mut _pv_1: uint32_t = 0x3f800000 as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_1,
        );
        let mut _pv_2: uint32_t = 0x3f800000 as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_2,
        );
        let mut _pv_3: uint32_t = 0x769034d7 as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_3,
        );
        let mut _pv_4: uint32_t = 0xf95c0000 as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_4,
        );
        let mut _pv_5: uint32_t = 0x141837 as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_5,
        );
        sub_00141010();
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint8_t,
            >(
                ((*__gamepkg_tls_g_esi).wrapping_add(0x69 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            1 as uint8_t,
        );
    }
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00141840() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0x78 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv: uint32_t = 0 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    let mut _pv_0: uint32_t = 0 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    let mut _pv_1: uint32_t = 0x3f800000 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    let mut _pv_2: uint32_t = 0x3f800000 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_2,
    );
    let mut _pv_3: uint32_t = 0x5975a035 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_3,
    );
    let mut _pv_4: uint32_t = 0xf95c0000 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_4,
    );
    let mut _pv_5: uint32_t = 0x141860 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_5,
    );
    sub_00141010();
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00141870() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0x78 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv: uint32_t = 0 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    let mut _pv_0: uint32_t = 0 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    let mut _pv_1: uint32_t = 0x3f800000 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    let mut _pv_2: uint32_t = 0x3f800000 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_2,
    );
    let mut _pv_3: uint32_t = 0xb894eb49 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_3,
    );
    let mut _pv_4: uint32_t = 0x168a0000 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_4,
    );
    let mut _pv_5: uint32_t = 0x141890 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_5,
    );
    sub_00141010();
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001418A0() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 0xffffff00 as uint32_t
        | ::core::ptr::read_volatile::<
            uint8_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint8_t,
            >(
                ((*__gamepkg_tls_g_esi).wrapping_add(0x69 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ) as uint32_t;
    _fa = ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t as uint32_t
        & 0xff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
    _fas = _fa as int8_t as int32_t;
    _fbs = _fb as int8_t as int32_t;
    's_374: {
        if _fa != _fb {
            break 's_374;
        }
        (*__gamepkg_tls_g_eax) = 0x4a71a0 as uint32_t;
        let mut _pv: uint32_t = 0x1418b5 as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv,
        );
        sub_00017310();
        _fa = ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t as uint32_t
            & 0xff as uint32_t;
        _fb = 0 as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
        _fas = _fa as int8_t as int32_t;
        _fbs = _fb as int8_t as int32_t;
        's_159: {
            if _fa != _fb {
                break 's_159;
            }
            (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    (0x73a1c0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            (*__gamepkg_tls_g_eax) = 0 as uint32_t;
            _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
            _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            _fbs = _fb as int32_t;
            if if if ::core::mem::size_of::<int32_t>()
                < ::core::mem::size_of::<int32_t>()
            {
                ::core::mem::size_of::<int32_t>()
            } else {
                ::core::mem::size_of::<int32_t>()
            } == 1usize
            {
                _fas as uint32_t as uint8_t as int8_t as int32_t
            } else if if ::core::mem::size_of::<int32_t>()
                < ::core::mem::size_of::<int32_t>()
            {
                ::core::mem::size_of::<int32_t>()
            } else {
                ::core::mem::size_of::<int32_t>()
            } == 2usize
            {
                _fas as uint32_t as uint16_t as int16_t as int32_t
            } else {
                _fas as uint32_t as int32_t
            }
                <= if if ::core::mem::size_of::<int32_t>()
                    < ::core::mem::size_of::<int32_t>()
                {
                    ::core::mem::size_of::<int32_t>()
                } else {
                    ::core::mem::size_of::<int32_t>()
                } == 1usize
                {
                    _fbs as uint32_t as uint8_t as int8_t as int32_t
                } else if if ::core::mem::size_of::<int32_t>()
                    < ::core::mem::size_of::<int32_t>()
                {
                    ::core::mem::size_of::<int32_t>()
                } else {
                    ::core::mem::size_of::<int32_t>()
                } == 2usize
                {
                    _fbs as uint32_t as uint16_t as int16_t as int32_t
                } else {
                    _fbs as uint32_t as int32_t
                }
            {
                break 's_159;
            }
            (*__gamepkg_tls_g_ecx) = 0x73baca as uint32_t;
            loop {
                _fa = ::core::ptr::read_volatile::<
                    uint8_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint8_t,
                    >(
                        ((*__gamepkg_tls_g_ecx) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) as uint32_t & 0xff as uint32_t;
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
                _fas = _fa as int8_t as int32_t;
                _fbs = _fb as int8_t as int32_t;
                if _fa != _fb {
                    break 's_374;
                }
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax).wrapping_add(1);
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                _fas = _fa as int32_t;
                _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
                _fb = 0x27e0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                _fbs = _fb as int32_t;
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx)
                    .wrapping_add(0x27e0 as uint32_t);
                _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                _fas = _fa as int32_t;
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                _fb = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                _fas = _fa as int32_t;
                _fbs = _fb as int32_t;
                if if if ::core::mem::size_of::<int32_t>()
                    < ::core::mem::size_of::<int32_t>()
                {
                    ::core::mem::size_of::<int32_t>()
                } else {
                    ::core::mem::size_of::<int32_t>()
                } == 1usize
                {
                    _fas as uint32_t as uint8_t as int8_t as int32_t
                } else if if ::core::mem::size_of::<int32_t>()
                    < ::core::mem::size_of::<int32_t>()
                {
                    ::core::mem::size_of::<int32_t>()
                } else {
                    ::core::mem::size_of::<int32_t>()
                } == 2usize
                {
                    _fas as uint32_t as uint16_t as int16_t as int32_t
                } else {
                    _fas as uint32_t as int32_t
                }
                    >= if if ::core::mem::size_of::<int32_t>()
                        < ::core::mem::size_of::<int32_t>()
                    {
                        ::core::mem::size_of::<int32_t>()
                    } else {
                        ::core::mem::size_of::<int32_t>()
                    } == 1usize
                    {
                        _fbs as uint32_t as uint8_t as int8_t as int32_t
                    } else if if ::core::mem::size_of::<int32_t>()
                        < ::core::mem::size_of::<int32_t>()
                    {
                        ::core::mem::size_of::<int32_t>()
                    } else {
                        ::core::mem::size_of::<int32_t>()
                    } == 2usize
                    {
                        _fbs as uint32_t as uint16_t as int16_t as int32_t
                    } else {
                        _fbs as uint32_t as int32_t
                    }
                {
                    break 's_159;
                }
            }
        }
        (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                (0x4d5370 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
        _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fbs = _fb as int32_t;
        's_212: {
            if _fa == _fb {
                break 's_212;
            }
            _fa = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_eax).wrapping_add(0x1b8 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            ) & 0xffffffff as uint32_t;
            _fb = 0x4d4bd8 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            _fbs = _fb as int32_t;
            if _fa != _fb {
                break 's_212;
            }
            _fa = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    (0x73a1a4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            ) & 0xffffffff as uint32_t;
            _fb = 1 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            _fbs = _fb as int32_t;
            if _fa == _fb {
                break 's_374;
            }
        }
        (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi).wrapping_add(0x64 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx).wrapping_add(1);
        _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_ecx);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi).wrapping_add(0x64 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            (*__gamepkg_tls_g_ecx),
        );
        (*__gamepkg_tls_g_edx) = (if ((*__gamepkg_tls_g_eax) as int32_t) < 0 as int32_t {
            0xffffffff as ::core::ffi::c_uint
        } else {
            0 as ::core::ffi::c_uint
        }) as uint32_t;
        (*__gamepkg_tls_g_ecx) = 0xa as uint32_t;
        let mut _dividend: int64_t = ((*__gamepkg_tls_g_edx) as int32_t as int64_t)
            << 32 as ::core::ffi::c_int | (*__gamepkg_tls_g_eax) as int64_t;
        (*__gamepkg_tls_g_eax) = (_dividend
            / (*__gamepkg_tls_g_ecx) as int32_t as int64_t) as int32_t as uint32_t;
        (*__gamepkg_tls_g_edx) = (_dividend
            % (*__gamepkg_tls_g_ecx) as int32_t as int64_t) as int32_t as uint32_t;
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint8_t,
            >(
                ((*__gamepkg_tls_g_esi).wrapping_add(0x69 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            5 as uint8_t,
        );
        _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
        _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fbs = _fb as int32_t;
        's_266: {
            if _fa == _fb {
                break 's_266;
            }
            (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
                ::core::ptr::read_volatile::<
                    ::core::ffi::c_float,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        ::core::ffi::c_float,
                    >(
                        (0x3b1684 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ),
            );
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    ::core::ffi::c_float,
                >(
                    ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                (*__gamepkg_tls_g_xmm0).f[0usize],
            );
        }
        (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi).wrapping_add(0x78 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        let mut _pv_0: uint32_t = 0 as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_0,
        );
        let mut _pv_1: uint32_t = 0 as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_1,
        );
        let mut _pv_2: uint32_t = 0x3f800000 as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_2,
        );
        let mut _pv_3: uint32_t = (*__gamepkg_tls_g_edx);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_3,
        );
        let mut _pv_4: uint32_t = 0xbd69b91e as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_4,
        );
        let mut _pv_5: uint32_t = 0x81c00000 as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_5,
        );
        let mut _pv_6: uint32_t = 0x141945 as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_6,
        );
        sub_00141010();
    }
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00141950() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        ::core::ffi::c_float,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    ) as int32_t as uint32_t;
    _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_68: {
        if if if ::core::mem::size_of::<int32_t>() < ::core::mem::size_of::<int32_t>() {
            ::core::mem::size_of::<int32_t>()
        } else {
            ::core::mem::size_of::<int32_t>()
        } == 1usize
        {
            _fas as uint32_t as uint8_t as int8_t as int32_t
        } else if if ::core::mem::size_of::<int32_t>()
            < ::core::mem::size_of::<int32_t>()
        {
            ::core::mem::size_of::<int32_t>()
        } else {
            ::core::mem::size_of::<int32_t>()
        } == 2usize
        {
            _fas as uint32_t as uint16_t as int16_t as int32_t
        } else {
            _fas as uint32_t as int32_t
        }
            < if if ::core::mem::size_of::<int32_t>() < ::core::mem::size_of::<int32_t>()
            {
                ::core::mem::size_of::<int32_t>()
            } else {
                ::core::mem::size_of::<int32_t>()
            } == 1usize
            {
                _fbs as uint32_t as uint8_t as int8_t as int32_t
            } else if if ::core::mem::size_of::<int32_t>()
                < ::core::mem::size_of::<int32_t>()
            {
                ::core::mem::size_of::<int32_t>()
            } else {
                ::core::mem::size_of::<int32_t>()
            } == 2usize
            {
                _fbs as uint32_t as uint16_t as int16_t as int32_t
            } else {
                _fbs as uint32_t as int32_t
            }
        {
            break 's_68;
        }
        _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
        _fb = 5 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fbs = _fb as int32_t;
        if if if ::core::mem::size_of::<int32_t>() < ::core::mem::size_of::<int32_t>() {
            ::core::mem::size_of::<int32_t>()
        } else {
            ::core::mem::size_of::<int32_t>()
        } == 1usize
        {
            _fas as uint32_t as uint8_t as int8_t as int32_t
        } else if if ::core::mem::size_of::<int32_t>()
            < ::core::mem::size_of::<int32_t>()
        {
            ::core::mem::size_of::<int32_t>()
        } else {
            ::core::mem::size_of::<int32_t>()
        } == 2usize
        {
            _fas as uint32_t as uint16_t as int16_t as int32_t
        } else {
            _fas as uint32_t as int32_t
        }
            >= if if ::core::mem::size_of::<int32_t>()
                < ::core::mem::size_of::<int32_t>()
            {
                ::core::mem::size_of::<int32_t>()
            } else {
                ::core::mem::size_of::<int32_t>()
            } == 1usize
            {
                _fbs as uint32_t as uint8_t as int8_t as int32_t
            } else if if ::core::mem::size_of::<int32_t>()
                < ::core::mem::size_of::<int32_t>()
            {
                ::core::mem::size_of::<int32_t>()
            } else {
                ::core::mem::size_of::<int32_t>()
            } == 2usize
            {
                _fbs as uint32_t as uint16_t as int16_t as int32_t
            } else {
                _fbs as uint32_t as int32_t
            }
        {
            break 's_68;
        }
        _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
        _fb = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_edi).wrapping_add(0x60 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fbs = _fb as int32_t;
        's_223: {
            if if if ::core::mem::size_of::<int32_t>()
                < ::core::mem::size_of::<int32_t>()
            {
                ::core::mem::size_of::<int32_t>()
            } else {
                ::core::mem::size_of::<int32_t>()
            } == 1usize
            {
                _fas as uint32_t as uint8_t as int8_t as int32_t
            } else if if ::core::mem::size_of::<int32_t>()
                < ::core::mem::size_of::<int32_t>()
            {
                ::core::mem::size_of::<int32_t>()
            } else {
                ::core::mem::size_of::<int32_t>()
            } == 2usize
            {
                _fas as uint32_t as uint16_t as int16_t as int32_t
            } else {
                _fas as uint32_t as int32_t
            }
                >= if if ::core::mem::size_of::<int32_t>()
                    < ::core::mem::size_of::<int32_t>()
                {
                    ::core::mem::size_of::<int32_t>()
                } else {
                    ::core::mem::size_of::<int32_t>()
                } == 1usize
                {
                    _fbs as uint32_t as uint8_t as int8_t as int32_t
                } else if if ::core::mem::size_of::<int32_t>()
                    < ::core::mem::size_of::<int32_t>()
                {
                    ::core::mem::size_of::<int32_t>()
                } else {
                    ::core::mem::size_of::<int32_t>()
                } == 2usize
                {
                    _fbs as uint32_t as uint16_t as int16_t as int32_t
                } else {
                    _fbs as uint32_t as int32_t
                }
            {
                break 's_223;
            }
            (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_edi).wrapping_add(0x78 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            let mut _pv_0: uint32_t = 0 as ::core::ffi::c_int as uint32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_0,
            );
            let mut _pv_1: uint32_t = 0 as ::core::ffi::c_int as uint32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_1,
            );
            let mut _pv_2: uint32_t = 0x3f800000 as ::core::ffi::c_int as uint32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_2,
            );
            let mut _pv_3: uint32_t = 0x3f400000 as ::core::ffi::c_int as uint32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_3,
            );
            let mut _pv_4: uint32_t = 0xbd69b91e as ::core::ffi::c_uint as uint32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_4,
            );
            let mut _pv_5: uint32_t = 0x81c00000 as ::core::ffi::c_uint as uint32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_5,
            );
            let mut _pv_6: uint32_t = 0x141990 as ::core::ffi::c_uint as uint32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_6,
            );
            sub_00141010();
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_edi).wrapping_add(0x60 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                (*__gamepkg_tls_g_esi),
            );
        }
        (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t);
        return;
    }
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_edi).wrapping_add(0x60 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        0x3e7 as uint32_t,
    );
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001419A0() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        ::core::ffi::c_float,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    ) as int32_t as uint32_t;
    _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_68: {
        if if if ::core::mem::size_of::<int32_t>() < ::core::mem::size_of::<int32_t>() {
            ::core::mem::size_of::<int32_t>()
        } else {
            ::core::mem::size_of::<int32_t>()
        } == 1usize
        {
            _fas as uint32_t as uint8_t as int8_t as int32_t
        } else if if ::core::mem::size_of::<int32_t>()
            < ::core::mem::size_of::<int32_t>()
        {
            ::core::mem::size_of::<int32_t>()
        } else {
            ::core::mem::size_of::<int32_t>()
        } == 2usize
        {
            _fas as uint32_t as uint16_t as int16_t as int32_t
        } else {
            _fas as uint32_t as int32_t
        }
            < if if ::core::mem::size_of::<int32_t>() < ::core::mem::size_of::<int32_t>()
            {
                ::core::mem::size_of::<int32_t>()
            } else {
                ::core::mem::size_of::<int32_t>()
            } == 1usize
            {
                _fbs as uint32_t as uint8_t as int8_t as int32_t
            } else if if ::core::mem::size_of::<int32_t>()
                < ::core::mem::size_of::<int32_t>()
            {
                ::core::mem::size_of::<int32_t>()
            } else {
                ::core::mem::size_of::<int32_t>()
            } == 2usize
            {
                _fbs as uint32_t as uint16_t as int16_t as int32_t
            } else {
                _fbs as uint32_t as int32_t
            }
        {
            break 's_68;
        }
        _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
        _fb = 0xa as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fbs = _fb as int32_t;
        if if if ::core::mem::size_of::<int32_t>() < ::core::mem::size_of::<int32_t>() {
            ::core::mem::size_of::<int32_t>()
        } else {
            ::core::mem::size_of::<int32_t>()
        } == 1usize
        {
            _fas as uint32_t as uint8_t as int8_t as int32_t
        } else if if ::core::mem::size_of::<int32_t>()
            < ::core::mem::size_of::<int32_t>()
        {
            ::core::mem::size_of::<int32_t>()
        } else {
            ::core::mem::size_of::<int32_t>()
        } == 2usize
        {
            _fas as uint32_t as uint16_t as int16_t as int32_t
        } else {
            _fas as uint32_t as int32_t
        }
            >= if if ::core::mem::size_of::<int32_t>()
                < ::core::mem::size_of::<int32_t>()
            {
                ::core::mem::size_of::<int32_t>()
            } else {
                ::core::mem::size_of::<int32_t>()
            } == 1usize
            {
                _fbs as uint32_t as uint8_t as int8_t as int32_t
            } else if if ::core::mem::size_of::<int32_t>()
                < ::core::mem::size_of::<int32_t>()
            {
                ::core::mem::size_of::<int32_t>()
            } else {
                ::core::mem::size_of::<int32_t>()
            } == 2usize
            {
                _fbs as uint32_t as uint16_t as int16_t as int32_t
            } else {
                _fbs as uint32_t as int32_t
            }
        {
            break 's_68;
        }
        _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
        _fb = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_edi).wrapping_add(0x60 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fbs = _fb as int32_t;
        's_223: {
            if if if ::core::mem::size_of::<int32_t>()
                < ::core::mem::size_of::<int32_t>()
            {
                ::core::mem::size_of::<int32_t>()
            } else {
                ::core::mem::size_of::<int32_t>()
            } == 1usize
            {
                _fas as uint32_t as uint8_t as int8_t as int32_t
            } else if if ::core::mem::size_of::<int32_t>()
                < ::core::mem::size_of::<int32_t>()
            {
                ::core::mem::size_of::<int32_t>()
            } else {
                ::core::mem::size_of::<int32_t>()
            } == 2usize
            {
                _fas as uint32_t as uint16_t as int16_t as int32_t
            } else {
                _fas as uint32_t as int32_t
            }
                >= if if ::core::mem::size_of::<int32_t>()
                    < ::core::mem::size_of::<int32_t>()
                {
                    ::core::mem::size_of::<int32_t>()
                } else {
                    ::core::mem::size_of::<int32_t>()
                } == 1usize
                {
                    _fbs as uint32_t as uint8_t as int8_t as int32_t
                } else if if ::core::mem::size_of::<int32_t>()
                    < ::core::mem::size_of::<int32_t>()
                {
                    ::core::mem::size_of::<int32_t>()
                } else {
                    ::core::mem::size_of::<int32_t>()
                } == 2usize
                {
                    _fbs as uint32_t as uint16_t as int16_t as int32_t
                } else {
                    _fbs as uint32_t as int32_t
                }
            {
                break 's_223;
            }
            (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_edi).wrapping_add(0x78 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            let mut _pv_0: uint32_t = 0 as ::core::ffi::c_int as uint32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_0,
            );
            let mut _pv_1: uint32_t = 0 as ::core::ffi::c_int as uint32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_1,
            );
            let mut _pv_2: uint32_t = 0x3f800000 as ::core::ffi::c_int as uint32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_2,
            );
            let mut _pv_3: uint32_t = 0x3f400000 as ::core::ffi::c_int as uint32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_3,
            );
            let mut _pv_4: uint32_t = 0xbd69b91e as ::core::ffi::c_uint as uint32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_4,
            );
            let mut _pv_5: uint32_t = 0x81c00000 as ::core::ffi::c_uint as uint32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_5,
            );
            let mut _pv_6: uint32_t = 0x1419e0 as ::core::ffi::c_uint as uint32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_6,
            );
            sub_00141010();
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_edi).wrapping_add(0x60 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                (*__gamepkg_tls_g_esi),
            );
        }
        (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t);
        return;
    }
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_edi).wrapping_add(0x60 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        0x3e7 as uint32_t,
    );
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001419F0() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebx = unsafe { gamepkg_tls_g_ebx() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_fp_control_word = unsafe { gamepkg_tls_g_fp_control_word() };
    let __gamepkg_tls_g_fp_stack = unsafe { gamepkg_tls_g_fp_stack() };
    let __gamepkg_tls_g_fp_top = unsafe { gamepkg_tls_g_fp_top() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    let __gamepkg_tls_g_xmm1 = unsafe { gamepkg_tls_g_xmm1() };
    let __gamepkg_tls_g_xmm2 = unsafe { gamepkg_tls_g_xmm2() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    _fb = 0x50 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(0x50 as uint32_t);
    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b16bc as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_xmm1) = XMM_ZERO();
    (*__gamepkg_tls_g_xmm2) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b16c0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_eax) = 0 as uint32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    let mut _pv: uint32_t = (*__gamepkg_tls_g_ebx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0x10 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0x14 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0x34 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b16b8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0x24 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_eax),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0x44 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b16b4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint8_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0x50 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t,
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint8_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0x51 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t,
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint8_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0x52 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t,
    );
    let mut _pv_0: uint32_t = (*__gamepkg_tls_g_eax);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    (*__gamepkg_tls_g_ebx) = (*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t);
    (*__gamepkg_tls_g_eax) = 0x40b7f4 as uint32_t;
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        0x37800000 as uint32_t,
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        0x6c51001c as uint32_t,
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0x1c as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm1).f[0usize],
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0x20 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm1).f[0usize],
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0x24 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm1).f[0usize],
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0x2c as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm2).f[0usize],
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0x30 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm2).f[0usize],
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0x34 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm2).f[0usize],
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0x44 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm1).f[0usize],
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0x4c as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0x50 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        0xffffffff as ::core::ffi::c_uint as uint32_t,
    );
    let mut _pv_1: uint32_t = 0x141a9e as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    sub_001C9E50();
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0x24 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_eax),
    );
    (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    's_287: {
        if _fa == _fb {
            break 's_287;
        }
        (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
            ::core::ptr::read_volatile::<
                ::core::ffi::c_float,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    ::core::ffi::c_float,
                >(
                    (0x3b168c as ::core::ffi::c_int as uint32_t as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            ),
        );
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                ((*__gamepkg_tls_g_esp).wrapping_add(0x24 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            (*__gamepkg_tls_g_xmm0).f[0usize],
        );
        (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_eax).wrapping_add(8 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_eax).wrapping_add(0x10 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        let mut _fp_value: ::core::ffi::c_double = ::core::ptr::read_volatile::<
            int32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                int32_t,
            >(
                ((*__gamepkg_tls_g_eax).wrapping_add(0x10 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ) as ::core::ffi::c_double;
        (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top) as ::core::ffi::c_uint)
            .wrapping_add(7 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
            as ::core::ffi::c_int;
        (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = _fp_value;
        _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
        _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fbs = _fb as int32_t;
        's_212: {
            if if if ::core::mem::size_of::<int32_t>()
                < ::core::mem::size_of::<int32_t>()
            {
                ::core::mem::size_of::<int32_t>()
            } else {
                ::core::mem::size_of::<int32_t>()
            } == 1usize
            {
                _fas as uint32_t as uint8_t as int8_t as int32_t
            } else if if ::core::mem::size_of::<int32_t>()
                < ::core::mem::size_of::<int32_t>()
            {
                ::core::mem::size_of::<int32_t>()
            } else {
                ::core::mem::size_of::<int32_t>()
            } == 2usize
            {
                _fas as uint32_t as uint16_t as int16_t as int32_t
            } else {
                _fas as uint32_t as int32_t
            }
                >= if if ::core::mem::size_of::<int32_t>()
                    < ::core::mem::size_of::<int32_t>()
                {
                    ::core::mem::size_of::<int32_t>()
                } else {
                    ::core::mem::size_of::<int32_t>()
                } == 1usize
                {
                    _fbs as uint32_t as uint8_t as int8_t as int32_t
                } else if if ::core::mem::size_of::<int32_t>()
                    < ::core::mem::size_of::<int32_t>()
                {
                    ::core::mem::size_of::<int32_t>()
                } else {
                    ::core::mem::size_of::<int32_t>()
                } == 2usize
                {
                    _fbs as uint32_t as uint16_t as int16_t as int32_t
                } else {
                    _fbs as uint32_t as int32_t
                }
            {
                break 's_212;
            }
            (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = if (*__gamepkg_tls_g_fp_control_word)
                as ::core::ffi::c_uint & 0x300 as ::core::ffi::c_uint != 0
            {
                (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                    + ::core::ptr::read_volatile::<
                        ::core::ffi::c_float,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x3b16a8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ) as ::core::ffi::c_double
            } else {
                recomp_fp_round24(
                    (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                        + ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b16a8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ) as ::core::ffi::c_double,
                )
            };
        }
        (*__gamepkg_tls_g_xmm0) = XMM_ZERO();
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                ((*__gamepkg_tls_g_esp).wrapping_add(0x2c as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                as ::core::ffi::c_float,
        );
        (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top) as ::core::ffi::c_uint)
            .wrapping_add(1 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
            as ::core::ffi::c_int;
        (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t);
        let mut _pv_2: uint32_t = (*__gamepkg_tls_g_edx);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_2,
        );
        (*__gamepkg_tls_g_eax) = 0x40b844 as uint32_t;
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                ((*__gamepkg_tls_g_esp).wrapping_add(0x40 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            (*__gamepkg_tls_g_xmm0).f[0usize],
        );
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint8_t,
            >(
                ((*__gamepkg_tls_g_esp).wrapping_add(0x50 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            1 as uint8_t,
        );
        let mut _pv_3: uint32_t = 0x141ae9 as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_3,
        );
        sub_001CD9F0();
        _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
        _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fbs = _fb as int32_t;
        if _fa == _fb {
            break 's_287;
        }
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint8_t,
            >(
                ((*__gamepkg_tls_g_eax).wrapping_add(0x31 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            (::core::ptr::read_volatile::<
                uint8_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint8_t,
                >(
                    ((*__gamepkg_tls_g_eax).wrapping_add(0x31 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            ) as ::core::ffi::c_int | 0x10 as ::core::ffi::c_int) as uint8_t,
        );
        _fa = ::core::ptr::read_volatile::<
            uint8_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint8_t,
            >(
                ((*__gamepkg_tls_g_eax).wrapping_add(0x31 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ) as uint32_t & 0xff as uint32_t;
        _fas = _fa as int8_t as int32_t;
    }
    _fb = 0x50 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(0x50 as uint32_t);
    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00141B00() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_ebx = unsafe { gamepkg_tls_g_ebx() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_fp_control_word = unsafe { gamepkg_tls_g_fp_control_word() };
    let __gamepkg_tls_g_fp_stack = unsafe { gamepkg_tls_g_fp_stack() };
    let __gamepkg_tls_g_fp_top = unsafe { gamepkg_tls_g_fp_top() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    let __gamepkg_tls_g_xmm1 = unsafe { gamepkg_tls_g_xmm1() };
    let __gamepkg_tls_g_xmm2 = unsafe { gamepkg_tls_g_xmm2() };
    let mut ebp: uint32_t = 0;
    let mut _flags: ::core::ffi::c_int = 0;
    let mut _fa: uint32_t = 0;
    let mut _fb: uint32_t = 0;
    let mut _fas: int32_t = 0;
    let mut _fbs: int32_t = 0;
    let mut _pv: uint32_t = 0;
    let mut _pv_0: uint32_t = 0;
    let mut _pv_1: uint32_t = 0;
    let mut _pv_2: uint32_t = 0;
    let mut _pv_3: uint32_t = 0;
    let mut _pv_4: uint32_t = 0;
    let mut _pv_5: uint32_t = 0;
    let mut _fp_value: ::core::ffi::c_double = 0.;
    let mut _pv_6: uint32_t = 0;
    let mut _pv_7: uint32_t = 0;
    let mut _pv_8: uint32_t = 0;
    let mut _pv_9: uint32_t = 0;
    let mut _fp_value_0: ::core::ffi::c_double = 0.;
    let mut _pv_10: uint32_t = 0;
    enum C2Rust_Block_33 {
        S_0,
        S_2,
        S_4,
        S_6,
        S_8,
        S_18,
        S_24,
        S_26,
        S_28,
        S_30,
        S_32,
        S_34,
        S_40,
        S_42,
        S_44,
        S_54,
        S_56,
        S_58,
        S_64,
        S_66,
        S_68,
        S_70,
        S_72,
        S_74,
        S_76,
        S_78,
        S_80,
        S_86,
        S_88,
        S_90,
        S_100,
        S_102,
        S_104,
        S_110,
        S_112,
        S_121,
        S_123,
        S_125,
        S_127,
        S_129,
        S_131,
        S_133,
        S_135,
        S_137,
        S_143,
        S_145,
        S_147,
        S_153,
        S_155,
        S_161,
        S_163,
        S_165,
        S_171,
        S_173,
        S_175,
        S_177,
        S_179,
        S_181,
        S_183,
        S_185,
        S_187,
        S_189,
        S_191,
        S_193,
        S_195,
        S_197,
        S_203,
        S_205,
        S_207,
        S_213,
        S_219,
        S_221,
        S_223,
        S_225,
        S_227,
        S_229,
        S_238,
        S_240,
        S_242,
        S_244,
        S_250,
        S_252,
        S_254,
        S_260,
        S_262,
        S_264,
        S_266,
        S_268,
        S_277,
        S_283,
        S_285,
        S_287,
        S_289,
        S_291,
        S_293,
        S_295,
        S_297,
        S_303,
        S_305,
        S_307,
        S_313,
        S_319,
        S_325,
        S_327,
        S_329,
        S_331,
        S_333,
        S_342,
        S_344,
        S_346,
        S_348,
        S_350,
        S_352,
        S_354,
        S_356,
        S_358,
        S_364,
        S_366,
        S_368,
        S_374,
        S_376,
        S_382,
        S_384,
        S_386,
        S_392,
        S_394,
        S_396,
        S_398,
        S_400,
        S_402,
        S_404,
        S_406,
        S_408,
        S_410,
        S_412,
        S_414,
        S_416,
        S_418,
        S_424,
        S_426,
        S_428,
        S_434,
        S_440,
        S_442,
        S_444,
        S_446,
        S_448,
        S_450,
        S_459,
        S_461,
        S_463,
        S_465,
        S_471,
        S_473,
        S_475,
        S_481,
        S_483,
        S_485,
        S_487,
        S_489,
        S_498,
        S_504,
        S_506,
        S_508,
        S_510,
        S_512,
        S_514,
        S_516,
        S_522,
        S_524,
        S_526,
        S_532,
        S_538,
        S_548,
        S_550,
        S_560,
        S_562,
        S_568,
        S_574,
        S_576,
        S_586,
        S_588,
        S_594,
        S_596,
        S_598,
        S_600,
        S_602,
        S_604,
        S_606,
    }
    let mut c2rust_current_block_33: C2Rust_Block_33;
    c2rust_current_block_33 = C2Rust_Block_33::S_0;
    loop {
        match c2rust_current_block_33 {
            C2Rust_Block_33::S_0 => {
                {
                    ebp = 0 as uint32_t;
                    c2rust_current_block_33 = C2Rust_Block_33::S_2;
                };
                {
                    ebp = (*__gamepkg_tls_g_ebp);
                    c2rust_current_block_33 = C2Rust_Block_33::S_4;
                };
                {
                    _flags = 0 as ::core::ffi::c_int;
                    c2rust_current_block_33 = C2Rust_Block_33::S_6;
                };
                {
                    _fa = 0 as uint32_t;
                    _fb = 0 as uint32_t;
                    c2rust_current_block_33 = C2Rust_Block_33::S_8;
                };
                {
                    _fas = 0 as int32_t;
                    _fbs = 0 as int32_t;
                    c2rust_current_block_33 = C2Rust_Block_33::S_18;
                };
                {
                    ebp = (*__gamepkg_tls_g_seh_ebp);
                    c2rust_current_block_33 = C2Rust_Block_33::S_24;
                };
                {
                    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b168c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_33 = C2Rust_Block_33::S_26;
                };
                {
                    _fb = 0x48 as ::core::ffi::c_int as uint32_t
                        & 0xffffffff as uint32_t;
                    c2rust_current_block_33 = C2Rust_Block_33::S_28;
                };
                {
                    _fbs = _fb as int32_t;
                    c2rust_current_block_33 = C2Rust_Block_33::S_30;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(0x48 as uint32_t);
                    c2rust_current_block_33 = C2Rust_Block_33::S_32;
                };
                {
                    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                    c2rust_current_block_33 = C2Rust_Block_33::S_34;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_33 = C2Rust_Block_33::S_40;
                };
                {
                    _pv = (*__gamepkg_tls_g_ebx);
                    c2rust_current_block_33 = C2Rust_Block_33::S_42;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_33 = C2Rust_Block_33::S_44;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv,
                    );
                    c2rust_current_block_33 = C2Rust_Block_33::S_54;
                };
                {
                    _pv_0 = ebp;
                    c2rust_current_block_33 = C2Rust_Block_33::S_56;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_33 = C2Rust_Block_33::S_58;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_0,
                    );
                    c2rust_current_block_33 = C2Rust_Block_33::S_64;
                };
                {
                    ebp = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x54 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_33 = C2Rust_Block_33::S_66;
                };
                {
                    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (ebp.wrapping_add(8 as uint32_t) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_33 = C2Rust_Block_33::S_68;
                };
                {
                    (*__gamepkg_tls_g_ebx) = 0 as uint32_t;
                    c2rust_current_block_33 = C2Rust_Block_33::S_70;
                };
                {
                    _fa = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
                    c2rust_current_block_33 = C2Rust_Block_33::S_72;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_33 = C2Rust_Block_33::S_74;
                };
                {
                    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                    c2rust_current_block_33 = C2Rust_Block_33::S_76;
                };
                {
                    _fb = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
                    c2rust_current_block_33 = C2Rust_Block_33::S_78;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_33 = C2Rust_Block_33::S_80;
                };
                {
                    _fbs = _fb as int32_t;
                    c2rust_current_block_33 = C2Rust_Block_33::S_86;
                };
                {
                    _pv_1 = (*__gamepkg_tls_g_esi);
                    c2rust_current_block_33 = C2Rust_Block_33::S_88;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_33 = C2Rust_Block_33::S_90;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_1,
                    );
                    c2rust_current_block_33 = C2Rust_Block_33::S_100;
                };
                {
                    _pv_2 = (*__gamepkg_tls_g_edi);
                    c2rust_current_block_33 = C2Rust_Block_33::S_102;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_33 = C2Rust_Block_33::S_104;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_2,
                    );
                    c2rust_current_block_33 = C2Rust_Block_33::S_110;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (ebp.wrapping_add(0x1c as uint32_t) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm0).f[0usize],
                    );
                    c2rust_current_block_33 = C2Rust_Block_33::S_112;
                };
                {
                    if _fa != _fb {
                        c2rust_current_block_33 = C2Rust_Block_33::S_325;
                    } else {
                        c2rust_current_block_33 = C2Rust_Block_33::S_121;
                    }
                };
            }
            C2Rust_Block_33::S_121 => {
                {
                    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b16bc as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_33 = C2Rust_Block_33::S_123;
                };
                {
                    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (ebp.wrapping_add(0x7c as uint32_t) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_33 = C2Rust_Block_33::S_125;
                };
                {
                    (*__gamepkg_tls_g_xmm1) = XMM_ZERO();
                    c2rust_current_block_33 = C2Rust_Block_33::S_127;
                };
                {
                    (*__gamepkg_tls_g_xmm2) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b16c0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_33 = C2Rust_Block_33::S_129;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x10 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm0).f[0usize],
                    );
                    c2rust_current_block_33 = C2Rust_Block_33::S_131;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x14 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm0).f[0usize],
                    );
                    c2rust_current_block_33 = C2Rust_Block_33::S_133;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x18 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm0).f[0usize],
                    );
                    c2rust_current_block_33 = C2Rust_Block_33::S_135;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x38 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm0).f[0usize],
                    );
                    c2rust_current_block_33 = C2Rust_Block_33::S_137;
                };
                {
                    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b16b8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_33 = C2Rust_Block_33::S_143;
                };
                {
                    _pv_3 = (*__gamepkg_tls_g_ebx);
                    c2rust_current_block_33 = C2Rust_Block_33::S_145;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_33 = C2Rust_Block_33::S_147;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_3,
                    );
                    c2rust_current_block_33 = C2Rust_Block_33::S_153;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x4c as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm0).f[0usize],
                    );
                    c2rust_current_block_33 = C2Rust_Block_33::S_155;
                };
                {
                    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b16b4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_33 = C2Rust_Block_33::S_161;
                };
                {
                    _pv_4 = (*__gamepkg_tls_g_eax);
                    c2rust_current_block_33 = C2Rust_Block_33::S_163;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_33 = C2Rust_Block_33::S_165;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_4,
                    );
                    c2rust_current_block_33 = C2Rust_Block_33::S_171;
                };
                {
                    (*__gamepkg_tls_g_eax) = 0x39c320 as uint32_t;
                    c2rust_current_block_33 = C2Rust_Block_33::S_173;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x24 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm1).f[0usize],
                    );
                    c2rust_current_block_33 = C2Rust_Block_33::S_175;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x28 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm1).f[0usize],
                    );
                    c2rust_current_block_33 = C2Rust_Block_33::S_177;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x2c as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm1).f[0usize],
                    );
                    c2rust_current_block_33 = C2Rust_Block_33::S_179;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x30 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_ebx),
                    );
                    c2rust_current_block_33 = C2Rust_Block_33::S_181;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x34 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm2).f[0usize],
                    );
                    c2rust_current_block_33 = C2Rust_Block_33::S_183;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x38 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm2).f[0usize],
                    );
                    c2rust_current_block_33 = C2Rust_Block_33::S_185;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x3c as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm2).f[0usize],
                    );
                    c2rust_current_block_33 = C2Rust_Block_33::S_187;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x4c as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm1).f[0usize],
                    );
                    c2rust_current_block_33 = C2Rust_Block_33::S_189;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x54 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm0).f[0usize],
                    );
                    c2rust_current_block_33 = C2Rust_Block_33::S_191;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x58 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        0xffffffff as ::core::ffi::c_uint as uint32_t,
                    );
                    c2rust_current_block_33 = C2Rust_Block_33::S_193;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x5c as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_ebx) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_33 = C2Rust_Block_33::S_195;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x5d as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_ebx) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_33 = C2Rust_Block_33::S_197;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x5e as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_ebx) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_33 = C2Rust_Block_33::S_203;
                };
                {
                    _pv_5 = 0x141bbd as ::core::ffi::c_uint as uint32_t;
                    c2rust_current_block_33 = C2Rust_Block_33::S_205;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_33 = C2Rust_Block_33::S_207;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_5,
                    );
                    c2rust_current_block_33 = C2Rust_Block_33::S_213;
                };
                {
                    sub_001C99D0();
                    c2rust_current_block_33 = C2Rust_Block_33::S_219;
                };
                {
                    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                    c2rust_current_block_33 = C2Rust_Block_33::S_221;
                };
                {
                    _fb = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
                    c2rust_current_block_33 = C2Rust_Block_33::S_223;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_33 = C2Rust_Block_33::S_225;
                };
                {
                    _fbs = _fb as int32_t;
                    c2rust_current_block_33 = C2Rust_Block_33::S_227;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x28 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_eax),
                    );
                    c2rust_current_block_33 = C2Rust_Block_33::S_229;
                };
                {
                    if _fa == _fb {
                        c2rust_current_block_33 = C2Rust_Block_33::S_325;
                    } else {
                        c2rust_current_block_33 = C2Rust_Block_33::S_238;
                    }
                };
            }
            C2Rust_Block_33::S_238 => {
                {
                    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b168c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_33 = C2Rust_Block_33::S_240;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x2c as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm0).f[0usize],
                    );
                    c2rust_current_block_33 = C2Rust_Block_33::S_242;
                };
                {
                    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_eax).wrapping_add(8 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_33 = C2Rust_Block_33::S_244;
                };
                {
                    (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_ecx).wrapping_add(0x10 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_33 = C2Rust_Block_33::S_250;
                };
                {
                    _fp_value = ::core::ptr::read_volatile::<
                        int32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            int32_t,
                        >(
                            ((*__gamepkg_tls_g_ecx).wrapping_add(0x10 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ) as ::core::ffi::c_double;
                    c2rust_current_block_33 = C2Rust_Block_33::S_252;
                };
                {
                    (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top)
                        as ::core::ffi::c_uint)
                        .wrapping_add(7 as ::core::ffi::c_uint)
                        & 7 as ::core::ffi::c_uint) as ::core::ffi::c_int;
                    c2rust_current_block_33 = C2Rust_Block_33::S_254;
                };
                {
                    (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = _fp_value;
                    c2rust_current_block_33 = C2Rust_Block_33::S_260;
                };
                {
                    _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                    c2rust_current_block_33 = C2Rust_Block_33::S_262;
                };
                {
                    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                    c2rust_current_block_33 = C2Rust_Block_33::S_264;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_33 = C2Rust_Block_33::S_266;
                };
                {
                    _fbs = _fb as int32_t;
                    c2rust_current_block_33 = C2Rust_Block_33::S_268;
                };
                {
                    if if if ::core::mem::size_of::<int32_t>()
                        < ::core::mem::size_of::<int32_t>()
                    {
                        ::core::mem::size_of::<int32_t>()
                    } else {
                        ::core::mem::size_of::<int32_t>()
                    } == 1usize
                    {
                        _fas as uint32_t as uint8_t as int8_t as int32_t
                    } else if if ::core::mem::size_of::<int32_t>()
                        < ::core::mem::size_of::<int32_t>()
                    {
                        ::core::mem::size_of::<int32_t>()
                    } else {
                        ::core::mem::size_of::<int32_t>()
                    } == 2usize
                    {
                        _fas as uint32_t as uint16_t as int16_t as int32_t
                    } else {
                        _fas as uint32_t as int32_t
                    }
                        >= if if ::core::mem::size_of::<int32_t>()
                            < ::core::mem::size_of::<int32_t>()
                        {
                            ::core::mem::size_of::<int32_t>()
                        } else {
                            ::core::mem::size_of::<int32_t>()
                        } == 1usize
                        {
                            _fbs as uint32_t as uint8_t as int8_t as int32_t
                        } else if if ::core::mem::size_of::<int32_t>()
                            < ::core::mem::size_of::<int32_t>()
                        {
                            ::core::mem::size_of::<int32_t>()
                        } else {
                            ::core::mem::size_of::<int32_t>()
                        } == 2usize
                        {
                            _fbs as uint32_t as uint16_t as int16_t as int32_t
                        } else {
                            _fbs as uint32_t as int32_t
                        }
                    {
                        c2rust_current_block_33 = C2Rust_Block_33::S_283;
                    } else {
                        c2rust_current_block_33 = C2Rust_Block_33::S_277;
                    }
                };
            }
            C2Rust_Block_33::S_277 => {
                (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = if (*__gamepkg_tls_g_fp_control_word)
                    as ::core::ffi::c_uint & 0x300 as ::core::ffi::c_uint != 0
                {
                    (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                        + ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b16a8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ) as ::core::ffi::c_double
                } else {
                    recomp_fp_round24(
                        (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                            + ::core::ptr::read_volatile::<
                                ::core::ffi::c_float,
                            >(
                                ::core::ptr::with_exposed_provenance_mut::<
                                    ::core::ffi::c_float,
                                >(
                                    (0x3b16a8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                                ),
                            ) as ::core::ffi::c_double,
                    )
                };
                c2rust_current_block_33 = C2Rust_Block_33::S_283;
            }
            C2Rust_Block_33::S_283 => {
                {
                    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b16c0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_33 = C2Rust_Block_33::S_285;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x34 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                            as ::core::ffi::c_float,
                    );
                    c2rust_current_block_33 = C2Rust_Block_33::S_287;
                };
                {
                    (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top)
                        as ::core::ffi::c_uint)
                        .wrapping_add(1 as ::core::ffi::c_uint)
                        & 7 as ::core::ffi::c_uint) as ::core::ffi::c_int;
                    c2rust_current_block_33 = C2Rust_Block_33::S_289;
                };
                {
                    (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_esp)
                        .wrapping_add(0x10 as uint32_t);
                    c2rust_current_block_33 = C2Rust_Block_33::S_291;
                };
                {
                    (*__gamepkg_tls_g_esi) = 0x40b844 as uint32_t;
                    c2rust_current_block_33 = C2Rust_Block_33::S_293;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x54 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        1 as uint8_t,
                    );
                    c2rust_current_block_33 = C2Rust_Block_33::S_295;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x55 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        1 as uint8_t,
                    );
                    c2rust_current_block_33 = C2Rust_Block_33::S_297;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x38 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm0).f[0usize],
                    );
                    c2rust_current_block_33 = C2Rust_Block_33::S_303;
                };
                {
                    _pv_6 = 0x141c10 as ::core::ffi::c_uint as uint32_t;
                    c2rust_current_block_33 = C2Rust_Block_33::S_305;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_33 = C2Rust_Block_33::S_307;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_6,
                    );
                    c2rust_current_block_33 = C2Rust_Block_33::S_313;
                };
                {
                    sub_001CD8D0();
                    c2rust_current_block_33 = C2Rust_Block_33::S_319;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (ebp.wrapping_add(8 as uint32_t) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_eax),
                    );
                    c2rust_current_block_33 = C2Rust_Block_33::S_325;
                };
            }
            C2Rust_Block_33::S_325 => {
                {
                    _fa = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (ebp.wrapping_add(0xc as uint32_t) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ) & 0xffffffff as uint32_t;
                    c2rust_current_block_33 = C2Rust_Block_33::S_327;
                };
                {
                    _fb = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
                    c2rust_current_block_33 = C2Rust_Block_33::S_329;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_33 = C2Rust_Block_33::S_331;
                };
                {
                    _fbs = _fb as int32_t;
                    c2rust_current_block_33 = C2Rust_Block_33::S_333;
                };
                {
                    if _fa != _fb {
                        c2rust_current_block_33 = C2Rust_Block_33::S_548;
                    } else {
                        c2rust_current_block_33 = C2Rust_Block_33::S_342;
                    }
                };
            }
            C2Rust_Block_33::S_342 => {
                {
                    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b16bc as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_33 = C2Rust_Block_33::S_344;
                };
                {
                    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (ebp.wrapping_add(0x7c as uint32_t) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_33 = C2Rust_Block_33::S_346;
                };
                {
                    (*__gamepkg_tls_g_xmm1) = XMM_ZERO();
                    c2rust_current_block_33 = C2Rust_Block_33::S_348;
                };
                {
                    (*__gamepkg_tls_g_xmm2) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b16c0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_33 = C2Rust_Block_33::S_350;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x10 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm0).f[0usize],
                    );
                    c2rust_current_block_33 = C2Rust_Block_33::S_352;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x14 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm0).f[0usize],
                    );
                    c2rust_current_block_33 = C2Rust_Block_33::S_354;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x18 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm0).f[0usize],
                    );
                    c2rust_current_block_33 = C2Rust_Block_33::S_356;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x38 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm0).f[0usize],
                    );
                    c2rust_current_block_33 = C2Rust_Block_33::S_358;
                };
                {
                    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b16b8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_33 = C2Rust_Block_33::S_364;
                };
                {
                    _pv_7 = (*__gamepkg_tls_g_ebx);
                    c2rust_current_block_33 = C2Rust_Block_33::S_366;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_33 = C2Rust_Block_33::S_368;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_7,
                    );
                    c2rust_current_block_33 = C2Rust_Block_33::S_374;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x4c as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm0).f[0usize],
                    );
                    c2rust_current_block_33 = C2Rust_Block_33::S_376;
                };
                {
                    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b16b4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_33 = C2Rust_Block_33::S_382;
                };
                {
                    _pv_8 = (*__gamepkg_tls_g_eax);
                    c2rust_current_block_33 = C2Rust_Block_33::S_384;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_33 = C2Rust_Block_33::S_386;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_8,
                    );
                    c2rust_current_block_33 = C2Rust_Block_33::S_392;
                };
                {
                    (*__gamepkg_tls_g_eax) = 0x39c328 as uint32_t;
                    c2rust_current_block_33 = C2Rust_Block_33::S_394;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x24 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm1).f[0usize],
                    );
                    c2rust_current_block_33 = C2Rust_Block_33::S_396;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x28 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm1).f[0usize],
                    );
                    c2rust_current_block_33 = C2Rust_Block_33::S_398;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x2c as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm1).f[0usize],
                    );
                    c2rust_current_block_33 = C2Rust_Block_33::S_400;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x30 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_ebx),
                    );
                    c2rust_current_block_33 = C2Rust_Block_33::S_402;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x34 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm2).f[0usize],
                    );
                    c2rust_current_block_33 = C2Rust_Block_33::S_404;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x38 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm2).f[0usize],
                    );
                    c2rust_current_block_33 = C2Rust_Block_33::S_406;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x3c as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm2).f[0usize],
                    );
                    c2rust_current_block_33 = C2Rust_Block_33::S_408;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x4c as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm1).f[0usize],
                    );
                    c2rust_current_block_33 = C2Rust_Block_33::S_410;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x54 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm0).f[0usize],
                    );
                    c2rust_current_block_33 = C2Rust_Block_33::S_412;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x58 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        0xffffffff as ::core::ffi::c_uint as uint32_t,
                    );
                    c2rust_current_block_33 = C2Rust_Block_33::S_414;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x5c as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_ebx) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_33 = C2Rust_Block_33::S_416;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x5d as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_ebx) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_33 = C2Rust_Block_33::S_418;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x5e as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_ebx) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_33 = C2Rust_Block_33::S_424;
                };
                {
                    _pv_9 = 0x141cb4 as ::core::ffi::c_uint as uint32_t;
                    c2rust_current_block_33 = C2Rust_Block_33::S_426;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_33 = C2Rust_Block_33::S_428;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_9,
                    );
                    c2rust_current_block_33 = C2Rust_Block_33::S_434;
                };
                {
                    sub_001C99D0();
                    c2rust_current_block_33 = C2Rust_Block_33::S_440;
                };
                {
                    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                    c2rust_current_block_33 = C2Rust_Block_33::S_442;
                };
                {
                    _fb = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
                    c2rust_current_block_33 = C2Rust_Block_33::S_444;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_33 = C2Rust_Block_33::S_446;
                };
                {
                    _fbs = _fb as int32_t;
                    c2rust_current_block_33 = C2Rust_Block_33::S_448;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x28 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_eax),
                    );
                    c2rust_current_block_33 = C2Rust_Block_33::S_450;
                };
                {
                    if _fa == _fb {
                        c2rust_current_block_33 = C2Rust_Block_33::S_548;
                    } else {
                        c2rust_current_block_33 = C2Rust_Block_33::S_459;
                    }
                };
            }
            C2Rust_Block_33::S_459 => {
                {
                    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b168c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_33 = C2Rust_Block_33::S_461;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x2c as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm0).f[0usize],
                    );
                    c2rust_current_block_33 = C2Rust_Block_33::S_463;
                };
                {
                    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_eax).wrapping_add(8 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_33 = C2Rust_Block_33::S_465;
                };
                {
                    (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_ecx).wrapping_add(0x10 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_33 = C2Rust_Block_33::S_471;
                };
                {
                    _fp_value_0 = ::core::ptr::read_volatile::<
                        int32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            int32_t,
                        >(
                            ((*__gamepkg_tls_g_ecx).wrapping_add(0x10 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ) as ::core::ffi::c_double;
                    c2rust_current_block_33 = C2Rust_Block_33::S_473;
                };
                {
                    (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top)
                        as ::core::ffi::c_uint)
                        .wrapping_add(7 as ::core::ffi::c_uint)
                        & 7 as ::core::ffi::c_uint) as ::core::ffi::c_int;
                    c2rust_current_block_33 = C2Rust_Block_33::S_475;
                };
                {
                    (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = _fp_value_0;
                    c2rust_current_block_33 = C2Rust_Block_33::S_481;
                };
                {
                    _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                    c2rust_current_block_33 = C2Rust_Block_33::S_483;
                };
                {
                    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                    c2rust_current_block_33 = C2Rust_Block_33::S_485;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_33 = C2Rust_Block_33::S_487;
                };
                {
                    _fbs = _fb as int32_t;
                    c2rust_current_block_33 = C2Rust_Block_33::S_489;
                };
                {
                    if if if ::core::mem::size_of::<int32_t>()
                        < ::core::mem::size_of::<int32_t>()
                    {
                        ::core::mem::size_of::<int32_t>()
                    } else {
                        ::core::mem::size_of::<int32_t>()
                    } == 1usize
                    {
                        _fas as uint32_t as uint8_t as int8_t as int32_t
                    } else if if ::core::mem::size_of::<int32_t>()
                        < ::core::mem::size_of::<int32_t>()
                    {
                        ::core::mem::size_of::<int32_t>()
                    } else {
                        ::core::mem::size_of::<int32_t>()
                    } == 2usize
                    {
                        _fas as uint32_t as uint16_t as int16_t as int32_t
                    } else {
                        _fas as uint32_t as int32_t
                    }
                        >= if if ::core::mem::size_of::<int32_t>()
                            < ::core::mem::size_of::<int32_t>()
                        {
                            ::core::mem::size_of::<int32_t>()
                        } else {
                            ::core::mem::size_of::<int32_t>()
                        } == 1usize
                        {
                            _fbs as uint32_t as uint8_t as int8_t as int32_t
                        } else if if ::core::mem::size_of::<int32_t>()
                            < ::core::mem::size_of::<int32_t>()
                        {
                            ::core::mem::size_of::<int32_t>()
                        } else {
                            ::core::mem::size_of::<int32_t>()
                        } == 2usize
                        {
                            _fbs as uint32_t as uint16_t as int16_t as int32_t
                        } else {
                            _fbs as uint32_t as int32_t
                        }
                    {
                        c2rust_current_block_33 = C2Rust_Block_33::S_504;
                    } else {
                        c2rust_current_block_33 = C2Rust_Block_33::S_498;
                    }
                };
            }
            C2Rust_Block_33::S_498 => {
                (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = if (*__gamepkg_tls_g_fp_control_word)
                    as ::core::ffi::c_uint & 0x300 as ::core::ffi::c_uint != 0
                {
                    (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                        + ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b16a8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ) as ::core::ffi::c_double
                } else {
                    recomp_fp_round24(
                        (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                            + ::core::ptr::read_volatile::<
                                ::core::ffi::c_float,
                            >(
                                ::core::ptr::with_exposed_provenance_mut::<
                                    ::core::ffi::c_float,
                                >(
                                    (0x3b16a8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                                ),
                            ) as ::core::ffi::c_double,
                    )
                };
                c2rust_current_block_33 = C2Rust_Block_33::S_504;
            }
            C2Rust_Block_33::S_504 => {
                {
                    (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_esp)
                        .wrapping_add(0x10 as uint32_t);
                    c2rust_current_block_33 = C2Rust_Block_33::S_506;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x34 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                            as ::core::ffi::c_float,
                    );
                    c2rust_current_block_33 = C2Rust_Block_33::S_508;
                };
                {
                    (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top)
                        as ::core::ffi::c_uint)
                        .wrapping_add(1 as ::core::ffi::c_uint)
                        & 7 as ::core::ffi::c_uint) as ::core::ffi::c_int;
                    c2rust_current_block_33 = C2Rust_Block_33::S_510;
                };
                {
                    (*__gamepkg_tls_g_esi) = 0x40b844 as uint32_t;
                    c2rust_current_block_33 = C2Rust_Block_33::S_512;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x54 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        1 as uint8_t,
                    );
                    c2rust_current_block_33 = C2Rust_Block_33::S_514;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x55 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        1 as uint8_t,
                    );
                    c2rust_current_block_33 = C2Rust_Block_33::S_516;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x38 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm0).f[0usize],
                    );
                    c2rust_current_block_33 = C2Rust_Block_33::S_522;
                };
                {
                    _pv_10 = 0x141cff as ::core::ffi::c_uint as uint32_t;
                    c2rust_current_block_33 = C2Rust_Block_33::S_524;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_33 = C2Rust_Block_33::S_526;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_10,
                    );
                    c2rust_current_block_33 = C2Rust_Block_33::S_532;
                };
                {
                    sub_001CD8D0();
                    c2rust_current_block_33 = C2Rust_Block_33::S_538;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (ebp.wrapping_add(0xc as uint32_t) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_eax),
                    );
                    c2rust_current_block_33 = C2Rust_Block_33::S_548;
                };
            }
            C2Rust_Block_33::S_548 => {
                {
                    (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_33 = C2Rust_Block_33::S_550;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_add(4 as uint32_t);
                    c2rust_current_block_33 = C2Rust_Block_33::S_560;
                };
                {
                    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_33 = C2Rust_Block_33::S_562;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_add(4 as uint32_t);
                    c2rust_current_block_33 = C2Rust_Block_33::S_568;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (ebp.wrapping_add(0x48 as uint32_t) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        0xe10 as uint32_t,
                    );
                    c2rust_current_block_33 = C2Rust_Block_33::S_574;
                };
                {
                    ebp = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_33 = C2Rust_Block_33::S_576;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_add(4 as uint32_t);
                    c2rust_current_block_33 = C2Rust_Block_33::S_586;
                };
                {
                    (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_33 = C2Rust_Block_33::S_588;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_add(4 as uint32_t);
                    c2rust_current_block_33 = C2Rust_Block_33::S_594;
                };
                {
                    _fb = 0x48 as ::core::ffi::c_int as uint32_t
                        & 0xffffffff as uint32_t;
                    c2rust_current_block_33 = C2Rust_Block_33::S_596;
                };
                {
                    _fbs = _fb as int32_t;
                    c2rust_current_block_33 = C2Rust_Block_33::S_598;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_add(0x48 as uint32_t);
                    c2rust_current_block_33 = C2Rust_Block_33::S_600;
                };
                {
                    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                    c2rust_current_block_33 = C2Rust_Block_33::S_602;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_33 = C2Rust_Block_33::S_604;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_add(8 as uint32_t);
                    c2rust_current_block_33 = C2Rust_Block_33::S_606;
                };
                return;
            }
            C2Rust_Block_33::S_100
            | C2Rust_Block_33::S_102
            | C2Rust_Block_33::S_104
            | C2Rust_Block_33::S_110
            | C2Rust_Block_33::S_112
            | C2Rust_Block_33::S_123
            | C2Rust_Block_33::S_125
            | C2Rust_Block_33::S_127
            | C2Rust_Block_33::S_129
            | C2Rust_Block_33::S_131
            | C2Rust_Block_33::S_133
            | C2Rust_Block_33::S_135
            | C2Rust_Block_33::S_137
            | C2Rust_Block_33::S_143
            | C2Rust_Block_33::S_145
            | C2Rust_Block_33::S_147
            | C2Rust_Block_33::S_153
            | C2Rust_Block_33::S_155
            | C2Rust_Block_33::S_161
            | C2Rust_Block_33::S_163
            | C2Rust_Block_33::S_165
            | C2Rust_Block_33::S_171
            | C2Rust_Block_33::S_173
            | C2Rust_Block_33::S_175
            | C2Rust_Block_33::S_177
            | C2Rust_Block_33::S_179
            | C2Rust_Block_33::S_18
            | C2Rust_Block_33::S_181
            | C2Rust_Block_33::S_183
            | C2Rust_Block_33::S_185
            | C2Rust_Block_33::S_187
            | C2Rust_Block_33::S_189
            | C2Rust_Block_33::S_191
            | C2Rust_Block_33::S_193
            | C2Rust_Block_33::S_195
            | C2Rust_Block_33::S_197
            | C2Rust_Block_33::S_2
            | C2Rust_Block_33::S_203
            | C2Rust_Block_33::S_205
            | C2Rust_Block_33::S_207
            | C2Rust_Block_33::S_213
            | C2Rust_Block_33::S_219
            | C2Rust_Block_33::S_221
            | C2Rust_Block_33::S_223
            | C2Rust_Block_33::S_225
            | C2Rust_Block_33::S_227
            | C2Rust_Block_33::S_229
            | C2Rust_Block_33::S_24
            | C2Rust_Block_33::S_240
            | C2Rust_Block_33::S_242
            | C2Rust_Block_33::S_244
            | C2Rust_Block_33::S_250
            | C2Rust_Block_33::S_252
            | C2Rust_Block_33::S_254
            | C2Rust_Block_33::S_26
            | C2Rust_Block_33::S_260
            | C2Rust_Block_33::S_262
            | C2Rust_Block_33::S_264
            | C2Rust_Block_33::S_266
            | C2Rust_Block_33::S_268
            | C2Rust_Block_33::S_28
            | C2Rust_Block_33::S_285
            | C2Rust_Block_33::S_287
            | C2Rust_Block_33::S_289
            | C2Rust_Block_33::S_291
            | C2Rust_Block_33::S_293
            | C2Rust_Block_33::S_295
            | C2Rust_Block_33::S_297
            | C2Rust_Block_33::S_30
            | C2Rust_Block_33::S_303
            | C2Rust_Block_33::S_305
            | C2Rust_Block_33::S_307
            | C2Rust_Block_33::S_313
            | C2Rust_Block_33::S_319
            | C2Rust_Block_33::S_32
            | C2Rust_Block_33::S_327
            | C2Rust_Block_33::S_329
            | C2Rust_Block_33::S_331
            | C2Rust_Block_33::S_333
            | C2Rust_Block_33::S_34
            | C2Rust_Block_33::S_344
            | C2Rust_Block_33::S_346
            | C2Rust_Block_33::S_348
            | C2Rust_Block_33::S_350
            | C2Rust_Block_33::S_352
            | C2Rust_Block_33::S_354
            | C2Rust_Block_33::S_356
            | C2Rust_Block_33::S_358
            | C2Rust_Block_33::S_364
            | C2Rust_Block_33::S_366
            | C2Rust_Block_33::S_368
            | C2Rust_Block_33::S_374
            | C2Rust_Block_33::S_376
            | C2Rust_Block_33::S_382
            | C2Rust_Block_33::S_384
            | C2Rust_Block_33::S_386
            | C2Rust_Block_33::S_392
            | C2Rust_Block_33::S_394
            | C2Rust_Block_33::S_396
            | C2Rust_Block_33::S_398
            | C2Rust_Block_33::S_4
            | C2Rust_Block_33::S_40
            | C2Rust_Block_33::S_400
            | C2Rust_Block_33::S_402
            | C2Rust_Block_33::S_404
            | C2Rust_Block_33::S_406
            | C2Rust_Block_33::S_408
            | C2Rust_Block_33::S_410
            | C2Rust_Block_33::S_412
            | C2Rust_Block_33::S_414
            | C2Rust_Block_33::S_416
            | C2Rust_Block_33::S_418
            | C2Rust_Block_33::S_42
            | C2Rust_Block_33::S_424
            | C2Rust_Block_33::S_426
            | C2Rust_Block_33::S_428
            | C2Rust_Block_33::S_434
            | C2Rust_Block_33::S_44
            | C2Rust_Block_33::S_440
            | C2Rust_Block_33::S_442
            | C2Rust_Block_33::S_444
            | C2Rust_Block_33::S_446
            | C2Rust_Block_33::S_448
            | C2Rust_Block_33::S_450
            | C2Rust_Block_33::S_461
            | C2Rust_Block_33::S_463
            | C2Rust_Block_33::S_465
            | C2Rust_Block_33::S_471
            | C2Rust_Block_33::S_473
            | C2Rust_Block_33::S_475
            | C2Rust_Block_33::S_481
            | C2Rust_Block_33::S_483
            | C2Rust_Block_33::S_485
            | C2Rust_Block_33::S_487
            | C2Rust_Block_33::S_489
            | C2Rust_Block_33::S_506
            | C2Rust_Block_33::S_508
            | C2Rust_Block_33::S_510
            | C2Rust_Block_33::S_512
            | C2Rust_Block_33::S_514
            | C2Rust_Block_33::S_516
            | C2Rust_Block_33::S_522
            | C2Rust_Block_33::S_524
            | C2Rust_Block_33::S_526
            | C2Rust_Block_33::S_532
            | C2Rust_Block_33::S_538
            | C2Rust_Block_33::S_54
            | C2Rust_Block_33::S_550
            | C2Rust_Block_33::S_56
            | C2Rust_Block_33::S_560
            | C2Rust_Block_33::S_562
            | C2Rust_Block_33::S_568
            | C2Rust_Block_33::S_574
            | C2Rust_Block_33::S_576
            | C2Rust_Block_33::S_58
            | C2Rust_Block_33::S_586
            | C2Rust_Block_33::S_588
            | C2Rust_Block_33::S_594
            | C2Rust_Block_33::S_596
            | C2Rust_Block_33::S_598
            | C2Rust_Block_33::S_6
            | C2Rust_Block_33::S_600
            | C2Rust_Block_33::S_602
            | C2Rust_Block_33::S_604
            | C2Rust_Block_33::S_606
            | C2Rust_Block_33::S_64
            | C2Rust_Block_33::S_66
            | C2Rust_Block_33::S_68
            | C2Rust_Block_33::S_70
            | C2Rust_Block_33::S_72
            | C2Rust_Block_33::S_74
            | C2Rust_Block_33::S_76
            | C2Rust_Block_33::S_78
            | C2Rust_Block_33::S_8
            | C2Rust_Block_33::S_80
            | C2Rust_Block_33::S_86
            | C2Rust_Block_33::S_88
            | C2Rust_Block_33::S_90 => {
                unreachable!("GamePKG compacted dispatch state reached")
            }
        }
    };
}
#[no_mangle]
pub unsafe extern "C" fn sub_00141D20() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_ebx = unsafe { gamepkg_tls_g_ebx() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_fp_control_word = unsafe { gamepkg_tls_g_fp_control_word() };
    let __gamepkg_tls_g_fp_stack = unsafe { gamepkg_tls_g_fp_stack() };
    let __gamepkg_tls_g_fp_top = unsafe { gamepkg_tls_g_fp_top() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    let __gamepkg_tls_g_xmm1 = unsafe { gamepkg_tls_g_xmm1() };
    let __gamepkg_tls_g_xmm2 = unsafe { gamepkg_tls_g_xmm2() };
    let mut ebp: uint32_t = 0;
    let mut _flags: ::core::ffi::c_int = 0;
    let mut _fa: uint32_t = 0;
    let mut _fb: uint32_t = 0;
    let mut _fas: int32_t = 0;
    let mut _fbs: int32_t = 0;
    let mut _pv: uint32_t = 0;
    let mut _pv_0: uint32_t = 0;
    let mut _pv_1: uint32_t = 0;
    let mut _pv_2: uint32_t = 0;
    let mut _pv_3: uint32_t = 0;
    let mut _pv_4: uint32_t = 0;
    let mut _fp_value: ::core::ffi::c_double = 0.;
    let mut _pv_5: uint32_t = 0;
    let mut _pv_6: uint32_t = 0;
    let mut _pv_7: uint32_t = 0;
    let mut _fp_value_0: ::core::ffi::c_double = 0.;
    let mut _pv_8: uint32_t = 0;
    enum C2Rust_Block_34 {
        S_0,
        S_2,
        S_4,
        S_6,
        S_8,
        S_18,
        S_24,
        S_26,
        S_28,
        S_30,
        S_32,
        S_38,
        S_40,
        S_42,
        S_52,
        S_54,
        S_56,
        S_62,
        S_64,
        S_66,
        S_68,
        S_70,
        S_72,
        S_74,
        S_76,
        S_78,
        S_84,
        S_86,
        S_88,
        S_98,
        S_100,
        S_102,
        S_108,
        S_117,
        S_119,
        S_121,
        S_123,
        S_125,
        S_127,
        S_129,
        S_131,
        S_133,
        S_135,
        S_137,
        S_139,
        S_141,
        S_143,
        S_149,
        S_151,
        S_153,
        S_159,
        S_161,
        S_163,
        S_165,
        S_167,
        S_169,
        S_171,
        S_173,
        S_175,
        S_177,
        S_179,
        S_185,
        S_187,
        S_189,
        S_195,
        S_201,
        S_203,
        S_205,
        S_207,
        S_209,
        S_211,
        S_220,
        S_222,
        S_224,
        S_226,
        S_232,
        S_234,
        S_236,
        S_242,
        S_244,
        S_246,
        S_248,
        S_250,
        S_259,
        S_265,
        S_267,
        S_269,
        S_271,
        S_273,
        S_275,
        S_277,
        S_279,
        S_281,
        S_283,
        S_285,
        S_287,
        S_289,
        S_291,
        S_293,
        S_295,
        S_297,
        S_299,
        S_301,
        S_303,
        S_309,
        S_311,
        S_313,
        S_319,
        S_325,
        S_327,
        S_329,
        S_331,
        S_333,
        S_335,
        S_344,
        S_346,
        S_348,
        S_354,
        S_356,
        S_358,
        S_360,
        S_362,
        S_370,
        S_376,
        S_378,
        S_380,
        S_382,
        S_384,
        S_393,
        S_395,
        S_397,
        S_399,
        S_401,
        S_403,
        S_405,
        S_407,
        S_409,
        S_411,
        S_413,
        S_415,
        S_417,
        S_423,
        S_425,
        S_427,
        S_433,
        S_435,
        S_437,
        S_439,
        S_441,
        S_443,
        S_445,
        S_447,
        S_449,
        S_451,
        S_453,
        S_459,
        S_461,
        S_463,
        S_469,
        S_475,
        S_477,
        S_479,
        S_481,
        S_483,
        S_485,
        S_494,
        S_496,
        S_498,
        S_500,
        S_506,
        S_508,
        S_510,
        S_516,
        S_518,
        S_520,
        S_522,
        S_524,
        S_533,
        S_539,
        S_541,
        S_543,
        S_545,
        S_547,
        S_549,
        S_551,
        S_553,
        S_555,
        S_557,
        S_559,
        S_561,
        S_563,
        S_565,
        S_567,
        S_569,
        S_571,
        S_573,
        S_575,
        S_577,
        S_583,
        S_585,
        S_587,
        S_593,
        S_599,
        S_601,
        S_603,
        S_605,
        S_607,
        S_609,
        S_618,
        S_620,
        S_622,
        S_628,
        S_638,
        S_640,
        S_650,
        S_652,
        S_662,
        S_664,
        S_674,
        S_676,
        S_682,
        S_684,
        S_686,
        S_688,
        S_690,
        S_692,
        S_694,
    }
    let mut c2rust_current_block_34: C2Rust_Block_34;
    c2rust_current_block_34 = C2Rust_Block_34::S_0;
    loop {
        match c2rust_current_block_34 {
            C2Rust_Block_34::S_0 => {
                {
                    ebp = 0 as uint32_t;
                    c2rust_current_block_34 = C2Rust_Block_34::S_2;
                };
                {
                    ebp = (*__gamepkg_tls_g_ebp);
                    c2rust_current_block_34 = C2Rust_Block_34::S_4;
                };
                {
                    _flags = 0 as ::core::ffi::c_int;
                    c2rust_current_block_34 = C2Rust_Block_34::S_6;
                };
                {
                    _fa = 0 as uint32_t;
                    _fb = 0 as uint32_t;
                    c2rust_current_block_34 = C2Rust_Block_34::S_8;
                };
                {
                    _fas = 0 as int32_t;
                    _fbs = 0 as int32_t;
                    c2rust_current_block_34 = C2Rust_Block_34::S_18;
                };
                {
                    ebp = (*__gamepkg_tls_g_seh_ebp);
                    c2rust_current_block_34 = C2Rust_Block_34::S_24;
                };
                {
                    _fb = 0x48 as ::core::ffi::c_int as uint32_t
                        & 0xffffffff as uint32_t;
                    c2rust_current_block_34 = C2Rust_Block_34::S_26;
                };
                {
                    _fbs = _fb as int32_t;
                    c2rust_current_block_34 = C2Rust_Block_34::S_28;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(0x48 as uint32_t);
                    c2rust_current_block_34 = C2Rust_Block_34::S_30;
                };
                {
                    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                    c2rust_current_block_34 = C2Rust_Block_34::S_32;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_34 = C2Rust_Block_34::S_38;
                };
                {
                    _pv = (*__gamepkg_tls_g_ebx);
                    c2rust_current_block_34 = C2Rust_Block_34::S_40;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_34 = C2Rust_Block_34::S_42;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv,
                    );
                    c2rust_current_block_34 = C2Rust_Block_34::S_52;
                };
                {
                    _pv_0 = ebp;
                    c2rust_current_block_34 = C2Rust_Block_34::S_54;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_34 = C2Rust_Block_34::S_56;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_0,
                    );
                    c2rust_current_block_34 = C2Rust_Block_34::S_62;
                };
                {
                    ebp = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x54 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_34 = C2Rust_Block_34::S_64;
                };
                {
                    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (ebp.wrapping_add(8 as uint32_t) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_34 = C2Rust_Block_34::S_66;
                };
                {
                    (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                    c2rust_current_block_34 = C2Rust_Block_34::S_68;
                };
                {
                    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                    c2rust_current_block_34 = C2Rust_Block_34::S_70;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_34 = C2Rust_Block_34::S_72;
                };
                {
                    _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                    c2rust_current_block_34 = C2Rust_Block_34::S_74;
                };
                {
                    _fb = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                    c2rust_current_block_34 = C2Rust_Block_34::S_76;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_34 = C2Rust_Block_34::S_78;
                };
                {
                    _fbs = _fb as int32_t;
                    c2rust_current_block_34 = C2Rust_Block_34::S_84;
                };
                {
                    _pv_1 = (*__gamepkg_tls_g_esi);
                    c2rust_current_block_34 = C2Rust_Block_34::S_86;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_34 = C2Rust_Block_34::S_88;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_1,
                    );
                    c2rust_current_block_34 = C2Rust_Block_34::S_98;
                };
                {
                    _pv_2 = (*__gamepkg_tls_g_edi);
                    c2rust_current_block_34 = C2Rust_Block_34::S_100;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_34 = C2Rust_Block_34::S_102;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_2,
                    );
                    c2rust_current_block_34 = C2Rust_Block_34::S_108;
                };
                {
                    if _fa != _fb {
                        c2rust_current_block_34 = C2Rust_Block_34::S_370;
                    } else {
                        c2rust_current_block_34 = C2Rust_Block_34::S_117;
                    }
                };
            }
            C2Rust_Block_34::S_117 => {
                {
                    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b16bc as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_34 = C2Rust_Block_34::S_119;
                };
                {
                    (*__gamepkg_tls_g_xmm1) = XMM_ZERO();
                    c2rust_current_block_34 = C2Rust_Block_34::S_121;
                };
                {
                    (*__gamepkg_tls_g_xmm2) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b16c0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_34 = C2Rust_Block_34::S_123;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x10 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm0).f[0usize],
                    );
                    c2rust_current_block_34 = C2Rust_Block_34::S_125;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x14 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm0).f[0usize],
                    );
                    c2rust_current_block_34 = C2Rust_Block_34::S_127;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x18 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm0).f[0usize],
                    );
                    c2rust_current_block_34 = C2Rust_Block_34::S_129;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x38 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm0).f[0usize],
                    );
                    c2rust_current_block_34 = C2Rust_Block_34::S_131;
                };
                {
                    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b16b8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_34 = C2Rust_Block_34::S_133;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x28 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_eax),
                    );
                    c2rust_current_block_34 = C2Rust_Block_34::S_135;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x48 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm0).f[0usize],
                    );
                    c2rust_current_block_34 = C2Rust_Block_34::S_137;
                };
                {
                    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b16b4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_34 = C2Rust_Block_34::S_139;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x54 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_34 = C2Rust_Block_34::S_141;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x55 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_34 = C2Rust_Block_34::S_143;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x56 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_34 = C2Rust_Block_34::S_149;
                };
                {
                    _pv_3 = (*__gamepkg_tls_g_eax);
                    c2rust_current_block_34 = C2Rust_Block_34::S_151;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_34 = C2Rust_Block_34::S_153;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_3,
                    );
                    c2rust_current_block_34 = C2Rust_Block_34::S_159;
                };
                {
                    (*__gamepkg_tls_g_ebx) = 0x39c338 as uint32_t;
                    c2rust_current_block_34 = C2Rust_Block_34::S_161;
                };
                {
                    (*__gamepkg_tls_g_eax) = 0x40b7f4 as uint32_t;
                    c2rust_current_block_34 = C2Rust_Block_34::S_163;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x20 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm1).f[0usize],
                    );
                    c2rust_current_block_34 = C2Rust_Block_34::S_165;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x24 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm1).f[0usize],
                    );
                    c2rust_current_block_34 = C2Rust_Block_34::S_167;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x28 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm1).f[0usize],
                    );
                    c2rust_current_block_34 = C2Rust_Block_34::S_169;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x30 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm2).f[0usize],
                    );
                    c2rust_current_block_34 = C2Rust_Block_34::S_171;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x34 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm2).f[0usize],
                    );
                    c2rust_current_block_34 = C2Rust_Block_34::S_173;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x38 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm2).f[0usize],
                    );
                    c2rust_current_block_34 = C2Rust_Block_34::S_175;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x48 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm1).f[0usize],
                    );
                    c2rust_current_block_34 = C2Rust_Block_34::S_177;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x50 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm0).f[0usize],
                    );
                    c2rust_current_block_34 = C2Rust_Block_34::S_179;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x54 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        0xffffffff as ::core::ffi::c_uint as uint32_t,
                    );
                    c2rust_current_block_34 = C2Rust_Block_34::S_185;
                };
                {
                    _pv_4 = 0x141dd1 as ::core::ffi::c_uint as uint32_t;
                    c2rust_current_block_34 = C2Rust_Block_34::S_187;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_34 = C2Rust_Block_34::S_189;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_4,
                    );
                    c2rust_current_block_34 = C2Rust_Block_34::S_195;
                };
                {
                    sub_001C9E50();
                    c2rust_current_block_34 = C2Rust_Block_34::S_201;
                };
                {
                    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                    c2rust_current_block_34 = C2Rust_Block_34::S_203;
                };
                {
                    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                    c2rust_current_block_34 = C2Rust_Block_34::S_205;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_34 = C2Rust_Block_34::S_207;
                };
                {
                    _fbs = _fb as int32_t;
                    c2rust_current_block_34 = C2Rust_Block_34::S_209;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x28 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_eax),
                    );
                    c2rust_current_block_34 = C2Rust_Block_34::S_211;
                };
                {
                    if _fa == _fb {
                        c2rust_current_block_34 = C2Rust_Block_34::S_354;
                    } else {
                        c2rust_current_block_34 = C2Rust_Block_34::S_220;
                    }
                };
            }
            C2Rust_Block_34::S_220 => {
                {
                    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b168c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_34 = C2Rust_Block_34::S_222;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x2c as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm0).f[0usize],
                    );
                    c2rust_current_block_34 = C2Rust_Block_34::S_224;
                };
                {
                    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_eax).wrapping_add(8 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_34 = C2Rust_Block_34::S_226;
                };
                {
                    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_eax).wrapping_add(0x10 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_34 = C2Rust_Block_34::S_232;
                };
                {
                    _fp_value = ::core::ptr::read_volatile::<
                        int32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            int32_t,
                        >(
                            ((*__gamepkg_tls_g_eax).wrapping_add(0x10 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ) as ::core::ffi::c_double;
                    c2rust_current_block_34 = C2Rust_Block_34::S_234;
                };
                {
                    (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top)
                        as ::core::ffi::c_uint)
                        .wrapping_add(7 as ::core::ffi::c_uint)
                        & 7 as ::core::ffi::c_uint) as ::core::ffi::c_int;
                    c2rust_current_block_34 = C2Rust_Block_34::S_236;
                };
                {
                    (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = _fp_value;
                    c2rust_current_block_34 = C2Rust_Block_34::S_242;
                };
                {
                    _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                    c2rust_current_block_34 = C2Rust_Block_34::S_244;
                };
                {
                    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                    c2rust_current_block_34 = C2Rust_Block_34::S_246;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_34 = C2Rust_Block_34::S_248;
                };
                {
                    _fbs = _fb as int32_t;
                    c2rust_current_block_34 = C2Rust_Block_34::S_250;
                };
                {
                    if if if ::core::mem::size_of::<int32_t>()
                        < ::core::mem::size_of::<int32_t>()
                    {
                        ::core::mem::size_of::<int32_t>()
                    } else {
                        ::core::mem::size_of::<int32_t>()
                    } == 1usize
                    {
                        _fas as uint32_t as uint8_t as int8_t as int32_t
                    } else if if ::core::mem::size_of::<int32_t>()
                        < ::core::mem::size_of::<int32_t>()
                    {
                        ::core::mem::size_of::<int32_t>()
                    } else {
                        ::core::mem::size_of::<int32_t>()
                    } == 2usize
                    {
                        _fas as uint32_t as uint16_t as int16_t as int32_t
                    } else {
                        _fas as uint32_t as int32_t
                    }
                        >= if if ::core::mem::size_of::<int32_t>()
                            < ::core::mem::size_of::<int32_t>()
                        {
                            ::core::mem::size_of::<int32_t>()
                        } else {
                            ::core::mem::size_of::<int32_t>()
                        } == 1usize
                        {
                            _fbs as uint32_t as uint8_t as int8_t as int32_t
                        } else if if ::core::mem::size_of::<int32_t>()
                            < ::core::mem::size_of::<int32_t>()
                        {
                            ::core::mem::size_of::<int32_t>()
                        } else {
                            ::core::mem::size_of::<int32_t>()
                        } == 2usize
                        {
                            _fbs as uint32_t as uint16_t as int16_t as int32_t
                        } else {
                            _fbs as uint32_t as int32_t
                        }
                    {
                        c2rust_current_block_34 = C2Rust_Block_34::S_265;
                    } else {
                        c2rust_current_block_34 = C2Rust_Block_34::S_259;
                    }
                };
            }
            C2Rust_Block_34::S_259 => {
                (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = if (*__gamepkg_tls_g_fp_control_word)
                    as ::core::ffi::c_uint & 0x300 as ::core::ffi::c_uint != 0
                {
                    (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                        + ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b16a8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ) as ::core::ffi::c_double
                } else {
                    recomp_fp_round24(
                        (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                            + ::core::ptr::read_volatile::<
                                ::core::ffi::c_float,
                            >(
                                ::core::ptr::with_exposed_provenance_mut::<
                                    ::core::ffi::c_float,
                                >(
                                    (0x3b16a8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                                ),
                            ) as ::core::ffi::c_double,
                    )
                };
                c2rust_current_block_34 = C2Rust_Block_34::S_265;
            }
            C2Rust_Block_34::S_265 => {
                {
                    (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x73c610 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_34 = C2Rust_Block_34::S_267;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x34 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                            as ::core::ffi::c_float,
                    );
                    c2rust_current_block_34 = C2Rust_Block_34::S_269;
                };
                {
                    (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top)
                        as ::core::ffi::c_uint)
                        .wrapping_add(1 as ::core::ffi::c_uint)
                        & 7 as ::core::ffi::c_uint) as ::core::ffi::c_int;
                    c2rust_current_block_34 = C2Rust_Block_34::S_271;
                };
                {
                    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
                        & 0xffffff00 as uint32_t
                        | 1 as ::core::ffi::c_int as uint8_t as uint32_t;
                    c2rust_current_block_34 = C2Rust_Block_34::S_273;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x54 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_34 = C2Rust_Block_34::S_275;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x55 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_34 = C2Rust_Block_34::S_277;
                };
                {
                    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_edx).wrapping_add(0x204 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_34 = C2Rust_Block_34::S_279;
                };
                {
                    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                ((*__gamepkg_tls_g_eax).wrapping_add(0x30 as uint32_t)
                                    as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_34 = C2Rust_Block_34::S_281;
                };
                {
                    _fb = 0x30 as ::core::ffi::c_int as uint32_t
                        & 0xffffffff as uint32_t;
                    c2rust_current_block_34 = C2Rust_Block_34::S_283;
                };
                {
                    _fbs = _fb as int32_t;
                    c2rust_current_block_34 = C2Rust_Block_34::S_285;
                };
                {
                    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
                        .wrapping_add(0x30 as uint32_t);
                    c2rust_current_block_34 = C2Rust_Block_34::S_287;
                };
                {
                    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                    c2rust_current_block_34 = C2Rust_Block_34::S_289;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_34 = C2Rust_Block_34::S_291;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x10 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm0).f[0usize],
                    );
                    c2rust_current_block_34 = C2Rust_Block_34::S_293;
                };
                {
                    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                ((*__gamepkg_tls_g_eax).wrapping_add(4 as uint32_t)
                                    as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_34 = C2Rust_Block_34::S_295;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x14 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm0).f[0usize],
                    );
                    c2rust_current_block_34 = C2Rust_Block_34::S_297;
                };
                {
                    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                ((*__gamepkg_tls_g_eax).wrapping_add(8 as uint32_t)
                                    as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_34 = C2Rust_Block_34::S_299;
                };
                {
                    (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_esp)
                        .wrapping_add(0x10 as uint32_t);
                    c2rust_current_block_34 = C2Rust_Block_34::S_301;
                };
                {
                    (*__gamepkg_tls_g_esi) = 0x40b844 as uint32_t;
                    c2rust_current_block_34 = C2Rust_Block_34::S_303;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x18 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm0).f[0usize],
                    );
                    c2rust_current_block_34 = C2Rust_Block_34::S_309;
                };
                {
                    _pv_5 = 0x141e46 as ::core::ffi::c_uint as uint32_t;
                    c2rust_current_block_34 = C2Rust_Block_34::S_311;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_34 = C2Rust_Block_34::S_313;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_5,
                    );
                    c2rust_current_block_34 = C2Rust_Block_34::S_319;
                };
                {
                    sub_001CD8D0();
                    c2rust_current_block_34 = C2Rust_Block_34::S_325;
                };
                {
                    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                    c2rust_current_block_34 = C2Rust_Block_34::S_327;
                };
                {
                    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                    c2rust_current_block_34 = C2Rust_Block_34::S_329;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_34 = C2Rust_Block_34::S_331;
                };
                {
                    _fbs = _fb as int32_t;
                    c2rust_current_block_34 = C2Rust_Block_34::S_333;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (ebp.wrapping_add(8 as uint32_t) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_eax),
                    );
                    c2rust_current_block_34 = C2Rust_Block_34::S_335;
                };
                {
                    if _fa == _fb {
                        c2rust_current_block_34 = C2Rust_Block_34::S_354;
                    } else {
                        c2rust_current_block_34 = C2Rust_Block_34::S_344;
                    }
                };
            }
            C2Rust_Block_34::S_344 => {
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            ((*__gamepkg_tls_g_eax).wrapping_add(0x37 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (::core::ptr::read_volatile::<
                            uint8_t,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                uint8_t,
                            >(
                                ((*__gamepkg_tls_g_eax).wrapping_add(0x37 as uint32_t)
                                    as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ) as ::core::ffi::c_int | 0x10 as ::core::ffi::c_int) as uint8_t,
                    );
                    c2rust_current_block_34 = C2Rust_Block_34::S_346;
                };
                {
                    _fa = ::core::ptr::read_volatile::<
                        uint8_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            ((*__gamepkg_tls_g_eax).wrapping_add(0x37 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ) as uint32_t & 0xff as uint32_t;
                    c2rust_current_block_34 = C2Rust_Block_34::S_348;
                };
                {
                    _fas = _fa as int8_t as int32_t;
                    c2rust_current_block_34 = C2Rust_Block_34::S_354;
                };
            }
            C2Rust_Block_34::S_354 => {
                {
                    (*__gamepkg_tls_g_xmm0) = XMM_ZERO();
                    c2rust_current_block_34 = C2Rust_Block_34::S_356;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (ebp.wrapping_add(0x1c as uint32_t) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm0).f[0usize],
                    );
                    c2rust_current_block_34 = C2Rust_Block_34::S_358;
                };
                {
                    (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                    c2rust_current_block_34 = C2Rust_Block_34::S_360;
                };
                {
                    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                    c2rust_current_block_34 = C2Rust_Block_34::S_362;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_34 = C2Rust_Block_34::S_376;
                };
            }
            C2Rust_Block_34::S_370 => {
                (*__gamepkg_tls_g_xmm0) = XMM_ZERO();
                c2rust_current_block_34 = C2Rust_Block_34::S_376;
            }
            C2Rust_Block_34::S_376 => {
                {
                    _fa = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (ebp.wrapping_add(0xc as uint32_t) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ) & 0xffffffff as uint32_t;
                    c2rust_current_block_34 = C2Rust_Block_34::S_378;
                };
                {
                    _fb = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                    c2rust_current_block_34 = C2Rust_Block_34::S_380;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_34 = C2Rust_Block_34::S_382;
                };
                {
                    _fbs = _fb as int32_t;
                    c2rust_current_block_34 = C2Rust_Block_34::S_384;
                };
                {
                    if _fa != _fb {
                        c2rust_current_block_34 = C2Rust_Block_34::S_638;
                    } else {
                        c2rust_current_block_34 = C2Rust_Block_34::S_393;
                    }
                };
            }
            C2Rust_Block_34::S_393 => {
                {
                    (*__gamepkg_tls_g_xmm1) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b16bc as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_34 = C2Rust_Block_34::S_395;
                };
                {
                    (*__gamepkg_tls_g_xmm2) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b16c0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_34 = C2Rust_Block_34::S_397;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x1c as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm0).f[0usize],
                    );
                    c2rust_current_block_34 = C2Rust_Block_34::S_399;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x20 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm0).f[0usize],
                    );
                    c2rust_current_block_34 = C2Rust_Block_34::S_401;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x24 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm0).f[0usize],
                    );
                    c2rust_current_block_34 = C2Rust_Block_34::S_403;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x44 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm0).f[0usize],
                    );
                    c2rust_current_block_34 = C2Rust_Block_34::S_405;
                };
                {
                    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b16b8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_34 = C2Rust_Block_34::S_407;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x28 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_eax),
                    );
                    c2rust_current_block_34 = C2Rust_Block_34::S_409;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x48 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm0).f[0usize],
                    );
                    c2rust_current_block_34 = C2Rust_Block_34::S_411;
                };
                {
                    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b16b4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_34 = C2Rust_Block_34::S_413;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x54 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_34 = C2Rust_Block_34::S_415;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x55 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_34 = C2Rust_Block_34::S_417;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x56 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_34 = C2Rust_Block_34::S_423;
                };
                {
                    _pv_6 = (*__gamepkg_tls_g_eax);
                    c2rust_current_block_34 = C2Rust_Block_34::S_425;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_34 = C2Rust_Block_34::S_427;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_6,
                    );
                    c2rust_current_block_34 = C2Rust_Block_34::S_433;
                };
                {
                    (*__gamepkg_tls_g_ebx) = 0x39c340 as uint32_t;
                    c2rust_current_block_34 = C2Rust_Block_34::S_435;
                };
                {
                    (*__gamepkg_tls_g_eax) = 0x40b7f4 as uint32_t;
                    c2rust_current_block_34 = C2Rust_Block_34::S_437;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x14 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm1).f[0usize],
                    );
                    c2rust_current_block_34 = C2Rust_Block_34::S_439;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x18 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm1).f[0usize],
                    );
                    c2rust_current_block_34 = C2Rust_Block_34::S_441;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x1c as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm1).f[0usize],
                    );
                    c2rust_current_block_34 = C2Rust_Block_34::S_443;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x30 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm2).f[0usize],
                    );
                    c2rust_current_block_34 = C2Rust_Block_34::S_445;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x34 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm2).f[0usize],
                    );
                    c2rust_current_block_34 = C2Rust_Block_34::S_447;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x38 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm2).f[0usize],
                    );
                    c2rust_current_block_34 = C2Rust_Block_34::S_449;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x3c as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm1).f[0usize],
                    );
                    c2rust_current_block_34 = C2Rust_Block_34::S_451;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x50 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm0).f[0usize],
                    );
                    c2rust_current_block_34 = C2Rust_Block_34::S_453;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x54 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        0xffffffff as ::core::ffi::c_uint as uint32_t,
                    );
                    c2rust_current_block_34 = C2Rust_Block_34::S_459;
                };
                {
                    _pv_7 = 0x141eff as ::core::ffi::c_uint as uint32_t;
                    c2rust_current_block_34 = C2Rust_Block_34::S_461;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_34 = C2Rust_Block_34::S_463;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_7,
                    );
                    c2rust_current_block_34 = C2Rust_Block_34::S_469;
                };
                {
                    sub_001C9E50();
                    c2rust_current_block_34 = C2Rust_Block_34::S_475;
                };
                {
                    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                    c2rust_current_block_34 = C2Rust_Block_34::S_477;
                };
                {
                    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                    c2rust_current_block_34 = C2Rust_Block_34::S_479;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_34 = C2Rust_Block_34::S_481;
                };
                {
                    _fbs = _fb as int32_t;
                    c2rust_current_block_34 = C2Rust_Block_34::S_483;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x28 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_eax),
                    );
                    c2rust_current_block_34 = C2Rust_Block_34::S_485;
                };
                {
                    if _fa == _fb {
                        c2rust_current_block_34 = C2Rust_Block_34::S_628;
                    } else {
                        c2rust_current_block_34 = C2Rust_Block_34::S_494;
                    }
                };
            }
            C2Rust_Block_34::S_494 => {
                {
                    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b168c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_34 = C2Rust_Block_34::S_496;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x2c as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm0).f[0usize],
                    );
                    c2rust_current_block_34 = C2Rust_Block_34::S_498;
                };
                {
                    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_eax).wrapping_add(8 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_34 = C2Rust_Block_34::S_500;
                };
                {
                    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_eax).wrapping_add(0x10 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_34 = C2Rust_Block_34::S_506;
                };
                {
                    _fp_value_0 = ::core::ptr::read_volatile::<
                        int32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            int32_t,
                        >(
                            ((*__gamepkg_tls_g_eax).wrapping_add(0x10 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ) as ::core::ffi::c_double;
                    c2rust_current_block_34 = C2Rust_Block_34::S_508;
                };
                {
                    (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top)
                        as ::core::ffi::c_uint)
                        .wrapping_add(7 as ::core::ffi::c_uint)
                        & 7 as ::core::ffi::c_uint) as ::core::ffi::c_int;
                    c2rust_current_block_34 = C2Rust_Block_34::S_510;
                };
                {
                    (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = _fp_value_0;
                    c2rust_current_block_34 = C2Rust_Block_34::S_516;
                };
                {
                    _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                    c2rust_current_block_34 = C2Rust_Block_34::S_518;
                };
                {
                    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                    c2rust_current_block_34 = C2Rust_Block_34::S_520;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_34 = C2Rust_Block_34::S_522;
                };
                {
                    _fbs = _fb as int32_t;
                    c2rust_current_block_34 = C2Rust_Block_34::S_524;
                };
                {
                    if if if ::core::mem::size_of::<int32_t>()
                        < ::core::mem::size_of::<int32_t>()
                    {
                        ::core::mem::size_of::<int32_t>()
                    } else {
                        ::core::mem::size_of::<int32_t>()
                    } == 1usize
                    {
                        _fas as uint32_t as uint8_t as int8_t as int32_t
                    } else if if ::core::mem::size_of::<int32_t>()
                        < ::core::mem::size_of::<int32_t>()
                    {
                        ::core::mem::size_of::<int32_t>()
                    } else {
                        ::core::mem::size_of::<int32_t>()
                    } == 2usize
                    {
                        _fas as uint32_t as uint16_t as int16_t as int32_t
                    } else {
                        _fas as uint32_t as int32_t
                    }
                        >= if if ::core::mem::size_of::<int32_t>()
                            < ::core::mem::size_of::<int32_t>()
                        {
                            ::core::mem::size_of::<int32_t>()
                        } else {
                            ::core::mem::size_of::<int32_t>()
                        } == 1usize
                        {
                            _fbs as uint32_t as uint8_t as int8_t as int32_t
                        } else if if ::core::mem::size_of::<int32_t>()
                            < ::core::mem::size_of::<int32_t>()
                        {
                            ::core::mem::size_of::<int32_t>()
                        } else {
                            ::core::mem::size_of::<int32_t>()
                        } == 2usize
                        {
                            _fbs as uint32_t as uint16_t as int16_t as int32_t
                        } else {
                            _fbs as uint32_t as int32_t
                        }
                    {
                        c2rust_current_block_34 = C2Rust_Block_34::S_539;
                    } else {
                        c2rust_current_block_34 = C2Rust_Block_34::S_533;
                    }
                };
            }
            C2Rust_Block_34::S_533 => {
                (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = if (*__gamepkg_tls_g_fp_control_word)
                    as ::core::ffi::c_uint & 0x300 as ::core::ffi::c_uint != 0
                {
                    (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                        + ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b16a8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ) as ::core::ffi::c_double
                } else {
                    recomp_fp_round24(
                        (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                            + ::core::ptr::read_volatile::<
                                ::core::ffi::c_float,
                            >(
                                ::core::ptr::with_exposed_provenance_mut::<
                                    ::core::ffi::c_float,
                                >(
                                    (0x3b16a8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                                ),
                            ) as ::core::ffi::c_double,
                    )
                };
                c2rust_current_block_34 = C2Rust_Block_34::S_539;
            }
            C2Rust_Block_34::S_539 => {
                {
                    (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x73c610 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_34 = C2Rust_Block_34::S_541;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x34 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                            as ::core::ffi::c_float,
                    );
                    c2rust_current_block_34 = C2Rust_Block_34::S_543;
                };
                {
                    (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top)
                        as ::core::ffi::c_uint)
                        .wrapping_add(1 as ::core::ffi::c_uint)
                        & 7 as ::core::ffi::c_uint) as ::core::ffi::c_int;
                    c2rust_current_block_34 = C2Rust_Block_34::S_545;
                };
                {
                    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
                        & 0xffffff00 as uint32_t
                        | 1 as ::core::ffi::c_int as uint8_t as uint32_t;
                    c2rust_current_block_34 = C2Rust_Block_34::S_547;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x54 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_34 = C2Rust_Block_34::S_549;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x55 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_34 = C2Rust_Block_34::S_551;
                };
                {
                    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_edx).wrapping_add(0x204 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_34 = C2Rust_Block_34::S_553;
                };
                {
                    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                ((*__gamepkg_tls_g_eax).wrapping_add(0x30 as uint32_t)
                                    as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_34 = C2Rust_Block_34::S_555;
                };
                {
                    _fb = 0x30 as ::core::ffi::c_int as uint32_t
                        & 0xffffffff as uint32_t;
                    c2rust_current_block_34 = C2Rust_Block_34::S_557;
                };
                {
                    _fbs = _fb as int32_t;
                    c2rust_current_block_34 = C2Rust_Block_34::S_559;
                };
                {
                    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
                        .wrapping_add(0x30 as uint32_t);
                    c2rust_current_block_34 = C2Rust_Block_34::S_561;
                };
                {
                    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                    c2rust_current_block_34 = C2Rust_Block_34::S_563;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_34 = C2Rust_Block_34::S_565;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x10 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm0).f[0usize],
                    );
                    c2rust_current_block_34 = C2Rust_Block_34::S_567;
                };
                {
                    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                ((*__gamepkg_tls_g_eax).wrapping_add(4 as uint32_t)
                                    as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_34 = C2Rust_Block_34::S_569;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x14 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm0).f[0usize],
                    );
                    c2rust_current_block_34 = C2Rust_Block_34::S_571;
                };
                {
                    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                ((*__gamepkg_tls_g_eax).wrapping_add(8 as uint32_t)
                                    as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_34 = C2Rust_Block_34::S_573;
                };
                {
                    (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_esp)
                        .wrapping_add(0x10 as uint32_t);
                    c2rust_current_block_34 = C2Rust_Block_34::S_575;
                };
                {
                    (*__gamepkg_tls_g_esi) = 0x40b844 as uint32_t;
                    c2rust_current_block_34 = C2Rust_Block_34::S_577;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x18 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm0).f[0usize],
                    );
                    c2rust_current_block_34 = C2Rust_Block_34::S_583;
                };
                {
                    _pv_8 = 0x141f74 as ::core::ffi::c_uint as uint32_t;
                    c2rust_current_block_34 = C2Rust_Block_34::S_585;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_34 = C2Rust_Block_34::S_587;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_8,
                    );
                    c2rust_current_block_34 = C2Rust_Block_34::S_593;
                };
                {
                    sub_001CD8D0();
                    c2rust_current_block_34 = C2Rust_Block_34::S_599;
                };
                {
                    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                    c2rust_current_block_34 = C2Rust_Block_34::S_601;
                };
                {
                    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                    c2rust_current_block_34 = C2Rust_Block_34::S_603;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_34 = C2Rust_Block_34::S_605;
                };
                {
                    _fbs = _fb as int32_t;
                    c2rust_current_block_34 = C2Rust_Block_34::S_607;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (ebp.wrapping_add(0xc as uint32_t) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_eax),
                    );
                    c2rust_current_block_34 = C2Rust_Block_34::S_609;
                };
                {
                    if _fa == _fb {
                        c2rust_current_block_34 = C2Rust_Block_34::S_628;
                    } else {
                        c2rust_current_block_34 = C2Rust_Block_34::S_618;
                    }
                };
            }
            C2Rust_Block_34::S_618 => {
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            ((*__gamepkg_tls_g_eax).wrapping_add(0x37 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (::core::ptr::read_volatile::<
                            uint8_t,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                uint8_t,
                            >(
                                ((*__gamepkg_tls_g_eax).wrapping_add(0x37 as uint32_t)
                                    as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ) as ::core::ffi::c_int | 0x10 as ::core::ffi::c_int) as uint8_t,
                    );
                    c2rust_current_block_34 = C2Rust_Block_34::S_620;
                };
                {
                    _fa = ::core::ptr::read_volatile::<
                        uint8_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            ((*__gamepkg_tls_g_eax).wrapping_add(0x37 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ) as uint32_t & 0xff as uint32_t;
                    c2rust_current_block_34 = C2Rust_Block_34::S_622;
                };
                {
                    _fas = _fa as int8_t as int32_t;
                    c2rust_current_block_34 = C2Rust_Block_34::S_628;
                };
            }
            C2Rust_Block_34::S_628 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(0x48 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    0xe10 as uint32_t,
                );
                c2rust_current_block_34 = C2Rust_Block_34::S_638;
            }
            C2Rust_Block_34::S_638 => {
                {
                    (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_34 = C2Rust_Block_34::S_640;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_add(4 as uint32_t);
                    c2rust_current_block_34 = C2Rust_Block_34::S_650;
                };
                {
                    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_34 = C2Rust_Block_34::S_652;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_add(4 as uint32_t);
                    c2rust_current_block_34 = C2Rust_Block_34::S_662;
                };
                {
                    ebp = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_34 = C2Rust_Block_34::S_664;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_add(4 as uint32_t);
                    c2rust_current_block_34 = C2Rust_Block_34::S_674;
                };
                {
                    (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_34 = C2Rust_Block_34::S_676;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_add(4 as uint32_t);
                    c2rust_current_block_34 = C2Rust_Block_34::S_682;
                };
                {
                    _fb = 0x48 as ::core::ffi::c_int as uint32_t
                        & 0xffffffff as uint32_t;
                    c2rust_current_block_34 = C2Rust_Block_34::S_684;
                };
                {
                    _fbs = _fb as int32_t;
                    c2rust_current_block_34 = C2Rust_Block_34::S_686;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_add(0x48 as uint32_t);
                    c2rust_current_block_34 = C2Rust_Block_34::S_688;
                };
                {
                    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                    c2rust_current_block_34 = C2Rust_Block_34::S_690;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_34 = C2Rust_Block_34::S_692;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_add(8 as uint32_t);
                    c2rust_current_block_34 = C2Rust_Block_34::S_694;
                };
                return;
            }
            C2Rust_Block_34::S_100
            | C2Rust_Block_34::S_102
            | C2Rust_Block_34::S_108
            | C2Rust_Block_34::S_119
            | C2Rust_Block_34::S_121
            | C2Rust_Block_34::S_123
            | C2Rust_Block_34::S_125
            | C2Rust_Block_34::S_127
            | C2Rust_Block_34::S_129
            | C2Rust_Block_34::S_131
            | C2Rust_Block_34::S_133
            | C2Rust_Block_34::S_135
            | C2Rust_Block_34::S_137
            | C2Rust_Block_34::S_139
            | C2Rust_Block_34::S_141
            | C2Rust_Block_34::S_143
            | C2Rust_Block_34::S_149
            | C2Rust_Block_34::S_151
            | C2Rust_Block_34::S_153
            | C2Rust_Block_34::S_159
            | C2Rust_Block_34::S_161
            | C2Rust_Block_34::S_163
            | C2Rust_Block_34::S_165
            | C2Rust_Block_34::S_167
            | C2Rust_Block_34::S_169
            | C2Rust_Block_34::S_171
            | C2Rust_Block_34::S_173
            | C2Rust_Block_34::S_175
            | C2Rust_Block_34::S_177
            | C2Rust_Block_34::S_179
            | C2Rust_Block_34::S_18
            | C2Rust_Block_34::S_185
            | C2Rust_Block_34::S_187
            | C2Rust_Block_34::S_189
            | C2Rust_Block_34::S_195
            | C2Rust_Block_34::S_2
            | C2Rust_Block_34::S_201
            | C2Rust_Block_34::S_203
            | C2Rust_Block_34::S_205
            | C2Rust_Block_34::S_207
            | C2Rust_Block_34::S_209
            | C2Rust_Block_34::S_211
            | C2Rust_Block_34::S_222
            | C2Rust_Block_34::S_224
            | C2Rust_Block_34::S_226
            | C2Rust_Block_34::S_232
            | C2Rust_Block_34::S_234
            | C2Rust_Block_34::S_236
            | C2Rust_Block_34::S_24
            | C2Rust_Block_34::S_242
            | C2Rust_Block_34::S_244
            | C2Rust_Block_34::S_246
            | C2Rust_Block_34::S_248
            | C2Rust_Block_34::S_250
            | C2Rust_Block_34::S_26
            | C2Rust_Block_34::S_267
            | C2Rust_Block_34::S_269
            | C2Rust_Block_34::S_271
            | C2Rust_Block_34::S_273
            | C2Rust_Block_34::S_275
            | C2Rust_Block_34::S_277
            | C2Rust_Block_34::S_279
            | C2Rust_Block_34::S_28
            | C2Rust_Block_34::S_281
            | C2Rust_Block_34::S_283
            | C2Rust_Block_34::S_285
            | C2Rust_Block_34::S_287
            | C2Rust_Block_34::S_289
            | C2Rust_Block_34::S_291
            | C2Rust_Block_34::S_293
            | C2Rust_Block_34::S_295
            | C2Rust_Block_34::S_297
            | C2Rust_Block_34::S_299
            | C2Rust_Block_34::S_30
            | C2Rust_Block_34::S_301
            | C2Rust_Block_34::S_303
            | C2Rust_Block_34::S_309
            | C2Rust_Block_34::S_311
            | C2Rust_Block_34::S_313
            | C2Rust_Block_34::S_319
            | C2Rust_Block_34::S_32
            | C2Rust_Block_34::S_325
            | C2Rust_Block_34::S_327
            | C2Rust_Block_34::S_329
            | C2Rust_Block_34::S_331
            | C2Rust_Block_34::S_333
            | C2Rust_Block_34::S_335
            | C2Rust_Block_34::S_346
            | C2Rust_Block_34::S_348
            | C2Rust_Block_34::S_356
            | C2Rust_Block_34::S_358
            | C2Rust_Block_34::S_360
            | C2Rust_Block_34::S_362
            | C2Rust_Block_34::S_378
            | C2Rust_Block_34::S_38
            | C2Rust_Block_34::S_380
            | C2Rust_Block_34::S_382
            | C2Rust_Block_34::S_384
            | C2Rust_Block_34::S_395
            | C2Rust_Block_34::S_397
            | C2Rust_Block_34::S_399
            | C2Rust_Block_34::S_4
            | C2Rust_Block_34::S_40
            | C2Rust_Block_34::S_401
            | C2Rust_Block_34::S_403
            | C2Rust_Block_34::S_405
            | C2Rust_Block_34::S_407
            | C2Rust_Block_34::S_409
            | C2Rust_Block_34::S_411
            | C2Rust_Block_34::S_413
            | C2Rust_Block_34::S_415
            | C2Rust_Block_34::S_417
            | C2Rust_Block_34::S_42
            | C2Rust_Block_34::S_423
            | C2Rust_Block_34::S_425
            | C2Rust_Block_34::S_427
            | C2Rust_Block_34::S_433
            | C2Rust_Block_34::S_435
            | C2Rust_Block_34::S_437
            | C2Rust_Block_34::S_439
            | C2Rust_Block_34::S_441
            | C2Rust_Block_34::S_443
            | C2Rust_Block_34::S_445
            | C2Rust_Block_34::S_447
            | C2Rust_Block_34::S_449
            | C2Rust_Block_34::S_451
            | C2Rust_Block_34::S_453
            | C2Rust_Block_34::S_459
            | C2Rust_Block_34::S_461
            | C2Rust_Block_34::S_463
            | C2Rust_Block_34::S_469
            | C2Rust_Block_34::S_475
            | C2Rust_Block_34::S_477
            | C2Rust_Block_34::S_479
            | C2Rust_Block_34::S_481
            | C2Rust_Block_34::S_483
            | C2Rust_Block_34::S_485
            | C2Rust_Block_34::S_496
            | C2Rust_Block_34::S_498
            | C2Rust_Block_34::S_500
            | C2Rust_Block_34::S_506
            | C2Rust_Block_34::S_508
            | C2Rust_Block_34::S_510
            | C2Rust_Block_34::S_516
            | C2Rust_Block_34::S_518
            | C2Rust_Block_34::S_52
            | C2Rust_Block_34::S_520
            | C2Rust_Block_34::S_522
            | C2Rust_Block_34::S_524
            | C2Rust_Block_34::S_54
            | C2Rust_Block_34::S_541
            | C2Rust_Block_34::S_543
            | C2Rust_Block_34::S_545
            | C2Rust_Block_34::S_547
            | C2Rust_Block_34::S_549
            | C2Rust_Block_34::S_551
            | C2Rust_Block_34::S_553
            | C2Rust_Block_34::S_555
            | C2Rust_Block_34::S_557
            | C2Rust_Block_34::S_559
            | C2Rust_Block_34::S_56
            | C2Rust_Block_34::S_561
            | C2Rust_Block_34::S_563
            | C2Rust_Block_34::S_565
            | C2Rust_Block_34::S_567
            | C2Rust_Block_34::S_569
            | C2Rust_Block_34::S_571
            | C2Rust_Block_34::S_573
            | C2Rust_Block_34::S_575
            | C2Rust_Block_34::S_577
            | C2Rust_Block_34::S_583
            | C2Rust_Block_34::S_585
            | C2Rust_Block_34::S_587
            | C2Rust_Block_34::S_593
            | C2Rust_Block_34::S_599
            | C2Rust_Block_34::S_6
            | C2Rust_Block_34::S_601
            | C2Rust_Block_34::S_603
            | C2Rust_Block_34::S_605
            | C2Rust_Block_34::S_607
            | C2Rust_Block_34::S_609
            | C2Rust_Block_34::S_62
            | C2Rust_Block_34::S_620
            | C2Rust_Block_34::S_622
            | C2Rust_Block_34::S_64
            | C2Rust_Block_34::S_640
            | C2Rust_Block_34::S_650
            | C2Rust_Block_34::S_652
            | C2Rust_Block_34::S_66
            | C2Rust_Block_34::S_662
            | C2Rust_Block_34::S_664
            | C2Rust_Block_34::S_674
            | C2Rust_Block_34::S_676
            | C2Rust_Block_34::S_68
            | C2Rust_Block_34::S_682
            | C2Rust_Block_34::S_684
            | C2Rust_Block_34::S_686
            | C2Rust_Block_34::S_688
            | C2Rust_Block_34::S_690
            | C2Rust_Block_34::S_692
            | C2Rust_Block_34::S_694
            | C2Rust_Block_34::S_70
            | C2Rust_Block_34::S_72
            | C2Rust_Block_34::S_74
            | C2Rust_Block_34::S_76
            | C2Rust_Block_34::S_78
            | C2Rust_Block_34::S_8
            | C2Rust_Block_34::S_84
            | C2Rust_Block_34::S_86
            | C2Rust_Block_34::S_88
            | C2Rust_Block_34::S_98 => {
                unreachable!("GamePKG compacted dispatch state reached")
            }
        }
    };
}
#[no_mangle]
pub unsafe extern "C" fn sub_00141F90() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _fca: ::core::ffi::c_double = 0.0f64;
    let mut _fcb: ::core::ffi::c_double = 0.0f64;
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x50 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_244: {
        if _fa != _fb {
            break 's_244;
        }
        (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
            ::core::ptr::read_volatile::<
                ::core::ffi::c_float,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    ::core::ffi::c_float,
                >(
                    (0x3b1688 as ::core::ffi::c_int as uint32_t as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            ),
        );
        _fca = (*__gamepkg_tls_g_xmm0).f[0usize] as ::core::ffi::c_double;
        _fcb = ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ) as ::core::ffi::c_double;
        's_188: {
            's_58: {
                if !(_fca <= _fcb || (_fca != _fca || _fcb != _fcb)) {
                    break 's_58;
                }
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                let mut _pv_3: uint32_t = 0 as ::core::ffi::c_int as uint32_t;
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_3,
                );
                let mut _pv_4: uint32_t = 1 as ::core::ffi::c_int as uint32_t;
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_4,
                );
                let mut _pv_5: uint32_t = (*__gamepkg_tls_g_edx);
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_5,
                );
                let mut _pv_6: uint32_t = (*__gamepkg_tls_g_eax);
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_6,
                );
                break 's_188;
            }
            (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            let mut _pv: uint32_t = 0x3e19999a as ::core::ffi::c_int as uint32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv,
            );
            let mut _pv_0: uint32_t = 1 as ::core::ffi::c_int as uint32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_0,
            );
            let mut _pv_1: uint32_t = (*__gamepkg_tls_g_eax);
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_1,
            );
            let mut _pv_2: uint32_t = (*__gamepkg_tls_g_ecx);
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_2,
            );
        }
        (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi).wrapping_add(0x78 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        let mut _pv_7: uint32_t = 0xb9a33e76 as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_7,
        );
        let mut _pv_8: uint32_t = 0x54300000 as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_8,
        );
        let mut _pv_9: uint32_t = 0x141fd9 as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_9,
        );
        sub_00141010();
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi).wrapping_add(0x50 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            5 as uint32_t,
        );
    }
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(12 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00141FF0() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 0xffffff00 as uint32_t
        | ::core::ptr::read_volatile::<
            uint8_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint8_t,
            >(
                ((*__gamepkg_tls_g_esi).wrapping_add(0x69 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ) as uint32_t;
    _fa = ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t as uint32_t
        & 0xff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
    _fas = _fa as int8_t as int32_t;
    _fbs = _fb as int8_t as int32_t;
    's_153: {
        if _fa != _fb {
            break 's_153;
        }
        let mut _pv: uint32_t = 0 as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv,
        );
        let mut _pv_0: uint32_t = 1 as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_0,
        );
        let mut _pv_1: uint32_t = 0x3f800000 as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_1,
        );
        let mut _pv_2: uint32_t = 0x3f19999a as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_2,
        );
        let mut _pv_3: uint32_t = 0x5b5ced84 as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_3,
        );
        let mut _pv_4: uint32_t = 0x76000000 as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_4,
        );
        (*__gamepkg_tls_g_eax) = 0 as uint32_t;
        _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        let mut _pv_5: uint32_t = 0x142016 as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_5,
        );
        sub_00141010();
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint8_t,
            >(
                ((*__gamepkg_tls_g_esi).wrapping_add(0x69 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            2 as uint8_t,
        );
    }
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00142020() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_ebx = unsafe { gamepkg_tls_g_ebx() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_fp_control_word = unsafe { gamepkg_tls_g_fp_control_word() };
    let __gamepkg_tls_g_fp_stack = unsafe { gamepkg_tls_g_fp_stack() };
    let __gamepkg_tls_g_fp_top = unsafe { gamepkg_tls_g_fp_top() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    let __gamepkg_tls_g_xmm1 = unsafe { gamepkg_tls_g_xmm1() };
    let __gamepkg_tls_g_xmm2 = unsafe { gamepkg_tls_g_xmm2() };
    let mut ebp: uint32_t = 0;
    let mut _flags: ::core::ffi::c_int = 0;
    let mut _fa: uint32_t = 0;
    let mut _fb: uint32_t = 0;
    let mut _fas: int32_t = 0;
    let mut _fbs: int32_t = 0;
    let mut _pv: uint32_t = 0;
    let mut _pv_0: uint32_t = 0;
    let mut _pv_1: uint32_t = 0;
    let mut _pv_2: uint32_t = 0;
    let mut _pv_3: uint32_t = 0;
    let mut _fp_value: ::core::ffi::c_double = 0.;
    let mut _pv_4: uint32_t = 0;
    let mut _pv_5: uint32_t = 0;
    let mut _dividend: uint64_t = 0;
    let mut _pv_6: uint32_t = 0;
    enum C2Rust_Block_37 {
        S_0,
        S_2,
        S_4,
        S_6,
        S_8,
        S_18,
        S_24,
        S_26,
        S_28,
        S_30,
        S_32,
        S_38,
        S_40,
        S_42,
        S_52,
        S_54,
        S_56,
        S_62,
        S_64,
        S_66,
        S_68,
        S_70,
        S_72,
        S_74,
        S_76,
        S_78,
        S_80,
        S_89,
        S_91,
        S_93,
        S_95,
        S_97,
        S_99,
        S_101,
        S_103,
        S_105,
        S_111,
        S_113,
        S_115,
        S_121,
        S_123,
        S_129,
        S_131,
        S_133,
        S_139,
        S_141,
        S_143,
        S_145,
        S_147,
        S_149,
        S_151,
        S_153,
        S_155,
        S_157,
        S_159,
        S_161,
        S_163,
        S_165,
        S_171,
        S_173,
        S_175,
        S_181,
        S_187,
        S_189,
        S_191,
        S_193,
        S_195,
        S_197,
        S_206,
        S_208,
        S_210,
        S_212,
        S_218,
        S_220,
        S_222,
        S_228,
        S_230,
        S_232,
        S_234,
        S_240,
        S_242,
        S_244,
        S_254,
        S_256,
        S_258,
        S_264,
        S_273,
        S_279,
        S_281,
        S_283,
        S_285,
        S_287,
        S_289,
        S_291,
        S_293,
        S_295,
        S_297,
        S_299,
        S_301,
        S_303,
        S_305,
        S_307,
        S_309,
        S_311,
        S_313,
        S_315,
        S_317,
        S_319,
        S_321,
        S_323,
        S_325,
        S_327,
        S_329,
        S_331,
        S_333,
        S_335,
        S_338,
        S_340,
        S_342,
        S_346,
        S_348,
        S_350,
        S_352,
        S_358,
        S_360,
        S_362,
        S_368,
        S_374,
        S_376,
        S_378,
        S_380,
        S_386,
        S_388,
        S_394,
        S_400,
        S_402,
        S_408,
        S_417,
        S_419,
        S_421,
        S_431,
        S_433,
        S_443,
        S_445,
        S_451,
        S_453,
        S_455,
        S_457,
        S_459,
        S_461,
        S_463,
    }
    let mut c2rust_current_block_37: C2Rust_Block_37;
    c2rust_current_block_37 = C2Rust_Block_37::S_0;
    loop {
        match c2rust_current_block_37 {
            C2Rust_Block_37::S_0 => {
                {
                    ebp = 0 as uint32_t;
                    c2rust_current_block_37 = C2Rust_Block_37::S_2;
                };
                {
                    ebp = (*__gamepkg_tls_g_ebp);
                    c2rust_current_block_37 = C2Rust_Block_37::S_4;
                };
                {
                    _flags = 0 as ::core::ffi::c_int;
                    c2rust_current_block_37 = C2Rust_Block_37::S_6;
                };
                {
                    _fa = 0 as uint32_t;
                    _fb = 0 as uint32_t;
                    c2rust_current_block_37 = C2Rust_Block_37::S_8;
                };
                {
                    _fas = 0 as int32_t;
                    _fbs = 0 as int32_t;
                    c2rust_current_block_37 = C2Rust_Block_37::S_18;
                };
                {
                    ebp = (*__gamepkg_tls_g_seh_ebp);
                    c2rust_current_block_37 = C2Rust_Block_37::S_24;
                };
                {
                    _fb = 0x48 as ::core::ffi::c_int as uint32_t
                        & 0xffffffff as uint32_t;
                    c2rust_current_block_37 = C2Rust_Block_37::S_26;
                };
                {
                    _fbs = _fb as int32_t;
                    c2rust_current_block_37 = C2Rust_Block_37::S_28;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(0x48 as uint32_t);
                    c2rust_current_block_37 = C2Rust_Block_37::S_30;
                };
                {
                    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                    c2rust_current_block_37 = C2Rust_Block_37::S_32;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_37 = C2Rust_Block_37::S_38;
                };
                {
                    _pv = (*__gamepkg_tls_g_ebx);
                    c2rust_current_block_37 = C2Rust_Block_37::S_40;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_37 = C2Rust_Block_37::S_42;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv,
                    );
                    c2rust_current_block_37 = C2Rust_Block_37::S_52;
                };
                {
                    _pv_0 = ebp;
                    c2rust_current_block_37 = C2Rust_Block_37::S_54;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_37 = C2Rust_Block_37::S_56;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_0,
                    );
                    c2rust_current_block_37 = C2Rust_Block_37::S_62;
                };
                {
                    ebp = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x54 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_37 = C2Rust_Block_37::S_64;
                };
                {
                    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (ebp.wrapping_add(4 as uint32_t) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_37 = C2Rust_Block_37::S_66;
                };
                {
                    (*__gamepkg_tls_g_ebx) = 0 as uint32_t;
                    c2rust_current_block_37 = C2Rust_Block_37::S_68;
                };
                {
                    _fa = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
                    c2rust_current_block_37 = C2Rust_Block_37::S_70;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_37 = C2Rust_Block_37::S_72;
                };
                {
                    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                    c2rust_current_block_37 = C2Rust_Block_37::S_74;
                };
                {
                    _fb = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
                    c2rust_current_block_37 = C2Rust_Block_37::S_76;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_37 = C2Rust_Block_37::S_78;
                };
                {
                    _fbs = _fb as int32_t;
                    c2rust_current_block_37 = C2Rust_Block_37::S_80;
                };
                {
                    if _fa != _fb {
                        c2rust_current_block_37 = C2Rust_Block_37::S_431;
                    } else {
                        c2rust_current_block_37 = C2Rust_Block_37::S_89;
                    }
                };
            }
            C2Rust_Block_37::S_89 => {
                {
                    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b16bc as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_37 = C2Rust_Block_37::S_91;
                };
                {
                    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (ebp.wrapping_add(0x7c as uint32_t) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_37 = C2Rust_Block_37::S_93;
                };
                {
                    (*__gamepkg_tls_g_xmm1) = XMM_ZERO();
                    c2rust_current_block_37 = C2Rust_Block_37::S_95;
                };
                {
                    (*__gamepkg_tls_g_xmm2) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b16c0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_37 = C2Rust_Block_37::S_97;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm0).f[0usize],
                    );
                    c2rust_current_block_37 = C2Rust_Block_37::S_99;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm0).f[0usize],
                    );
                    c2rust_current_block_37 = C2Rust_Block_37::S_101;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x10 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm0).f[0usize],
                    );
                    c2rust_current_block_37 = C2Rust_Block_37::S_103;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x30 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm0).f[0usize],
                    );
                    c2rust_current_block_37 = C2Rust_Block_37::S_105;
                };
                {
                    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b16b8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_37 = C2Rust_Block_37::S_111;
                };
                {
                    _pv_1 = (*__gamepkg_tls_g_ebx);
                    c2rust_current_block_37 = C2Rust_Block_37::S_113;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_37 = C2Rust_Block_37::S_115;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_1,
                    );
                    c2rust_current_block_37 = C2Rust_Block_37::S_121;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x44 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm0).f[0usize],
                    );
                    c2rust_current_block_37 = C2Rust_Block_37::S_123;
                };
                {
                    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b16b4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_37 = C2Rust_Block_37::S_129;
                };
                {
                    _pv_2 = (*__gamepkg_tls_g_eax);
                    c2rust_current_block_37 = C2Rust_Block_37::S_131;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_37 = C2Rust_Block_37::S_133;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_2,
                    );
                    c2rust_current_block_37 = C2Rust_Block_37::S_139;
                };
                {
                    (*__gamepkg_tls_g_eax) = 0x39c330 as uint32_t;
                    c2rust_current_block_37 = C2Rust_Block_37::S_141;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x1c as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm1).f[0usize],
                    );
                    c2rust_current_block_37 = C2Rust_Block_37::S_143;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x20 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm1).f[0usize],
                    );
                    c2rust_current_block_37 = C2Rust_Block_37::S_145;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x24 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm1).f[0usize],
                    );
                    c2rust_current_block_37 = C2Rust_Block_37::S_147;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x28 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_ebx),
                    );
                    c2rust_current_block_37 = C2Rust_Block_37::S_149;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x2c as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm2).f[0usize],
                    );
                    c2rust_current_block_37 = C2Rust_Block_37::S_151;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x30 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm2).f[0usize],
                    );
                    c2rust_current_block_37 = C2Rust_Block_37::S_153;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x34 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm2).f[0usize],
                    );
                    c2rust_current_block_37 = C2Rust_Block_37::S_155;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x44 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm1).f[0usize],
                    );
                    c2rust_current_block_37 = C2Rust_Block_37::S_157;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x4c as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm0).f[0usize],
                    );
                    c2rust_current_block_37 = C2Rust_Block_37::S_159;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x50 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        0xffffffff as ::core::ffi::c_uint as uint32_t,
                    );
                    c2rust_current_block_37 = C2Rust_Block_37::S_161;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x54 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_ebx) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_37 = C2Rust_Block_37::S_163;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x55 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_ebx) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_37 = C2Rust_Block_37::S_165;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x56 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_ebx) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_37 = C2Rust_Block_37::S_171;
                };
                {
                    _pv_3 = 0x1420ce as ::core::ffi::c_uint as uint32_t;
                    c2rust_current_block_37 = C2Rust_Block_37::S_173;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_37 = C2Rust_Block_37::S_175;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_3,
                    );
                    c2rust_current_block_37 = C2Rust_Block_37::S_181;
                };
                {
                    sub_001C99D0();
                    c2rust_current_block_37 = C2Rust_Block_37::S_187;
                };
                {
                    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                    c2rust_current_block_37 = C2Rust_Block_37::S_189;
                };
                {
                    _fb = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
                    c2rust_current_block_37 = C2Rust_Block_37::S_191;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_37 = C2Rust_Block_37::S_193;
                };
                {
                    _fbs = _fb as int32_t;
                    c2rust_current_block_37 = C2Rust_Block_37::S_195;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x20 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_eax),
                    );
                    c2rust_current_block_37 = C2Rust_Block_37::S_197;
                };
                {
                    if _fa == _fb {
                        c2rust_current_block_37 = C2Rust_Block_37::S_431;
                    } else {
                        c2rust_current_block_37 = C2Rust_Block_37::S_206;
                    }
                };
            }
            C2Rust_Block_37::S_206 => {
                {
                    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b1730 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_37 = C2Rust_Block_37::S_208;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x24 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm0).f[0usize],
                    );
                    c2rust_current_block_37 = C2Rust_Block_37::S_210;
                };
                {
                    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_eax).wrapping_add(8 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_37 = C2Rust_Block_37::S_212;
                };
                {
                    (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_ecx).wrapping_add(0x10 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_37 = C2Rust_Block_37::S_218;
                };
                {
                    _fp_value = ::core::ptr::read_volatile::<
                        int32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            int32_t,
                        >(
                            ((*__gamepkg_tls_g_ecx).wrapping_add(0x10 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ) as ::core::ffi::c_double;
                    c2rust_current_block_37 = C2Rust_Block_37::S_220;
                };
                {
                    (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top)
                        as ::core::ffi::c_uint)
                        .wrapping_add(7 as ::core::ffi::c_uint)
                        & 7 as ::core::ffi::c_uint) as ::core::ffi::c_int;
                    c2rust_current_block_37 = C2Rust_Block_37::S_222;
                };
                {
                    (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = _fp_value;
                    c2rust_current_block_37 = C2Rust_Block_37::S_228;
                };
                {
                    _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                    c2rust_current_block_37 = C2Rust_Block_37::S_230;
                };
                {
                    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                    c2rust_current_block_37 = C2Rust_Block_37::S_232;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_37 = C2Rust_Block_37::S_234;
                };
                {
                    _fbs = _fb as int32_t;
                    c2rust_current_block_37 = C2Rust_Block_37::S_240;
                };
                {
                    _pv_4 = (*__gamepkg_tls_g_esi);
                    c2rust_current_block_37 = C2Rust_Block_37::S_242;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_37 = C2Rust_Block_37::S_244;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_4,
                    );
                    c2rust_current_block_37 = C2Rust_Block_37::S_254;
                };
                {
                    _pv_5 = (*__gamepkg_tls_g_edi);
                    c2rust_current_block_37 = C2Rust_Block_37::S_256;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_37 = C2Rust_Block_37::S_258;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_5,
                    );
                    c2rust_current_block_37 = C2Rust_Block_37::S_264;
                };
                {
                    if if if ::core::mem::size_of::<int32_t>()
                        < ::core::mem::size_of::<int32_t>()
                    {
                        ::core::mem::size_of::<int32_t>()
                    } else {
                        ::core::mem::size_of::<int32_t>()
                    } == 1usize
                    {
                        _fas as uint32_t as uint8_t as int8_t as int32_t
                    } else if if ::core::mem::size_of::<int32_t>()
                        < ::core::mem::size_of::<int32_t>()
                    {
                        ::core::mem::size_of::<int32_t>()
                    } else {
                        ::core::mem::size_of::<int32_t>()
                    } == 2usize
                    {
                        _fas as uint32_t as uint16_t as int16_t as int32_t
                    } else {
                        _fas as uint32_t as int32_t
                    }
                        >= if if ::core::mem::size_of::<int32_t>()
                            < ::core::mem::size_of::<int32_t>()
                        {
                            ::core::mem::size_of::<int32_t>()
                        } else {
                            ::core::mem::size_of::<int32_t>()
                        } == 1usize
                        {
                            _fbs as uint32_t as uint8_t as int8_t as int32_t
                        } else if if ::core::mem::size_of::<int32_t>()
                            < ::core::mem::size_of::<int32_t>()
                        {
                            ::core::mem::size_of::<int32_t>()
                        } else {
                            ::core::mem::size_of::<int32_t>()
                        } == 2usize
                        {
                            _fbs as uint32_t as uint16_t as int16_t as int32_t
                        } else {
                            _fbs as uint32_t as int32_t
                        }
                    {
                        c2rust_current_block_37 = C2Rust_Block_37::S_279;
                    } else {
                        c2rust_current_block_37 = C2Rust_Block_37::S_273;
                    }
                };
            }
            C2Rust_Block_37::S_273 => {
                (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = if (*__gamepkg_tls_g_fp_control_word)
                    as ::core::ffi::c_uint & 0x300 as ::core::ffi::c_uint != 0
                {
                    (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                        + ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b16a8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ) as ::core::ffi::c_double
                } else {
                    recomp_fp_round24(
                        (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                            + ::core::ptr::read_volatile::<
                                ::core::ffi::c_float,
                            >(
                                ::core::ptr::with_exposed_provenance_mut::<
                                    ::core::ffi::c_float,
                                >(
                                    (0x3b16a8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                                ),
                            ) as ::core::ffi::c_double,
                    )
                };
                c2rust_current_block_37 = C2Rust_Block_37::S_279;
            }
            C2Rust_Block_37::S_279 => {
                {
                    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                        int16_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            int16_t,
                        >(
                            (0x40f792 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ) as int32_t as uint32_t;
                    c2rust_current_block_37 = C2Rust_Block_37::S_281;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x34 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                            as ::core::ffi::c_float,
                    );
                    c2rust_current_block_37 = C2Rust_Block_37::S_283;
                };
                {
                    (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top)
                        as ::core::ffi::c_uint)
                        .wrapping_add(1 as ::core::ffi::c_uint)
                        & 7 as ::core::ffi::c_uint) as ::core::ffi::c_int;
                    c2rust_current_block_37 = C2Rust_Block_37::S_285;
                };
                {
                    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x40f790 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_37 = C2Rust_Block_37::S_287;
                };
                {
                    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
                        << 0x10 as ::core::ffi::c_int;
                    c2rust_current_block_37 = C2Rust_Block_37::S_289;
                };
                {
                    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                    c2rust_current_block_37 = C2Rust_Block_37::S_291;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_37 = C2Rust_Block_37::S_293;
                };
                {
                    _fb = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                    c2rust_current_block_37 = C2Rust_Block_37::S_295;
                };
                {
                    _fbs = _fb as int32_t;
                    c2rust_current_block_37 = C2Rust_Block_37::S_297;
                };
                {
                    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
                        .wrapping_add((*__gamepkg_tls_g_ecx));
                    c2rust_current_block_37 = C2Rust_Block_37::S_299;
                };
                {
                    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                    c2rust_current_block_37 = C2Rust_Block_37::S_301;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_37 = C2Rust_Block_37::S_303;
                };
                {
                    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x40f794 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_37 = C2Rust_Block_37::S_305;
                };
                {
                    _fb = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                    c2rust_current_block_37 = C2Rust_Block_37::S_307;
                };
                {
                    _fbs = _fb as int32_t;
                    c2rust_current_block_37 = C2Rust_Block_37::S_309;
                };
                {
                    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
                        .wrapping_add((*__gamepkg_tls_g_ecx));
                    c2rust_current_block_37 = C2Rust_Block_37::S_311;
                };
                {
                    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                    c2rust_current_block_37 = C2Rust_Block_37::S_313;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_37 = C2Rust_Block_37::S_315;
                };
                {
                    _fb = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                    c2rust_current_block_37 = C2Rust_Block_37::S_317;
                };
                {
                    _fbs = _fb as int32_t;
                    c2rust_current_block_37 = C2Rust_Block_37::S_319;
                };
                {
                    (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx)
                        .wrapping_add((*__gamepkg_tls_g_eax));
                    c2rust_current_block_37 = C2Rust_Block_37::S_321;
                };
                {
                    _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                    c2rust_current_block_37 = C2Rust_Block_37::S_323;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_37 = C2Rust_Block_37::S_325;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x40f794 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_ecx),
                    );
                    c2rust_current_block_37 = C2Rust_Block_37::S_327;
                };
                {
                    (*__gamepkg_tls_g_edx) = 0 as uint32_t;
                    c2rust_current_block_37 = C2Rust_Block_37::S_329;
                };
                {
                    _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                    c2rust_current_block_37 = C2Rust_Block_37::S_331;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_37 = C2Rust_Block_37::S_333;
                };
                {
                    (*__gamepkg_tls_g_ecx) = 0x13880 as uint32_t;
                    c2rust_current_block_37 = C2Rust_Block_37::S_335;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x40f790 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_eax),
                    );
                    c2rust_current_block_37 = C2Rust_Block_37::S_338;
                };
                {
                    _dividend = ((*__gamepkg_tls_g_edx) as uint64_t)
                        << 32 as ::core::ffi::c_int | (*__gamepkg_tls_g_eax) as uint64_t;
                    c2rust_current_block_37 = C2Rust_Block_37::S_340;
                };
                {
                    (*__gamepkg_tls_g_eax) = _dividend
                        .wrapping_div((*__gamepkg_tls_g_ecx) as uint64_t) as uint32_t;
                    c2rust_current_block_37 = C2Rust_Block_37::S_342;
                };
                {
                    (*__gamepkg_tls_g_edx) = _dividend
                        .wrapping_rem((*__gamepkg_tls_g_ecx) as uint64_t) as uint32_t;
                    c2rust_current_block_37 = C2Rust_Block_37::S_346;
                };
                {
                    (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_esp)
                        .wrapping_add(0x10 as uint32_t);
                    c2rust_current_block_37 = C2Rust_Block_37::S_348;
                };
                {
                    (*__gamepkg_tls_g_esi) = 0x40b844 as uint32_t;
                    c2rust_current_block_37 = C2Rust_Block_37::S_350;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x54 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        1 as uint8_t,
                    );
                    c2rust_current_block_37 = C2Rust_Block_37::S_352;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x50 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_edx),
                    );
                    c2rust_current_block_37 = C2Rust_Block_37::S_358;
                };
                {
                    _pv_6 = 0x142143 as ::core::ffi::c_uint as uint32_t;
                    c2rust_current_block_37 = C2Rust_Block_37::S_360;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_37 = C2Rust_Block_37::S_362;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_6,
                    );
                    c2rust_current_block_37 = C2Rust_Block_37::S_368;
                };
                {
                    sub_001CD8D0();
                    c2rust_current_block_37 = C2Rust_Block_37::S_374;
                };
                {
                    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                    c2rust_current_block_37 = C2Rust_Block_37::S_376;
                };
                {
                    _fb = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
                    c2rust_current_block_37 = C2Rust_Block_37::S_378;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_37 = C2Rust_Block_37::S_380;
                };
                {
                    _fbs = _fb as int32_t;
                    c2rust_current_block_37 = C2Rust_Block_37::S_386;
                };
                {
                    (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_37 = C2Rust_Block_37::S_388;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_add(4 as uint32_t);
                    c2rust_current_block_37 = C2Rust_Block_37::S_394;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (ebp.wrapping_add(4 as uint32_t) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_eax),
                    );
                    c2rust_current_block_37 = C2Rust_Block_37::S_400;
                };
                {
                    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_37 = C2Rust_Block_37::S_402;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_add(4 as uint32_t);
                    c2rust_current_block_37 = C2Rust_Block_37::S_408;
                };
                {
                    if _fa == _fb {
                        c2rust_current_block_37 = C2Rust_Block_37::S_431;
                    } else {
                        c2rust_current_block_37 = C2Rust_Block_37::S_417;
                    }
                };
            }
            C2Rust_Block_37::S_417 => {
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            ((*__gamepkg_tls_g_eax).wrapping_add(0x37 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (::core::ptr::read_volatile::<
                            uint8_t,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                uint8_t,
                            >(
                                ((*__gamepkg_tls_g_eax).wrapping_add(0x37 as uint32_t)
                                    as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ) as ::core::ffi::c_int | 0x10 as ::core::ffi::c_int) as uint8_t,
                    );
                    c2rust_current_block_37 = C2Rust_Block_37::S_419;
                };
                {
                    _fa = ::core::ptr::read_volatile::<
                        uint8_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            ((*__gamepkg_tls_g_eax).wrapping_add(0x37 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ) as uint32_t & 0xff as uint32_t;
                    c2rust_current_block_37 = C2Rust_Block_37::S_421;
                };
                {
                    _fas = _fa as int8_t as int32_t;
                    c2rust_current_block_37 = C2Rust_Block_37::S_431;
                };
            }
            C2Rust_Block_37::S_431 => {
                {
                    ebp = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_37 = C2Rust_Block_37::S_433;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_add(4 as uint32_t);
                    c2rust_current_block_37 = C2Rust_Block_37::S_443;
                };
                {
                    (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_37 = C2Rust_Block_37::S_445;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_add(4 as uint32_t);
                    c2rust_current_block_37 = C2Rust_Block_37::S_451;
                };
                {
                    _fb = 0x48 as ::core::ffi::c_int as uint32_t
                        & 0xffffffff as uint32_t;
                    c2rust_current_block_37 = C2Rust_Block_37::S_453;
                };
                {
                    _fbs = _fb as int32_t;
                    c2rust_current_block_37 = C2Rust_Block_37::S_455;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_add(0x48 as uint32_t);
                    c2rust_current_block_37 = C2Rust_Block_37::S_457;
                };
                {
                    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                    c2rust_current_block_37 = C2Rust_Block_37::S_459;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_37 = C2Rust_Block_37::S_461;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_add(8 as uint32_t);
                    c2rust_current_block_37 = C2Rust_Block_37::S_463;
                };
                return;
            }
            C2Rust_Block_37::S_101
            | C2Rust_Block_37::S_103
            | C2Rust_Block_37::S_105
            | C2Rust_Block_37::S_111
            | C2Rust_Block_37::S_113
            | C2Rust_Block_37::S_115
            | C2Rust_Block_37::S_121
            | C2Rust_Block_37::S_123
            | C2Rust_Block_37::S_129
            | C2Rust_Block_37::S_131
            | C2Rust_Block_37::S_133
            | C2Rust_Block_37::S_139
            | C2Rust_Block_37::S_141
            | C2Rust_Block_37::S_143
            | C2Rust_Block_37::S_145
            | C2Rust_Block_37::S_147
            | C2Rust_Block_37::S_149
            | C2Rust_Block_37::S_151
            | C2Rust_Block_37::S_153
            | C2Rust_Block_37::S_155
            | C2Rust_Block_37::S_157
            | C2Rust_Block_37::S_159
            | C2Rust_Block_37::S_161
            | C2Rust_Block_37::S_163
            | C2Rust_Block_37::S_165
            | C2Rust_Block_37::S_171
            | C2Rust_Block_37::S_173
            | C2Rust_Block_37::S_175
            | C2Rust_Block_37::S_18
            | C2Rust_Block_37::S_181
            | C2Rust_Block_37::S_187
            | C2Rust_Block_37::S_189
            | C2Rust_Block_37::S_191
            | C2Rust_Block_37::S_193
            | C2Rust_Block_37::S_195
            | C2Rust_Block_37::S_197
            | C2Rust_Block_37::S_2
            | C2Rust_Block_37::S_208
            | C2Rust_Block_37::S_210
            | C2Rust_Block_37::S_212
            | C2Rust_Block_37::S_218
            | C2Rust_Block_37::S_220
            | C2Rust_Block_37::S_222
            | C2Rust_Block_37::S_228
            | C2Rust_Block_37::S_230
            | C2Rust_Block_37::S_232
            | C2Rust_Block_37::S_234
            | C2Rust_Block_37::S_24
            | C2Rust_Block_37::S_240
            | C2Rust_Block_37::S_242
            | C2Rust_Block_37::S_244
            | C2Rust_Block_37::S_254
            | C2Rust_Block_37::S_256
            | C2Rust_Block_37::S_258
            | C2Rust_Block_37::S_26
            | C2Rust_Block_37::S_264
            | C2Rust_Block_37::S_28
            | C2Rust_Block_37::S_281
            | C2Rust_Block_37::S_283
            | C2Rust_Block_37::S_285
            | C2Rust_Block_37::S_287
            | C2Rust_Block_37::S_289
            | C2Rust_Block_37::S_291
            | C2Rust_Block_37::S_293
            | C2Rust_Block_37::S_295
            | C2Rust_Block_37::S_297
            | C2Rust_Block_37::S_299
            | C2Rust_Block_37::S_30
            | C2Rust_Block_37::S_301
            | C2Rust_Block_37::S_303
            | C2Rust_Block_37::S_305
            | C2Rust_Block_37::S_307
            | C2Rust_Block_37::S_309
            | C2Rust_Block_37::S_311
            | C2Rust_Block_37::S_313
            | C2Rust_Block_37::S_315
            | C2Rust_Block_37::S_317
            | C2Rust_Block_37::S_319
            | C2Rust_Block_37::S_32
            | C2Rust_Block_37::S_321
            | C2Rust_Block_37::S_323
            | C2Rust_Block_37::S_325
            | C2Rust_Block_37::S_327
            | C2Rust_Block_37::S_329
            | C2Rust_Block_37::S_331
            | C2Rust_Block_37::S_333
            | C2Rust_Block_37::S_335
            | C2Rust_Block_37::S_338
            | C2Rust_Block_37::S_340
            | C2Rust_Block_37::S_342
            | C2Rust_Block_37::S_346
            | C2Rust_Block_37::S_348
            | C2Rust_Block_37::S_350
            | C2Rust_Block_37::S_352
            | C2Rust_Block_37::S_358
            | C2Rust_Block_37::S_360
            | C2Rust_Block_37::S_362
            | C2Rust_Block_37::S_368
            | C2Rust_Block_37::S_374
            | C2Rust_Block_37::S_376
            | C2Rust_Block_37::S_378
            | C2Rust_Block_37::S_38
            | C2Rust_Block_37::S_380
            | C2Rust_Block_37::S_386
            | C2Rust_Block_37::S_388
            | C2Rust_Block_37::S_394
            | C2Rust_Block_37::S_4
            | C2Rust_Block_37::S_40
            | C2Rust_Block_37::S_400
            | C2Rust_Block_37::S_402
            | C2Rust_Block_37::S_408
            | C2Rust_Block_37::S_419
            | C2Rust_Block_37::S_42
            | C2Rust_Block_37::S_421
            | C2Rust_Block_37::S_433
            | C2Rust_Block_37::S_443
            | C2Rust_Block_37::S_445
            | C2Rust_Block_37::S_451
            | C2Rust_Block_37::S_453
            | C2Rust_Block_37::S_455
            | C2Rust_Block_37::S_457
            | C2Rust_Block_37::S_459
            | C2Rust_Block_37::S_461
            | C2Rust_Block_37::S_463
            | C2Rust_Block_37::S_52
            | C2Rust_Block_37::S_54
            | C2Rust_Block_37::S_56
            | C2Rust_Block_37::S_6
            | C2Rust_Block_37::S_62
            | C2Rust_Block_37::S_64
            | C2Rust_Block_37::S_66
            | C2Rust_Block_37::S_68
            | C2Rust_Block_37::S_70
            | C2Rust_Block_37::S_72
            | C2Rust_Block_37::S_74
            | C2Rust_Block_37::S_76
            | C2Rust_Block_37::S_78
            | C2Rust_Block_37::S_8
            | C2Rust_Block_37::S_80
            | C2Rust_Block_37::S_91
            | C2Rust_Block_37::S_93
            | C2Rust_Block_37::S_95
            | C2Rust_Block_37::S_97
            | C2Rust_Block_37::S_99 => {
                unreachable!("GamePKG compacted dispatch state reached")
            }
        }
    };
}
#[no_mangle]
pub unsafe extern "C" fn sub_00142160() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_edi).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_187: {
        if _fa == _fb {
            break 's_187;
        }
        (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi).wrapping_add(0xc as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        let mut _pv_0: uint32_t = 0 as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_0,
        );
        let mut _pv_1: uint32_t = (*__gamepkg_tls_g_eax);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_1,
        );
        let mut _pv_2: uint32_t = 0x142173 as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_2,
        );
        sub_001FB100();
        (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi).wrapping_add(0xc as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        let mut _pv_3: uint32_t = 0 as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_3,
        );
        let mut _pv_4: uint32_t = (*__gamepkg_tls_g_ecx);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_4,
        );
        let mut _pv_5: uint32_t = 0x14217e as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_5,
        );
        sub_001FB140();
        (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 0xffffff00 as uint32_t
            | ::core::ptr::read_volatile::<
                uint8_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint8_t,
                >(
                    ((*__gamepkg_tls_g_esi).wrapping_add(0x37 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            ) as uint32_t;
        (*__gamepkg_tls_g_xmm0) = XMM_ZERO();
        _fb = 0x10 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fbs = _fb as int32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(0x10 as uint32_t);
        _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 0xffffff00 as uint32_t
            | (((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t
                as ::core::ffi::c_int & 1 as ::core::ffi::c_int) as uint8_t as uint32_t;
        _fa = ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t as uint32_t
            & 0xff as uint32_t;
        _fas = _fa as int8_t as int32_t;
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint8_t,
            >(
                ((*__gamepkg_tls_g_esi).wrapping_add(0x34 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            0 as uint8_t,
        );
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                ((*__gamepkg_tls_g_esi).wrapping_add(0x30 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            (*__gamepkg_tls_g_xmm0).f[0usize],
        );
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint8_t,
            >(
                ((*__gamepkg_tls_g_esi).wrapping_add(0x37 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t,
        );
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_edi).wrapping_add(4 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            0 as uint32_t,
        );
    }
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001421A0() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 0xffffff00 as uint32_t
        | ::core::ptr::read_volatile::<
            uint8_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint8_t,
            >(
                ((*__gamepkg_tls_g_esi).wrapping_add(0x69 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ) as uint32_t;
    _fa = ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t as uint32_t
        & 0xff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
    _fas = _fa as int8_t as int32_t;
    _fbs = _fb as int8_t as int32_t;
    's_153: {
        if _fa != _fb {
            break 's_153;
        }
        let mut _pv: uint32_t = 0 as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv,
        );
        let mut _pv_0: uint32_t = 1 as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_0,
        );
        let mut _pv_1: uint32_t = 0x3f800000 as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_1,
        );
        let mut _pv_2: uint32_t = 0x3ea8f5c3 as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_2,
        );
        let mut _pv_3: uint32_t = 0x5b5ced84 as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_3,
        );
        let mut _pv_4: uint32_t = 0x76000000 as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_4,
        );
        (*__gamepkg_tls_g_eax) = 0 as uint32_t;
        _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        let mut _pv_5: uint32_t = 0x1421c6 as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_5,
        );
        sub_00141010();
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint8_t,
            >(
                ((*__gamepkg_tls_g_esi).wrapping_add(0x69 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            2 as uint8_t,
        );
    }
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001421D0() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0x7c as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv: uint32_t = 0 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    let mut _pv_0: uint32_t = 1 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    let mut _pv_1: uint32_t = 0x3f800000 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    let mut _pv_2: uint32_t = 0x3f19999a as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_2,
    );
    let mut _pv_3: uint32_t = 0xa8c69079 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_3,
    );
    let mut _pv_4: uint32_t = 0x27500000 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_4,
    );
    let mut _pv_5: uint32_t = 0x1421f0 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_5,
    );
    sub_00141010();
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00142200() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_ebx = unsafe { gamepkg_tls_g_ebx() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_fp_control_word = unsafe { gamepkg_tls_g_fp_control_word() };
    let __gamepkg_tls_g_fp_stack = unsafe { gamepkg_tls_g_fp_stack() };
    let __gamepkg_tls_g_fp_top = unsafe { gamepkg_tls_g_fp_top() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    let __gamepkg_tls_g_xmm1 = unsafe { gamepkg_tls_g_xmm1() };
    let __gamepkg_tls_g_xmm2 = unsafe { gamepkg_tls_g_xmm2() };
    let mut ebp: uint32_t = 0;
    let mut _flags: ::core::ffi::c_int = 0;
    let mut _fa: uint32_t = 0;
    let mut _fb: uint32_t = 0;
    let mut _fas: int32_t = 0;
    let mut _fbs: int32_t = 0;
    let mut _pv: uint32_t = 0;
    let mut _pv_0: uint32_t = 0;
    let mut _pv_1: uint32_t = 0;
    let mut _pv_2: uint32_t = 0;
    let mut _pv_3: uint32_t = 0;
    let mut _pv_4: uint32_t = 0;
    let mut _pv_5: uint32_t = 0;
    let mut _fp_value: ::core::ffi::c_double = 0.;
    let mut _pv_6: uint32_t = 0;
    let mut _pv_7: uint32_t = 0;
    let mut _pv_8: uint32_t = 0;
    let mut _pv_9: uint32_t = 0;
    let mut _pv_10: uint32_t = 0;
    enum C2Rust_Block_41 {
        S_0,
        S_2,
        S_4,
        S_6,
        S_8,
        S_18,
        S_24,
        S_26,
        S_28,
        S_30,
        S_32,
        S_38,
        S_40,
        S_42,
        S_52,
        S_54,
        S_56,
        S_62,
        S_64,
        S_66,
        S_68,
        S_70,
        S_72,
        S_74,
        S_76,
        S_78,
        S_80,
        S_89,
        S_91,
        S_93,
        S_95,
        S_101,
        S_103,
        S_105,
        S_115,
        S_117,
        S_119,
        S_125,
        S_127,
        S_129,
        S_131,
        S_133,
        S_139,
        S_141,
        S_143,
        S_149,
        S_151,
        S_157,
        S_159,
        S_161,
        S_167,
        S_169,
        S_171,
        S_173,
        S_175,
        S_177,
        S_179,
        S_181,
        S_183,
        S_185,
        S_187,
        S_189,
        S_191,
        S_193,
        S_199,
        S_201,
        S_203,
        S_209,
        S_215,
        S_217,
        S_219,
        S_221,
        S_223,
        S_225,
        S_234,
        S_236,
        S_238,
        S_240,
        S_246,
        S_248,
        S_250,
        S_256,
        S_258,
        S_260,
        S_262,
        S_264,
        S_273,
        S_279,
        S_281,
        S_283,
        S_285,
        S_287,
        S_289,
        S_291,
        S_297,
        S_299,
        S_301,
        S_307,
        S_313,
        S_319,
        S_321,
        S_323,
        S_333,
        S_335,
        S_337,
        S_343,
        S_349,
        S_351,
        S_353,
        S_359,
        S_365,
        S_367,
        S_369,
        S_371,
        S_373,
        S_375,
        S_384,
        S_386,
        S_388,
        S_390,
        S_396,
        S_398,
        S_400,
        S_406,
        S_416,
        S_418,
        S_424,
        S_430,
        S_432,
        S_446,
        S_448,
        S_458,
        S_460,
        S_466,
        S_468,
        S_470,
        S_472,
        S_474,
        S_476,
        S_478,
    }
    let mut c2rust_current_block_41: C2Rust_Block_41;
    c2rust_current_block_41 = C2Rust_Block_41::S_0;
    loop {
        match c2rust_current_block_41 {
            C2Rust_Block_41::S_0 => {
                {
                    ebp = 0 as uint32_t;
                    c2rust_current_block_41 = C2Rust_Block_41::S_2;
                };
                {
                    ebp = (*__gamepkg_tls_g_ebp);
                    c2rust_current_block_41 = C2Rust_Block_41::S_4;
                };
                {
                    _flags = 0 as ::core::ffi::c_int;
                    c2rust_current_block_41 = C2Rust_Block_41::S_6;
                };
                {
                    _fa = 0 as uint32_t;
                    _fb = 0 as uint32_t;
                    c2rust_current_block_41 = C2Rust_Block_41::S_8;
                };
                {
                    _fas = 0 as int32_t;
                    _fbs = 0 as int32_t;
                    c2rust_current_block_41 = C2Rust_Block_41::S_18;
                };
                {
                    ebp = (*__gamepkg_tls_g_seh_ebp);
                    c2rust_current_block_41 = C2Rust_Block_41::S_24;
                };
                {
                    _fb = 0x48 as ::core::ffi::c_int as uint32_t
                        & 0xffffffff as uint32_t;
                    c2rust_current_block_41 = C2Rust_Block_41::S_26;
                };
                {
                    _fbs = _fb as int32_t;
                    c2rust_current_block_41 = C2Rust_Block_41::S_28;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(0x48 as uint32_t);
                    c2rust_current_block_41 = C2Rust_Block_41::S_30;
                };
                {
                    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                    c2rust_current_block_41 = C2Rust_Block_41::S_32;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_41 = C2Rust_Block_41::S_38;
                };
                {
                    _pv = (*__gamepkg_tls_g_ebx);
                    c2rust_current_block_41 = C2Rust_Block_41::S_40;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_41 = C2Rust_Block_41::S_42;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv,
                    );
                    c2rust_current_block_41 = C2Rust_Block_41::S_52;
                };
                {
                    _pv_0 = ebp;
                    c2rust_current_block_41 = C2Rust_Block_41::S_54;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_41 = C2Rust_Block_41::S_56;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_0,
                    );
                    c2rust_current_block_41 = C2Rust_Block_41::S_62;
                };
                {
                    ebp = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x54 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_41 = C2Rust_Block_41::S_64;
                };
                {
                    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
                        & 0xffffff00 as uint32_t
                        | ::core::ptr::read_volatile::<
                            uint8_t,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                uint8_t,
                            >(
                                (ebp.wrapping_add(0x69 as uint32_t) as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ) as uint32_t;
                    c2rust_current_block_41 = C2Rust_Block_41::S_66;
                };
                {
                    (*__gamepkg_tls_g_ebx) = 0 as uint32_t;
                    c2rust_current_block_41 = C2Rust_Block_41::S_68;
                };
                {
                    _fa = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
                    c2rust_current_block_41 = C2Rust_Block_41::S_70;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_41 = C2Rust_Block_41::S_72;
                };
                {
                    _fa = ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t
                        as uint32_t & 0xff as uint32_t;
                    c2rust_current_block_41 = C2Rust_Block_41::S_74;
                };
                {
                    _fb = ((*__gamepkg_tls_g_ebx) & 0xff as uint32_t) as uint8_t
                        as uint32_t & 0xff as uint32_t;
                    c2rust_current_block_41 = C2Rust_Block_41::S_76;
                };
                {
                    _fas = _fa as int8_t as int32_t;
                    c2rust_current_block_41 = C2Rust_Block_41::S_78;
                };
                {
                    _fbs = _fb as int8_t as int32_t;
                    c2rust_current_block_41 = C2Rust_Block_41::S_80;
                };
                {
                    if _fa != _fb {
                        c2rust_current_block_41 = C2Rust_Block_41::S_446;
                    } else {
                        c2rust_current_block_41 = C2Rust_Block_41::S_89;
                    }
                };
            }
            C2Rust_Block_41::S_89 => {
                {
                    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b16bc as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_41 = C2Rust_Block_41::S_91;
                };
                {
                    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (ebp.wrapping_add(0x7c as uint32_t) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_41 = C2Rust_Block_41::S_93;
                };
                {
                    (*__gamepkg_tls_g_xmm1) = XMM_ZERO();
                    c2rust_current_block_41 = C2Rust_Block_41::S_95;
                };
                {
                    (*__gamepkg_tls_g_xmm2) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b16c0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_41 = C2Rust_Block_41::S_101;
                };
                {
                    _pv_1 = (*__gamepkg_tls_g_esi);
                    c2rust_current_block_41 = C2Rust_Block_41::S_103;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_41 = C2Rust_Block_41::S_105;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_1,
                    );
                    c2rust_current_block_41 = C2Rust_Block_41::S_115;
                };
                {
                    _pv_2 = (*__gamepkg_tls_g_edi);
                    c2rust_current_block_41 = C2Rust_Block_41::S_117;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_41 = C2Rust_Block_41::S_119;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_2,
                    );
                    c2rust_current_block_41 = C2Rust_Block_41::S_125;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x10 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm0).f[0usize],
                    );
                    c2rust_current_block_41 = C2Rust_Block_41::S_127;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x14 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm0).f[0usize],
                    );
                    c2rust_current_block_41 = C2Rust_Block_41::S_129;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x18 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm0).f[0usize],
                    );
                    c2rust_current_block_41 = C2Rust_Block_41::S_131;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x38 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm0).f[0usize],
                    );
                    c2rust_current_block_41 = C2Rust_Block_41::S_133;
                };
                {
                    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b16b8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_41 = C2Rust_Block_41::S_139;
                };
                {
                    _pv_3 = (*__gamepkg_tls_g_ebx);
                    c2rust_current_block_41 = C2Rust_Block_41::S_141;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_41 = C2Rust_Block_41::S_143;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_3,
                    );
                    c2rust_current_block_41 = C2Rust_Block_41::S_149;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x4c as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm0).f[0usize],
                    );
                    c2rust_current_block_41 = C2Rust_Block_41::S_151;
                };
                {
                    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b16b4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_41 = C2Rust_Block_41::S_157;
                };
                {
                    _pv_4 = (*__gamepkg_tls_g_eax);
                    c2rust_current_block_41 = C2Rust_Block_41::S_159;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_41 = C2Rust_Block_41::S_161;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_4,
                    );
                    c2rust_current_block_41 = C2Rust_Block_41::S_167;
                };
                {
                    (*__gamepkg_tls_g_eax) = 0x39c348 as uint32_t;
                    c2rust_current_block_41 = C2Rust_Block_41::S_169;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x24 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm1).f[0usize],
                    );
                    c2rust_current_block_41 = C2Rust_Block_41::S_171;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x28 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm1).f[0usize],
                    );
                    c2rust_current_block_41 = C2Rust_Block_41::S_173;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x2c as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm1).f[0usize],
                    );
                    c2rust_current_block_41 = C2Rust_Block_41::S_175;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x30 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_ebx),
                    );
                    c2rust_current_block_41 = C2Rust_Block_41::S_177;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x34 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm2).f[0usize],
                    );
                    c2rust_current_block_41 = C2Rust_Block_41::S_179;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x38 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm2).f[0usize],
                    );
                    c2rust_current_block_41 = C2Rust_Block_41::S_181;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x3c as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm2).f[0usize],
                    );
                    c2rust_current_block_41 = C2Rust_Block_41::S_183;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x4c as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm1).f[0usize],
                    );
                    c2rust_current_block_41 = C2Rust_Block_41::S_185;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x54 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm0).f[0usize],
                    );
                    c2rust_current_block_41 = C2Rust_Block_41::S_187;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x58 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        0xffffffff as ::core::ffi::c_uint as uint32_t,
                    );
                    c2rust_current_block_41 = C2Rust_Block_41::S_189;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x5c as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_ebx) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_41 = C2Rust_Block_41::S_191;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x5d as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_ebx) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_41 = C2Rust_Block_41::S_193;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x5e as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_ebx) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_41 = C2Rust_Block_41::S_199;
                };
                {
                    _pv_5 = 0x1422b0 as ::core::ffi::c_uint as uint32_t;
                    c2rust_current_block_41 = C2Rust_Block_41::S_201;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_41 = C2Rust_Block_41::S_203;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_5,
                    );
                    c2rust_current_block_41 = C2Rust_Block_41::S_209;
                };
                {
                    sub_001C99D0();
                    c2rust_current_block_41 = C2Rust_Block_41::S_215;
                };
                {
                    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                    c2rust_current_block_41 = C2Rust_Block_41::S_217;
                };
                {
                    _fb = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
                    c2rust_current_block_41 = C2Rust_Block_41::S_219;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_41 = C2Rust_Block_41::S_221;
                };
                {
                    _fbs = _fb as int32_t;
                    c2rust_current_block_41 = C2Rust_Block_41::S_223;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x28 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_eax),
                    );
                    c2rust_current_block_41 = C2Rust_Block_41::S_225;
                };
                {
                    if _fa == _fb {
                        c2rust_current_block_41 = C2Rust_Block_41::S_313;
                    } else {
                        c2rust_current_block_41 = C2Rust_Block_41::S_234;
                    }
                };
            }
            C2Rust_Block_41::S_234 => {
                {
                    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b1684 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_41 = C2Rust_Block_41::S_236;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x2c as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm0).f[0usize],
                    );
                    c2rust_current_block_41 = C2Rust_Block_41::S_238;
                };
                {
                    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_eax).wrapping_add(8 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_41 = C2Rust_Block_41::S_240;
                };
                {
                    (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_ecx).wrapping_add(0x10 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_41 = C2Rust_Block_41::S_246;
                };
                {
                    _fp_value = ::core::ptr::read_volatile::<
                        int32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            int32_t,
                        >(
                            ((*__gamepkg_tls_g_ecx).wrapping_add(0x10 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ) as ::core::ffi::c_double;
                    c2rust_current_block_41 = C2Rust_Block_41::S_248;
                };
                {
                    (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top)
                        as ::core::ffi::c_uint)
                        .wrapping_add(7 as ::core::ffi::c_uint)
                        & 7 as ::core::ffi::c_uint) as ::core::ffi::c_int;
                    c2rust_current_block_41 = C2Rust_Block_41::S_250;
                };
                {
                    (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = _fp_value;
                    c2rust_current_block_41 = C2Rust_Block_41::S_256;
                };
                {
                    _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                    c2rust_current_block_41 = C2Rust_Block_41::S_258;
                };
                {
                    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                    c2rust_current_block_41 = C2Rust_Block_41::S_260;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_41 = C2Rust_Block_41::S_262;
                };
                {
                    _fbs = _fb as int32_t;
                    c2rust_current_block_41 = C2Rust_Block_41::S_264;
                };
                {
                    if if if ::core::mem::size_of::<int32_t>()
                        < ::core::mem::size_of::<int32_t>()
                    {
                        ::core::mem::size_of::<int32_t>()
                    } else {
                        ::core::mem::size_of::<int32_t>()
                    } == 1usize
                    {
                        _fas as uint32_t as uint8_t as int8_t as int32_t
                    } else if if ::core::mem::size_of::<int32_t>()
                        < ::core::mem::size_of::<int32_t>()
                    {
                        ::core::mem::size_of::<int32_t>()
                    } else {
                        ::core::mem::size_of::<int32_t>()
                    } == 2usize
                    {
                        _fas as uint32_t as uint16_t as int16_t as int32_t
                    } else {
                        _fas as uint32_t as int32_t
                    }
                        >= if if ::core::mem::size_of::<int32_t>()
                            < ::core::mem::size_of::<int32_t>()
                        {
                            ::core::mem::size_of::<int32_t>()
                        } else {
                            ::core::mem::size_of::<int32_t>()
                        } == 1usize
                        {
                            _fbs as uint32_t as uint8_t as int8_t as int32_t
                        } else if if ::core::mem::size_of::<int32_t>()
                            < ::core::mem::size_of::<int32_t>()
                        {
                            ::core::mem::size_of::<int32_t>()
                        } else {
                            ::core::mem::size_of::<int32_t>()
                        } == 2usize
                        {
                            _fbs as uint32_t as uint16_t as int16_t as int32_t
                        } else {
                            _fbs as uint32_t as int32_t
                        }
                    {
                        c2rust_current_block_41 = C2Rust_Block_41::S_279;
                    } else {
                        c2rust_current_block_41 = C2Rust_Block_41::S_273;
                    }
                };
            }
            C2Rust_Block_41::S_273 => {
                (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = if (*__gamepkg_tls_g_fp_control_word)
                    as ::core::ffi::c_uint & 0x300 as ::core::ffi::c_uint != 0
                {
                    (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                        + ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b16a8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ) as ::core::ffi::c_double
                } else {
                    recomp_fp_round24(
                        (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                            + ::core::ptr::read_volatile::<
                                ::core::ffi::c_float,
                            >(
                                ::core::ptr::with_exposed_provenance_mut::<
                                    ::core::ffi::c_float,
                                >(
                                    (0x3b16a8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                                ),
                            ) as ::core::ffi::c_double,
                    )
                };
                c2rust_current_block_41 = C2Rust_Block_41::S_279;
            }
            C2Rust_Block_41::S_279 => {
                {
                    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b16c0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_41 = C2Rust_Block_41::S_281;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x34 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                            as ::core::ffi::c_float,
                    );
                    c2rust_current_block_41 = C2Rust_Block_41::S_283;
                };
                {
                    (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top)
                        as ::core::ffi::c_uint)
                        .wrapping_add(1 as ::core::ffi::c_uint)
                        & 7 as ::core::ffi::c_uint) as ::core::ffi::c_int;
                    c2rust_current_block_41 = C2Rust_Block_41::S_285;
                };
                {
                    (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_esp)
                        .wrapping_add(0x10 as uint32_t);
                    c2rust_current_block_41 = C2Rust_Block_41::S_287;
                };
                {
                    (*__gamepkg_tls_g_esi) = 0x40b844 as uint32_t;
                    c2rust_current_block_41 = C2Rust_Block_41::S_289;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x54 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        1 as uint8_t,
                    );
                    c2rust_current_block_41 = C2Rust_Block_41::S_291;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x38 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm0).f[0usize],
                    );
                    c2rust_current_block_41 = C2Rust_Block_41::S_297;
                };
                {
                    _pv_6 = 0x1422fe as ::core::ffi::c_uint as uint32_t;
                    c2rust_current_block_41 = C2Rust_Block_41::S_299;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_41 = C2Rust_Block_41::S_301;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_6,
                    );
                    c2rust_current_block_41 = C2Rust_Block_41::S_307;
                };
                {
                    sub_001CD8D0();
                    c2rust_current_block_41 = C2Rust_Block_41::S_313;
                };
            }
            C2Rust_Block_41::S_313 => {
                {
                    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (ebp.wrapping_add(0x7c as uint32_t) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_41 = C2Rust_Block_41::S_319;
                };
                {
                    _pv_7 = (*__gamepkg_tls_g_ebx);
                    c2rust_current_block_41 = C2Rust_Block_41::S_321;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_41 = C2Rust_Block_41::S_323;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_7,
                    );
                    c2rust_current_block_41 = C2Rust_Block_41::S_333;
                };
                {
                    _pv_8 = (*__gamepkg_tls_g_eax);
                    c2rust_current_block_41 = C2Rust_Block_41::S_335;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_41 = C2Rust_Block_41::S_337;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_8,
                    );
                    c2rust_current_block_41 = C2Rust_Block_41::S_343;
                };
                {
                    (*__gamepkg_tls_g_eax) = 0x39c350 as uint32_t;
                    c2rust_current_block_41 = C2Rust_Block_41::S_349;
                };
                {
                    _pv_9 = 0x14230d as ::core::ffi::c_uint as uint32_t;
                    c2rust_current_block_41 = C2Rust_Block_41::S_351;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_41 = C2Rust_Block_41::S_353;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_9,
                    );
                    c2rust_current_block_41 = C2Rust_Block_41::S_359;
                };
                {
                    sub_001C99D0();
                    c2rust_current_block_41 = C2Rust_Block_41::S_365;
                };
                {
                    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                    c2rust_current_block_41 = C2Rust_Block_41::S_367;
                };
                {
                    _fb = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
                    c2rust_current_block_41 = C2Rust_Block_41::S_369;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_41 = C2Rust_Block_41::S_371;
                };
                {
                    _fbs = _fb as int32_t;
                    c2rust_current_block_41 = C2Rust_Block_41::S_373;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x28 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_eax),
                    );
                    c2rust_current_block_41 = C2Rust_Block_41::S_375;
                };
                {
                    if _fa == _fb {
                        c2rust_current_block_41 = C2Rust_Block_41::S_416;
                    } else {
                        c2rust_current_block_41 = C2Rust_Block_41::S_384;
                    }
                };
            }
            C2Rust_Block_41::S_384 => {
                {
                    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b168c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_41 = C2Rust_Block_41::S_386;
                };
                {
                    (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_esp)
                        .wrapping_add(0x10 as uint32_t);
                    c2rust_current_block_41 = C2Rust_Block_41::S_388;
                };
                {
                    (*__gamepkg_tls_g_esi) = 0x40b844 as uint32_t;
                    c2rust_current_block_41 = C2Rust_Block_41::S_390;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x38 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm0).f[0usize],
                    );
                    c2rust_current_block_41 = C2Rust_Block_41::S_396;
                };
                {
                    _pv_10 = 0x142331 as ::core::ffi::c_uint as uint32_t;
                    c2rust_current_block_41 = C2Rust_Block_41::S_398;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_41 = C2Rust_Block_41::S_400;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_10,
                    );
                    c2rust_current_block_41 = C2Rust_Block_41::S_406;
                };
                {
                    sub_001CD8D0();
                    c2rust_current_block_41 = C2Rust_Block_41::S_416;
                };
            }
            C2Rust_Block_41::S_416 => {
                {
                    (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_41 = C2Rust_Block_41::S_418;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_add(4 as uint32_t);
                    c2rust_current_block_41 = C2Rust_Block_41::S_424;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (ebp.wrapping_add(0x69 as uint32_t) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        0x14 as uint8_t,
                    );
                    c2rust_current_block_41 = C2Rust_Block_41::S_430;
                };
                {
                    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_41 = C2Rust_Block_41::S_432;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_add(4 as uint32_t);
                    c2rust_current_block_41 = C2Rust_Block_41::S_446;
                };
            }
            C2Rust_Block_41::S_446 => {
                {
                    ebp = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_41 = C2Rust_Block_41::S_448;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_add(4 as uint32_t);
                    c2rust_current_block_41 = C2Rust_Block_41::S_458;
                };
                {
                    (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_41 = C2Rust_Block_41::S_460;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_add(4 as uint32_t);
                    c2rust_current_block_41 = C2Rust_Block_41::S_466;
                };
                {
                    _fb = 0x48 as ::core::ffi::c_int as uint32_t
                        & 0xffffffff as uint32_t;
                    c2rust_current_block_41 = C2Rust_Block_41::S_468;
                };
                {
                    _fbs = _fb as int32_t;
                    c2rust_current_block_41 = C2Rust_Block_41::S_470;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_add(0x48 as uint32_t);
                    c2rust_current_block_41 = C2Rust_Block_41::S_472;
                };
                {
                    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                    c2rust_current_block_41 = C2Rust_Block_41::S_474;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_41 = C2Rust_Block_41::S_476;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_add(8 as uint32_t);
                    c2rust_current_block_41 = C2Rust_Block_41::S_478;
                };
                return;
            }
            C2Rust_Block_41::S_101
            | C2Rust_Block_41::S_103
            | C2Rust_Block_41::S_105
            | C2Rust_Block_41::S_115
            | C2Rust_Block_41::S_117
            | C2Rust_Block_41::S_119
            | C2Rust_Block_41::S_125
            | C2Rust_Block_41::S_127
            | C2Rust_Block_41::S_129
            | C2Rust_Block_41::S_131
            | C2Rust_Block_41::S_133
            | C2Rust_Block_41::S_139
            | C2Rust_Block_41::S_141
            | C2Rust_Block_41::S_143
            | C2Rust_Block_41::S_149
            | C2Rust_Block_41::S_151
            | C2Rust_Block_41::S_157
            | C2Rust_Block_41::S_159
            | C2Rust_Block_41::S_161
            | C2Rust_Block_41::S_167
            | C2Rust_Block_41::S_169
            | C2Rust_Block_41::S_171
            | C2Rust_Block_41::S_173
            | C2Rust_Block_41::S_175
            | C2Rust_Block_41::S_177
            | C2Rust_Block_41::S_179
            | C2Rust_Block_41::S_18
            | C2Rust_Block_41::S_181
            | C2Rust_Block_41::S_183
            | C2Rust_Block_41::S_185
            | C2Rust_Block_41::S_187
            | C2Rust_Block_41::S_189
            | C2Rust_Block_41::S_191
            | C2Rust_Block_41::S_193
            | C2Rust_Block_41::S_199
            | C2Rust_Block_41::S_2
            | C2Rust_Block_41::S_201
            | C2Rust_Block_41::S_203
            | C2Rust_Block_41::S_209
            | C2Rust_Block_41::S_215
            | C2Rust_Block_41::S_217
            | C2Rust_Block_41::S_219
            | C2Rust_Block_41::S_221
            | C2Rust_Block_41::S_223
            | C2Rust_Block_41::S_225
            | C2Rust_Block_41::S_236
            | C2Rust_Block_41::S_238
            | C2Rust_Block_41::S_24
            | C2Rust_Block_41::S_240
            | C2Rust_Block_41::S_246
            | C2Rust_Block_41::S_248
            | C2Rust_Block_41::S_250
            | C2Rust_Block_41::S_256
            | C2Rust_Block_41::S_258
            | C2Rust_Block_41::S_26
            | C2Rust_Block_41::S_260
            | C2Rust_Block_41::S_262
            | C2Rust_Block_41::S_264
            | C2Rust_Block_41::S_28
            | C2Rust_Block_41::S_281
            | C2Rust_Block_41::S_283
            | C2Rust_Block_41::S_285
            | C2Rust_Block_41::S_287
            | C2Rust_Block_41::S_289
            | C2Rust_Block_41::S_291
            | C2Rust_Block_41::S_297
            | C2Rust_Block_41::S_299
            | C2Rust_Block_41::S_30
            | C2Rust_Block_41::S_301
            | C2Rust_Block_41::S_307
            | C2Rust_Block_41::S_319
            | C2Rust_Block_41::S_32
            | C2Rust_Block_41::S_321
            | C2Rust_Block_41::S_323
            | C2Rust_Block_41::S_333
            | C2Rust_Block_41::S_335
            | C2Rust_Block_41::S_337
            | C2Rust_Block_41::S_343
            | C2Rust_Block_41::S_349
            | C2Rust_Block_41::S_351
            | C2Rust_Block_41::S_353
            | C2Rust_Block_41::S_359
            | C2Rust_Block_41::S_365
            | C2Rust_Block_41::S_367
            | C2Rust_Block_41::S_369
            | C2Rust_Block_41::S_371
            | C2Rust_Block_41::S_373
            | C2Rust_Block_41::S_375
            | C2Rust_Block_41::S_38
            | C2Rust_Block_41::S_386
            | C2Rust_Block_41::S_388
            | C2Rust_Block_41::S_390
            | C2Rust_Block_41::S_396
            | C2Rust_Block_41::S_398
            | C2Rust_Block_41::S_4
            | C2Rust_Block_41::S_40
            | C2Rust_Block_41::S_400
            | C2Rust_Block_41::S_406
            | C2Rust_Block_41::S_418
            | C2Rust_Block_41::S_42
            | C2Rust_Block_41::S_424
            | C2Rust_Block_41::S_430
            | C2Rust_Block_41::S_432
            | C2Rust_Block_41::S_448
            | C2Rust_Block_41::S_458
            | C2Rust_Block_41::S_460
            | C2Rust_Block_41::S_466
            | C2Rust_Block_41::S_468
            | C2Rust_Block_41::S_470
            | C2Rust_Block_41::S_472
            | C2Rust_Block_41::S_474
            | C2Rust_Block_41::S_476
            | C2Rust_Block_41::S_478
            | C2Rust_Block_41::S_52
            | C2Rust_Block_41::S_54
            | C2Rust_Block_41::S_56
            | C2Rust_Block_41::S_6
            | C2Rust_Block_41::S_62
            | C2Rust_Block_41::S_64
            | C2Rust_Block_41::S_66
            | C2Rust_Block_41::S_68
            | C2Rust_Block_41::S_70
            | C2Rust_Block_41::S_72
            | C2Rust_Block_41::S_74
            | C2Rust_Block_41::S_76
            | C2Rust_Block_41::S_78
            | C2Rust_Block_41::S_8
            | C2Rust_Block_41::S_80
            | C2Rust_Block_41::S_91
            | C2Rust_Block_41::S_93
            | C2Rust_Block_41::S_95 => {
                unreachable!("GamePKG compacted dispatch state reached")
            }
        }
    };
}
#[no_mangle]
pub unsafe extern "C" fn sub_00142340() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 0xffffff00 as uint32_t
        | ::core::ptr::read_volatile::<
            uint8_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint8_t,
            >(
                ((*__gamepkg_tls_g_esi).wrapping_add(0x13 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ) as uint32_t;
    let mut _pv: uint32_t = 0x3e19999a as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    let mut _pv_0: uint32_t = 1 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    let mut _pv_1: uint32_t = 0x3f800000 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    let mut _pv_2: uint32_t = 0x3f800000 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_2,
    );
    _fa = ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t as uint32_t
        & 0xff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
    _fas = _fa as int8_t as int32_t;
    _fbs = _fb as int8_t as int32_t;
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x7c as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv_3: uint32_t = 0xa8c5d19d as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_3,
    );
    's_169: {
        if _fa == _fb {
            break 's_169;
        }
        let mut _pv_4: uint32_t = 0x149a0000 as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_4,
        );
        let mut _pv_5: uint32_t = 0x14236a as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_5,
        );
        sub_00141010();
        (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 0xffffff00 as uint32_t
            | ::core::ptr::read_volatile::<
                uint8_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint8_t,
                >(
                    ((*__gamepkg_tls_g_esi).wrapping_add(0x13 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            ) as uint32_t;
        _fa = ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t as uint32_t
            & 0xff as uint32_t;
        _fb = 0 as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
        _fas = _fa as int8_t as int32_t;
        _fbs = _fb as int8_t as int32_t;
        (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 0xffffff00 as uint32_t
            | (if _fa == _fb {
                1 as ::core::ffi::c_int
            } else {
                0 as ::core::ffi::c_int
            }) as uint8_t as uint32_t;
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint8_t,
            >(
                ((*__gamepkg_tls_g_esi).wrapping_add(0x13 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t,
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        return;
    }
    let mut _pv_6: uint32_t = 0x1ab48000 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_6,
    );
    let mut _pv_7: uint32_t = 0x142380 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_7,
    );
    sub_00141010();
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 0xffffff00 as uint32_t
        | ::core::ptr::read_volatile::<
            uint8_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint8_t,
            >(
                ((*__gamepkg_tls_g_esi).wrapping_add(0x13 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ) as uint32_t;
    _fa = ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t as uint32_t
        & 0xff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
    _fas = _fa as int8_t as int32_t;
    _fbs = _fb as int8_t as int32_t;
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 0xffffff00 as uint32_t
        | (if _fa == _fb { 1 as ::core::ffi::c_int } else { 0 as ::core::ffi::c_int })
            as uint8_t as uint32_t;
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint8_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x13 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t,
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00142390() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0x7c as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv: uint32_t = 0x3e4ccccd as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    let mut _pv_0: uint32_t = 0 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    let mut _pv_1: uint32_t = 0x3f800000 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    let mut _pv_2: uint32_t = 0x3f800000 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_2,
    );
    let mut _pv_3: uint32_t = 0xa8b667c9 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_3,
    );
    let mut _pv_4: uint32_t = 0x26300000 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_4,
    );
    let mut _pv_5: uint32_t = 0x1423b3 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_5,
    );
    sub_00141010();
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001423C0() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0x7c as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv: uint32_t = 0x3e4ccccd as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    let mut _pv_0: uint32_t = 0 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    let mut _pv_1: uint32_t = 0x3f800000 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    let mut _pv_2: uint32_t = 0x3f800000 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_2,
    );
    let mut _pv_3: uint32_t = 0xa8c02e2f as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_3,
    );
    let mut _pv_4: uint32_t = 0x34ac8000 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_4,
    );
    let mut _pv_5: uint32_t = 0x1423e3 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_5,
    );
    sub_00141010();
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001423F0() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0x7c as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv: uint32_t = 0 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    let mut _pv_0: uint32_t = 0 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    let mut _pv_1: uint32_t = 0x3f800000 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    let mut _pv_2: uint32_t = 0x3ee66666 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_2,
    );
    let mut _pv_3: uint32_t = 0xbebb1cdb as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_3,
    );
    let mut _pv_4: uint32_t = 0x8db40000 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_4,
    );
    let mut _pv_5: uint32_t = 0x142410 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_5,
    );
    sub_00141010();
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00142420() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0x7c as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv: uint32_t = 0 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    let mut _pv_0: uint32_t = 0 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    let mut _pv_1: uint32_t = 0x3f800000 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    let mut _pv_2: uint32_t = 0x3f333333 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_2,
    );
    let mut _pv_3: uint32_t = 0x6048d35d as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_3,
    );
    let mut _pv_4: uint32_t = 0x3000000 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_4,
    );
    let mut _pv_5: uint32_t = 0x142440 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_5,
    );
    sub_00141010();
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00142450() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 0xffffff00 as uint32_t
        | ::core::ptr::read_volatile::<
            uint8_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint8_t,
            >(
                ((*__gamepkg_tls_g_esi).wrapping_add(0x69 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ) as uint32_t;
    _fa = ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t as uint32_t
        & 0xff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
    _fas = _fa as int8_t as int32_t;
    _fbs = _fb as int8_t as int32_t;
    's_151: {
        if _fa != _fb {
            break 's_151;
        }
        (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi).wrapping_add(0x7c as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        let mut _pv: uint32_t = 0 as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv,
        );
        let mut _pv_0: uint32_t = 0 as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_0,
        );
        let mut _pv_1: uint32_t = 0x3f800000 as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_1,
        );
        let mut _pv_2: uint32_t = 0x3f800000 as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_2,
        );
        let mut _pv_3: uint32_t = 0xa4f3b88c as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_3,
        );
        let mut _pv_4: uint32_t = 0xe6900000 as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_4,
        );
        let mut _pv_5: uint32_t = 0x142477 as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_5,
        );
        sub_00141010();
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint8_t,
            >(
                ((*__gamepkg_tls_g_esi).wrapping_add(0x69 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            8 as uint8_t,
        );
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint8_t,
            >(
                ((*__gamepkg_tls_g_esi).wrapping_add(0x68 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            0x10 as uint8_t,
        );
    }
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00142480() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0x7c as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv: uint32_t = 0 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    let mut _pv_0: uint32_t = 0 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    let mut _pv_1: uint32_t = 0x3f800000 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    let mut _pv_2: uint32_t = 0x3f800000 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_2,
    );
    let mut _pv_3: uint32_t = 0xbd608e17 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_3,
    );
    let mut _pv_4: uint32_t = 0x8ea1c000 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_4,
    );
    let mut _pv_5: uint32_t = 0x1424a0 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_5,
    );
    sub_00141010();
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001424B0() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
    _fb = 1 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_35: {
        if _fa == _fb {
            break 's_35;
        }
        _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
        _fb = 2 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fbs = _fb as int32_t;
        's_166: {
            if _fa == _fb {
                break 's_166;
            }
            _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
            _fb = 3 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            _fbs = _fb as int32_t;
            's_297: {
                if _fa == _fb {
                    break 's_297;
                }
                _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                _fb = 4 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                _fas = _fa as int32_t;
                _fbs = _fb as int32_t;
                's_534: {
                    if _fa != _fb {
                        break 's_534;
                    }
                    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_eax).wrapping_add(0x7c as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    let mut _pv_20: uint32_t = 0 as ::core::ffi::c_int as uint32_t;
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_20,
                    );
                    let mut _pv_21: uint32_t = 0 as ::core::ffi::c_int as uint32_t;
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_21,
                    );
                    let mut _pv_22: uint32_t = 0x3f800000 as ::core::ffi::c_int
                        as uint32_t;
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_22,
                    );
                    let mut _pv_23: uint32_t = 0x3f400000 as ::core::ffi::c_int
                        as uint32_t;
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_23,
                    );
                    let mut _pv_24: uint32_t = 0xbc3dd2e8 as ::core::ffi::c_uint
                        as uint32_t;
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_24,
                    );
                    let mut _pv_25: uint32_t = 0xd0600000 as ::core::ffi::c_uint
                        as uint32_t;
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_25,
                    );
                    let mut _pv_26: uint32_t = 0x142547 as ::core::ffi::c_uint
                        as uint32_t;
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_26,
                    );
                    sub_00141010();
                }
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                return;
            }
            (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_eax).wrapping_add(0x7c as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            let mut _pv_13: uint32_t = 0 as ::core::ffi::c_int as uint32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_13,
            );
            let mut _pv_14: uint32_t = 0 as ::core::ffi::c_int as uint32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_14,
            );
            let mut _pv_15: uint32_t = 0x3f800000 as ::core::ffi::c_int as uint32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_15,
            );
            let mut _pv_16: uint32_t = 0x3f19999a as ::core::ffi::c_int as uint32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_16,
            );
            let mut _pv_17: uint32_t = 0xbc3dd2c2 as ::core::ffi::c_uint as uint32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_17,
            );
            let mut _pv_18: uint32_t = 0xaac00000 as ::core::ffi::c_uint as uint32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_18,
            );
            let mut _pv_19: uint32_t = 0x142521 as ::core::ffi::c_uint as uint32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_19,
            );
            sub_00141010();
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
            return;
        }
        (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_eax).wrapping_add(0x7c as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        let mut _pv_6: uint32_t = 0 as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_6,
        );
        let mut _pv_7: uint32_t = 0 as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_7,
        );
        let mut _pv_8: uint32_t = 0x3f800000 as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_8,
        );
        let mut _pv_9: uint32_t = 0x3f000000 as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_9,
        );
        let mut _pv_10: uint32_t = 0xbc3dd29c as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_10,
        );
        let mut _pv_11: uint32_t = 0x85200000 as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_11,
        );
        let mut _pv_12: uint32_t = 0x1424fb as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_12,
        );
        sub_00141010();
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        return;
    }
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0x7c as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv: uint32_t = 0 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    let mut _pv_0: uint32_t = 0 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    let mut _pv_1: uint32_t = 0x3f800000 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    let mut _pv_2: uint32_t = 0x3ecccccd as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_2,
    );
    let mut _pv_3: uint32_t = 0xbc3dd276 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_3,
    );
    let mut _pv_4: uint32_t = 0x5f800000 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_4,
    );
    let mut _pv_5: uint32_t = 0x1424d5 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_5,
    );
    sub_00141010();
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00142550() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    let __gamepkg_tls_g_xmm1 = unsafe { gamepkg_tls_g_xmm1() };
    let mut ebp: uint32_t = 0;
    let mut _flags: ::core::ffi::c_int = 0;
    let mut _fa: uint32_t = 0;
    let mut _fb: uint32_t = 0;
    let mut _fas: int32_t = 0;
    let mut _fbs: int32_t = 0;
    let mut _pv: uint32_t = 0;
    let mut _pv_0: uint32_t = 0;
    let mut _pv_1: uint32_t = 0;
    let mut _pv_2: uint32_t = 0;
    let mut _pv_3: uint32_t = 0;
    let mut _pv_4: uint32_t = 0;
    let mut _pv_5: uint32_t = 0;
    let mut _pv_6: uint32_t = 0;
    let mut _pv_7: uint32_t = 0;
    let mut _pv_8: uint32_t = 0;
    let mut _pv_9: uint32_t = 0;
    let mut _pv_10: uint32_t = 0;
    let mut _pv_11: uint32_t = 0;
    let mut _pv_12: uint32_t = 0;
    let mut _pv_13: uint32_t = 0;
    let mut _pv_14: uint32_t = 0;
    let mut _pv_15: uint32_t = 0;
    let mut _pv_16: uint32_t = 0;
    let mut _pv_17: uint32_t = 0;
    let mut _pv_18: uint32_t = 0;
    let mut _pv_19: uint32_t = 0;
    let mut _pv_20: uint32_t = 0;
    let mut _pv_21: uint32_t = 0;
    let mut _pv_22: uint32_t = 0;
    let mut _pv_23: uint32_t = 0;
    let mut _pv_24: uint32_t = 0;
    let mut _pv_25: uint32_t = 0;
    let mut _pv_26: uint32_t = 0;
    let mut _pv_27: uint32_t = 0;
    let mut _pv_28: uint32_t = 0;
    let mut _pv_29: uint32_t = 0;
    enum C2Rust_Block_50 {
        S_0,
        S_2,
        S_4,
        S_6,
        S_8,
        S_26,
        S_28,
        S_30,
        S_36,
        S_38,
        S_40,
        S_42,
        S_44,
        S_46,
        S_48,
        S_50,
        S_52,
        S_54,
        S_56,
        S_58,
        S_60,
        S_66,
        S_68,
        S_70,
        S_80,
        S_82,
        S_84,
        S_90,
        S_92,
        S_94,
        S_96,
        S_98,
        S_100,
        S_102,
        S_104,
        S_106,
        S_108,
        S_110,
        S_112,
        S_114,
        S_123,
        S_129,
        S_131,
        S_133,
        S_143,
        S_145,
        S_147,
        S_157,
        S_159,
        S_161,
        S_171,
        S_173,
        S_175,
        S_181,
        S_183,
        S_189,
        S_191,
        S_193,
        S_199,
        S_205,
        S_207,
        S_209,
        S_211,
        S_213,
        S_215,
        S_224,
        S_226,
        S_228,
        S_230,
        S_232,
        S_234,
        S_247,
        S_249,
        S_251,
        S_261,
        S_263,
        S_265,
        S_275,
        S_277,
        S_279,
        S_289,
        S_291,
        S_293,
        S_299,
        S_301,
        S_307,
        S_309,
        S_311,
        S_317,
        S_323,
        S_329,
        S_331,
        S_333,
        S_335,
        S_337,
        S_339,
        S_348,
        S_350,
        S_352,
        S_358,
        S_360,
        S_362,
        S_368,
        S_378,
        S_380,
        S_382,
        S_388,
        S_394,
        S_396,
        S_398,
        S_404,
        S_406,
        S_408,
        S_410,
        S_416,
        S_418,
        S_420,
        S_426,
        S_432,
        S_434,
        S_436,
        S_438,
        S_440,
        S_442,
        S_444,
        S_453,
        S_455,
        S_457,
        S_463,
        S_465,
        S_467,
        S_473,
        S_483,
        S_485,
        S_487,
        S_493,
        S_499,
        S_501,
        S_503,
        S_509,
        S_511,
        S_513,
        S_515,
        S_521,
        S_523,
        S_525,
        S_531,
        S_537,
        S_539,
        S_541,
        S_543,
        S_549,
        S_551,
        S_553,
        S_559,
        S_565,
        S_571,
        S_573,
        S_575,
        S_581,
        S_587,
        S_589,
        S_591,
        S_597,
        S_599,
        S_601,
        S_603,
        S_609,
        S_611,
        S_613,
        S_619,
        S_625,
        S_627,
        S_629,
        S_631,
        S_637,
        S_639,
        S_641,
        S_647,
        S_653,
        S_655,
        S_661,
        S_663,
        S_665,
        S_671,
        S_677,
        S_679,
        S_681,
        S_687,
        S_689,
        S_691,
        S_697,
        S_699,
        S_701,
        S_707,
        S_713,
        S_719,
        S_721,
        S_727,
        S_729,
        S_731,
        S_737,
        S_743,
        S_745,
        S_751,
        S_753,
        S_755,
        S_761,
        S_767,
        S_769,
        S_771,
        S_773,
        S_775,
        S_777,
        S_779,
        S_781,
        S_783,
        S_789,
        S_791,
        S_801,
        S_803,
        S_809,
        S_815,
        S_817,
        S_823,
        S_825,
        S_835,
        S_837,
        S_843,
        S_845,
        S_847,
        S_853,
        S_855,
        S_861,
        S_867,
        S_869,
        S_875,
        S_877,
    }
    let mut c2rust_current_block_50: C2Rust_Block_50;
    c2rust_current_block_50 = C2Rust_Block_50::S_0;
    loop {
        match c2rust_current_block_50 {
            C2Rust_Block_50::S_0 => {
                {
                    ebp = 0 as uint32_t;
                    c2rust_current_block_50 = C2Rust_Block_50::S_2;
                };
                {
                    ebp = (*__gamepkg_tls_g_ebp);
                    c2rust_current_block_50 = C2Rust_Block_50::S_4;
                };
                {
                    _flags = 0 as ::core::ffi::c_int;
                    c2rust_current_block_50 = C2Rust_Block_50::S_6;
                };
                {
                    _fa = 0 as uint32_t;
                    _fb = 0 as uint32_t;
                    c2rust_current_block_50 = C2Rust_Block_50::S_8;
                };
                {
                    _fas = 0 as int32_t;
                    _fbs = 0 as int32_t;
                    c2rust_current_block_50 = C2Rust_Block_50::S_26;
                };
                {
                    _pv = ebp;
                    c2rust_current_block_50 = C2Rust_Block_50::S_28;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_50 = C2Rust_Block_50::S_30;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv,
                    );
                    c2rust_current_block_50 = C2Rust_Block_50::S_36;
                };
                {
                    ebp = (*__gamepkg_tls_g_esp);
                    c2rust_current_block_50 = C2Rust_Block_50::S_38;
                };
                {
                    (*__gamepkg_tls_g_ebp) = ebp;
                    c2rust_current_block_50 = C2Rust_Block_50::S_40;
                };
                {
                    (*__gamepkg_tls_g_seh_ebp) = ebp;
                    c2rust_current_block_50 = C2Rust_Block_50::S_42;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        & 0xfffffff8 as uint32_t;
                    c2rust_current_block_50 = C2Rust_Block_50::S_44;
                };
                {
                    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                    c2rust_current_block_50 = C2Rust_Block_50::S_46;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_50 = C2Rust_Block_50::S_48;
                };
                {
                    _fb = 8 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                    c2rust_current_block_50 = C2Rust_Block_50::S_50;
                };
                {
                    _fbs = _fb as int32_t;
                    c2rust_current_block_50 = C2Rust_Block_50::S_52;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(8 as uint32_t);
                    c2rust_current_block_50 = C2Rust_Block_50::S_54;
                };
                {
                    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                    c2rust_current_block_50 = C2Rust_Block_50::S_56;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_50 = C2Rust_Block_50::S_58;
                };
                {
                    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b168c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_50 = C2Rust_Block_50::S_60;
                };
                {
                    (*__gamepkg_tls_g_xmm1) = XMM_ZERO();
                    c2rust_current_block_50 = C2Rust_Block_50::S_66;
                };
                {
                    _pv_0 = (*__gamepkg_tls_g_esi);
                    c2rust_current_block_50 = C2Rust_Block_50::S_68;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_50 = C2Rust_Block_50::S_70;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_0,
                    );
                    c2rust_current_block_50 = C2Rust_Block_50::S_80;
                };
                {
                    _pv_1 = (*__gamepkg_tls_g_edi);
                    c2rust_current_block_50 = C2Rust_Block_50::S_82;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_50 = C2Rust_Block_50::S_84;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_1,
                    );
                    c2rust_current_block_50 = C2Rust_Block_50::S_90;
                };
                {
                    (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_eax);
                    c2rust_current_block_50 = C2Rust_Block_50::S_92;
                };
                {
                    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_edi).wrapping_add(8 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_50 = C2Rust_Block_50::S_94;
                };
                {
                    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                    c2rust_current_block_50 = C2Rust_Block_50::S_96;
                };
                {
                    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                    c2rust_current_block_50 = C2Rust_Block_50::S_98;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_50 = C2Rust_Block_50::S_100;
                };
                {
                    _fbs = _fb as int32_t;
                    c2rust_current_block_50 = C2Rust_Block_50::S_102;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_edi).wrapping_add(4 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        0 as uint32_t,
                    );
                    c2rust_current_block_50 = C2Rust_Block_50::S_104;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_edi) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        0 as uint32_t,
                    );
                    c2rust_current_block_50 = C2Rust_Block_50::S_106;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            ((*__gamepkg_tls_g_edi).wrapping_add(0x20 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm0).f[0usize],
                    );
                    c2rust_current_block_50 = C2Rust_Block_50::S_108;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            ((*__gamepkg_tls_g_edi).wrapping_add(0x24 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm1).f[0usize],
                    );
                    c2rust_current_block_50 = C2Rust_Block_50::S_110;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            ((*__gamepkg_tls_g_edi).wrapping_add(0x30 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm0).f[0usize],
                    );
                    c2rust_current_block_50 = C2Rust_Block_50::S_112;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            ((*__gamepkg_tls_g_edi).wrapping_add(0x34 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm0).f[0usize],
                    );
                    c2rust_current_block_50 = C2Rust_Block_50::S_114;
                };
                {
                    if _fa != _fb {
                        c2rust_current_block_50 = C2Rust_Block_50::S_224;
                    } else {
                        c2rust_current_block_50 = C2Rust_Block_50::S_123;
                    }
                };
            }
            C2Rust_Block_50::S_123 => {
                {
                    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x3ec270 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_50 = C2Rust_Block_50::S_129;
                };
                {
                    _pv_2 = 0x2000 as ::core::ffi::c_int as uint32_t;
                    c2rust_current_block_50 = C2Rust_Block_50::S_131;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_50 = C2Rust_Block_50::S_133;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_2,
                    );
                    c2rust_current_block_50 = C2Rust_Block_50::S_143;
                };
                {
                    _pv_3 = 1 as ::core::ffi::c_int as uint32_t;
                    c2rust_current_block_50 = C2Rust_Block_50::S_145;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_50 = C2Rust_Block_50::S_147;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_3,
                    );
                    c2rust_current_block_50 = C2Rust_Block_50::S_157;
                };
                {
                    _pv_4 = (*__gamepkg_tls_g_eax);
                    c2rust_current_block_50 = C2Rust_Block_50::S_159;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_50 = C2Rust_Block_50::S_161;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_4,
                    );
                    c2rust_current_block_50 = C2Rust_Block_50::S_171;
                };
                {
                    _pv_5 = 0x40b7f4 as ::core::ffi::c_int as uint32_t;
                    c2rust_current_block_50 = C2Rust_Block_50::S_173;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_50 = C2Rust_Block_50::S_175;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_5,
                    );
                    c2rust_current_block_50 = C2Rust_Block_50::S_181;
                };
                {
                    (*__gamepkg_tls_g_ebp) = ebp;
                    c2rust_current_block_50 = C2Rust_Block_50::S_183;
                };
                {
                    (*__gamepkg_tls_g_seh_ebp) = ebp;
                    c2rust_current_block_50 = C2Rust_Block_50::S_189;
                };
                {
                    _pv_6 = 0x1425a7 as ::core::ffi::c_uint as uint32_t;
                    c2rust_current_block_50 = C2Rust_Block_50::S_191;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_50 = C2Rust_Block_50::S_193;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_6,
                    );
                    c2rust_current_block_50 = C2Rust_Block_50::S_199;
                };
                {
                    sub_001C9C80();
                    c2rust_current_block_50 = C2Rust_Block_50::S_205;
                };
                {
                    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                    c2rust_current_block_50 = C2Rust_Block_50::S_207;
                };
                {
                    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                    c2rust_current_block_50 = C2Rust_Block_50::S_209;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_50 = C2Rust_Block_50::S_211;
                };
                {
                    _fbs = _fb as int32_t;
                    c2rust_current_block_50 = C2Rust_Block_50::S_213;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_edi).wrapping_add(8 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_eax),
                    );
                    c2rust_current_block_50 = C2Rust_Block_50::S_215;
                };
                {
                    if _fa == _fb {
                        c2rust_current_block_50 = C2Rust_Block_50::S_835;
                    } else {
                        c2rust_current_block_50 = C2Rust_Block_50::S_224;
                    }
                };
            }
            C2Rust_Block_50::S_224 => {
                {
                    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_edi).wrapping_add(0x44 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_50 = C2Rust_Block_50::S_226;
                };
                {
                    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                    c2rust_current_block_50 = C2Rust_Block_50::S_228;
                };
                {
                    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                    c2rust_current_block_50 = C2Rust_Block_50::S_230;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_50 = C2Rust_Block_50::S_232;
                };
                {
                    _fbs = _fb as int32_t;
                    c2rust_current_block_50 = C2Rust_Block_50::S_234;
                };
                {
                    if _fa != _fb {
                        c2rust_current_block_50 = C2Rust_Block_50::S_329;
                    } else {
                        c2rust_current_block_50 = C2Rust_Block_50::S_247;
                    }
                };
            }
            C2Rust_Block_50::S_247 => {
                {
                    _pv_7 = 0x2000 as ::core::ffi::c_int as uint32_t;
                    c2rust_current_block_50 = C2Rust_Block_50::S_249;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_50 = C2Rust_Block_50::S_251;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_7,
                    );
                    c2rust_current_block_50 = C2Rust_Block_50::S_261;
                };
                {
                    _pv_8 = 1 as ::core::ffi::c_int as uint32_t;
                    c2rust_current_block_50 = C2Rust_Block_50::S_263;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_50 = C2Rust_Block_50::S_265;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_8,
                    );
                    c2rust_current_block_50 = C2Rust_Block_50::S_275;
                };
                {
                    _pv_9 = 0x3ad1e8 as ::core::ffi::c_int as uint32_t;
                    c2rust_current_block_50 = C2Rust_Block_50::S_277;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_50 = C2Rust_Block_50::S_279;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_9,
                    );
                    c2rust_current_block_50 = C2Rust_Block_50::S_289;
                };
                {
                    _pv_10 = 0x40b7f4 as ::core::ffi::c_int as uint32_t;
                    c2rust_current_block_50 = C2Rust_Block_50::S_291;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_50 = C2Rust_Block_50::S_293;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_10,
                    );
                    c2rust_current_block_50 = C2Rust_Block_50::S_299;
                };
                {
                    (*__gamepkg_tls_g_ebp) = ebp;
                    c2rust_current_block_50 = C2Rust_Block_50::S_301;
                };
                {
                    (*__gamepkg_tls_g_seh_ebp) = ebp;
                    c2rust_current_block_50 = C2Rust_Block_50::S_307;
                };
                {
                    _pv_11 = 0x1425cf as ::core::ffi::c_uint as uint32_t;
                    c2rust_current_block_50 = C2Rust_Block_50::S_309;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_50 = C2Rust_Block_50::S_311;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_11,
                    );
                    c2rust_current_block_50 = C2Rust_Block_50::S_317;
                };
                {
                    sub_001C9C80();
                    c2rust_current_block_50 = C2Rust_Block_50::S_323;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_edi).wrapping_add(0x44 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_eax),
                    );
                    c2rust_current_block_50 = C2Rust_Block_50::S_329;
                };
            }
            C2Rust_Block_50::S_329 => {
                {
                    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_edi).wrapping_add(0x44 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_50 = C2Rust_Block_50::S_331;
                };
                {
                    _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
                    c2rust_current_block_50 = C2Rust_Block_50::S_333;
                };
                {
                    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                    c2rust_current_block_50 = C2Rust_Block_50::S_335;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_50 = C2Rust_Block_50::S_337;
                };
                {
                    _fbs = _fb as int32_t;
                    c2rust_current_block_50 = C2Rust_Block_50::S_339;
                };
                {
                    if _fa == _fb {
                        c2rust_current_block_50 = C2Rust_Block_50::S_835;
                    } else {
                        c2rust_current_block_50 = C2Rust_Block_50::S_348;
                    }
                };
            }
            C2Rust_Block_50::S_348 => {
                {
                    (*__gamepkg_tls_g_eax) = 0x3ad240 as uint32_t;
                    c2rust_current_block_50 = C2Rust_Block_50::S_350;
                };
                {
                    (*__gamepkg_tls_g_ebp) = ebp;
                    c2rust_current_block_50 = C2Rust_Block_50::S_352;
                };
                {
                    (*__gamepkg_tls_g_seh_ebp) = ebp;
                    c2rust_current_block_50 = C2Rust_Block_50::S_358;
                };
                {
                    _pv_12 = 0x1425e7 as ::core::ffi::c_uint as uint32_t;
                    c2rust_current_block_50 = C2Rust_Block_50::S_360;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_50 = C2Rust_Block_50::S_362;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_12,
                    );
                    c2rust_current_block_50 = C2Rust_Block_50::S_368;
                };
                {
                    sub_001AEAA0();
                    c2rust_current_block_50 = C2Rust_Block_50::S_378;
                };
                {
                    _pv_13 = 0 as ::core::ffi::c_int as uint32_t;
                    c2rust_current_block_50 = C2Rust_Block_50::S_380;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_50 = C2Rust_Block_50::S_382;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_13,
                    );
                    c2rust_current_block_50 = C2Rust_Block_50::S_388;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_eax),
                    );
                    c2rust_current_block_50 = C2Rust_Block_50::S_394;
                };
                {
                    _pv_14 = (*__gamepkg_tls_g_esi);
                    c2rust_current_block_50 = C2Rust_Block_50::S_396;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_50 = C2Rust_Block_50::S_398;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_14,
                    );
                    c2rust_current_block_50 = C2Rust_Block_50::S_404;
                };
                {
                    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_esp)
                        .wrapping_add(0x10 as uint32_t);
                    c2rust_current_block_50 = C2Rust_Block_50::S_406;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x14 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_edx),
                    );
                    c2rust_current_block_50 = C2Rust_Block_50::S_408;
                };
                {
                    (*__gamepkg_tls_g_ebp) = ebp;
                    c2rust_current_block_50 = C2Rust_Block_50::S_410;
                };
                {
                    (*__gamepkg_tls_g_seh_ebp) = ebp;
                    c2rust_current_block_50 = C2Rust_Block_50::S_416;
                };
                {
                    _pv_15 = 0x1425fb as ::core::ffi::c_uint as uint32_t;
                    c2rust_current_block_50 = C2Rust_Block_50::S_418;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_50 = C2Rust_Block_50::S_420;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_15,
                    );
                    c2rust_current_block_50 = C2Rust_Block_50::S_426;
                };
                {
                    sub_001C99D0();
                    c2rust_current_block_50 = C2Rust_Block_50::S_432;
                };
                {
                    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_edi).wrapping_add(8 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_50 = C2Rust_Block_50::S_434;
                };
                {
                    _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
                    c2rust_current_block_50 = C2Rust_Block_50::S_436;
                };
                {
                    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                    c2rust_current_block_50 = C2Rust_Block_50::S_438;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_50 = C2Rust_Block_50::S_440;
                };
                {
                    _fbs = _fb as int32_t;
                    c2rust_current_block_50 = C2Rust_Block_50::S_442;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_edi).wrapping_add(0x48 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_eax),
                    );
                    c2rust_current_block_50 = C2Rust_Block_50::S_444;
                };
                {
                    if _fa == _fb {
                        c2rust_current_block_50 = C2Rust_Block_50::S_719;
                    } else {
                        c2rust_current_block_50 = C2Rust_Block_50::S_453;
                    }
                };
            }
            C2Rust_Block_50::S_453 => {
                {
                    (*__gamepkg_tls_g_eax) = 0x3ae388 as uint32_t;
                    c2rust_current_block_50 = C2Rust_Block_50::S_455;
                };
                {
                    (*__gamepkg_tls_g_ebp) = ebp;
                    c2rust_current_block_50 = C2Rust_Block_50::S_457;
                };
                {
                    (*__gamepkg_tls_g_seh_ebp) = ebp;
                    c2rust_current_block_50 = C2Rust_Block_50::S_463;
                };
                {
                    _pv_16 = 0x14260f as ::core::ffi::c_uint as uint32_t;
                    c2rust_current_block_50 = C2Rust_Block_50::S_465;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_50 = C2Rust_Block_50::S_467;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_16,
                    );
                    c2rust_current_block_50 = C2Rust_Block_50::S_473;
                };
                {
                    sub_001AEAA0();
                    c2rust_current_block_50 = C2Rust_Block_50::S_483;
                };
                {
                    _pv_17 = 0 as ::core::ffi::c_int as uint32_t;
                    c2rust_current_block_50 = C2Rust_Block_50::S_485;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_50 = C2Rust_Block_50::S_487;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_17,
                    );
                    c2rust_current_block_50 = C2Rust_Block_50::S_493;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_eax),
                    );
                    c2rust_current_block_50 = C2Rust_Block_50::S_499;
                };
                {
                    _pv_18 = (*__gamepkg_tls_g_esi);
                    c2rust_current_block_50 = C2Rust_Block_50::S_501;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_50 = C2Rust_Block_50::S_503;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_18,
                    );
                    c2rust_current_block_50 = C2Rust_Block_50::S_509;
                };
                {
                    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_esp)
                        .wrapping_add(0x10 as uint32_t);
                    c2rust_current_block_50 = C2Rust_Block_50::S_511;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x14 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_edx),
                    );
                    c2rust_current_block_50 = C2Rust_Block_50::S_513;
                };
                {
                    (*__gamepkg_tls_g_ebp) = ebp;
                    c2rust_current_block_50 = C2Rust_Block_50::S_515;
                };
                {
                    (*__gamepkg_tls_g_seh_ebp) = ebp;
                    c2rust_current_block_50 = C2Rust_Block_50::S_521;
                };
                {
                    _pv_19 = 0x142623 as ::core::ffi::c_uint as uint32_t;
                    c2rust_current_block_50 = C2Rust_Block_50::S_523;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_50 = C2Rust_Block_50::S_525;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_19,
                    );
                    c2rust_current_block_50 = C2Rust_Block_50::S_531;
                };
                {
                    sub_001C99D0();
                    c2rust_current_block_50 = C2Rust_Block_50::S_537;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_edi).wrapping_add(0xc as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_eax),
                    );
                    c2rust_current_block_50 = C2Rust_Block_50::S_539;
                };
                {
                    (*__gamepkg_tls_g_eax) = 0x3ae378 as uint32_t;
                    c2rust_current_block_50 = C2Rust_Block_50::S_541;
                };
                {
                    (*__gamepkg_tls_g_ebp) = ebp;
                    c2rust_current_block_50 = C2Rust_Block_50::S_543;
                };
                {
                    (*__gamepkg_tls_g_seh_ebp) = ebp;
                    c2rust_current_block_50 = C2Rust_Block_50::S_549;
                };
                {
                    _pv_20 = 0x142630 as ::core::ffi::c_uint as uint32_t;
                    c2rust_current_block_50 = C2Rust_Block_50::S_551;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_50 = C2Rust_Block_50::S_553;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_20,
                    );
                    c2rust_current_block_50 = C2Rust_Block_50::S_559;
                };
                {
                    sub_001AEAA0();
                    c2rust_current_block_50 = C2Rust_Block_50::S_565;
                };
                {
                    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_edi).wrapping_add(8 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_50 = C2Rust_Block_50::S_571;
                };
                {
                    _pv_21 = 0 as ::core::ffi::c_int as uint32_t;
                    c2rust_current_block_50 = C2Rust_Block_50::S_573;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_50 = C2Rust_Block_50::S_575;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_21,
                    );
                    c2rust_current_block_50 = C2Rust_Block_50::S_581;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_eax),
                    );
                    c2rust_current_block_50 = C2Rust_Block_50::S_587;
                };
                {
                    _pv_22 = (*__gamepkg_tls_g_ecx);
                    c2rust_current_block_50 = C2Rust_Block_50::S_589;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_50 = C2Rust_Block_50::S_591;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_22,
                    );
                    c2rust_current_block_50 = C2Rust_Block_50::S_597;
                };
                {
                    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_esp)
                        .wrapping_add(0x10 as uint32_t);
                    c2rust_current_block_50 = C2Rust_Block_50::S_599;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x14 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_edx),
                    );
                    c2rust_current_block_50 = C2Rust_Block_50::S_601;
                };
                {
                    (*__gamepkg_tls_g_ebp) = ebp;
                    c2rust_current_block_50 = C2Rust_Block_50::S_603;
                };
                {
                    (*__gamepkg_tls_g_seh_ebp) = ebp;
                    c2rust_current_block_50 = C2Rust_Block_50::S_609;
                };
                {
                    _pv_23 = 0x142647 as ::core::ffi::c_uint as uint32_t;
                    c2rust_current_block_50 = C2Rust_Block_50::S_611;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_50 = C2Rust_Block_50::S_613;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_23,
                    );
                    c2rust_current_block_50 = C2Rust_Block_50::S_619;
                };
                {
                    sub_001C99D0();
                    c2rust_current_block_50 = C2Rust_Block_50::S_625;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_edi).wrapping_add(0x10 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_eax),
                    );
                    c2rust_current_block_50 = C2Rust_Block_50::S_627;
                };
                {
                    (*__gamepkg_tls_g_eax) = 0x3ae36c as uint32_t;
                    c2rust_current_block_50 = C2Rust_Block_50::S_629;
                };
                {
                    (*__gamepkg_tls_g_ebp) = ebp;
                    c2rust_current_block_50 = C2Rust_Block_50::S_631;
                };
                {
                    (*__gamepkg_tls_g_seh_ebp) = ebp;
                    c2rust_current_block_50 = C2Rust_Block_50::S_637;
                };
                {
                    _pv_24 = 0x142654 as ::core::ffi::c_uint as uint32_t;
                    c2rust_current_block_50 = C2Rust_Block_50::S_639;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_50 = C2Rust_Block_50::S_641;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_24,
                    );
                    c2rust_current_block_50 = C2Rust_Block_50::S_647;
                };
                {
                    sub_001AEAA0();
                    c2rust_current_block_50 = C2Rust_Block_50::S_653;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_edx),
                    );
                    c2rust_current_block_50 = C2Rust_Block_50::S_655;
                };
                {
                    (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_edi).wrapping_add(8 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_50 = C2Rust_Block_50::S_661;
                };
                {
                    _pv_25 = 0 as ::core::ffi::c_int as uint32_t;
                    c2rust_current_block_50 = C2Rust_Block_50::S_663;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_50 = C2Rust_Block_50::S_665;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_25,
                    );
                    c2rust_current_block_50 = C2Rust_Block_50::S_671;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_eax),
                    );
                    c2rust_current_block_50 = C2Rust_Block_50::S_677;
                };
                {
                    _pv_26 = (*__gamepkg_tls_g_edx);
                    c2rust_current_block_50 = C2Rust_Block_50::S_679;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_50 = C2Rust_Block_50::S_681;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_26,
                    );
                    c2rust_current_block_50 = C2Rust_Block_50::S_687;
                };
                {
                    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_esp)
                        .wrapping_add(0x10 as uint32_t);
                    c2rust_current_block_50 = C2Rust_Block_50::S_689;
                };
                {
                    (*__gamepkg_tls_g_ebp) = ebp;
                    c2rust_current_block_50 = C2Rust_Block_50::S_691;
                };
                {
                    (*__gamepkg_tls_g_seh_ebp) = ebp;
                    c2rust_current_block_50 = C2Rust_Block_50::S_697;
                };
                {
                    _pv_27 = 0x14266b as ::core::ffi::c_uint as uint32_t;
                    c2rust_current_block_50 = C2Rust_Block_50::S_699;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_50 = C2Rust_Block_50::S_701;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_27,
                    );
                    c2rust_current_block_50 = C2Rust_Block_50::S_707;
                };
                {
                    sub_001C99D0();
                    c2rust_current_block_50 = C2Rust_Block_50::S_713;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_edi).wrapping_add(0x14 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_eax),
                    );
                    c2rust_current_block_50 = C2Rust_Block_50::S_719;
                };
            }
            C2Rust_Block_50::S_719 => {
                {
                    (*__gamepkg_tls_g_ebp) = ebp;
                    c2rust_current_block_50 = C2Rust_Block_50::S_721;
                };
                {
                    (*__gamepkg_tls_g_seh_ebp) = ebp;
                    c2rust_current_block_50 = C2Rust_Block_50::S_727;
                };
                {
                    _pv_28 = 0x142673 as ::core::ffi::c_uint as uint32_t;
                    c2rust_current_block_50 = C2Rust_Block_50::S_729;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_50 = C2Rust_Block_50::S_731;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_28,
                    );
                    c2rust_current_block_50 = C2Rust_Block_50::S_737;
                };
                {
                    sub_00142C80();
                    c2rust_current_block_50 = C2Rust_Block_50::S_743;
                };
                {
                    (*__gamepkg_tls_g_ebp) = ebp;
                    c2rust_current_block_50 = C2Rust_Block_50::S_745;
                };
                {
                    (*__gamepkg_tls_g_seh_ebp) = ebp;
                    c2rust_current_block_50 = C2Rust_Block_50::S_751;
                };
                {
                    _pv_29 = 0x142678 as ::core::ffi::c_uint as uint32_t;
                    c2rust_current_block_50 = C2Rust_Block_50::S_753;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_50 = C2Rust_Block_50::S_755;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_29,
                    );
                    c2rust_current_block_50 = C2Rust_Block_50::S_761;
                };
                {
                    sub_00142910();
                    c2rust_current_block_50 = C2Rust_Block_50::S_767;
                };
                {
                    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_edi).wrapping_add(8 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_50 = C2Rust_Block_50::S_769;
                };
                {
                    (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                    c2rust_current_block_50 = C2Rust_Block_50::S_771;
                };
                {
                    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                    c2rust_current_block_50 = C2Rust_Block_50::S_773;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_50 = C2Rust_Block_50::S_775;
                };
                {
                    _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                    c2rust_current_block_50 = C2Rust_Block_50::S_777;
                };
                {
                    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                    c2rust_current_block_50 = C2Rust_Block_50::S_779;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_50 = C2Rust_Block_50::S_781;
                };
                {
                    _fbs = _fb as int32_t;
                    c2rust_current_block_50 = C2Rust_Block_50::S_783;
                };
                {
                    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
                        & 0xffffff00 as uint32_t
                        | (if _fa == _fb {
                            1 as ::core::ffi::c_int
                        } else {
                            0 as ::core::ffi::c_int
                        }) as uint8_t as uint32_t;
                    c2rust_current_block_50 = C2Rust_Block_50::S_789;
                };
                {
                    (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_50 = C2Rust_Block_50::S_791;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_add(4 as uint32_t);
                    c2rust_current_block_50 = C2Rust_Block_50::S_801;
                };
                {
                    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_50 = C2Rust_Block_50::S_803;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_add(4 as uint32_t);
                    c2rust_current_block_50 = C2Rust_Block_50::S_809;
                };
                {
                    (*__gamepkg_tls_g_esp) = ebp;
                    c2rust_current_block_50 = C2Rust_Block_50::S_815;
                };
                {
                    ebp = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_50 = C2Rust_Block_50::S_817;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_add(4 as uint32_t);
                    c2rust_current_block_50 = C2Rust_Block_50::S_823;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_add(4 as uint32_t);
                    c2rust_current_block_50 = C2Rust_Block_50::S_825;
                };
                return;
            }
            C2Rust_Block_50::S_835 => {
                {
                    (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_50 = C2Rust_Block_50::S_837;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_add(4 as uint32_t);
                    c2rust_current_block_50 = C2Rust_Block_50::S_843;
                };
                {
                    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
                        & 0xffffff00 as uint32_t
                        | 0 as ::core::ffi::c_int as uint8_t as uint32_t;
                    c2rust_current_block_50 = C2Rust_Block_50::S_845;
                };
                {
                    _fa = ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t
                        as uint32_t & 0xff as uint32_t;
                    c2rust_current_block_50 = C2Rust_Block_50::S_847;
                };
                {
                    _fas = _fa as int8_t as int32_t;
                    c2rust_current_block_50 = C2Rust_Block_50::S_853;
                };
                {
                    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_50 = C2Rust_Block_50::S_855;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_add(4 as uint32_t);
                    c2rust_current_block_50 = C2Rust_Block_50::S_861;
                };
                {
                    (*__gamepkg_tls_g_esp) = ebp;
                    c2rust_current_block_50 = C2Rust_Block_50::S_867;
                };
                {
                    ebp = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_50 = C2Rust_Block_50::S_869;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_add(4 as uint32_t);
                    c2rust_current_block_50 = C2Rust_Block_50::S_875;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_add(4 as uint32_t);
                    c2rust_current_block_50 = C2Rust_Block_50::S_877;
                };
                return;
            }
            C2Rust_Block_50::S_100
            | C2Rust_Block_50::S_102
            | C2Rust_Block_50::S_104
            | C2Rust_Block_50::S_106
            | C2Rust_Block_50::S_108
            | C2Rust_Block_50::S_110
            | C2Rust_Block_50::S_112
            | C2Rust_Block_50::S_114
            | C2Rust_Block_50::S_129
            | C2Rust_Block_50::S_131
            | C2Rust_Block_50::S_133
            | C2Rust_Block_50::S_143
            | C2Rust_Block_50::S_145
            | C2Rust_Block_50::S_147
            | C2Rust_Block_50::S_157
            | C2Rust_Block_50::S_159
            | C2Rust_Block_50::S_161
            | C2Rust_Block_50::S_171
            | C2Rust_Block_50::S_173
            | C2Rust_Block_50::S_175
            | C2Rust_Block_50::S_181
            | C2Rust_Block_50::S_183
            | C2Rust_Block_50::S_189
            | C2Rust_Block_50::S_191
            | C2Rust_Block_50::S_193
            | C2Rust_Block_50::S_199
            | C2Rust_Block_50::S_2
            | C2Rust_Block_50::S_205
            | C2Rust_Block_50::S_207
            | C2Rust_Block_50::S_209
            | C2Rust_Block_50::S_211
            | C2Rust_Block_50::S_213
            | C2Rust_Block_50::S_215
            | C2Rust_Block_50::S_226
            | C2Rust_Block_50::S_228
            | C2Rust_Block_50::S_230
            | C2Rust_Block_50::S_232
            | C2Rust_Block_50::S_234
            | C2Rust_Block_50::S_249
            | C2Rust_Block_50::S_251
            | C2Rust_Block_50::S_26
            | C2Rust_Block_50::S_261
            | C2Rust_Block_50::S_263
            | C2Rust_Block_50::S_265
            | C2Rust_Block_50::S_275
            | C2Rust_Block_50::S_277
            | C2Rust_Block_50::S_279
            | C2Rust_Block_50::S_28
            | C2Rust_Block_50::S_289
            | C2Rust_Block_50::S_291
            | C2Rust_Block_50::S_293
            | C2Rust_Block_50::S_299
            | C2Rust_Block_50::S_30
            | C2Rust_Block_50::S_301
            | C2Rust_Block_50::S_307
            | C2Rust_Block_50::S_309
            | C2Rust_Block_50::S_311
            | C2Rust_Block_50::S_317
            | C2Rust_Block_50::S_323
            | C2Rust_Block_50::S_331
            | C2Rust_Block_50::S_333
            | C2Rust_Block_50::S_335
            | C2Rust_Block_50::S_337
            | C2Rust_Block_50::S_339
            | C2Rust_Block_50::S_350
            | C2Rust_Block_50::S_352
            | C2Rust_Block_50::S_358
            | C2Rust_Block_50::S_36
            | C2Rust_Block_50::S_360
            | C2Rust_Block_50::S_362
            | C2Rust_Block_50::S_368
            | C2Rust_Block_50::S_378
            | C2Rust_Block_50::S_38
            | C2Rust_Block_50::S_380
            | C2Rust_Block_50::S_382
            | C2Rust_Block_50::S_388
            | C2Rust_Block_50::S_394
            | C2Rust_Block_50::S_396
            | C2Rust_Block_50::S_398
            | C2Rust_Block_50::S_4
            | C2Rust_Block_50::S_40
            | C2Rust_Block_50::S_404
            | C2Rust_Block_50::S_406
            | C2Rust_Block_50::S_408
            | C2Rust_Block_50::S_410
            | C2Rust_Block_50::S_416
            | C2Rust_Block_50::S_418
            | C2Rust_Block_50::S_42
            | C2Rust_Block_50::S_420
            | C2Rust_Block_50::S_426
            | C2Rust_Block_50::S_432
            | C2Rust_Block_50::S_434
            | C2Rust_Block_50::S_436
            | C2Rust_Block_50::S_438
            | C2Rust_Block_50::S_44
            | C2Rust_Block_50::S_440
            | C2Rust_Block_50::S_442
            | C2Rust_Block_50::S_444
            | C2Rust_Block_50::S_455
            | C2Rust_Block_50::S_457
            | C2Rust_Block_50::S_46
            | C2Rust_Block_50::S_463
            | C2Rust_Block_50::S_465
            | C2Rust_Block_50::S_467
            | C2Rust_Block_50::S_473
            | C2Rust_Block_50::S_48
            | C2Rust_Block_50::S_483
            | C2Rust_Block_50::S_485
            | C2Rust_Block_50::S_487
            | C2Rust_Block_50::S_493
            | C2Rust_Block_50::S_499
            | C2Rust_Block_50::S_50
            | C2Rust_Block_50::S_501
            | C2Rust_Block_50::S_503
            | C2Rust_Block_50::S_509
            | C2Rust_Block_50::S_511
            | C2Rust_Block_50::S_513
            | C2Rust_Block_50::S_515
            | C2Rust_Block_50::S_52
            | C2Rust_Block_50::S_521
            | C2Rust_Block_50::S_523
            | C2Rust_Block_50::S_525
            | C2Rust_Block_50::S_531
            | C2Rust_Block_50::S_537
            | C2Rust_Block_50::S_539
            | C2Rust_Block_50::S_54
            | C2Rust_Block_50::S_541
            | C2Rust_Block_50::S_543
            | C2Rust_Block_50::S_549
            | C2Rust_Block_50::S_551
            | C2Rust_Block_50::S_553
            | C2Rust_Block_50::S_559
            | C2Rust_Block_50::S_56
            | C2Rust_Block_50::S_565
            | C2Rust_Block_50::S_571
            | C2Rust_Block_50::S_573
            | C2Rust_Block_50::S_575
            | C2Rust_Block_50::S_58
            | C2Rust_Block_50::S_581
            | C2Rust_Block_50::S_587
            | C2Rust_Block_50::S_589
            | C2Rust_Block_50::S_591
            | C2Rust_Block_50::S_597
            | C2Rust_Block_50::S_599
            | C2Rust_Block_50::S_6
            | C2Rust_Block_50::S_60
            | C2Rust_Block_50::S_601
            | C2Rust_Block_50::S_603
            | C2Rust_Block_50::S_609
            | C2Rust_Block_50::S_611
            | C2Rust_Block_50::S_613
            | C2Rust_Block_50::S_619
            | C2Rust_Block_50::S_625
            | C2Rust_Block_50::S_627
            | C2Rust_Block_50::S_629
            | C2Rust_Block_50::S_631
            | C2Rust_Block_50::S_637
            | C2Rust_Block_50::S_639
            | C2Rust_Block_50::S_641
            | C2Rust_Block_50::S_647
            | C2Rust_Block_50::S_653
            | C2Rust_Block_50::S_655
            | C2Rust_Block_50::S_66
            | C2Rust_Block_50::S_661
            | C2Rust_Block_50::S_663
            | C2Rust_Block_50::S_665
            | C2Rust_Block_50::S_671
            | C2Rust_Block_50::S_677
            | C2Rust_Block_50::S_679
            | C2Rust_Block_50::S_68
            | C2Rust_Block_50::S_681
            | C2Rust_Block_50::S_687
            | C2Rust_Block_50::S_689
            | C2Rust_Block_50::S_691
            | C2Rust_Block_50::S_697
            | C2Rust_Block_50::S_699
            | C2Rust_Block_50::S_70
            | C2Rust_Block_50::S_701
            | C2Rust_Block_50::S_707
            | C2Rust_Block_50::S_713
            | C2Rust_Block_50::S_721
            | C2Rust_Block_50::S_727
            | C2Rust_Block_50::S_729
            | C2Rust_Block_50::S_731
            | C2Rust_Block_50::S_737
            | C2Rust_Block_50::S_743
            | C2Rust_Block_50::S_745
            | C2Rust_Block_50::S_751
            | C2Rust_Block_50::S_753
            | C2Rust_Block_50::S_755
            | C2Rust_Block_50::S_761
            | C2Rust_Block_50::S_767
            | C2Rust_Block_50::S_769
            | C2Rust_Block_50::S_771
            | C2Rust_Block_50::S_773
            | C2Rust_Block_50::S_775
            | C2Rust_Block_50::S_777
            | C2Rust_Block_50::S_779
            | C2Rust_Block_50::S_781
            | C2Rust_Block_50::S_783
            | C2Rust_Block_50::S_789
            | C2Rust_Block_50::S_791
            | C2Rust_Block_50::S_8
            | C2Rust_Block_50::S_80
            | C2Rust_Block_50::S_801
            | C2Rust_Block_50::S_803
            | C2Rust_Block_50::S_809
            | C2Rust_Block_50::S_815
            | C2Rust_Block_50::S_817
            | C2Rust_Block_50::S_82
            | C2Rust_Block_50::S_823
            | C2Rust_Block_50::S_825
            | C2Rust_Block_50::S_837
            | C2Rust_Block_50::S_84
            | C2Rust_Block_50::S_843
            | C2Rust_Block_50::S_845
            | C2Rust_Block_50::S_847
            | C2Rust_Block_50::S_853
            | C2Rust_Block_50::S_855
            | C2Rust_Block_50::S_861
            | C2Rust_Block_50::S_867
            | C2Rust_Block_50::S_869
            | C2Rust_Block_50::S_875
            | C2Rust_Block_50::S_877
            | C2Rust_Block_50::S_90
            | C2Rust_Block_50::S_92
            | C2Rust_Block_50::S_94
            | C2Rust_Block_50::S_96
            | C2Rust_Block_50::S_98 => {
                unreachable!("GamePKG compacted dispatch state reached")
            }
        }
    };
}
#[no_mangle]
pub unsafe extern "C" fn sub_00142690() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebx = unsafe { gamepkg_tls_g_ebx() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    let mut _flags: ::core::ffi::c_int = 0;
    let mut _fa: uint32_t = 0;
    let mut _fb: uint32_t = 0;
    let mut _fas: int32_t = 0;
    let mut _fbs: int32_t = 0;
    let mut _pv: uint32_t = 0;
    let mut _pv_0: uint32_t = 0;
    let mut _pv_1: uint32_t = 0;
    let mut _pv_2: uint32_t = 0;
    let mut _pv_3: uint32_t = 0;
    let mut _pv_4: uint32_t = 0;
    let mut _pv_5: uint32_t = 0;
    let mut _pv_6: uint32_t = 0;
    let mut _pv_7: uint32_t = 0;
    let mut _pv_8: uint32_t = 0;
    let mut _dividend: uint64_t = 0;
    let mut _dividend_0: uint64_t = 0;
    let mut _pv_9: uint32_t = 0;
    let mut _pv_10: uint32_t = 0;
    let mut _pv_11: uint32_t = 0;
    let mut _pv_12: uint32_t = 0;
    let mut _pv_13: uint32_t = 0;
    let mut _pv_14: uint32_t = 0;
    let mut _pv_15: uint32_t = 0;
    enum C2Rust_Block_51 {
        S_0,
        S_2,
        S_4,
        S_18,
        S_20,
        S_22,
        S_24,
        S_26,
        S_32,
        S_34,
        S_36,
        S_46,
        S_48,
        S_50,
        S_60,
        S_62,
        S_64,
        S_70,
        S_72,
        S_74,
        S_76,
        S_78,
        S_80,
        S_82,
        S_84,
        S_86,
        S_88,
        S_90,
        S_92,
        S_94,
        S_103,
        S_105,
        S_107,
        S_109,
        S_111,
        S_113,
        S_115,
        S_117,
        S_119,
        S_121,
        S_123,
        S_125,
        S_127,
        S_129,
        S_131,
        S_140,
        S_146,
        S_148,
        S_150,
        S_152,
        S_154,
        S_163,
        S_165,
        S_167,
        S_169,
        S_175,
        S_177,
        S_179,
        S_181,
        S_183,
        S_192,
        S_194,
        S_196,
        S_198,
        S_204,
        S_206,
        S_208,
        S_210,
        S_212,
        S_221,
        S_223,
        S_225,
        S_227,
        S_233,
        S_235,
        S_237,
        S_239,
        S_241,
        S_243,
        S_252,
        S_260,
        S_266,
        S_268,
        S_270,
        S_272,
        S_274,
        S_276,
        S_278,
        S_280,
        S_282,
        S_284,
        S_286,
        S_288,
        S_290,
        S_292,
        S_294,
        S_296,
        S_298,
        S_300,
        S_302,
        S_311,
        S_313,
        S_319,
        S_321,
        S_323,
        S_325,
        S_327,
        S_336,
        S_338,
        S_340,
        S_342,
        S_344,
        S_353,
        S_355,
        S_357,
        S_365,
        S_371,
        S_373,
        S_375,
        S_377,
        S_379,
        S_381,
        S_383,
        S_385,
        S_387,
        S_389,
        S_398,
        S_400,
        S_402,
        S_404,
        S_406,
        S_415,
        S_417,
        S_419,
        S_421,
        S_423,
        S_432,
        S_434,
        S_436,
        S_438,
        S_440,
        S_442,
        S_444,
        S_446,
        S_448,
        S_450,
        S_452,
        S_454,
        S_467,
        S_469,
        S_471,
        S_481,
        S_483,
        S_485,
        S_491,
        S_503,
        S_509,
        S_511,
        S_513,
        S_519,
        S_531,
        S_537,
        S_539,
        S_541,
        S_547,
        S_553,
        S_555,
        S_557,
        S_559,
        S_561,
        S_574,
        S_576,
        S_578,
        S_588,
        S_590,
        S_592,
        S_598,
        S_610,
        S_616,
        S_618,
        S_620,
        S_626,
        S_632,
        S_634,
        S_636,
        S_638,
        S_640,
        S_642,
        S_651,
        S_653,
        S_655,
        S_657,
        S_659,
        S_661,
        S_663,
        S_665,
        S_667,
        S_669,
        S_678,
        S_680,
        S_682,
        S_684,
        S_686,
        S_688,
        S_690,
        S_692,
        S_694,
        S_696,
        S_698,
        S_700,
        S_702,
        S_704,
        S_706,
        S_708,
        S_710,
        S_712,
        S_714,
        S_716,
        S_718,
        S_720,
        S_722,
        S_724,
        S_726,
        S_728,
        S_730,
        S_733,
        S_735,
        S_737,
        S_741,
        S_743,
        S_745,
        S_747,
        S_749,
        S_751,
        S_757,
        S_759,
        S_761,
        S_763,
        S_765,
        S_767,
        S_776,
        S_778,
        S_780,
        S_782,
        S_784,
        S_786,
        S_788,
        S_790,
        S_792,
        S_794,
        S_803,
        S_805,
        S_807,
        S_809,
        S_811,
        S_813,
        S_815,
        S_817,
        S_819,
        S_821,
        S_823,
        S_825,
        S_827,
        S_829,
        S_831,
        S_833,
        S_835,
        S_837,
        S_839,
        S_841,
        S_843,
        S_845,
        S_847,
        S_849,
        S_851,
        S_853,
        S_855,
        S_857,
        S_859,
        S_861,
        S_864,
        S_866,
        S_868,
        S_872,
        S_874,
        S_876,
        S_878,
        S_880,
        S_882,
        S_888,
        S_890,
        S_900,
        S_902,
        S_912,
        S_914,
        S_920,
        S_922,
        S_924,
        S_926,
        S_928,
        S_930,
        S_932,
        S_938,
        S_940,
        S_942,
        S_944,
        S_946,
        S_948,
        S_957,
        S_963,
        S_965,
        S_967,
        S_977,
        S_979,
        S_981,
        S_991,
        S_993,
        S_995,
        S_1001,
        S_1007,
        S_1013,
        S_1015,
        S_1017,
        S_1027,
        S_1029,
        S_1031,
        S_1041,
        S_1043,
        S_1045,
        S_1051,
        S_1057,
        S_1059,
        S_1061,
        S_1063,
        S_1065,
        S_1067,
        S_1069,
        S_1071,
        S_1073,
        S_1075,
        S_1077,
        S_1079,
        S_1081,
        S_1083,
        S_1085,
        S_1091,
        S_1097,
        S_1099,
        S_1101,
        S_1107,
        S_1117,
        S_1119,
        S_1129,
        S_1131,
        S_1141,
        S_1143,
        S_1149,
        S_1151,
        S_1153,
        S_1155,
        S_1157,
        S_1159,
        S_1161,
    }
    let mut c2rust_current_block_51: C2Rust_Block_51;
    c2rust_current_block_51 = C2Rust_Block_51::S_0;
    loop {
        match c2rust_current_block_51 {
            C2Rust_Block_51::S_0 => {
                {
                    _flags = 0 as ::core::ffi::c_int;
                    c2rust_current_block_51 = C2Rust_Block_51::S_2;
                };
                {
                    _fa = 0 as uint32_t;
                    _fb = 0 as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_4;
                };
                {
                    _fas = 0 as int32_t;
                    _fbs = 0 as int32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_18;
                };
                {
                    _fb = 0x10 as ::core::ffi::c_int as uint32_t
                        & 0xffffffff as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_20;
                };
                {
                    _fbs = _fb as int32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_22;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(0x10 as uint32_t);
                    c2rust_current_block_51 = C2Rust_Block_51::S_24;
                };
                {
                    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_26;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_32;
                };
                {
                    _pv = (*__gamepkg_tls_g_ebx);
                    c2rust_current_block_51 = C2Rust_Block_51::S_34;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_51 = C2Rust_Block_51::S_36;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv,
                    );
                    c2rust_current_block_51 = C2Rust_Block_51::S_46;
                };
                {
                    _pv_0 = (*__gamepkg_tls_g_esi);
                    c2rust_current_block_51 = C2Rust_Block_51::S_48;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_51 = C2Rust_Block_51::S_50;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_0,
                    );
                    c2rust_current_block_51 = C2Rust_Block_51::S_60;
                };
                {
                    _pv_1 = (*__gamepkg_tls_g_edi);
                    c2rust_current_block_51 = C2Rust_Block_51::S_62;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_51 = C2Rust_Block_51::S_64;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_1,
                    );
                    c2rust_current_block_51 = C2Rust_Block_51::S_70;
                };
                {
                    (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_eax);
                    c2rust_current_block_51 = C2Rust_Block_51::S_72;
                };
                {
                    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_edi).wrapping_add(4 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_51 = C2Rust_Block_51::S_74;
                };
                {
                    (*__gamepkg_tls_g_ebx) = 0 as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_76;
                };
                {
                    _fa = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_78;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_80;
                };
                {
                    (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_edx)
                        & 0xffffff00 as uint32_t
                        | 0 as ::core::ffi::c_int as uint8_t as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_82;
                };
                {
                    _fa = ((*__gamepkg_tls_g_edx) & 0xff as uint32_t) as uint8_t
                        as uint32_t & 0xff as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_84;
                };
                {
                    _fas = _fa as int8_t as int32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_86;
                };
                {
                    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_88;
                };
                {
                    _fb = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_90;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_92;
                };
                {
                    _fbs = _fb as int32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_94;
                };
                {
                    if _fa == _fb {
                        c2rust_current_block_51 = C2Rust_Block_51::S_938;
                    } else {
                        c2rust_current_block_51 = C2Rust_Block_51::S_103;
                    }
                };
            }
            C2Rust_Block_51::S_103 => {
                {
                    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax).wrapping_sub(1);
                    c2rust_current_block_51 = C2Rust_Block_51::S_105;
                };
                {
                    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_107;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_109;
                };
                {
                    _fb = (_fa == 0x7fffffff as uint32_t) as ::core::ffi::c_int
                        as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_111;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_edi).wrapping_add(4 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_eax),
                    );
                    c2rust_current_block_51 = C2Rust_Block_51::S_113;
                };
                {
                    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_edi) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_51 = C2Rust_Block_51::S_115;
                };
                {
                    (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx)
                        & 0xffffff00 as uint32_t
                        | ::core::ptr::read_volatile::<
                            uint8_t,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                uint8_t,
                            >(
                                ((*__gamepkg_tls_g_eax).wrapping_add(0x8d3 as uint32_t)
                                    as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ) as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_117;
                };
                {
                    (*__gamepkg_tls_g_esi) = 0 as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_119;
                };
                {
                    _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_121;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_123;
                };
                {
                    _fa = ((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t
                        as uint32_t & 0xff as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_125;
                };
                {
                    _fb = ((*__gamepkg_tls_g_ebx) & 0xff as uint32_t) as uint8_t
                        as uint32_t & 0xff as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_127;
                };
                {
                    _fas = _fa as int8_t as int32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_129;
                };
                {
                    _fbs = _fb as int8_t as int32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_131;
                };
                {
                    if _fa == _fb {
                        c2rust_current_block_51 = C2Rust_Block_51::S_146;
                    } else {
                        c2rust_current_block_51 = C2Rust_Block_51::S_140;
                    }
                };
            }
            C2Rust_Block_51::S_140 => {
                (*__gamepkg_tls_g_esi) = 1 as uint32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_146;
            }
            C2Rust_Block_51::S_146 => {
                {
                    _fa = ::core::ptr::read_volatile::<
                        uint8_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            ((*__gamepkg_tls_g_eax).wrapping_add(0x993 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ) as uint32_t & 0xff as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_148;
                };
                {
                    _fb = ((*__gamepkg_tls_g_ebx) & 0xff as uint32_t) as uint8_t
                        as uint32_t & 0xff as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_150;
                };
                {
                    _fas = _fa as int8_t as int32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_152;
                };
                {
                    _fbs = _fb as int8_t as int32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_154;
                };
                {
                    if _fa == _fb {
                        c2rust_current_block_51 = C2Rust_Block_51::S_175;
                    } else {
                        c2rust_current_block_51 = C2Rust_Block_51::S_163;
                    }
                };
            }
            C2Rust_Block_51::S_163 => {
                {
                    (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi).wrapping_add(1);
                    c2rust_current_block_51 = C2Rust_Block_51::S_165;
                };
                {
                    _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_167;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_169;
                };
                {
                    _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int
                        as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_175;
                };
            }
            C2Rust_Block_51::S_175 => {
                {
                    _fa = ::core::ptr::read_volatile::<
                        uint8_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            ((*__gamepkg_tls_g_eax).wrapping_add(0xa53 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ) as uint32_t & 0xff as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_177;
                };
                {
                    _fb = ((*__gamepkg_tls_g_ebx) & 0xff as uint32_t) as uint8_t
                        as uint32_t & 0xff as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_179;
                };
                {
                    _fas = _fa as int8_t as int32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_181;
                };
                {
                    _fbs = _fb as int8_t as int32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_183;
                };
                {
                    if _fa == _fb {
                        c2rust_current_block_51 = C2Rust_Block_51::S_204;
                    } else {
                        c2rust_current_block_51 = C2Rust_Block_51::S_192;
                    }
                };
            }
            C2Rust_Block_51::S_192 => {
                {
                    (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi).wrapping_add(1);
                    c2rust_current_block_51 = C2Rust_Block_51::S_194;
                };
                {
                    _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_196;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_198;
                };
                {
                    _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int
                        as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_204;
                };
            }
            C2Rust_Block_51::S_204 => {
                {
                    _fa = ::core::ptr::read_volatile::<
                        uint8_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            ((*__gamepkg_tls_g_eax).wrapping_add(0xb13 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ) as uint32_t & 0xff as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_206;
                };
                {
                    _fb = ((*__gamepkg_tls_g_ebx) & 0xff as uint32_t) as uint8_t
                        as uint32_t & 0xff as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_208;
                };
                {
                    _fas = _fa as int8_t as int32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_210;
                };
                {
                    _fbs = _fb as int8_t as int32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_212;
                };
                {
                    if _fa == _fb {
                        c2rust_current_block_51 = C2Rust_Block_51::S_233;
                    } else {
                        c2rust_current_block_51 = C2Rust_Block_51::S_221;
                    }
                };
            }
            C2Rust_Block_51::S_221 => {
                {
                    (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi).wrapping_add(1);
                    c2rust_current_block_51 = C2Rust_Block_51::S_223;
                };
                {
                    _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_225;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_227;
                };
                {
                    _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int
                        as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_233;
                };
            }
            C2Rust_Block_51::S_233 => {
                {
                    _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_235;
                };
                {
                    _fb = 2 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_237;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_239;
                };
                {
                    _fbs = _fb as int32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_241;
                };
                {
                    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                ((*__gamepkg_tls_g_edi).wrapping_add(0x20 as uint32_t)
                                    as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_51 = C2Rust_Block_51::S_243;
                };
                {
                    if if if ::core::mem::size_of::<int32_t>()
                        < ::core::mem::size_of::<int32_t>()
                    {
                        ::core::mem::size_of::<int32_t>()
                    } else {
                        ::core::mem::size_of::<int32_t>()
                    } == 1usize
                    {
                        _fas as uint32_t as uint8_t as int8_t as int32_t
                    } else if if ::core::mem::size_of::<int32_t>()
                        < ::core::mem::size_of::<int32_t>()
                    {
                        ::core::mem::size_of::<int32_t>()
                    } else {
                        ::core::mem::size_of::<int32_t>()
                    } == 2usize
                    {
                        _fas as uint32_t as uint16_t as int16_t as int32_t
                    } else {
                        _fas as uint32_t as int32_t
                    }
                        <= if if ::core::mem::size_of::<int32_t>()
                            < ::core::mem::size_of::<int32_t>()
                        {
                            ::core::mem::size_of::<int32_t>()
                        } else {
                            ::core::mem::size_of::<int32_t>()
                        } == 1usize
                        {
                            _fbs as uint32_t as uint8_t as int8_t as int32_t
                        } else if if ::core::mem::size_of::<int32_t>()
                            < ::core::mem::size_of::<int32_t>()
                        {
                            ::core::mem::size_of::<int32_t>()
                        } else {
                            ::core::mem::size_of::<int32_t>()
                        } == 2usize
                        {
                            _fbs as uint32_t as uint16_t as int16_t as int32_t
                        } else {
                            _fbs as uint32_t as int32_t
                        }
                    {
                        c2rust_current_block_51 = C2Rust_Block_51::S_260;
                    } else {
                        c2rust_current_block_51 = C2Rust_Block_51::S_252;
                    }
                };
            }
            C2Rust_Block_51::S_252 => {
                (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
                    + ::core::ptr::read_volatile::<
                        ::core::ffi::c_float,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x3a69bc as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                c2rust_current_block_51 = C2Rust_Block_51::S_266;
            }
            C2Rust_Block_51::S_260 => {
                (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
                    - ::core::ptr::read_volatile::<
                        ::core::ffi::c_float,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x3a69b4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                c2rust_current_block_51 = C2Rust_Block_51::S_266;
            }
            C2Rust_Block_51::S_266 => {
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            ((*__gamepkg_tls_g_edi).wrapping_add(0x20 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm0).f[0usize],
                    );
                    c2rust_current_block_51 = C2Rust_Block_51::S_268;
                };
                {
                    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b168c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_51 = C2Rust_Block_51::S_270;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm0).f[0usize],
                    );
                    c2rust_current_block_51 = C2Rust_Block_51::S_272;
                };
                {
                    (*__gamepkg_tls_g_xmm0) = XMM_ZERO();
                    c2rust_current_block_51 = C2Rust_Block_51::S_274;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x10 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm0).f[0usize],
                    );
                    c2rust_current_block_51 = C2Rust_Block_51::S_276;
                };
                {
                    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                ((*__gamepkg_tls_g_edi).wrapping_add(0x20 as uint32_t)
                                    as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_51 = C2Rust_Block_51::S_278;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x14 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm0).f[0usize],
                    );
                    c2rust_current_block_51 = C2Rust_Block_51::S_280;
                };
                {
                    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                ((*__gamepkg_tls_g_esp).wrapping_add(0x14 as uint32_t)
                                    as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_51 = C2Rust_Block_51::S_282;
                };
                {
                    (*__gamepkg_tls_g_xmm0).f[0usize] = if (*__gamepkg_tls_g_xmm0)
                        .f[0usize]
                        > ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                ((*__gamepkg_tls_g_esp).wrapping_add(0x10 as uint32_t)
                                    as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        )
                    {
                        (*__gamepkg_tls_g_xmm0).f[0usize]
                    } else {
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                ((*__gamepkg_tls_g_esp).wrapping_add(0x10 as uint32_t)
                                    as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        )
                    };
                    c2rust_current_block_51 = C2Rust_Block_51::S_284;
                };
                {
                    (*__gamepkg_tls_g_xmm0).f[0usize] = if (*__gamepkg_tls_g_xmm0)
                        .f[0usize]
                        < ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t)
                                    as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        )
                    {
                        (*__gamepkg_tls_g_xmm0).f[0usize]
                    } else {
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t)
                                    as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        )
                    };
                    c2rust_current_block_51 = C2Rust_Block_51::S_286;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(0x18 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm0).f[0usize],
                    );
                    c2rust_current_block_51 = C2Rust_Block_51::S_288;
                };
                {
                    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                ((*__gamepkg_tls_g_esp).wrapping_add(0x18 as uint32_t)
                                    as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_51 = C2Rust_Block_51::S_290;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            ((*__gamepkg_tls_g_edi).wrapping_add(0x20 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm0).f[0usize],
                    );
                    c2rust_current_block_51 = C2Rust_Block_51::S_292;
                };
                {
                    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x73a1c0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_51 = C2Rust_Block_51::S_294;
                };
                {
                    _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_296;
                };
                {
                    _fb = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_298;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_300;
                };
                {
                    _fbs = _fb as int32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_302;
                };
                {
                    if if if ::core::mem::size_of::<int32_t>()
                        < ::core::mem::size_of::<int32_t>()
                    {
                        ::core::mem::size_of::<int32_t>()
                    } else {
                        ::core::mem::size_of::<int32_t>()
                    } == 1usize
                    {
                        _fas as uint32_t as uint8_t as int8_t as int32_t
                    } else if if ::core::mem::size_of::<int32_t>()
                        < ::core::mem::size_of::<int32_t>()
                    {
                        ::core::mem::size_of::<int32_t>()
                    } else {
                        ::core::mem::size_of::<int32_t>()
                    } == 2usize
                    {
                        _fas as uint32_t as uint16_t as int16_t as int32_t
                    } else {
                        _fas as uint32_t as int32_t
                    }
                        <= if if ::core::mem::size_of::<int32_t>()
                            < ::core::mem::size_of::<int32_t>()
                        {
                            ::core::mem::size_of::<int32_t>()
                        } else {
                            ::core::mem::size_of::<int32_t>()
                        } == 1usize
                        {
                            _fbs as uint32_t as uint8_t as int8_t as int32_t
                        } else if if ::core::mem::size_of::<int32_t>()
                            < ::core::mem::size_of::<int32_t>()
                        {
                            ::core::mem::size_of::<int32_t>()
                        } else {
                            ::core::mem::size_of::<int32_t>()
                        } == 2usize
                        {
                            _fbs as uint32_t as uint16_t as int16_t as int32_t
                        } else {
                            _fbs as uint32_t as int32_t
                        }
                    {
                        c2rust_current_block_51 = C2Rust_Block_51::S_398;
                    } else {
                        c2rust_current_block_51 = C2Rust_Block_51::S_311;
                    }
                };
            }
            C2Rust_Block_51::S_311 => {
                {
                    (*__gamepkg_tls_g_eax) = 0x73baca as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_313;
                };
                {
                    (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi);
                    c2rust_current_block_51 = C2Rust_Block_51::S_319;
                };
            }
            C2Rust_Block_51::S_319 => {
                {
                    _fa = ((*__gamepkg_tls_g_edx) & 0xff as uint32_t) as uint8_t
                        as uint32_t & 0xff as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_321;
                };
                {
                    _fb = ((*__gamepkg_tls_g_ebx) & 0xff as uint32_t) as uint8_t
                        as uint32_t & 0xff as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_323;
                };
                {
                    _fas = _fa as int8_t as int32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_325;
                };
                {
                    _fbs = _fb as int8_t as int32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_327;
                };
                {
                    if _fa != _fb {
                        c2rust_current_block_51 = C2Rust_Block_51::S_365;
                    } else {
                        c2rust_current_block_51 = C2Rust_Block_51::S_336;
                    }
                };
            }
            C2Rust_Block_51::S_336 => {
                {
                    _fa = ::core::ptr::read_volatile::<
                        uint8_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            ((*__gamepkg_tls_g_eax) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ) as uint32_t & 0xff as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_338;
                };
                {
                    _fb = ((*__gamepkg_tls_g_ebx) & 0xff as uint32_t) as uint8_t
                        as uint32_t & 0xff as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_340;
                };
                {
                    _fas = _fa as int8_t as int32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_342;
                };
                {
                    _fbs = _fb as int8_t as int32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_344;
                };
                {
                    if _fa != _fb {
                        c2rust_current_block_51 = C2Rust_Block_51::S_365;
                    } else {
                        c2rust_current_block_51 = C2Rust_Block_51::S_353;
                    }
                };
            }
            C2Rust_Block_51::S_353 => {
                {
                    (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_edx)
                        & 0xffffff00 as uint32_t
                        | 0 as ::core::ffi::c_int as uint8_t as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_355;
                };
                {
                    _fa = ((*__gamepkg_tls_g_edx) & 0xff as uint32_t) as uint8_t
                        as uint32_t & 0xff as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_357;
                };
                {
                    _fas = _fa as int8_t as int32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_371;
                };
            }
            C2Rust_Block_51::S_365 => {
                (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_edx) & 0xffffff00 as uint32_t
                    | 1 as ::core::ffi::c_int as uint8_t as uint32_t;
                c2rust_current_block_51 = C2Rust_Block_51::S_371;
            }
            C2Rust_Block_51::S_371 => {
                {
                    _fb = 0x27e0 as ::core::ffi::c_int as uint32_t
                        & 0xffffffff as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_373;
                };
                {
                    _fbs = _fb as int32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_375;
                };
                {
                    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
                        .wrapping_add(0x27e0 as uint32_t);
                    c2rust_current_block_51 = C2Rust_Block_51::S_377;
                };
                {
                    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_379;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_381;
                };
                {
                    (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx).wrapping_sub(1);
                    c2rust_current_block_51 = C2Rust_Block_51::S_383;
                };
                {
                    _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_385;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_387;
                };
                {
                    _fb = (_fa == 0x7fffffff as uint32_t) as ::core::ffi::c_int
                        as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_389;
                };
                {
                    if _fa != 0 as uint32_t {
                        c2rust_current_block_51 = C2Rust_Block_51::S_319;
                    } else {
                        c2rust_current_block_51 = C2Rust_Block_51::S_398;
                    }
                };
            }
            C2Rust_Block_51::S_398 => {
                {
                    _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_400;
                };
                {
                    _fb = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_402;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_404;
                };
                {
                    _fbs = _fb as int32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_406;
                };
                {
                    if _fa != _fb {
                        c2rust_current_block_51 = C2Rust_Block_51::S_531;
                    } else {
                        c2rust_current_block_51 = C2Rust_Block_51::S_415;
                    }
                };
            }
            C2Rust_Block_51::S_415 => {
                {
                    _fa = ((*__gamepkg_tls_g_edx) & 0xff as uint32_t) as uint8_t
                        as uint32_t & 0xff as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_417;
                };
                {
                    _fb = ((*__gamepkg_tls_g_ebx) & 0xff as uint32_t) as uint8_t
                        as uint32_t & 0xff as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_419;
                };
                {
                    _fas = _fa as int8_t as int32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_421;
                };
                {
                    _fbs = _fb as int8_t as int32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_423;
                };
                {
                    if _fa == _fb {
                        c2rust_current_block_51 = C2Rust_Block_51::S_531;
                    } else {
                        c2rust_current_block_51 = C2Rust_Block_51::S_432;
                    }
                };
            }
            C2Rust_Block_51::S_432 => {
                {
                    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_edi).wrapping_add(0x38 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_51 = C2Rust_Block_51::S_434;
                };
                {
                    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_edi).wrapping_add(0x4c as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_51 = C2Rust_Block_51::S_436;
                };
                {
                    (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx).wrapping_add(1);
                    c2rust_current_block_51 = C2Rust_Block_51::S_438;
                };
                {
                    _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_440;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_442;
                };
                {
                    _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int
                        as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_444;
                };
                {
                    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_446;
                };
                {
                    _fb = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_448;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_450;
                };
                {
                    _fbs = _fb as int32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_452;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_edi).wrapping_add(0x38 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_ecx),
                    );
                    c2rust_current_block_51 = C2Rust_Block_51::S_454;
                };
                {
                    if _fa != _fb {
                        c2rust_current_block_51 = C2Rust_Block_51::S_503;
                    } else {
                        c2rust_current_block_51 = C2Rust_Block_51::S_467;
                    }
                };
            }
            C2Rust_Block_51::S_467 => {
                {
                    _pv_2 = (*__gamepkg_tls_g_edi);
                    c2rust_current_block_51 = C2Rust_Block_51::S_469;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_51 = C2Rust_Block_51::S_471;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_2,
                    );
                    c2rust_current_block_51 = C2Rust_Block_51::S_481;
                };
                {
                    _pv_3 = 0x142782 as ::core::ffi::c_uint as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_483;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_51 = C2Rust_Block_51::S_485;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_3,
                    );
                    c2rust_current_block_51 = C2Rust_Block_51::S_491;
                };
                {
                    sub_00142990();
                    c2rust_current_block_51 = C2Rust_Block_51::S_553;
                };
            }
            C2Rust_Block_51::S_503 => {
                {
                    (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_edi);
                    c2rust_current_block_51 = C2Rust_Block_51::S_509;
                };
                {
                    _pv_4 = 0x14278b as ::core::ffi::c_uint as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_511;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_51 = C2Rust_Block_51::S_513;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_4,
                    );
                    c2rust_current_block_51 = C2Rust_Block_51::S_519;
                };
                {
                    sub_00142B00();
                    c2rust_current_block_51 = C2Rust_Block_51::S_553;
                };
            }
            C2Rust_Block_51::S_531 => {
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_edi).wrapping_add(0x38 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_ebx),
                    );
                    c2rust_current_block_51 = C2Rust_Block_51::S_537;
                };
                {
                    _pv_5 = 0x142795 as ::core::ffi::c_uint as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_539;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_51 = C2Rust_Block_51::S_541;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_5,
                    );
                    c2rust_current_block_51 = C2Rust_Block_51::S_547;
                };
                {
                    sub_00142910();
                    c2rust_current_block_51 = C2Rust_Block_51::S_553;
                };
            }
            C2Rust_Block_51::S_553 => {
                {
                    _fa = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_edi).wrapping_add(0x18 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ) & 0xffffffff as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_555;
                };
                {
                    _fb = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_557;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_559;
                };
                {
                    _fbs = _fb as int32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_561;
                };
                {
                    if _fa != _fb {
                        c2rust_current_block_51 = C2Rust_Block_51::S_610;
                    } else {
                        c2rust_current_block_51 = C2Rust_Block_51::S_574;
                    }
                };
            }
            C2Rust_Block_51::S_574 => {
                {
                    _pv_6 = (*__gamepkg_tls_g_edi);
                    c2rust_current_block_51 = C2Rust_Block_51::S_576;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_51 = C2Rust_Block_51::S_578;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_6,
                    );
                    c2rust_current_block_51 = C2Rust_Block_51::S_588;
                };
                {
                    _pv_7 = 0x1427a0 as ::core::ffi::c_uint as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_590;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_51 = C2Rust_Block_51::S_592;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_7,
                    );
                    c2rust_current_block_51 = C2Rust_Block_51::S_598;
                };
                {
                    sub_00142CD0();
                    c2rust_current_block_51 = C2Rust_Block_51::S_632;
                };
            }
            C2Rust_Block_51::S_610 => {
                {
                    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_edi);
                    c2rust_current_block_51 = C2Rust_Block_51::S_616;
                };
                {
                    _pv_8 = 0x1427a9 as ::core::ffi::c_uint as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_618;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_51 = C2Rust_Block_51::S_620;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_8,
                    );
                    c2rust_current_block_51 = C2Rust_Block_51::S_626;
                };
                {
                    sub_00142E70();
                    c2rust_current_block_51 = C2Rust_Block_51::S_632;
                };
            }
            C2Rust_Block_51::S_632 => {
                {
                    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_edi).wrapping_add(0x28 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_51 = C2Rust_Block_51::S_634;
                };
                {
                    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_636;
                };
                {
                    _fb = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_638;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_640;
                };
                {
                    _fbs = _fb as int32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_642;
                };
                {
                    if _fa == _fb {
                        c2rust_current_block_51 = C2Rust_Block_51::S_757;
                    } else {
                        c2rust_current_block_51 = C2Rust_Block_51::S_651;
                    }
                };
            }
            C2Rust_Block_51::S_651 => {
                {
                    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax).wrapping_sub(1);
                    c2rust_current_block_51 = C2Rust_Block_51::S_653;
                };
                {
                    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_655;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_657;
                };
                {
                    _fb = (_fa == 0x7fffffff as uint32_t) as ::core::ffi::c_int
                        as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_659;
                };
                {
                    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_661;
                };
                {
                    _fb = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_663;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_665;
                };
                {
                    _fbs = _fb as int32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_667;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_edi).wrapping_add(0x28 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_eax),
                    );
                    c2rust_current_block_51 = C2Rust_Block_51::S_669;
                };
                {
                    if _fa != _fb {
                        c2rust_current_block_51 = C2Rust_Block_51::S_757;
                    } else {
                        c2rust_current_block_51 = C2Rust_Block_51::S_678;
                    }
                };
            }
            C2Rust_Block_51::S_678 => {
                {
                    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                        int16_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            int16_t,
                        >(
                            (0x40fbba as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ) as int32_t as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_680;
                };
                {
                    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x40fbb8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_51 = C2Rust_Block_51::S_682;
                };
                {
                    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
                        << 0x10 as ::core::ffi::c_int;
                    c2rust_current_block_51 = C2Rust_Block_51::S_684;
                };
                {
                    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_686;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_688;
                };
                {
                    _fb = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_690;
                };
                {
                    _fbs = _fb as int32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_692;
                };
                {
                    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
                        .wrapping_add((*__gamepkg_tls_g_ecx));
                    c2rust_current_block_51 = C2Rust_Block_51::S_694;
                };
                {
                    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_696;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_698;
                };
                {
                    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x40fbbc as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_51 = C2Rust_Block_51::S_700;
                };
                {
                    _fb = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_702;
                };
                {
                    _fbs = _fb as int32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_704;
                };
                {
                    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
                        .wrapping_add((*__gamepkg_tls_g_ecx));
                    c2rust_current_block_51 = C2Rust_Block_51::S_706;
                };
                {
                    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_708;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_710;
                };
                {
                    _fb = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_712;
                };
                {
                    _fbs = _fb as int32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_714;
                };
                {
                    (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx)
                        .wrapping_add((*__gamepkg_tls_g_eax));
                    c2rust_current_block_51 = C2Rust_Block_51::S_716;
                };
                {
                    _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_718;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_720;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x40fbbc as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_ecx),
                    );
                    c2rust_current_block_51 = C2Rust_Block_51::S_722;
                };
                {
                    (*__gamepkg_tls_g_edx) = 0 as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_724;
                };
                {
                    _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_726;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_728;
                };
                {
                    (*__gamepkg_tls_g_ecx) = 0x1e as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_730;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x40fbb8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_eax),
                    );
                    c2rust_current_block_51 = C2Rust_Block_51::S_733;
                };
                {
                    _dividend = ((*__gamepkg_tls_g_edx) as uint64_t)
                        << 32 as ::core::ffi::c_int | (*__gamepkg_tls_g_eax) as uint64_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_735;
                };
                {
                    (*__gamepkg_tls_g_eax) = _dividend
                        .wrapping_div((*__gamepkg_tls_g_ecx) as uint64_t) as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_737;
                };
                {
                    (*__gamepkg_tls_g_edx) = _dividend
                        .wrapping_rem((*__gamepkg_tls_g_ecx) as uint64_t) as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_741;
                };
                {
                    _fb = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_743;
                };
                {
                    _fbs = _fb as int32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_745;
                };
                {
                    (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_edx)
                        .wrapping_add((*__gamepkg_tls_g_ecx));
                    c2rust_current_block_51 = C2Rust_Block_51::S_747;
                };
                {
                    _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_749;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_751;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_edi).wrapping_add(0x2c as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_edx),
                    );
                    c2rust_current_block_51 = C2Rust_Block_51::S_757;
                };
            }
            C2Rust_Block_51::S_757 => {
                {
                    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_edi).wrapping_add(0x2c as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_51 = C2Rust_Block_51::S_759;
                };
                {
                    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_761;
                };
                {
                    _fb = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_763;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_765;
                };
                {
                    _fbs = _fb as int32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_767;
                };
                {
                    if _fa == _fb {
                        c2rust_current_block_51 = C2Rust_Block_51::S_1117;
                    } else {
                        c2rust_current_block_51 = C2Rust_Block_51::S_776;
                    }
                };
            }
            C2Rust_Block_51::S_776 => {
                {
                    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax).wrapping_sub(1);
                    c2rust_current_block_51 = C2Rust_Block_51::S_778;
                };
                {
                    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_780;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_782;
                };
                {
                    _fb = (_fa == 0x7fffffff as uint32_t) as ::core::ffi::c_int
                        as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_784;
                };
                {
                    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_786;
                };
                {
                    _fb = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_788;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_790;
                };
                {
                    _fbs = _fb as int32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_792;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_edi).wrapping_add(0x2c as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_eax),
                    );
                    c2rust_current_block_51 = C2Rust_Block_51::S_794;
                };
                {
                    if _fa != _fb {
                        c2rust_current_block_51 = C2Rust_Block_51::S_1117;
                    } else {
                        c2rust_current_block_51 = C2Rust_Block_51::S_803;
                    }
                };
            }
            C2Rust_Block_51::S_803 => {
                {
                    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x40fbb8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_51 = C2Rust_Block_51::S_805;
                };
                {
                    (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x40fbb8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_51 = C2Rust_Block_51::S_807;
                };
                {
                    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x40fbbc as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_51 = C2Rust_Block_51::S_809;
                };
                {
                    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
                        << 0x10 as ::core::ffi::c_int;
                    c2rust_current_block_51 = C2Rust_Block_51::S_811;
                };
                {
                    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_813;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_815;
                };
                {
                    (*__gamepkg_tls_g_edx) = ((*__gamepkg_tls_g_edx) as int32_t
                        >> (0x10 as ::core::ffi::c_uint & 31 as ::core::ffi::c_uint))
                        as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_817;
                };
                {
                    _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_819;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_821;
                };
                {
                    _fb = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_823;
                };
                {
                    _fbs = _fb as int32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_825;
                };
                {
                    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
                        .wrapping_add((*__gamepkg_tls_g_edx));
                    c2rust_current_block_51 = C2Rust_Block_51::S_827;
                };
                {
                    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_829;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_831;
                };
                {
                    _fb = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_833;
                };
                {
                    _fbs = _fb as int32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_835;
                };
                {
                    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
                        .wrapping_add((*__gamepkg_tls_g_ecx));
                    c2rust_current_block_51 = C2Rust_Block_51::S_837;
                };
                {
                    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_839;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_841;
                };
                {
                    _fb = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_843;
                };
                {
                    _fbs = _fb as int32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_845;
                };
                {
                    (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx)
                        .wrapping_add((*__gamepkg_tls_g_eax));
                    c2rust_current_block_51 = C2Rust_Block_51::S_847;
                };
                {
                    _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_849;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_851;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x40fbbc as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_ecx),
                    );
                    c2rust_current_block_51 = C2Rust_Block_51::S_853;
                };
                {
                    (*__gamepkg_tls_g_edx) = 0 as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_855;
                };
                {
                    _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_857;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_859;
                };
                {
                    (*__gamepkg_tls_g_ecx) = 0x1e as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_861;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x40fbb8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_eax),
                    );
                    c2rust_current_block_51 = C2Rust_Block_51::S_864;
                };
                {
                    _dividend_0 = ((*__gamepkg_tls_g_edx) as uint64_t)
                        << 32 as ::core::ffi::c_int | (*__gamepkg_tls_g_eax) as uint64_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_866;
                };
                {
                    (*__gamepkg_tls_g_eax) = _dividend_0
                        .wrapping_div((*__gamepkg_tls_g_ecx) as uint64_t) as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_868;
                };
                {
                    (*__gamepkg_tls_g_edx) = _dividend_0
                        .wrapping_rem((*__gamepkg_tls_g_ecx) as uint64_t) as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_872;
                };
                {
                    _fb = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_874;
                };
                {
                    _fbs = _fb as int32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_876;
                };
                {
                    (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_edx)
                        .wrapping_add((*__gamepkg_tls_g_ecx));
                    c2rust_current_block_51 = C2Rust_Block_51::S_878;
                };
                {
                    _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_880;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_882;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_edi).wrapping_add(0x28 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_edx),
                    );
                    c2rust_current_block_51 = C2Rust_Block_51::S_888;
                };
                {
                    (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_51 = C2Rust_Block_51::S_890;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_add(4 as uint32_t);
                    c2rust_current_block_51 = C2Rust_Block_51::S_900;
                };
                {
                    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_51 = C2Rust_Block_51::S_902;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_add(4 as uint32_t);
                    c2rust_current_block_51 = C2Rust_Block_51::S_912;
                };
                {
                    (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_51 = C2Rust_Block_51::S_914;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_add(4 as uint32_t);
                    c2rust_current_block_51 = C2Rust_Block_51::S_920;
                };
                {
                    _fb = 0x10 as ::core::ffi::c_int as uint32_t
                        & 0xffffffff as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_922;
                };
                {
                    _fbs = _fb as int32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_924;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_add(0x10 as uint32_t);
                    c2rust_current_block_51 = C2Rust_Block_51::S_926;
                };
                {
                    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_928;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_930;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_add(4 as uint32_t);
                    c2rust_current_block_51 = C2Rust_Block_51::S_932;
                };
                return;
            }
            C2Rust_Block_51::S_938 => {
                {
                    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_edi).wrapping_add(0x18 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_51 = C2Rust_Block_51::S_940;
                };
                {
                    _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_942;
                };
                {
                    _fb = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_944;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_946;
                };
                {
                    _fbs = _fb as int32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_948;
                };
                {
                    if _fa == _fb {
                        c2rust_current_block_51 = C2Rust_Block_51::S_1091;
                    } else {
                        c2rust_current_block_51 = C2Rust_Block_51::S_957;
                    }
                };
            }
            C2Rust_Block_51::S_957 => {
                {
                    (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esi).wrapping_add(0xc as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_51 = C2Rust_Block_51::S_963;
                };
                {
                    _pv_9 = (*__gamepkg_tls_g_ebx);
                    c2rust_current_block_51 = C2Rust_Block_51::S_965;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_51 = C2Rust_Block_51::S_967;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_9,
                    );
                    c2rust_current_block_51 = C2Rust_Block_51::S_977;
                };
                {
                    _pv_10 = (*__gamepkg_tls_g_edx);
                    c2rust_current_block_51 = C2Rust_Block_51::S_979;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_51 = C2Rust_Block_51::S_981;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_10,
                    );
                    c2rust_current_block_51 = C2Rust_Block_51::S_991;
                };
                {
                    _pv_11 = 0x142851 as ::core::ffi::c_uint as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_993;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_51 = C2Rust_Block_51::S_995;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_11,
                    );
                    c2rust_current_block_51 = C2Rust_Block_51::S_1001;
                };
                {
                    sub_001FB100();
                    c2rust_current_block_51 = C2Rust_Block_51::S_1007;
                };
                {
                    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esi).wrapping_add(0xc as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_51 = C2Rust_Block_51::S_1013;
                };
                {
                    _pv_12 = (*__gamepkg_tls_g_ebx);
                    c2rust_current_block_51 = C2Rust_Block_51::S_1015;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_51 = C2Rust_Block_51::S_1017;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_12,
                    );
                    c2rust_current_block_51 = C2Rust_Block_51::S_1027;
                };
                {
                    _pv_13 = (*__gamepkg_tls_g_eax);
                    c2rust_current_block_51 = C2Rust_Block_51::S_1029;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_51 = C2Rust_Block_51::S_1031;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_13,
                    );
                    c2rust_current_block_51 = C2Rust_Block_51::S_1041;
                };
                {
                    _pv_14 = 0x14285b as ::core::ffi::c_uint as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_1043;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_51 = C2Rust_Block_51::S_1045;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_14,
                    );
                    c2rust_current_block_51 = C2Rust_Block_51::S_1051;
                };
                {
                    sub_001FB140();
                    c2rust_current_block_51 = C2Rust_Block_51::S_1057;
                };
                {
                    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
                        & 0xffffff00 as uint32_t
                        | ::core::ptr::read_volatile::<
                            uint8_t,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                uint8_t,
                            >(
                                ((*__gamepkg_tls_g_esi).wrapping_add(0x37 as uint32_t)
                                    as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ) as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_1059;
                };
                {
                    (*__gamepkg_tls_g_xmm0) = XMM_ZERO();
                    c2rust_current_block_51 = C2Rust_Block_51::S_1061;
                };
                {
                    _fb = 0x10 as ::core::ffi::c_int as uint32_t
                        & 0xffffffff as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_1063;
                };
                {
                    _fbs = _fb as int32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_1065;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_add(0x10 as uint32_t);
                    c2rust_current_block_51 = C2Rust_Block_51::S_1067;
                };
                {
                    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_1069;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_1071;
                };
                {
                    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
                        & 0xffffff00 as uint32_t
                        | (((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t
                            as ::core::ffi::c_int & 1 as ::core::ffi::c_int) as uint8_t
                            as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_1073;
                };
                {
                    _fa = ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t
                        as uint32_t & 0xff as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_1075;
                };
                {
                    _fas = _fa as int8_t as int32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_1077;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            ((*__gamepkg_tls_g_esi).wrapping_add(0x34 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_ebx) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_51 = C2Rust_Block_51::S_1079;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            ((*__gamepkg_tls_g_esi).wrapping_add(0x30 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm0).f[0usize],
                    );
                    c2rust_current_block_51 = C2Rust_Block_51::S_1081;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            ((*__gamepkg_tls_g_esi).wrapping_add(0x37 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_51 = C2Rust_Block_51::S_1083;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_edi).wrapping_add(0x18 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_ebx),
                    );
                    c2rust_current_block_51 = C2Rust_Block_51::S_1085;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_edi).wrapping_add(0x1c as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_ebx),
                    );
                    c2rust_current_block_51 = C2Rust_Block_51::S_1091;
                };
            }
            C2Rust_Block_51::S_1091 => {
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_edi).wrapping_add(4 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_ebx),
                    );
                    c2rust_current_block_51 = C2Rust_Block_51::S_1097;
                };
                {
                    _pv_15 = 0x14287f as ::core::ffi::c_uint as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_1099;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_51 = C2Rust_Block_51::S_1101;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_15,
                    );
                    c2rust_current_block_51 = C2Rust_Block_51::S_1107;
                };
                {
                    sub_00142910();
                    c2rust_current_block_51 = C2Rust_Block_51::S_1117;
                };
            }
            C2Rust_Block_51::S_1117 => {
                {
                    (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_51 = C2Rust_Block_51::S_1119;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_add(4 as uint32_t);
                    c2rust_current_block_51 = C2Rust_Block_51::S_1129;
                };
                {
                    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_51 = C2Rust_Block_51::S_1131;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_add(4 as uint32_t);
                    c2rust_current_block_51 = C2Rust_Block_51::S_1141;
                };
                {
                    (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_51 = C2Rust_Block_51::S_1143;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_add(4 as uint32_t);
                    c2rust_current_block_51 = C2Rust_Block_51::S_1149;
                };
                {
                    _fb = 0x10 as ::core::ffi::c_int as uint32_t
                        & 0xffffffff as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_1151;
                };
                {
                    _fbs = _fb as int32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_1153;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_add(0x10 as uint32_t);
                    c2rust_current_block_51 = C2Rust_Block_51::S_1155;
                };
                {
                    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_1157;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_51 = C2Rust_Block_51::S_1159;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_add(4 as uint32_t);
                    c2rust_current_block_51 = C2Rust_Block_51::S_1161;
                };
                return;
            }
            C2Rust_Block_51::S_1001
            | C2Rust_Block_51::S_1007
            | C2Rust_Block_51::S_1013
            | C2Rust_Block_51::S_1015
            | C2Rust_Block_51::S_1017
            | C2Rust_Block_51::S_1027
            | C2Rust_Block_51::S_1029
            | C2Rust_Block_51::S_1031
            | C2Rust_Block_51::S_1041
            | C2Rust_Block_51::S_1043
            | C2Rust_Block_51::S_1045
            | C2Rust_Block_51::S_105
            | C2Rust_Block_51::S_1051
            | C2Rust_Block_51::S_1057
            | C2Rust_Block_51::S_1059
            | C2Rust_Block_51::S_1061
            | C2Rust_Block_51::S_1063
            | C2Rust_Block_51::S_1065
            | C2Rust_Block_51::S_1067
            | C2Rust_Block_51::S_1069
            | C2Rust_Block_51::S_107
            | C2Rust_Block_51::S_1071
            | C2Rust_Block_51::S_1073
            | C2Rust_Block_51::S_1075
            | C2Rust_Block_51::S_1077
            | C2Rust_Block_51::S_1079
            | C2Rust_Block_51::S_1081
            | C2Rust_Block_51::S_1083
            | C2Rust_Block_51::S_1085
            | C2Rust_Block_51::S_109
            | C2Rust_Block_51::S_1097
            | C2Rust_Block_51::S_1099
            | C2Rust_Block_51::S_1101
            | C2Rust_Block_51::S_1107
            | C2Rust_Block_51::S_111
            | C2Rust_Block_51::S_1119
            | C2Rust_Block_51::S_1129
            | C2Rust_Block_51::S_113
            | C2Rust_Block_51::S_1131
            | C2Rust_Block_51::S_1141
            | C2Rust_Block_51::S_1143
            | C2Rust_Block_51::S_1149
            | C2Rust_Block_51::S_115
            | C2Rust_Block_51::S_1151
            | C2Rust_Block_51::S_1153
            | C2Rust_Block_51::S_1155
            | C2Rust_Block_51::S_1157
            | C2Rust_Block_51::S_1159
            | C2Rust_Block_51::S_1161
            | C2Rust_Block_51::S_117
            | C2Rust_Block_51::S_119
            | C2Rust_Block_51::S_121
            | C2Rust_Block_51::S_123
            | C2Rust_Block_51::S_125
            | C2Rust_Block_51::S_127
            | C2Rust_Block_51::S_129
            | C2Rust_Block_51::S_131
            | C2Rust_Block_51::S_148
            | C2Rust_Block_51::S_150
            | C2Rust_Block_51::S_152
            | C2Rust_Block_51::S_154
            | C2Rust_Block_51::S_165
            | C2Rust_Block_51::S_167
            | C2Rust_Block_51::S_169
            | C2Rust_Block_51::S_177
            | C2Rust_Block_51::S_179
            | C2Rust_Block_51::S_18
            | C2Rust_Block_51::S_181
            | C2Rust_Block_51::S_183
            | C2Rust_Block_51::S_194
            | C2Rust_Block_51::S_196
            | C2Rust_Block_51::S_198
            | C2Rust_Block_51::S_2
            | C2Rust_Block_51::S_20
            | C2Rust_Block_51::S_206
            | C2Rust_Block_51::S_208
            | C2Rust_Block_51::S_210
            | C2Rust_Block_51::S_212
            | C2Rust_Block_51::S_22
            | C2Rust_Block_51::S_223
            | C2Rust_Block_51::S_225
            | C2Rust_Block_51::S_227
            | C2Rust_Block_51::S_235
            | C2Rust_Block_51::S_237
            | C2Rust_Block_51::S_239
            | C2Rust_Block_51::S_24
            | C2Rust_Block_51::S_241
            | C2Rust_Block_51::S_243
            | C2Rust_Block_51::S_26
            | C2Rust_Block_51::S_268
            | C2Rust_Block_51::S_270
            | C2Rust_Block_51::S_272
            | C2Rust_Block_51::S_274
            | C2Rust_Block_51::S_276
            | C2Rust_Block_51::S_278
            | C2Rust_Block_51::S_280
            | C2Rust_Block_51::S_282
            | C2Rust_Block_51::S_284
            | C2Rust_Block_51::S_286
            | C2Rust_Block_51::S_288
            | C2Rust_Block_51::S_290
            | C2Rust_Block_51::S_292
            | C2Rust_Block_51::S_294
            | C2Rust_Block_51::S_296
            | C2Rust_Block_51::S_298
            | C2Rust_Block_51::S_300
            | C2Rust_Block_51::S_302
            | C2Rust_Block_51::S_313
            | C2Rust_Block_51::S_32
            | C2Rust_Block_51::S_321
            | C2Rust_Block_51::S_323
            | C2Rust_Block_51::S_325
            | C2Rust_Block_51::S_327
            | C2Rust_Block_51::S_338
            | C2Rust_Block_51::S_34
            | C2Rust_Block_51::S_340
            | C2Rust_Block_51::S_342
            | C2Rust_Block_51::S_344
            | C2Rust_Block_51::S_355
            | C2Rust_Block_51::S_357
            | C2Rust_Block_51::S_36
            | C2Rust_Block_51::S_373
            | C2Rust_Block_51::S_375
            | C2Rust_Block_51::S_377
            | C2Rust_Block_51::S_379
            | C2Rust_Block_51::S_381
            | C2Rust_Block_51::S_383
            | C2Rust_Block_51::S_385
            | C2Rust_Block_51::S_387
            | C2Rust_Block_51::S_389
            | C2Rust_Block_51::S_4
            | C2Rust_Block_51::S_400
            | C2Rust_Block_51::S_402
            | C2Rust_Block_51::S_404
            | C2Rust_Block_51::S_406
            | C2Rust_Block_51::S_417
            | C2Rust_Block_51::S_419
            | C2Rust_Block_51::S_421
            | C2Rust_Block_51::S_423
            | C2Rust_Block_51::S_434
            | C2Rust_Block_51::S_436
            | C2Rust_Block_51::S_438
            | C2Rust_Block_51::S_440
            | C2Rust_Block_51::S_442
            | C2Rust_Block_51::S_444
            | C2Rust_Block_51::S_446
            | C2Rust_Block_51::S_448
            | C2Rust_Block_51::S_450
            | C2Rust_Block_51::S_452
            | C2Rust_Block_51::S_454
            | C2Rust_Block_51::S_46
            | C2Rust_Block_51::S_469
            | C2Rust_Block_51::S_471
            | C2Rust_Block_51::S_48
            | C2Rust_Block_51::S_481
            | C2Rust_Block_51::S_483
            | C2Rust_Block_51::S_485
            | C2Rust_Block_51::S_491
            | C2Rust_Block_51::S_50
            | C2Rust_Block_51::S_509
            | C2Rust_Block_51::S_511
            | C2Rust_Block_51::S_513
            | C2Rust_Block_51::S_519
            | C2Rust_Block_51::S_537
            | C2Rust_Block_51::S_539
            | C2Rust_Block_51::S_541
            | C2Rust_Block_51::S_547
            | C2Rust_Block_51::S_555
            | C2Rust_Block_51::S_557
            | C2Rust_Block_51::S_559
            | C2Rust_Block_51::S_561
            | C2Rust_Block_51::S_576
            | C2Rust_Block_51::S_578
            | C2Rust_Block_51::S_588
            | C2Rust_Block_51::S_590
            | C2Rust_Block_51::S_592
            | C2Rust_Block_51::S_598
            | C2Rust_Block_51::S_60
            | C2Rust_Block_51::S_616
            | C2Rust_Block_51::S_618
            | C2Rust_Block_51::S_62
            | C2Rust_Block_51::S_620
            | C2Rust_Block_51::S_626
            | C2Rust_Block_51::S_634
            | C2Rust_Block_51::S_636
            | C2Rust_Block_51::S_638
            | C2Rust_Block_51::S_64
            | C2Rust_Block_51::S_640
            | C2Rust_Block_51::S_642
            | C2Rust_Block_51::S_653
            | C2Rust_Block_51::S_655
            | C2Rust_Block_51::S_657
            | C2Rust_Block_51::S_659
            | C2Rust_Block_51::S_661
            | C2Rust_Block_51::S_663
            | C2Rust_Block_51::S_665
            | C2Rust_Block_51::S_667
            | C2Rust_Block_51::S_669
            | C2Rust_Block_51::S_680
            | C2Rust_Block_51::S_682
            | C2Rust_Block_51::S_684
            | C2Rust_Block_51::S_686
            | C2Rust_Block_51::S_688
            | C2Rust_Block_51::S_690
            | C2Rust_Block_51::S_692
            | C2Rust_Block_51::S_694
            | C2Rust_Block_51::S_696
            | C2Rust_Block_51::S_698
            | C2Rust_Block_51::S_70
            | C2Rust_Block_51::S_700
            | C2Rust_Block_51::S_702
            | C2Rust_Block_51::S_704
            | C2Rust_Block_51::S_706
            | C2Rust_Block_51::S_708
            | C2Rust_Block_51::S_710
            | C2Rust_Block_51::S_712
            | C2Rust_Block_51::S_714
            | C2Rust_Block_51::S_716
            | C2Rust_Block_51::S_718
            | C2Rust_Block_51::S_72
            | C2Rust_Block_51::S_720
            | C2Rust_Block_51::S_722
            | C2Rust_Block_51::S_724
            | C2Rust_Block_51::S_726
            | C2Rust_Block_51::S_728
            | C2Rust_Block_51::S_730
            | C2Rust_Block_51::S_733
            | C2Rust_Block_51::S_735
            | C2Rust_Block_51::S_737
            | C2Rust_Block_51::S_74
            | C2Rust_Block_51::S_741
            | C2Rust_Block_51::S_743
            | C2Rust_Block_51::S_745
            | C2Rust_Block_51::S_747
            | C2Rust_Block_51::S_749
            | C2Rust_Block_51::S_751
            | C2Rust_Block_51::S_759
            | C2Rust_Block_51::S_76
            | C2Rust_Block_51::S_761
            | C2Rust_Block_51::S_763
            | C2Rust_Block_51::S_765
            | C2Rust_Block_51::S_767
            | C2Rust_Block_51::S_778
            | C2Rust_Block_51::S_78
            | C2Rust_Block_51::S_780
            | C2Rust_Block_51::S_782
            | C2Rust_Block_51::S_784
            | C2Rust_Block_51::S_786
            | C2Rust_Block_51::S_788
            | C2Rust_Block_51::S_790
            | C2Rust_Block_51::S_792
            | C2Rust_Block_51::S_794
            | C2Rust_Block_51::S_80
            | C2Rust_Block_51::S_805
            | C2Rust_Block_51::S_807
            | C2Rust_Block_51::S_809
            | C2Rust_Block_51::S_811
            | C2Rust_Block_51::S_813
            | C2Rust_Block_51::S_815
            | C2Rust_Block_51::S_817
            | C2Rust_Block_51::S_819
            | C2Rust_Block_51::S_82
            | C2Rust_Block_51::S_821
            | C2Rust_Block_51::S_823
            | C2Rust_Block_51::S_825
            | C2Rust_Block_51::S_827
            | C2Rust_Block_51::S_829
            | C2Rust_Block_51::S_831
            | C2Rust_Block_51::S_833
            | C2Rust_Block_51::S_835
            | C2Rust_Block_51::S_837
            | C2Rust_Block_51::S_839
            | C2Rust_Block_51::S_84
            | C2Rust_Block_51::S_841
            | C2Rust_Block_51::S_843
            | C2Rust_Block_51::S_845
            | C2Rust_Block_51::S_847
            | C2Rust_Block_51::S_849
            | C2Rust_Block_51::S_851
            | C2Rust_Block_51::S_853
            | C2Rust_Block_51::S_855
            | C2Rust_Block_51::S_857
            | C2Rust_Block_51::S_859
            | C2Rust_Block_51::S_86
            | C2Rust_Block_51::S_861
            | C2Rust_Block_51::S_864
            | C2Rust_Block_51::S_866
            | C2Rust_Block_51::S_868
            | C2Rust_Block_51::S_872
            | C2Rust_Block_51::S_874
            | C2Rust_Block_51::S_876
            | C2Rust_Block_51::S_878
            | C2Rust_Block_51::S_88
            | C2Rust_Block_51::S_880
            | C2Rust_Block_51::S_882
            | C2Rust_Block_51::S_888
            | C2Rust_Block_51::S_890
            | C2Rust_Block_51::S_90
            | C2Rust_Block_51::S_900
            | C2Rust_Block_51::S_902
            | C2Rust_Block_51::S_912
            | C2Rust_Block_51::S_914
            | C2Rust_Block_51::S_92
            | C2Rust_Block_51::S_920
            | C2Rust_Block_51::S_922
            | C2Rust_Block_51::S_924
            | C2Rust_Block_51::S_926
            | C2Rust_Block_51::S_928
            | C2Rust_Block_51::S_930
            | C2Rust_Block_51::S_932
            | C2Rust_Block_51::S_94
            | C2Rust_Block_51::S_940
            | C2Rust_Block_51::S_942
            | C2Rust_Block_51::S_944
            | C2Rust_Block_51::S_946
            | C2Rust_Block_51::S_948
            | C2Rust_Block_51::S_963
            | C2Rust_Block_51::S_965
            | C2Rust_Block_51::S_967
            | C2Rust_Block_51::S_977
            | C2Rust_Block_51::S_979
            | C2Rust_Block_51::S_981
            | C2Rust_Block_51::S_991
            | C2Rust_Block_51::S_993
            | C2Rust_Block_51::S_995 => {
                unreachable!("GamePKG compacted dispatch state reached")
            }
        }
    };
}
#[no_mangle]
pub unsafe extern "C" fn sub_00142890() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebx = unsafe { gamepkg_tls_g_ebx() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _pv: uint32_t = (*__gamepkg_tls_g_ebx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    let mut _pv_0: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    let mut _pv_1: uint32_t = (*__gamepkg_tls_g_edi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_eax);
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_edi).wrapping_add(0x18 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_ebx) = 0 as uint32_t;
    _fa = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
    _fb = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_221: {
        if _fa == _fb {
            break 's_221;
        }
        (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi).wrapping_add(0xc as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        let mut _pv_2: uint32_t = (*__gamepkg_tls_g_ebx);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_2,
        );
        let mut _pv_3: uint32_t = (*__gamepkg_tls_g_eax);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_3,
        );
        let mut _pv_4: uint32_t = 0x1428a8 as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_4,
        );
        sub_001FB100();
        (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi).wrapping_add(0xc as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        let mut _pv_5: uint32_t = (*__gamepkg_tls_g_ebx);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_5,
        );
        let mut _pv_6: uint32_t = (*__gamepkg_tls_g_ecx);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_6,
        );
        let mut _pv_7: uint32_t = 0x1428b2 as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_7,
        );
        sub_001FB140();
        (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 0xffffff00 as uint32_t
            | ::core::ptr::read_volatile::<
                uint8_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint8_t,
                >(
                    ((*__gamepkg_tls_g_esi).wrapping_add(0x37 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            ) as uint32_t;
        (*__gamepkg_tls_g_xmm0) = XMM_ZERO();
        _fb = 0x10 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fbs = _fb as int32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(0x10 as uint32_t);
        _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 0xffffff00 as uint32_t
            | (((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t
                as ::core::ffi::c_int & 1 as ::core::ffi::c_int) as uint8_t as uint32_t;
        _fa = ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t as uint32_t
            & 0xff as uint32_t;
        _fas = _fa as int8_t as int32_t;
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint8_t,
            >(
                ((*__gamepkg_tls_g_esi).wrapping_add(0x34 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            ((*__gamepkg_tls_g_ebx) & 0xff as uint32_t) as uint8_t,
        );
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                ((*__gamepkg_tls_g_esi).wrapping_add(0x30 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            (*__gamepkg_tls_g_xmm0).f[0usize],
        );
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint8_t,
            >(
                ((*__gamepkg_tls_g_esi).wrapping_add(0x37 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t,
        );
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_edi).wrapping_add(0x18 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            (*__gamepkg_tls_g_ebx),
        );
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_edi).wrapping_add(0x1c as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            (*__gamepkg_tls_g_ebx),
        );
    }
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_edi).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_ebx),
    );
    let mut _pv_8: uint32_t = 0x1428d6 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_8,
    );
    sub_00142910();
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_edi).wrapping_add(0x44 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fb = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_296: {
        if _fa == _fb {
            break 's_296;
        }
        (*__gamepkg_tls_g_ebx) = 0x40b7f4 as uint32_t;
        let mut _pv_9: uint32_t = 0x1428e7 as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_9,
        );
        sub_001C9DE0();
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_edi).wrapping_add(0x44 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            0 as uint32_t,
        );
        (*__gamepkg_tls_g_ebx) = 0 as uint32_t;
        _fa = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
    }
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_edi).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fb = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_347: {
        if _fa == _fb {
            break 's_347;
        }
        (*__gamepkg_tls_g_ebx) = 0x40b7f4 as uint32_t;
        let mut _pv_10: uint32_t = 0x142901 as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_10,
        );
        sub_001C9DE0();
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_edi).wrapping_add(8 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            0 as uint32_t,
        );
    }
    (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
