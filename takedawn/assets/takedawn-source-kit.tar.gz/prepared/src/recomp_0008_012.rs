extern "C" {
    static mut g_xbox_mem_offset: ptrdiff_t;
    fn gamepkg_tls_g_eax() -> *mut uint32_t;
    fn gamepkg_tls_g_ecx() -> *mut uint32_t;
    fn gamepkg_tls_g_edx() -> *mut uint32_t;
    fn gamepkg_tls_g_esp() -> *mut uint32_t;
    fn gamepkg_tls_g_ebx() -> *mut uint32_t;
    fn gamepkg_tls_g_edi() -> *mut uint32_t;
    fn gamepkg_tls_g_esi() -> *mut uint32_t;
    fn gamepkg_tls_g_seh_ebp() -> *mut uint32_t;
    fn gamepkg_tls_g_ebp() -> *mut uint32_t;
    fn gamepkg_tls_g_xmm3() -> *mut RecompXmm;
    fn gamepkg_tls_g_xmm2() -> *mut RecompXmm;
    fn gamepkg_tls_g_xmm1() -> *mut RecompXmm;
    fn gamepkg_tls_g_xmm0() -> *mut RecompXmm;
    fn gamepkg_tls_g_xmm5() -> *mut RecompXmm;
    fn gamepkg_tls_g_xmm4() -> *mut RecompXmm;
    fn gamepkg_tls_g_xmm7() -> *mut RecompXmm;
    fn gamepkg_tls_g_xmm6() -> *mut RecompXmm;
}
pub type int32_t = i32;
pub type uint8_t = u8;
pub type uint32_t = u32;
pub type uint64_t = u64;
pub type uintptr_t = usize;
pub type ptrdiff_t = isize;
#[derive(Copy, Clone)]
#[repr(C)]
pub union RecompXmm {
    pub f: [::core::ffi::c_float; 4],
    pub d: [::core::ffi::c_double; 2],
    pub u: [uint32_t; 4],
    pub i: [int32_t; 4],
    pub q: [uint64_t; 2],
}
#[inline]
unsafe extern "C" fn XMM_ZERO() -> RecompXmm {
    let mut r: RecompXmm = RecompXmm { f: [0.; 4] };
    r.q[0usize] = 0 as uint64_t;
    r.q[1usize] = 0 as uint64_t;
    return r;
}
#[inline]
unsafe extern "C" fn XMM_SCALAR(mut v: ::core::ffi::c_float) -> RecompXmm {
    let mut r: RecompXmm = XMM_ZERO();
    r.f[0usize] = v;
    return r;
}
#[no_mangle]
pub unsafe extern "C" fn sub_0025E840() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b2108 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x4d914c as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0025E860() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b210c as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x4d705c as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0025E880() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b2110 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x4d7040 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0025E8A0() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1f00 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x4d9144 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0025E8C0() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1eec as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x4d7048 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0025E8E0() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x4d9144 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        - ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3a7964 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x4d9158 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0025E900() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x4d7048 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        - ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x388f08 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x4d9150 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0025E920() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1ca8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x4d9178 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0025E940() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3897a8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x4d915c as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0025E960() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x4d915c as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x4d9170 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0025E980() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1ca8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x4d7044 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0025E9A0() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x4d7048 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        * ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1728 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x4d9160 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0025E9C0() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x4d7048 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        * ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x39922c as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x4d7054 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0025E9E0() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x4d7048 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        - ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x4d7054 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x4d7050 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0025EA00() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1694 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x4d9148 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0025EA20() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b16d0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x4d704c as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0025EA40() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b2140 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x4d7058 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0025EA60() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1a90 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x4d9154 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0025EA80() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b2140 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x4d9164 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0025EAA0() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1f50 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x4d9168 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0025EAC0() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b18f0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x4d9174 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0025EAE0() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b2144 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x4d916c as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0025EB00() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b191c as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x4d9180 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0025EB20() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b2108 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x4d9184 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0025EB40() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b210c as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x4d917c as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0025EB60() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b191c as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x4d9230 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0025EB80() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b2108 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x4d9314 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0025EBA0() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b210c as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x4d9210 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0025EBC0() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b2110 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x4d9188 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0025EBE0() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1f00 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x4d9234 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0025EC00() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1eec as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x4d9190 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0025EC20() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x4d9234 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        - ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3a7964 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x4d93e8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0025EC40() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x4d9190 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        - ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x388f08 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x4d93e0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0025EC60() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1ca8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x4d9410 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0025EC80() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3897a8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x4d93ec as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0025ECA0() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x4d93ec as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x4d9400 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0025ECC0() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1ca8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x4d918c as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0025ECE0() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x4d9190 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        * ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1728 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x4d93f0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0025ED00() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x4d9190 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        * ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x39922c as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x4d9208 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0025ED20() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x4d9190 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        - ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x4d9208 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x4d91f8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0025ED40() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1694 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x4d9310 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0025ED60() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b16d0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x4d9194 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0025ED80() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b2140 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x4d920c as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0025EDA0() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1a90 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x4d93e4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0025EDC0() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b2140 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x4d93f4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0025EDE0() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1f50 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x4d93fc as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0025EE00() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b2148 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x4d93f8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0025EE20() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_ebx = unsafe { gamepkg_tls_g_ebx() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    let __gamepkg_tls_g_xmm1 = unsafe { gamepkg_tls_g_xmm1() };
    let __gamepkg_tls_g_xmm2 = unsafe { gamepkg_tls_g_xmm2() };
    let __gamepkg_tls_g_xmm3 = unsafe { gamepkg_tls_g_xmm3() };
    let __gamepkg_tls_g_xmm4 = unsafe { gamepkg_tls_g_xmm4() };
    let __gamepkg_tls_g_xmm5 = unsafe { gamepkg_tls_g_xmm5() };
    let __gamepkg_tls_g_xmm6 = unsafe { gamepkg_tls_g_xmm6() };
    let __gamepkg_tls_g_xmm7 = unsafe { gamepkg_tls_g_xmm7() };
    let mut ebp: uint32_t = 0;
    let mut _fa: uint32_t = 0;
    let mut _fb: uint32_t = 0;
    let mut _fas: int32_t = 0;
    let mut _fbs: int32_t = 0;
    let mut _pv: uint32_t = 0;
    let mut _pv_0: uint32_t = 0;
    let mut _pv_1: uint32_t = 0;
    let mut _pv_2: uint32_t = 0;
    enum C2Rust_Block_49 {
        S_0,
        S_2,
        S_4,
        S_6,
        S_16,
        S_22,
        S_24,
        S_26,
        S_28,
        S_30,
        S_32,
        S_34,
        S_36,
        S_38,
        S_40,
        S_42,
        S_44,
        S_46,
        S_48,
        S_50,
        S_52,
        S_58,
        S_60,
        S_62,
        S_68,
        S_70,
        S_76,
        S_78,
        S_80,
        S_86,
        S_88,
        S_90,
        S_92,
        S_94,
        S_100,
        S_102,
        S_104,
        S_110,
        S_112,
        S_114,
        S_120,
        S_122,
        S_124,
        S_130,
        S_132,
        S_134,
        S_136,
        S_138,
        S_140,
        S_142,
        S_144,
        S_146,
        S_148,
        S_150,
        S_152,
        S_154,
        S_156,
        S_158,
        S_160,
        S_162,
        S_164,
        S_166,
        S_168,
        S_170,
        S_172,
        S_174,
        S_176,
        S_178,
        S_180,
        S_182,
        S_184,
        S_186,
        S_188,
        S_190,
        S_192,
        S_194,
        S_196,
        S_198,
        S_200,
        S_202,
        S_204,
        S_206,
        S_208,
        S_210,
        S_212,
        S_214,
        S_216,
        S_218,
        S_220,
        S_222,
        S_224,
        S_226,
        S_228,
        S_230,
        S_232,
        S_234,
        S_236,
        S_238,
        S_240,
        S_242,
        S_244,
        S_246,
        S_248,
        S_250,
        S_252,
        S_254,
        S_256,
        S_258,
        S_260,
        S_262,
        S_264,
        S_266,
        S_268,
        S_270,
        S_272,
        S_274,
        S_276,
        S_278,
        S_280,
        S_282,
        S_284,
        S_286,
        S_288,
        S_290,
        S_292,
        S_294,
        S_296,
        S_298,
        S_300,
        S_302,
        S_304,
        S_306,
        S_308,
        S_310,
        S_312,
        S_314,
        S_316,
        S_318,
        S_320,
        S_322,
        S_324,
        S_326,
        S_328,
        S_330,
        S_332,
        S_334,
        S_336,
        S_338,
        S_340,
        S_342,
        S_344,
        S_346,
        S_348,
        S_350,
        S_352,
        S_354,
        S_356,
        S_358,
        S_360,
        S_362,
        S_364,
        S_366,
        S_368,
        S_370,
        S_372,
        S_374,
        S_376,
        S_378,
        S_380,
        S_382,
        S_384,
        S_386,
        S_388,
        S_390,
        S_392,
        S_394,
        S_396,
        S_398,
        S_400,
        S_402,
        S_404,
        S_406,
        S_408,
        S_410,
        S_412,
        S_414,
        S_416,
        S_418,
        S_420,
        S_422,
        S_424,
        S_426,
        S_428,
        S_430,
        S_432,
        S_434,
        S_436,
        S_438,
        S_440,
        S_442,
        S_444,
        S_446,
        S_448,
        S_450,
        S_452,
        S_454,
        S_456,
        S_458,
        S_460,
        S_462,
        S_464,
        S_466,
        S_468,
        S_470,
        S_472,
        S_474,
        S_476,
        S_478,
        S_480,
        S_482,
        S_484,
        S_486,
        S_488,
        S_490,
        S_492,
        S_494,
        S_496,
        S_498,
        S_500,
        S_502,
        S_504,
        S_506,
        S_508,
        S_510,
        S_512,
        S_514,
        S_516,
        S_518,
        S_520,
        S_522,
        S_524,
        S_526,
        S_528,
        S_530,
        S_532,
        S_534,
        S_536,
        S_538,
        S_540,
        S_542,
        S_544,
        S_546,
        S_548,
        S_550,
        S_552,
        S_554,
        S_556,
        S_558,
        S_560,
        S_562,
        S_564,
        S_566,
        S_568,
        S_570,
        S_572,
        S_574,
        S_576,
        S_578,
        S_580,
        S_582,
        S_584,
        S_586,
        S_588,
        S_590,
        S_592,
        S_594,
        S_596,
        S_598,
        S_600,
        S_602,
        S_604,
        S_606,
        S_608,
        S_610,
        S_612,
        S_614,
        S_616,
        S_618,
        S_620,
        S_622,
        S_624,
        S_626,
        S_628,
        S_630,
        S_632,
        S_634,
        S_636,
        S_638,
        S_640,
        S_642,
        S_644,
        S_646,
        S_648,
        S_650,
        S_652,
        S_654,
        S_656,
        S_658,
        S_660,
        S_662,
        S_664,
        S_666,
        S_668,
        S_670,
        S_672,
        S_674,
        S_676,
        S_678,
        S_680,
        S_682,
        S_684,
        S_686,
        S_688,
        S_690,
        S_692,
        S_694,
        S_696,
        S_698,
        S_700,
        S_702,
        S_704,
        S_706,
        S_708,
        S_710,
        S_712,
        S_714,
        S_716,
        S_718,
        S_720,
        S_722,
        S_724,
        S_726,
        S_728,
        S_730,
        S_732,
        S_734,
        S_736,
        S_738,
        S_740,
        S_742,
        S_744,
        S_746,
        S_748,
        S_750,
        S_752,
        S_754,
        S_756,
        S_758,
        S_760,
        S_762,
        S_764,
        S_766,
        S_768,
        S_770,
        S_772,
        S_774,
        S_776,
        S_778,
        S_780,
        S_782,
        S_784,
        S_786,
        S_788,
        S_790,
        S_792,
        S_794,
        S_796,
        S_798,
        S_800,
        S_802,
        S_804,
        S_806,
        S_808,
        S_810,
        S_812,
        S_814,
        S_816,
        S_818,
        S_820,
        S_822,
        S_824,
        S_826,
        S_828,
        S_830,
        S_832,
        S_834,
        S_836,
        S_838,
        S_840,
        S_842,
        S_844,
        S_846,
        S_848,
        S_850,
        S_852,
        S_854,
        S_856,
        S_858,
        S_860,
        S_862,
        S_864,
        S_866,
        S_868,
        S_870,
        S_872,
        S_874,
        S_876,
        S_878,
        S_880,
        S_882,
        S_884,
        S_886,
        S_888,
        S_890,
        S_892,
        S_894,
        S_896,
        S_898,
        S_900,
        S_902,
        S_904,
        S_906,
        S_908,
        S_910,
        S_912,
        S_914,
        S_916,
        S_918,
        S_920,
        S_922,
        S_924,
        S_926,
        S_928,
        S_930,
        S_932,
        S_934,
        S_936,
        S_938,
        S_940,
        S_942,
        S_944,
        S_946,
        S_948,
        S_950,
        S_952,
        S_954,
        S_956,
        S_958,
        S_960,
        S_962,
        S_964,
        S_966,
        S_968,
        S_970,
        S_972,
        S_974,
        S_976,
        S_978,
        S_980,
        S_982,
        S_984,
        S_986,
        S_988,
        S_990,
        S_992,
        S_994,
        S_996,
        S_998,
        S_1000,
        S_1002,
        S_1004,
        S_1006,
        S_1008,
        S_1010,
        S_1012,
        S_1014,
        S_1016,
        S_1018,
        S_1020,
        S_1022,
        S_1024,
        S_1026,
        S_1028,
        S_1030,
        S_1032,
        S_1034,
        S_1036,
        S_1038,
        S_1040,
        S_1042,
        S_1044,
        S_1046,
        S_1048,
        S_1050,
        S_1052,
        S_1054,
        S_1056,
        S_1058,
        S_1060,
        S_1062,
        S_1064,
        S_1066,
        S_1068,
        S_1070,
        S_1072,
        S_1074,
        S_1076,
        S_1078,
        S_1080,
        S_1082,
        S_1084,
        S_1086,
        S_1088,
        S_1090,
        S_1092,
        S_1094,
        S_1096,
        S_1098,
        S_1100,
        S_1102,
        S_1104,
        S_1106,
        S_1108,
        S_1110,
        S_1112,
        S_1114,
        S_1116,
        S_1118,
        S_1120,
        S_1122,
        S_1124,
        S_1126,
        S_1128,
        S_1130,
        S_1132,
        S_1134,
        S_1136,
        S_1138,
        S_1140,
        S_1142,
        S_1144,
        S_1146,
        S_1148,
        S_1150,
        S_1152,
        S_1154,
        S_1156,
        S_1158,
        S_1160,
        S_1162,
        S_1164,
        S_1166,
        S_1168,
        S_1170,
        S_1172,
        S_1174,
        S_1176,
        S_1178,
        S_1180,
        S_1182,
        S_1184,
        S_1186,
        S_1188,
        S_1190,
        S_1192,
        S_1194,
        S_1196,
        S_1198,
        S_1200,
        S_1202,
        S_1204,
        S_1206,
        S_1208,
        S_1210,
        S_1212,
        S_1214,
        S_1216,
        S_1218,
        S_1220,
        S_1222,
        S_1224,
        S_1226,
        S_1228,
        S_1230,
        S_1232,
        S_1234,
        S_1236,
        S_1238,
        S_1240,
        S_1242,
        S_1244,
        S_1246,
        S_1248,
        S_1250,
        S_1252,
        S_1254,
        S_1256,
        S_1258,
        S_1260,
        S_1262,
        S_1264,
        S_1266,
        S_1268,
        S_1270,
        S_1272,
        S_1274,
        S_1276,
        S_1278,
        S_1280,
        S_1282,
        S_1284,
        S_1286,
        S_1288,
        S_1290,
        S_1292,
        S_1294,
        S_1296,
        S_1298,
        S_1300,
        S_1302,
        S_1304,
        S_1306,
        S_1308,
        S_1310,
        S_1312,
        S_1314,
        S_1316,
        S_1318,
        S_1320,
        S_1322,
        S_1324,
        S_1326,
        S_1328,
        S_1330,
        S_1332,
        S_1334,
        S_1336,
        S_1338,
        S_1340,
        S_1342,
        S_1344,
        S_1346,
        S_1348,
        S_1350,
        S_1352,
        S_1354,
        S_1356,
        S_1358,
        S_1360,
        S_1362,
        S_1364,
        S_1366,
        S_1368,
        S_1370,
        S_1372,
        S_1374,
        S_1376,
        S_1378,
        S_1380,
        S_1382,
        S_1384,
        S_1386,
        S_1388,
        S_1390,
        S_1392,
        S_1394,
        S_1396,
        S_1398,
        S_1400,
        S_1402,
        S_1404,
        S_1406,
        S_1408,
        S_1410,
        S_1412,
        S_1414,
        S_1416,
        S_1418,
        S_1420,
        S_1422,
        S_1424,
        S_1426,
        S_1428,
        S_1430,
        S_1432,
        S_1434,
        S_1436,
        S_1438,
        S_1440,
        S_1442,
        S_1444,
        S_1446,
        S_1448,
        S_1450,
        S_1452,
        S_1454,
        S_1456,
        S_1458,
        S_1460,
        S_1462,
        S_1464,
        S_1466,
        S_1468,
        S_1470,
        S_1472,
        S_1474,
        S_1476,
        S_1478,
        S_1480,
        S_1482,
        S_1484,
        S_1486,
        S_1488,
        S_1490,
        S_1492,
        S_1494,
        S_1496,
        S_1498,
        S_1500,
        S_1502,
        S_1504,
        S_1506,
        S_1508,
        S_1510,
        S_1512,
        S_1514,
        S_1516,
        S_1518,
        S_1520,
        S_1522,
        S_1524,
        S_1526,
        S_1528,
        S_1530,
        S_1532,
        S_1534,
        S_1536,
        S_1538,
        S_1540,
        S_1542,
        S_1544,
        S_1546,
        S_1548,
        S_1550,
        S_1552,
        S_1554,
        S_1556,
        S_1558,
        S_1560,
        S_1562,
        S_1564,
        S_1566,
        S_1568,
        S_1570,
        S_1572,
        S_1574,
        S_1576,
        S_1578,
        S_1580,
        S_1582,
        S_1584,
        S_1586,
        S_1588,
        S_1590,
        S_1592,
        S_1594,
        S_1596,
        S_1598,
        S_1600,
        S_1602,
        S_1604,
        S_1606,
        S_1608,
        S_1610,
        S_1612,
        S_1614,
        S_1616,
        S_1618,
        S_1620,
        S_1622,
        S_1624,
        S_1626,
        S_1628,
        S_1630,
        S_1632,
        S_1634,
        S_1636,
        S_1638,
        S_1640,
        S_1642,
        S_1644,
        S_1646,
        S_1648,
        S_1650,
        S_1652,
        S_1654,
        S_1656,
        S_1658,
        S_1660,
        S_1662,
        S_1664,
        S_1666,
        S_1668,
        S_1670,
        S_1672,
        S_1674,
        S_1676,
        S_1678,
        S_1680,
        S_1682,
        S_1684,
        S_1686,
        S_1688,
        S_1690,
        S_1692,
        S_1694,
        S_1696,
        S_1698,
        S_1700,
        S_1702,
        S_1704,
        S_1706,
        S_1708,
        S_1710,
        S_1712,
        S_1714,
        S_1716,
        S_1718,
        S_1720,
        S_1722,
        S_1724,
        S_1726,
        S_1728,
        S_1730,
        S_1732,
        S_1734,
        S_1736,
        S_1738,
        S_1740,
        S_1742,
        S_1744,
        S_1746,
        S_1748,
        S_1750,
        S_1752,
        S_1754,
        S_1756,
        S_1758,
        S_1760,
        S_1762,
        S_1764,
        S_1766,
        S_1768,
        S_1770,
        S_1772,
        S_1774,
        S_1776,
        S_1778,
        S_1780,
        S_1782,
        S_1784,
        S_1786,
        S_1788,
        S_1790,
        S_1792,
        S_1794,
        S_1796,
        S_1798,
        S_1800,
        S_1802,
        S_1804,
        S_1806,
        S_1808,
        S_1810,
        S_1812,
        S_1814,
        S_1816,
        S_1818,
        S_1820,
        S_1822,
        S_1824,
        S_1826,
        S_1828,
        S_1830,
        S_1832,
        S_1834,
        S_1836,
        S_1838,
        S_1840,
        S_1842,
        S_1844,
        S_1846,
        S_1848,
        S_1850,
        S_1852,
        S_1854,
        S_1856,
        S_1858,
        S_1860,
        S_1862,
        S_1864,
        S_1866,
        S_1868,
        S_1870,
        S_1872,
        S_1874,
        S_1876,
        S_1878,
        S_1880,
        S_1882,
        S_1884,
        S_1886,
        S_1888,
        S_1890,
        S_1892,
        S_1894,
        S_1896,
        S_1898,
        S_1900,
        S_1902,
        S_1904,
        S_1906,
        S_1908,
        S_1910,
        S_1912,
        S_1914,
        S_1916,
        S_1918,
        S_1920,
        S_1922,
        S_1924,
        S_1926,
        S_1928,
        S_1930,
        S_1932,
        S_1934,
        S_1936,
        S_1938,
        S_1940,
        S_1942,
        S_1944,
        S_1946,
        S_1948,
        S_1950,
        S_1952,
        S_1954,
        S_1956,
        S_1958,
        S_1960,
        S_1962,
        S_1964,
        S_1966,
        S_1968,
        S_1970,
        S_1972,
        S_1974,
        S_1976,
        S_1978,
        S_1980,
        S_1982,
        S_1984,
        S_1986,
        S_1988,
        S_1990,
        S_1992,
        S_1994,
        S_1996,
        S_1998,
        S_2000,
        S_2002,
        S_2004,
        S_2006,
        S_2008,
        S_2010,
        S_2012,
        S_2014,
        S_2016,
        S_2018,
        S_2020,
        S_2022,
        S_2024,
        S_2026,
        S_2028,
        S_2030,
        S_2032,
        S_2034,
        S_2036,
        S_2038,
        S_2040,
        S_2042,
        S_2044,
        S_2046,
        S_2048,
        S_2050,
        S_2052,
        S_2054,
        S_2056,
        S_2058,
        S_2060,
        S_2062,
        S_2064,
        S_2066,
        S_2068,
        S_2070,
        S_2072,
        S_2074,
        S_2076,
        S_2078,
        S_2080,
        S_2082,
        S_2084,
        S_2086,
        S_2088,
        S_2090,
        S_2092,
        S_2094,
        S_2096,
        S_2098,
        S_2100,
        S_2102,
        S_2104,
        S_2106,
        S_2108,
        S_2110,
        S_2112,
        S_2114,
        S_2116,
        S_2118,
        S_2120,
        S_2122,
        S_2124,
        S_2126,
        S_2128,
        S_2130,
        S_2132,
        S_2134,
        S_2136,
        S_2138,
        S_2140,
        S_2142,
        S_2144,
        S_2146,
        S_2148,
        S_2150,
        S_2152,
        S_2154,
        S_2156,
        S_2158,
        S_2160,
        S_2162,
        S_2164,
        S_2166,
        S_2168,
        S_2170,
        S_2172,
        S_2174,
        S_2176,
        S_2178,
        S_2180,
        S_2182,
        S_2184,
        S_2186,
        S_2188,
        S_2190,
        S_2192,
        S_2194,
        S_2196,
        S_2198,
        S_2200,
        S_2202,
        S_2204,
        S_2206,
        S_2208,
        S_2210,
        S_2212,
        S_2214,
        S_2216,
        S_2218,
        S_2220,
        S_2222,
        S_2224,
        S_2226,
        S_2228,
        S_2230,
        S_2232,
        S_2234,
        S_2236,
        S_2238,
        S_2240,
        S_2242,
        S_2244,
        S_2246,
        S_2248,
        S_2250,
        S_2252,
        S_2254,
        S_2256,
        S_2258,
        S_2260,
        S_2262,
        S_2264,
        S_2266,
        S_2268,
        S_2270,
        S_2272,
        S_2274,
        S_2276,
        S_2278,
        S_2280,
        S_2282,
        S_2284,
        S_2286,
        S_2288,
        S_2290,
        S_2292,
        S_2294,
        S_2296,
        S_2298,
        S_2300,
        S_2302,
        S_2304,
        S_2306,
        S_2308,
        S_2310,
        S_2312,
        S_2314,
        S_2316,
        S_2318,
        S_2320,
        S_2322,
        S_2324,
        S_2326,
        S_2328,
        S_2330,
        S_2332,
        S_2334,
        S_2336,
        S_2338,
        S_2340,
        S_2342,
        S_2344,
        S_2346,
        S_2348,
        S_2350,
        S_2352,
        S_2354,
        S_2356,
        S_2358,
        S_2360,
        S_2362,
        S_2364,
        S_2366,
        S_2368,
        S_2370,
        S_2372,
        S_2374,
        S_2376,
        S_2378,
        S_2380,
        S_2382,
        S_2384,
        S_2386,
        S_2388,
        S_2390,
        S_2392,
        S_2394,
        S_2396,
        S_2398,
        S_2400,
        S_2402,
        S_2404,
        S_2406,
        S_2408,
        S_2410,
        S_2412,
        S_2414,
        S_2416,
        S_2418,
        S_2420,
        S_2422,
        S_2424,
        S_2426,
        S_2428,
        S_2430,
        S_2432,
        S_2434,
        S_2436,
        S_2438,
        S_2440,
        S_2442,
        S_2444,
        S_2446,
        S_2448,
        S_2450,
        S_2452,
        S_2454,
        S_2456,
        S_2458,
        S_2460,
        S_2462,
        S_2464,
        S_2466,
        S_2468,
        S_2470,
        S_2472,
        S_2474,
        S_2476,
        S_2478,
        S_2480,
        S_2482,
        S_2484,
        S_2486,
        S_2488,
        S_2490,
        S_2492,
        S_2494,
        S_2496,
        S_2498,
        S_2500,
        S_2502,
        S_2504,
        S_2506,
        S_2508,
        S_2510,
        S_2512,
        S_2514,
        S_2520,
        S_2522,
        S_2528,
        S_2530,
        S_2536,
        S_2538,
        S_2544,
        S_2546,
        S_2548,
        S_2554,
        S_2556,
        S_2562,
        S_2564,
        S_2566,
        S_2568,
        S_2570,
        S_2572,
        S_2574,
        S_2576,
        S_2578,
        S_2580,
        S_2582,
        S_2584,
        S_2586,
        S_2592,
        S_2594,
        S_2600,
        S_2602,
    }
    let mut c2rust_current_block_49: C2Rust_Block_49;
    c2rust_current_block_49 = C2Rust_Block_49::S_0;
    loop {
        match c2rust_current_block_49 {
            C2Rust_Block_49::S_0 => {
                {
                    ebp = 0 as uint32_t;
                    c2rust_current_block_49 = C2Rust_Block_49::S_2;
                };
                {
                    ebp = (*__gamepkg_tls_g_ebp);
                    c2rust_current_block_49 = C2Rust_Block_49::S_4;
                };
                {
                    _fa = 0 as uint32_t;
                    _fb = 0 as uint32_t;
                    c2rust_current_block_49 = C2Rust_Block_49::S_6;
                };
                {
                    _fas = 0 as int32_t;
                    _fbs = 0 as int32_t;
                    c2rust_current_block_49 = C2Rust_Block_49::S_16;
                };
                {
                    ebp = (*__gamepkg_tls_g_seh_ebp);
                    c2rust_current_block_49 = C2Rust_Block_49::S_22;
                };
                {
                    (*__gamepkg_tls_g_xmm1) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3a2d50 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_24;
                };
                {
                    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b168c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_26;
                };
                {
                    (*__gamepkg_tls_g_xmm3) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3a69c4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_28;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b16d4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_30;
                };
                {
                    (*__gamepkg_tls_g_xmm2) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3a69b4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_32;
                };
                {
                    (*__gamepkg_tls_g_xmm4) = XMM_ZERO();
                    c2rust_current_block_49 = C2Rust_Block_49::S_34;
                };
                {
                    (*__gamepkg_tls_g_xmm5) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3a7950 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_36;
                };
                {
                    (*__gamepkg_tls_g_xmm6) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3a7ed8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_38;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418330 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm1).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_40;
                };
                {
                    (*__gamepkg_tls_g_xmm1) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3a5600 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_42;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418334 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm1).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_44;
                };
                {
                    (*__gamepkg_tls_g_xmm1) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x39b2b0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_46;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418348 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm1).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_48;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x41834c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm1).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_50;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418350 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm1).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_52;
                };
                {
                    (*__gamepkg_tls_g_xmm1) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3a795c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_58;
                };
                {
                    _pv = (*__gamepkg_tls_g_ebx);
                    c2rust_current_block_49 = C2Rust_Block_49::S_60;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_49 = C2Rust_Block_49::S_62;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_68;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418360 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm1).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_70;
                };
                {
                    (*__gamepkg_tls_g_xmm1) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b2154 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_76;
                };
                {
                    _pv_0 = ebp;
                    c2rust_current_block_49 = C2Rust_Block_49::S_78;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_49 = C2Rust_Block_49::S_80;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_0,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_86;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418364 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm1).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_88;
                };
                {
                    (*__gamepkg_tls_g_xmm1) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b17c8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_90;
                };
                {
                    (*__gamepkg_tls_g_ecx) = 0 as uint32_t;
                    c2rust_current_block_49 = C2Rust_Block_49::S_92;
                };
                {
                    _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                    c2rust_current_block_49 = C2Rust_Block_49::S_94;
                };
                {
                    _fas = _fa as int32_t;
                    c2rust_current_block_49 = C2Rust_Block_49::S_100;
                };
                {
                    _pv_1 = (*__gamepkg_tls_g_esi);
                    c2rust_current_block_49 = C2Rust_Block_49::S_102;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_49 = C2Rust_Block_49::S_104;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_1,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_110;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x41838c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm1).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_112;
                };
                {
                    (*__gamepkg_tls_g_xmm1) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b1870 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_114;
                };
                {
                    (*__gamepkg_tls_g_edx) = 1 as uint32_t;
                    c2rust_current_block_49 = C2Rust_Block_49::S_120;
                };
                {
                    _pv_2 = (*__gamepkg_tls_g_edi);
                    c2rust_current_block_49 = C2Rust_Block_49::S_122;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_sub(4 as uint32_t);
                    c2rust_current_block_49 = C2Rust_Block_49::S_124;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        _pv_2,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_130;
                };
                {
                    (*__gamepkg_tls_g_eax) = 0xff as uint32_t;
                    c2rust_current_block_49 = C2Rust_Block_49::S_132;
                };
                {
                    (*__gamepkg_tls_g_ebx) = (*__gamepkg_tls_g_ebx)
                        & 0xffffff00 as uint32_t
                        | 0xc0 as ::core::ffi::c_int as uint8_t as uint32_t;
                    c2rust_current_block_49 = C2Rust_Block_49::S_134;
                };
                {
                    (*__gamepkg_tls_g_esi) = 3 as uint32_t;
                    c2rust_current_block_49 = C2Rust_Block_49::S_136;
                };
                {
                    ebp = 0x64 as uint32_t;
                    c2rust_current_block_49 = C2Rust_Block_49::S_138;
                };
                {
                    (*__gamepkg_tls_g_edi) = 0x40 as uint32_t;
                    c2rust_current_block_49 = C2Rust_Block_49::S_140;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418390 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm1).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_142;
                };
                {
                    (*__gamepkg_tls_g_xmm1) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b1684 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_144;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418318 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm0).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_146;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x41831c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm0).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_148;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x418320 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        0x3aaf44 as uint32_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_150;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418324 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_edx) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_152;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x418328 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_esi),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_154;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x41832c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_ecx),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_156;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418338 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        0x60 as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_158;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418339 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        0x60 as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_160;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x41833a as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        0x60 as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_162;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x41833b as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_164;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x41833c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        0x60 as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_166;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x41833d as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        0x60 as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_168;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x41833e as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        0x60 as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_170;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x41833f as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_172;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418340 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        0x60 as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_174;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418341 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        0x60 as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_176;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418342 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        0x60 as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_178;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418343 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        0x40 as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_180;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418344 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_182;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418354 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm3).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_184;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418358 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_186;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x41835c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm2).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_188;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418368 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm4).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_190;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x41836c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm3).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_192;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418370 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm3).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_194;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418374 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm0).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_196;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418378 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm0).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_198;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x41837c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_200;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x41837d as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_edx) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_202;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x418380 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ebp,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_204;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x418384 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        0xc8 as uint32_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_206;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x418388 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_edi),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_208;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418394 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm5).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_210;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418398 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm0).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_212;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x41839c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm0).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_214;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x4183a0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        0x3aaf50 as uint32_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_216;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x4183a4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_edx) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_218;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x4183a8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_ecx),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_220;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x4183ac as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_ecx),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_222;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x4183b0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm1).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_224;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x4183b4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm6).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_226;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x4183b8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_ebx) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_228;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x4183b9 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        0xb0 as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_230;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x4183ba as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        0x90 as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_232;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x4183bb as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_234;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x4183bc as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_ebx) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_236;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x4183d8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_238;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3a795c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_240;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x4183e0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_242;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b19c4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_244;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x4183e4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_246;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b1768 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_248;
                };
                {
                    (*__gamepkg_tls_g_xmm6) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b16ec as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_250;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x4183f4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_252;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x388e90 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_254;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x41840c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_256;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b1870 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_258;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418410 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_260;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b1a08 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_262;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418434 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_264;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b16e8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_266;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418448 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_268;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3a5600 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_270;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x41844c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_272;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3a2d50 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_274;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418450 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_276;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x384a80 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_278;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418454 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_280;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3a2928 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_282;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418458 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_284;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b1730 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_286;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x41845c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_288;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b16b8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_290;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418460 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_292;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b1ac4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_294;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418464 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_296;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b1768 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_298;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x4183bd as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        0xb0 as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_300;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x4183be as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        0x90 as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_302;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x4183bf as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_304;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x4183c0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_ebx) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_306;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x4183c1 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        0xb0 as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_308;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x4183c2 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        0x90 as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_310;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x4183c3 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        0x40 as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_312;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x4183c4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_314;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x4183c8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm6).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_316;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x4183cc as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm6).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_318;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x4183d0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm6).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_320;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x4183d4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm3).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_322;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x4183dc as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm3).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_324;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x4183e8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm4).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_326;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x4183ec as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm3).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_328;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x4183f0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm2).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_330;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x4183f8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm0).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_332;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x4183fc as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_334;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x4183fd as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_edx) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_336;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x418400 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        0x3c as uint32_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_338;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x418404 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_ecx),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_340;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x418408 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_edi),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_342;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418414 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm5).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_344;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418418 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm6).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_346;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x41841c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm6).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_348;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x418420 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        0x3aaf5c as uint32_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_350;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418424 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_edx) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_352;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x418428 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_edx),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_354;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x41842c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_ecx),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_356;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418430 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm1).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_358;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418438 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_360;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418439 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_362;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x41843a as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_364;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x41843b as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        0x10 as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_366;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x41843c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_368;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x41843d as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_370;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x41843e as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_372;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x41843f as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        0x80 as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_374;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418440 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_376;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418441 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_378;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418442 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_380;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418443 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_382;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418444 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_384;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418468 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm4).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_386;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x41846c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm3).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_388;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418470 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm1).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_390;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418474 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_392;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418478 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm0).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_394;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x41847c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_396;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x41847d as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_edx) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_398;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x388e90 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_400;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x41848c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_402;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b1688 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_404;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418490 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_406;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3a7f34 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_408;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418494 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_410;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3a5600 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_412;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418498 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_414;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x41849c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_416;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3a5a48 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_418;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x4184b0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_420;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3a69c0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_422;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x4184b4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_424;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3883c4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_426;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x4184c8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_428;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x4184cc as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_430;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x4184d0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_432;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b17e4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_434;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x4184d8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_436;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x387464 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_438;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x4184e4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_440;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b1688 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_442;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x4184f4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_444;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x388e90 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_446;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x41850c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_448;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b1870 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_450;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418510 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_452;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3a7f34 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_454;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418514 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_456;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3a5a48 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_458;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x418488 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_edi),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_460;
                };
                {
                    (*__gamepkg_tls_g_edi) = 0x3aaf64 as uint32_t;
                    c2rust_current_block_49 = C2Rust_Block_49::S_462;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418530 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_464;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3a69c0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_466;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x418480 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ebp,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_468;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x418484 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_ecx),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_470;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x4184a0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_edi),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_472;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x4184a4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_edx) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_474;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x4184a8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_esi),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_476;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x4184ac as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_ecx),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_478;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x4184b8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_480;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x4184b9 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_482;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x4184ba as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_484;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x4184bb as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_ebx) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_486;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x4184bc as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_488;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x4184bd as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_490;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x4184be as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_492;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x4184bf as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_ebx) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_494;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x4184c0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_496;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x4184c1 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_498;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x4184c2 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_500;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x4184c3 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_502;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x4184c4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_504;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x4184d4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm3).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_506;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x4184dc as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm2).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_508;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x4184e0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm5).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_510;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x4184e8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm4).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_512;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x4184ec as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm3).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_514;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x4184f0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm2).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_516;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x4184f8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm0).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_518;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x4184fc as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_edx) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_520;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x4184fd as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_edx) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_522;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x418500 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        0xb4 as uint32_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_524;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x418504 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        0x21c as uint32_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_526;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x418508 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_eax),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_528;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418518 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm0).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_530;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x41851c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm0).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_532;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x418520 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_edi),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_534;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418524 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_edx) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_536;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x418528 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_esi),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_538;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x41852c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_ecx),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_540;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418534 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_542;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418538 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_544;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418539 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        0x64 as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_546;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x41853a as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        0x19 as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_548;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x41853b as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        0x96 as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_550;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x41853c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_552;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x41853d as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        0x64 as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_554;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x41853e as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        0x19 as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_556;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x41853f as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        0x96 as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_558;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418540 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_560;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b2150 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_562;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418548 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_564;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x41854c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_566;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418550 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_568;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b17e4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_570;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418558 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_572;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x387464 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_574;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418564 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_576;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b1688 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_578;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418574 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_580;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x388e90 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_582;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x41858c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_584;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b1870 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_586;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418590 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_588;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b1698 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_590;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x4185d0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_592;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b16e8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_594;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x4185d4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_596;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3a2928 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_598;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x4185d8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_600;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b16e8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_602;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x4185dc as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_604;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b16b8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_606;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x4185e0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_608;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b16e8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_610;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x4185e4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_612;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b1768 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_614;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418560 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm5).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_616;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418594 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm5).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_618;
                };
                {
                    (*__gamepkg_tls_g_xmm5) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b1690 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_620;
                };
                {
                    (*__gamepkg_tls_g_edi) = 0x3aaf6c as uint32_t;
                    c2rust_current_block_49 = C2Rust_Block_49::S_622;
                };
                {
                    (*__gamepkg_tls_g_esi) = 2 as uint32_t;
                    c2rust_current_block_49 = C2Rust_Block_49::S_624;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x4185f4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_626;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3a7f34 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_628;
                };
                {
                    ebp = 0x78 as uint32_t;
                    c2rust_current_block_49 = C2Rust_Block_49::S_630;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418541 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        0x64 as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_632;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418542 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        0x19 as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_634;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418543 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_636;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418544 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_638;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418554 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm3).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_640;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x41855c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm2).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_642;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418568 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm4).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_644;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x41856c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm3).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_646;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418570 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm2).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_648;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418578 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm0).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_650;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x41857c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_edx) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_652;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x41857d as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_edx) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_654;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x418580 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        0x50 as uint32_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_656;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x418584 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        0xa0 as uint32_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_658;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x418588 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_eax),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_660;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418598 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm0).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_662;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x41859c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm0).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_664;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x4185a0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_edi),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_666;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x4185a4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_edx) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_668;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x4185a8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_esi),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_670;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x4185ac as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_ecx),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_672;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x4185b0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm5).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_674;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x4185b4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm3).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_676;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x4185b8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        0xe0 as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_678;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x4185b9 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        0xe0 as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_680;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x4185ba as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        0xe0 as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_682;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x4185bb as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_684;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x4185bc as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        0xe4 as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_686;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x4185bd as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        0xe4 as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_688;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x4185be as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        0xe4 as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_690;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x4185bf as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        0x70 as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_692;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x4185c0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_694;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x4185c1 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_696;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x4185c2 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_698;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x4185c3 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_700;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x4185c4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_702;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x4185c8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm6).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_704;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x4185cc as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm0).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_706;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x4185e8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm1).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_708;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x4185ec as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm3).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_710;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x4185f0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm1).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_712;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x4185f8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_714;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x4185fc as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_716;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x4185fd as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_edx) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_718;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x418600 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ebp,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_720;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x418604 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        0x96 as uint32_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_722;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x388e90 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_724;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x41860c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_726;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b1688 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_728;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418610 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_730;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x39c16c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_732;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418634 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_734;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b16e8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_736;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418648 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_738;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x41864c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_740;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b16b8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_742;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418658 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_744;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3a7950 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_746;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418660 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_748;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3a7ed8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_750;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418670 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_752;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b16f0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_754;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418674 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_756;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b16b0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_758;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418678 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_760;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x395be4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_762;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x41868c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_764;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3a5600 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_766;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x41869c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_768;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b1698 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_770;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x4186b0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_772;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b1a08 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_774;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x4186b4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_776;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x39b2b0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_778;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x418608 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_eax),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_780;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418614 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm1).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_782;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418618 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm6).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_784;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x41861c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm6).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_786;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x418620 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_edi),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_788;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418624 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_edx) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_790;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x418628 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_esi),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_792;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x41862c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_ecx),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_794;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418630 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm1).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_796;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418638 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_798;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418639 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_800;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x41863a as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_802;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x41863b as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_804;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x41863c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_806;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x41863d as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_808;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x41863e as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_810;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x41863f as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        0xe0 as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_812;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418640 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_814;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418641 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_816;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418642 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_818;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418643 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_820;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418644 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_822;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418650 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm0).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_824;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418654 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm2).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_826;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x41865c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm2).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_828;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418664 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm3).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_830;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418668 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm1).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_832;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x41866c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm4).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_834;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x41867c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_edx) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_836;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x41867d as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_edx) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_838;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x418680 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        0xc8 as uint32_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_840;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x418684 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_ecx),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_842;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x418688 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_eax),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_844;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418690 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm5).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_846;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418694 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm1).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_848;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418698 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm6).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_850;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x4186a0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_edi),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_852;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x4186a4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_edx) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_854;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x4186a8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_esi),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_856;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x4186ac as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_ecx),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_858;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x4186b8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_ebx) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_860;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x4186b9 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_ebx) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_862;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x4186ba as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_ebx) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_864;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x4186bb as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_866;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x4186bc as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_ebx) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_868;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x4186bd as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_ebx) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_870;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x4186be as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_ebx) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_872;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x4186bf as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        0xe0 as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_874;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x4186c0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_876;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x4186c1 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_878;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x4186c2 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_880;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x4186c3 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_882;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x4186c4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_884;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x4186c8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_886;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3a55f8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_888;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x4186cc as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_890;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3a5a48 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_892;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x4186d0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_894;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3a2928 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_896;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x4186d8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_898;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b1750 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_900;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x4186dc as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_902;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b16b8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_904;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x4186e0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_906;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3a7ed8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_908;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x4186f0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_910;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b16f0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_912;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x4186f4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_914;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b16b0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_916;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x4186f8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_918;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x388e90 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_920;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x41870c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_922;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3a5600 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_924;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418730 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_926;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b1870 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_928;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418748 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_930;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x395e88 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_932;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x41874c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_934;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b1730 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_936;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418754 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_938;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3a2928 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_940;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418758 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_942;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b1730 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_944;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x41875c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_946;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b16b8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_948;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418760 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_950;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3a7ed8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_952;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418770 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_954;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b16f0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_956;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418774 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_958;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b16b0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_960;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418778 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_962;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x395be0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_964;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x4186d4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm2).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_966;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x4186e4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm3).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_968;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x4186e8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm1).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_970;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x4186ec as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm4).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_972;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x4186fc as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_edx) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_974;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x4186fd as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_edx) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_976;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x418700 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        0xf0 as uint32_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_978;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x418704 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        0xf0 as uint32_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_980;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x418708 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_eax),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_982;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418710 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm5).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_984;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418714 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm1).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_986;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418718 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm6).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_988;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x41871c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm6).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_990;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x418720 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_edi),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_992;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418724 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_edx) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_994;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x418728 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_esi),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_996;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x41872c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_ecx),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_998;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418734 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm2).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1000;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418738 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1002;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418739 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1004;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x41873a as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1006;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x41873b as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1008;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x41873c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1010;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x41873d as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1012;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x41873e as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1014;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x41873f as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        0xa0 as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1016;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418740 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1018;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418741 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1020;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418742 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1022;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418743 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1024;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418744 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1026;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418750 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm5).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1028;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418764 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm3).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1030;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418768 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm1).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1032;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x41876c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm4).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1034;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x41877c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_edx) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1036;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x41877d as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_edx) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1038;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x418780 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_ecx),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1040;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x418784 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        0xf0 as uint32_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1042;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x418788 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_eax),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1044;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x41878c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1046;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3a5600 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1048;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418798 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1050;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x41879c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1052;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b1694 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1054;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x4187b0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1056;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x39cc08 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1058;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x4187c8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1060;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b03fc as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1062;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x4187d0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1064;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3a2928 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1066;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x4187d8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1068;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b1750 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1070;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x4187dc as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1072;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b16b8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1074;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x4187e0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1076;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3a69bc as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1078;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x4187e4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1080;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3a7ed8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1082;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x4187f0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1084;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b1870 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1086;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x4187f4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1088;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b16b0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1090;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x4187f8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1092;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b03f4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1094;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x41880c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1096;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b1688 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1098;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418810 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1100;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418814 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1102;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3895bc as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1104;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418830 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1106;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b1a78 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1108;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418834 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1110;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3a2d54 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1112;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418790 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm5).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1114;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418794 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm1).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1116;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x4187a0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_edi),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1118;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x4187a4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_edx) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1120;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x4187a8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_esi),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1122;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x4187ac as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_ecx),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1124;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x4187b4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm3).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1126;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x4187b8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        0xdc as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1128;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x4187b9 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        0xd7 as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1130;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x4187ba as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        0xc8 as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1132;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x4187bb as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        0xa as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1134;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x4187bc as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        0xdc as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1136;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x4187bd as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        0xd7 as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1138;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x4187be as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        0xc8 as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1140;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x4187bf as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        0xb4 as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1142;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x4187c0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1144;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x4187c1 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1146;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x4187c2 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        0xf0 as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1148;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x4187c3 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1150;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x4187c4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1152;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x4187cc as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm5).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1154;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x4187d4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm2).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1156;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x4187e8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm1).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1158;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x4187ec as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm4).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1160;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x4187fc as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_edx) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1162;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x4187fd as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_edx) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1164;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x418800 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        0xb4 as uint32_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1166;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x418804 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        0xdc as uint32_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1168;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x418808 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_eax),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1170;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418818 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm6).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1172;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x41881c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm6).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1174;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x418820 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_edi),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1176;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418824 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_edx) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1178;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x418828 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_esi),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1180;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x41882c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_ecx),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1182;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418838 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        0x8c as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1184;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418839 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        0x7d as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1186;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x41883a as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        0x4b as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1188;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x41883b as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        0x60 as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1190;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x41883c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        0x96 as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1192;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x41883d as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        0x8c as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1194;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x41883e as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        0x64 as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1196;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x41883f as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_ebx) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1198;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418840 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        0xd2 as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1200;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418841 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        0xb4 as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1202;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418842 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        0x82 as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1204;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418843 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1206;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418844 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1208;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418848 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1210;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3a2d50 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1212;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x41884c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1214;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3a2928 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1216;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418858 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1218;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b16b8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1220;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418860 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1222;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x39b258 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1224;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418864 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1226;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3a7ed8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1228;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418870 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1230;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b1870 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1232;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418874 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1234;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b16b0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1236;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418878 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1238;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x388e90 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1240;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x41888c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1242;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3a2d50 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1244;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x4188b0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1246;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x384148 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1248;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x4188b4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1250;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3a55f8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1252;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x4188c8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1254;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b1768 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1256;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x4188cc as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1258;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3a2928 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1260;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x4188d8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1262;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b1750 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1264;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x4188dc as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1266;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b16b8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1268;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x4188e0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1270;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3a7ed8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1272;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x4188f0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1274;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b1870 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1276;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x4188f4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1278;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b16b0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1280;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x4188f8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1282;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x388e90 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1284;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418850 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm5).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1286;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418854 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm3).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1288;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x41885c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm3).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1290;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418868 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm1).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1292;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x41886c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm4).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1294;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x41887c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_edx) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1296;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x41887d as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_edx) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1298;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x418880 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        0xf0 as uint32_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1300;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x418884 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_ecx),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1302;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x418888 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_eax),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1304;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418890 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm5).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1306;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418894 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm1).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1308;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418898 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm6).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1310;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x41889c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm6).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1312;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x4188a0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_edi),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1314;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x4188a4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_edx) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1316;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x4188a8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_esi),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1318;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x4188ac as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_ecx),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1320;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x4188b8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_ebx) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1322;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x4188b9 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        0xaa as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1324;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x4188ba as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        0xa0 as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1326;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x4188bb as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1328;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x4188bc as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_ebx) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1330;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x4188bd as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        0xa0 as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1332;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x4188be as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        0xa0 as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1334;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x4188bf as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        0xe0 as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1336;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x4188c0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_ebx) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1338;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x4188c1 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        0xa0 as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1340;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x4188c2 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        0xa0 as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1342;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x4188c3 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1344;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x4188c4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1346;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x4188d0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm5).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1348;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x4188d4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm2).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1350;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x4188e4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm3).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1352;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x4188e8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm1).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1354;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x4188ec as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm4).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1356;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x4188fc as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_edx) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1358;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x4188fd as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_edx) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1360;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x418900 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        0xf0 as uint32_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1362;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x418904 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_ecx),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1364;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x418908 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_eax),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1366;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x41890c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1368;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418910 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm5).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1370;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b1688 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1372;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418914 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1374;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3a5600 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1376;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418918 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1378;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x41891c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1380;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b1768 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1382;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418930 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1384;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3a5a44 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1386;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418934 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1388;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b1750 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1390;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418950 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1392;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b1884 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1394;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418958 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1396;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3a7950 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1398;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418960 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1400;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3a5a58 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1402;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418964 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1404;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3a7ed8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1406;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418970 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1408;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b1870 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1410;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418974 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1412;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b16b0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1414;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418978 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1416;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x388e90 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1418;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x41898c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1420;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b1688 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1422;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418994 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1424;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3a5600 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1426;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418998 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1428;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x41899c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1430;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b03ec as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1432;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x418920 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_edi),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1434;
                };
                {
                    (*__gamepkg_tls_g_edi) = 0x3aaf74 as uint32_t;
                    c2rust_current_block_49 = C2Rust_Block_49::S_1436;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x4189b0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1438;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3a69bc as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1440;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418924 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_edx) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1442;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x418928 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_esi),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1444;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x41892c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_ecx),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1446;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418938 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        0xa8 as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1448;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418939 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        0xb0 as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1450;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x41893a as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        0xb8 as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1452;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x41893b as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1454;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x41893c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        0xa8 as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1456;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x41893d as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        0xb0 as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1458;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x41893e as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        0xb8 as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1460;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x41893f as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        0x60 as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1462;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418940 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        0xa8 as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1464;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418941 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        0xb0 as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1466;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418942 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        0xb8 as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1468;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418943 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1470;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418944 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1472;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418948 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm3).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1474;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x41894c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm2).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1476;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418954 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm3).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1478;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x41895c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm2).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1480;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418968 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm1).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1482;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x41896c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm4).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1484;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x41897c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_edx) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1486;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x41897d as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1488;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x418980 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        0xf0 as uint32_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1490;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x418984 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_ecx),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1492;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x418988 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_eax),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1494;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418990 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm5).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1496;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x4189a0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_edi),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1498;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x4189a4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_edx) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1500;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x4189a8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_ecx),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1502;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x4189ac as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_edx),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1504;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x4189b4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1506;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x4189b8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1508;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x4189b9 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1510;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x4189ba as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1512;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x4189bb as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        0x10 as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1514;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x4189bc as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1516;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x4189bd as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1518;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x4189be as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1520;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x4189bf as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1522;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x4189c0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1524;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x4189c1 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1526;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x4189c2 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1528;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x4189c3 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1530;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x4189c4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1532;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b1698 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1534;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x4189cc as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1536;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3a5a48 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1538;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x4189d0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1540;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3a2928 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1542;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x4189d8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1544;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b1750 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1546;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x4189dc as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1548;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b16b8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1550;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x4189e0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1552;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3a69c0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1554;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x4189e4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1556;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3a7ed8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1558;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x4189f0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1560;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b16b0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1562;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x4189f8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1564;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x395be0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1566;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418a0c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1568;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b1698 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1570;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418a30 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1572;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b1730 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1574;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418a34 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1576;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418a48 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1578;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b18b8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1580;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418a4c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1582;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3a5a48 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1584;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418a50 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1586;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b16d8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1588;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418a58 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1590;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b1750 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1592;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418a5c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1594;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b16b8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1596;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418a60 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1598;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3a7ed8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1600;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418a70 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1602;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b16f0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1604;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418a74 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1606;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b16b0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1608;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418a78 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1610;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3a49fc as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1612;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x4189c8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm0).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1614;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x4189d4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm2).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1616;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x4189e8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm1).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1618;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x4189ec as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm4).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1620;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x4189f4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm0).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1622;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x4189fc as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1624;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x4189fd as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_edx) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1626;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x418a00 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_ecx),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1628;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x418a04 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ebp,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1630;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x418a08 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_eax),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1632;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418a10 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm5).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1634;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418a14 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm1).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1636;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418a18 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm6).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1638;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418a1c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm6).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1640;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x418a20 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_edi),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1642;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418a24 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_edx) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1644;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x418a28 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_ecx),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1646;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x418a2c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_ecx),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1648;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418a38 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1650;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418a39 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1652;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418a3a as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_ebx) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1654;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418a3b as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1656;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418a3c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        0x60 as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1658;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418a3d as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        0x30 as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1660;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418a3e as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        0x18 as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1662;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418a3f as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        0x80 as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1664;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418a40 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1666;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418a41 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1668;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418a42 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1670;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418a43 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1672;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418a44 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_edx) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1674;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418a54 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm2).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1676;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418a64 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm6).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1678;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418a68 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm1).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1680;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418a6c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm4).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1682;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418a7c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_edx) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1684;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418a7d as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_edx) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1686;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x418a80 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_ecx),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1688;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x418a84 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        0xc8 as uint32_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1690;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x418a88 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_eax),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1692;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418a8c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1694;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b1768 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1696;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418ab0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1698;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b1b28 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1700;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418ab4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1702;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x39c16c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1704;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418ac8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1706;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3a69c0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1708;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418acc as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1710;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3a5600 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1712;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418ad0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1714;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3a2928 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1716;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418ad8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1718;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b1884 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1720;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418ae0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1722;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x395e88 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1724;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418ae4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1726;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3a69c0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1728;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418ae8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1730;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3a7ed8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1732;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418af0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1734;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b17ac as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1736;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418af4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1738;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b16b0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1740;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418af8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1742;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x395be4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1744;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418b0c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1746;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b1688 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1748;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418b14 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1750;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3a5600 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1752;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418b18 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1754;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418b1c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1756;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b03ec as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1758;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418a90 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm5).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1760;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418a94 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm1).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1762;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418a98 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm0).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1764;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418a9c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm0).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1766;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x418aa0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        0x3aaf88 as uint32_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1768;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418aa4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_edx) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1770;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x418aa8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_ecx),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1772;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x418aac as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_esi),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1774;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418ab8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1776;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418ab9 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1778;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418aba as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1780;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418abb as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1782;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418abc as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_ebx) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1784;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418abd as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        0x80 as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1786;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418abe as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        0x40 as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1788;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418abf as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1790;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418ac0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        0x80 as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1792;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418ac1 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        0x10 as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1794;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418ac2 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        8 as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1796;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418ac3 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1798;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418ac4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_edx) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1800;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418ad4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm3).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1802;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418adc as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm2).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1804;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418aec as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm4).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1806;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418afc as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_edx) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1808;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418afd as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_edx) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1810;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x418b00 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_ecx),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1812;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x418b04 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        0x96 as uint32_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1814;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x418b08 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_eax),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1816;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418b10 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm5).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1818;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x418b20 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_edi),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1820;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418b24 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_edx) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1822;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x418b28 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_ecx),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1824;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x418b2c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_ecx),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1826;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418b30 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1828;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418b34 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm1).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1830;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418b38 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1832;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418b39 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1834;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418b3a as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1836;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418b3b as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1838;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418b3c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1840;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418b3d as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1842;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418b3e as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1844;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418b3f as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        0xa0 as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1846;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418b40 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1848;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418b41 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1850;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418b42 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1852;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418b43 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1854;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418b44 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1856;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b1870 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1858;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418b4c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1860;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b1698 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1862;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418b50 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1864;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3a2928 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1866;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418b58 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1868;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b1750 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1870;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418b5c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1872;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b16b8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1874;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418b60 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1876;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3a69c0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1878;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418b64 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1880;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3a7ed8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1882;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418b70 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1884;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b16f0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1886;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418b74 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1888;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b16b0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1890;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418b78 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1892;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x388e90 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1894;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418b8c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1896;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3a5600 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1898;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418bb0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1900;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b1730 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1902;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418bb4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1904;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418bc8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1906;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b18b8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1908;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418bcc as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1910;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3a5a48 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1912;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418bd0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1914;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b16d8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1916;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418bd8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1918;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b1750 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1920;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418bdc as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1922;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b16b8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1924;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418be0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1926;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3a69c0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1928;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418be4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1930;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3a7ed8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1932;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418bf0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1934;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b16f0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1936;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418bf4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1938;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b16b0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1940;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418b48 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm2).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1942;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418b54 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm2).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1944;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418b68 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm1).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1946;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418b6c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm4).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1948;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418b7c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_edx) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1950;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418b7d as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_edx) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1952;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x418b80 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_ecx),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1954;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x418b84 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ebp,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1956;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x418b88 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_eax),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1958;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418b90 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm5).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1960;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418b94 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm1).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1962;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418b98 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm6).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1964;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418b9c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm6).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1966;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x418ba0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_edi),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1968;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418ba4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_edx) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1970;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x418ba8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_ecx),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1972;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x418bac as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_ecx),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1974;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418bb8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1976;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418bb9 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1978;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418bba as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_ebx) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1980;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418bbb as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1982;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418bbc as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        0x60 as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1984;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418bbd as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        0x30 as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1986;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418bbe as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        0x18 as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1988;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418bbf as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        0x80 as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1990;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418bc0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1992;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418bc1 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1994;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418bc2 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1996;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418bc3 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_1998;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418bc4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_edx) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2000;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418bd4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm2).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2002;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418be8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm1).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2004;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418bec as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm4).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2006;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418bf8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2008;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418bfc as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_edx) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2010;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418bfd as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_edx) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2012;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x418c00 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_ecx),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2014;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x418c04 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        0xc8 as uint32_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2016;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x418c08 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_eax),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2018;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3a49fc as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2020;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418c0c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2022;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x39c16c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2024;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418c34 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2026;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3895ac as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2028;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418c4c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2030;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b1688 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2032;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418c50 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2034;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b17ac as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2036;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418c54 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm3).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2038;
                };
                {
                    (*__gamepkg_tls_g_xmm3) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3a2928 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2040;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418c74 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2042;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b16b0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2044;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418c58 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm3).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2046;
                };
                {
                    (*__gamepkg_tls_g_xmm3) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b1884 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2048;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418c78 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2050;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x395be4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2052;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418c60 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm3).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2054;
                };
                {
                    (*__gamepkg_tls_g_xmm3) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b214c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2056;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418c8c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2058;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b1688 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2060;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418c64 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm3).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2062;
                };
                {
                    (*__gamepkg_tls_g_xmm3) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3a69c0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2064;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418c94 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2066;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3a5600 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2068;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418c68 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm3).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2070;
                };
                {
                    (*__gamepkg_tls_g_xmm3) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3a7ed8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2072;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418c98 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2074;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418c9c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2076;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b17d8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2078;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418c10 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm5).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2080;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418c14 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm1).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2082;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418c18 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm0).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2084;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418c1c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm0).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2086;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x418c20 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        0x3aaf88 as uint32_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2088;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418c24 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_edx) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2090;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x418c28 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_ecx),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2092;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x418c2c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_esi),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2094;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418c30 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm1).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2096;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418c38 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2098;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418c39 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2100;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418c3a as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2102;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418c3b as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2104;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418c3c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_ebx) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2106;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418c3d as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        0x70 as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2108;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418c3e as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        0x40 as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2110;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418c3f as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2112;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418c40 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        0x80 as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2114;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418c41 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        0x10 as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2116;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418c42 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        8 as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2118;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418c43 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2120;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418c44 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_edx) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2122;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418c48 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm2).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2124;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418c5c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm2).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2126;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418c6c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm4).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2128;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418c70 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm3).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2130;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418c7c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_edx) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2132;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418c7d as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_edx) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2134;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x418c80 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_ecx),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2136;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x418c84 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        0xf0 as uint32_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2138;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x418c88 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_eax),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2140;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418c90 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm5).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2142;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x418ca0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_edi),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2144;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418ca4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_edx) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2146;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x418ca8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_ecx),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2148;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x418cac as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_ecx),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2150;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418cb0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2152;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418cb4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm2).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2154;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418cb8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2156;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418cb9 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2158;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418cba as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2160;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418cbb as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2162;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418cbc as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2164;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418cbd as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2166;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418cbe as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2168;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418cbf as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        0xa0 as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2170;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418cc0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2172;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418cc1 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2174;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418cc2 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2176;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418cc3 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2178;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418cc4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2180;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3a2d50 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2182;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418ccc as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2184;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3a5a48 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2186;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418cd0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2188;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3a2928 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2190;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418d18 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm6).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2192;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418d1c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm6).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2194;
                };
                {
                    (*__gamepkg_tls_g_xmm6) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b1870 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2196;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418cd8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2198;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b1750 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2200;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418d30 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm6).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2202;
                };
                {
                    (*__gamepkg_tls_g_xmm6) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b1730 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2204;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418cdc as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2206;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b16b8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2208;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418d34 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm6).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2210;
                };
                {
                    (*__gamepkg_tls_g_xmm6) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3a5a48 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2212;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418ce0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2214;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3a69c0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2216;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418d48 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm6).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2218;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418d50 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm6).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2220;
                };
                {
                    (*__gamepkg_tls_g_xmm6) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b16d8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2222;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418ce4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2224;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b16f0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2226;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418d58 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm6).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2228;
                };
                {
                    (*__gamepkg_tls_g_xmm6) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b1750 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2230;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418cf4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2232;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b16b0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2234;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418d5c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm6).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2236;
                };
                {
                    (*__gamepkg_tls_g_xmm6) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b16b8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2238;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418cf8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2240;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x388e90 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2242;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418d60 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm6).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2244;
                };
                {
                    (*__gamepkg_tls_g_xmm6) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b1688 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2246;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418d0c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2248;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b1c6c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2250;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418d64 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm6).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2252;
                };
                {
                    (*__gamepkg_tls_g_xmm6) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b1694 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2254;
                };
                {
                    (*__gamepkg_tls_g_ebx) = 0xc8 as uint32_t;
                    c2rust_current_block_49 = C2Rust_Block_49::S_2256;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418cc8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm1).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2258;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418cd4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm2).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2260;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418ce8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm1).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2262;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418cec as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm4).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2264;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418cf0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm3).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2266;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418cfc as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_edx) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2268;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418cfd as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_edx) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2270;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x418d00 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_ecx),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2272;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x418d04 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ebp,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2274;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x418d08 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_eax),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2276;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418d10 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm5).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2278;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418d14 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm1).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2280;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x418d20 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        0x3aaf90 as uint32_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2282;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418d24 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_edx) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2284;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x418d28 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_ecx),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2286;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x418d2c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_ecx),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2288;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418d38 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2290;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418d39 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2292;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418d3a as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2294;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418d3b as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        0x80 as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2296;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418d3c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2298;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418d3d as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        0xf0 as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2300;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418d3e as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        0x90 as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2302;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418d3f as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2304;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418d40 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        0x60 as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2306;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418d41 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        0x10 as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2308;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418d42 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2310;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418d43 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2312;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418d44 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_edx) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2314;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418d4c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm5).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2316;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418d54 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm2).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2318;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418d68 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm4).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2320;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418d6c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm4).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2322;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418d70 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm3).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2324;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418d74 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm6).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2326;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418d78 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm0).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2328;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418d7c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_edx) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2330;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418d7d as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_edx) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2332;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x418d80 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_ecx),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2334;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x418d84 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_ebx),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2336;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x418d88 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_eax),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2338;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418d8c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2340;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418d90 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm5).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2342;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b1698 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2344;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418db0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2346;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x387c04 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2348;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418db4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2350;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b16e8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2352;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418dcc as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2354;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b16d8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2356;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418dd8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2358;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b1750 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2360;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418ddc as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2362;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b16b8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2364;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418e14 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm1).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2366;
                };
                {
                    (*__gamepkg_tls_g_xmm1) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3a5a44 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2368;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418de0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2370;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b1730 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2372;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418df0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm3).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2374;
                };
                {
                    (*__gamepkg_tls_g_xmm3) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b16f0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2376;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418e30 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm1).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2378;
                };
                {
                    (*__gamepkg_tls_g_xmm1) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b1698 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2380;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418de8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2382;
                };
                {
                    (*__gamepkg_tls_g_xmm7) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3a49fc as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2384;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418df4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm3).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2386;
                };
                {
                    (*__gamepkg_tls_g_xmm3) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b16b0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2388;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418e4c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm1).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2390;
                };
                {
                    (*__gamepkg_tls_g_xmm1) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3a2928 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2392;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418d94 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm6).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2394;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418d98 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm0).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2396;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418d9c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm0).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2398;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x418da0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_edi),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2400;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418da4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_edx) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2402;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x418da8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_esi),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2404;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x418dac as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_ecx),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2406;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418db8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2408;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418db9 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        0xb0 as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2410;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418dba as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        0x70 as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2412;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418dbb as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2414;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418dbc as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        0x40 as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2416;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418dbd as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        0x30 as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2418;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418dbe as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        0x20 as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2420;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418dbf as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        0x80 as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2422;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418dc0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        0x60 as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2424;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418dc1 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        0x60 as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2426;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418dc2 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        0x60 as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2428;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418dc3 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2430;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418dc4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_edx) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2432;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418dc8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm5).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2434;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418dd0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm5).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2436;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418dd4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm2).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2438;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418de4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm0).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2440;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418dec as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm4).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2442;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418df8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm3).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2444;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418dfc as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_edx) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2446;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418dfd as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_edx) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2448;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x418e00 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_ecx),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2450;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x418e04 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_ebx),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2452;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x418e08 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_eax),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2454;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418e0c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm7).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2456;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418e10 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm5).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2458;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418e18 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm0).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2460;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418e1c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm0).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2462;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x418e20 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        0x3aafa0 as uint32_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2464;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418e24 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2466;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x418e28 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_ecx),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2468;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x418e2c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_esi),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2470;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418e34 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm2).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2472;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418e38 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2474;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418e39 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2476;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418e3a as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2478;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418e3b as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2480;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418e3c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2482;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418e3d as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2484;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418e3e as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2486;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418e3f as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        0x40 as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2488;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418e40 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2490;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418e41 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2492;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418e42 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        0x80 as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2494;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418e43 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2496;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418e44 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2498;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418e48 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm3).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2500;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418e50 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm0).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2502;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418e54 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm2).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2504;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418e58 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm1).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2506;
                };
                {
                    (*__gamepkg_tls_g_xmm1) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b1750 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2508;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418e5c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm1).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2510;
                };
                {
                    (*__gamepkg_tls_g_xmm1) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b16b8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2512;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418e60 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm1).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2514;
                };
                {
                    (*__gamepkg_tls_g_xmm1) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b1870 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2520;
                };
                {
                    (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2522;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_add(4 as uint32_t);
                    c2rust_current_block_49 = C2Rust_Block_49::S_2528;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418e64 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm1).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2530;
                };
                {
                    (*__gamepkg_tls_g_xmm1) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b17ac as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2536;
                };
                {
                    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2538;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_add(4 as uint32_t);
                    c2rust_current_block_49 = C2Rust_Block_49::S_2544;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418e70 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm1).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2546;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418e74 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm1).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2548;
                };
                {
                    (*__gamepkg_tls_g_xmm1) = XMM_SCALAR(
                        ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b1904 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2554;
                };
                {
                    ebp = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2556;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_add(4 as uint32_t);
                    c2rust_current_block_49 = C2Rust_Block_49::S_2562;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418e68 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm4).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2564;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418e6c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm4).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2566;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418e78 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm0).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2568;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418e7c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_edx) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2570;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            (0x418e7d as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        ((*__gamepkg_tls_g_edx) & 0xff as uint32_t) as uint8_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2572;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x418e80 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_ecx),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2574;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x418e84 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        0x32 as uint32_t,
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2576;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            (0x418e88 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_eax),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2578;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418e8c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm1).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2580;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418e90 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm5).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2582;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418e94 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm6).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2584;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418e98 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm0).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2586;
                };
                {
                    ::core::ptr::write_volatile(
                        ::core::ptr::with_exposed_provenance_mut::<
                            ::core::ffi::c_float,
                        >(
                            (0x418e9c as ::core::ffi::c_int as uint32_t as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                        (*__gamepkg_tls_g_xmm0).f[0usize],
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2592;
                };
                {
                    (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esp) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    );
                    c2rust_current_block_49 = C2Rust_Block_49::S_2594;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_add(4 as uint32_t);
                    c2rust_current_block_49 = C2Rust_Block_49::S_2600;
                };
                {
                    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                        .wrapping_add(4 as uint32_t);
                    c2rust_current_block_49 = C2Rust_Block_49::S_2602;
                };
                return;
            }
            C2Rust_Block_49::S_100
            | C2Rust_Block_49::S_1000
            | C2Rust_Block_49::S_1002
            | C2Rust_Block_49::S_1004
            | C2Rust_Block_49::S_1006
            | C2Rust_Block_49::S_1008
            | C2Rust_Block_49::S_1010
            | C2Rust_Block_49::S_1012
            | C2Rust_Block_49::S_1014
            | C2Rust_Block_49::S_1016
            | C2Rust_Block_49::S_1018
            | C2Rust_Block_49::S_102
            | C2Rust_Block_49::S_1020
            | C2Rust_Block_49::S_1022
            | C2Rust_Block_49::S_1024
            | C2Rust_Block_49::S_1026
            | C2Rust_Block_49::S_1028
            | C2Rust_Block_49::S_1030
            | C2Rust_Block_49::S_1032
            | C2Rust_Block_49::S_1034
            | C2Rust_Block_49::S_1036
            | C2Rust_Block_49::S_1038
            | C2Rust_Block_49::S_104
            | C2Rust_Block_49::S_1040
            | C2Rust_Block_49::S_1042
            | C2Rust_Block_49::S_1044
            | C2Rust_Block_49::S_1046
            | C2Rust_Block_49::S_1048
            | C2Rust_Block_49::S_1050
            | C2Rust_Block_49::S_1052
            | C2Rust_Block_49::S_1054
            | C2Rust_Block_49::S_1056
            | C2Rust_Block_49::S_1058
            | C2Rust_Block_49::S_1060
            | C2Rust_Block_49::S_1062
            | C2Rust_Block_49::S_1064
            | C2Rust_Block_49::S_1066
            | C2Rust_Block_49::S_1068
            | C2Rust_Block_49::S_1070
            | C2Rust_Block_49::S_1072
            | C2Rust_Block_49::S_1074
            | C2Rust_Block_49::S_1076
            | C2Rust_Block_49::S_1078
            | C2Rust_Block_49::S_1080
            | C2Rust_Block_49::S_1082
            | C2Rust_Block_49::S_1084
            | C2Rust_Block_49::S_1086
            | C2Rust_Block_49::S_1088
            | C2Rust_Block_49::S_1090
            | C2Rust_Block_49::S_1092
            | C2Rust_Block_49::S_1094
            | C2Rust_Block_49::S_1096
            | C2Rust_Block_49::S_1098
            | C2Rust_Block_49::S_110
            | C2Rust_Block_49::S_1100
            | C2Rust_Block_49::S_1102
            | C2Rust_Block_49::S_1104
            | C2Rust_Block_49::S_1106
            | C2Rust_Block_49::S_1108
            | C2Rust_Block_49::S_1110
            | C2Rust_Block_49::S_1112
            | C2Rust_Block_49::S_1114
            | C2Rust_Block_49::S_1116
            | C2Rust_Block_49::S_1118
            | C2Rust_Block_49::S_112
            | C2Rust_Block_49::S_1120
            | C2Rust_Block_49::S_1122
            | C2Rust_Block_49::S_1124
            | C2Rust_Block_49::S_1126
            | C2Rust_Block_49::S_1128
            | C2Rust_Block_49::S_1130
            | C2Rust_Block_49::S_1132
            | C2Rust_Block_49::S_1134
            | C2Rust_Block_49::S_1136
            | C2Rust_Block_49::S_1138
            | C2Rust_Block_49::S_114
            | C2Rust_Block_49::S_1140
            | C2Rust_Block_49::S_1142
            | C2Rust_Block_49::S_1144
            | C2Rust_Block_49::S_1146
            | C2Rust_Block_49::S_1148
            | C2Rust_Block_49::S_1150
            | C2Rust_Block_49::S_1152
            | C2Rust_Block_49::S_1154
            | C2Rust_Block_49::S_1156
            | C2Rust_Block_49::S_1158
            | C2Rust_Block_49::S_1160
            | C2Rust_Block_49::S_1162
            | C2Rust_Block_49::S_1164
            | C2Rust_Block_49::S_1166
            | C2Rust_Block_49::S_1168
            | C2Rust_Block_49::S_1170
            | C2Rust_Block_49::S_1172
            | C2Rust_Block_49::S_1174
            | C2Rust_Block_49::S_1176
            | C2Rust_Block_49::S_1178
            | C2Rust_Block_49::S_1180
            | C2Rust_Block_49::S_1182
            | C2Rust_Block_49::S_1184
            | C2Rust_Block_49::S_1186
            | C2Rust_Block_49::S_1188
            | C2Rust_Block_49::S_1190
            | C2Rust_Block_49::S_1192
            | C2Rust_Block_49::S_1194
            | C2Rust_Block_49::S_1196
            | C2Rust_Block_49::S_1198
            | C2Rust_Block_49::S_120
            | C2Rust_Block_49::S_1200
            | C2Rust_Block_49::S_1202
            | C2Rust_Block_49::S_1204
            | C2Rust_Block_49::S_1206
            | C2Rust_Block_49::S_1208
            | C2Rust_Block_49::S_1210
            | C2Rust_Block_49::S_1212
            | C2Rust_Block_49::S_1214
            | C2Rust_Block_49::S_1216
            | C2Rust_Block_49::S_1218
            | C2Rust_Block_49::S_122
            | C2Rust_Block_49::S_1220
            | C2Rust_Block_49::S_1222
            | C2Rust_Block_49::S_1224
            | C2Rust_Block_49::S_1226
            | C2Rust_Block_49::S_1228
            | C2Rust_Block_49::S_1230
            | C2Rust_Block_49::S_1232
            | C2Rust_Block_49::S_1234
            | C2Rust_Block_49::S_1236
            | C2Rust_Block_49::S_1238
            | C2Rust_Block_49::S_124
            | C2Rust_Block_49::S_1240
            | C2Rust_Block_49::S_1242
            | C2Rust_Block_49::S_1244
            | C2Rust_Block_49::S_1246
            | C2Rust_Block_49::S_1248
            | C2Rust_Block_49::S_1250
            | C2Rust_Block_49::S_1252
            | C2Rust_Block_49::S_1254
            | C2Rust_Block_49::S_1256
            | C2Rust_Block_49::S_1258
            | C2Rust_Block_49::S_1260
            | C2Rust_Block_49::S_1262
            | C2Rust_Block_49::S_1264
            | C2Rust_Block_49::S_1266
            | C2Rust_Block_49::S_1268
            | C2Rust_Block_49::S_1270
            | C2Rust_Block_49::S_1272
            | C2Rust_Block_49::S_1274
            | C2Rust_Block_49::S_1276
            | C2Rust_Block_49::S_1278
            | C2Rust_Block_49::S_1280
            | C2Rust_Block_49::S_1282
            | C2Rust_Block_49::S_1284
            | C2Rust_Block_49::S_1286
            | C2Rust_Block_49::S_1288
            | C2Rust_Block_49::S_1290
            | C2Rust_Block_49::S_1292
            | C2Rust_Block_49::S_1294
            | C2Rust_Block_49::S_1296
            | C2Rust_Block_49::S_1298
            | C2Rust_Block_49::S_130
            | C2Rust_Block_49::S_1300
            | C2Rust_Block_49::S_1302
            | C2Rust_Block_49::S_1304
            | C2Rust_Block_49::S_1306
            | C2Rust_Block_49::S_1308
            | C2Rust_Block_49::S_1310
            | C2Rust_Block_49::S_1312
            | C2Rust_Block_49::S_1314
            | C2Rust_Block_49::S_1316
            | C2Rust_Block_49::S_1318
            | C2Rust_Block_49::S_132
            | C2Rust_Block_49::S_1320
            | C2Rust_Block_49::S_1322
            | C2Rust_Block_49::S_1324
            | C2Rust_Block_49::S_1326
            | C2Rust_Block_49::S_1328
            | C2Rust_Block_49::S_1330
            | C2Rust_Block_49::S_1332
            | C2Rust_Block_49::S_1334
            | C2Rust_Block_49::S_1336
            | C2Rust_Block_49::S_1338
            | C2Rust_Block_49::S_134
            | C2Rust_Block_49::S_1340
            | C2Rust_Block_49::S_1342
            | C2Rust_Block_49::S_1344
            | C2Rust_Block_49::S_1346
            | C2Rust_Block_49::S_1348
            | C2Rust_Block_49::S_1350
            | C2Rust_Block_49::S_1352
            | C2Rust_Block_49::S_1354
            | C2Rust_Block_49::S_1356
            | C2Rust_Block_49::S_1358
            | C2Rust_Block_49::S_136
            | C2Rust_Block_49::S_1360
            | C2Rust_Block_49::S_1362
            | C2Rust_Block_49::S_1364
            | C2Rust_Block_49::S_1366
            | C2Rust_Block_49::S_1368
            | C2Rust_Block_49::S_1370
            | C2Rust_Block_49::S_1372
            | C2Rust_Block_49::S_1374
            | C2Rust_Block_49::S_1376
            | C2Rust_Block_49::S_1378
            | C2Rust_Block_49::S_138
            | C2Rust_Block_49::S_1380
            | C2Rust_Block_49::S_1382
            | C2Rust_Block_49::S_1384
            | C2Rust_Block_49::S_1386
            | C2Rust_Block_49::S_1388
            | C2Rust_Block_49::S_1390
            | C2Rust_Block_49::S_1392
            | C2Rust_Block_49::S_1394
            | C2Rust_Block_49::S_1396
            | C2Rust_Block_49::S_1398
            | C2Rust_Block_49::S_140
            | C2Rust_Block_49::S_1400
            | C2Rust_Block_49::S_1402
            | C2Rust_Block_49::S_1404
            | C2Rust_Block_49::S_1406
            | C2Rust_Block_49::S_1408
            | C2Rust_Block_49::S_1410
            | C2Rust_Block_49::S_1412
            | C2Rust_Block_49::S_1414
            | C2Rust_Block_49::S_1416
            | C2Rust_Block_49::S_1418
            | C2Rust_Block_49::S_142
            | C2Rust_Block_49::S_1420
            | C2Rust_Block_49::S_1422
            | C2Rust_Block_49::S_1424
            | C2Rust_Block_49::S_1426
            | C2Rust_Block_49::S_1428
            | C2Rust_Block_49::S_1430
            | C2Rust_Block_49::S_1432
            | C2Rust_Block_49::S_1434
            | C2Rust_Block_49::S_1436
            | C2Rust_Block_49::S_1438
            | C2Rust_Block_49::S_144
            | C2Rust_Block_49::S_1440
            | C2Rust_Block_49::S_1442
            | C2Rust_Block_49::S_1444
            | C2Rust_Block_49::S_1446
            | C2Rust_Block_49::S_1448
            | C2Rust_Block_49::S_1450
            | C2Rust_Block_49::S_1452
            | C2Rust_Block_49::S_1454
            | C2Rust_Block_49::S_1456
            | C2Rust_Block_49::S_1458
            | C2Rust_Block_49::S_146
            | C2Rust_Block_49::S_1460
            | C2Rust_Block_49::S_1462
            | C2Rust_Block_49::S_1464
            | C2Rust_Block_49::S_1466
            | C2Rust_Block_49::S_1468
            | C2Rust_Block_49::S_1470
            | C2Rust_Block_49::S_1472
            | C2Rust_Block_49::S_1474
            | C2Rust_Block_49::S_1476
            | C2Rust_Block_49::S_1478
            | C2Rust_Block_49::S_148
            | C2Rust_Block_49::S_1480
            | C2Rust_Block_49::S_1482
            | C2Rust_Block_49::S_1484
            | C2Rust_Block_49::S_1486
            | C2Rust_Block_49::S_1488
            | C2Rust_Block_49::S_1490
            | C2Rust_Block_49::S_1492
            | C2Rust_Block_49::S_1494
            | C2Rust_Block_49::S_1496
            | C2Rust_Block_49::S_1498
            | C2Rust_Block_49::S_150
            | C2Rust_Block_49::S_1500
            | C2Rust_Block_49::S_1502
            | C2Rust_Block_49::S_1504
            | C2Rust_Block_49::S_1506
            | C2Rust_Block_49::S_1508
            | C2Rust_Block_49::S_1510
            | C2Rust_Block_49::S_1512
            | C2Rust_Block_49::S_1514
            | C2Rust_Block_49::S_1516
            | C2Rust_Block_49::S_1518
            | C2Rust_Block_49::S_152
            | C2Rust_Block_49::S_1520
            | C2Rust_Block_49::S_1522
            | C2Rust_Block_49::S_1524
            | C2Rust_Block_49::S_1526
            | C2Rust_Block_49::S_1528
            | C2Rust_Block_49::S_1530
            | C2Rust_Block_49::S_1532
            | C2Rust_Block_49::S_1534
            | C2Rust_Block_49::S_1536
            | C2Rust_Block_49::S_1538
            | C2Rust_Block_49::S_154
            | C2Rust_Block_49::S_1540
            | C2Rust_Block_49::S_1542
            | C2Rust_Block_49::S_1544
            | C2Rust_Block_49::S_1546
            | C2Rust_Block_49::S_1548
            | C2Rust_Block_49::S_1550
            | C2Rust_Block_49::S_1552
            | C2Rust_Block_49::S_1554
            | C2Rust_Block_49::S_1556
            | C2Rust_Block_49::S_1558
            | C2Rust_Block_49::S_156
            | C2Rust_Block_49::S_1560
            | C2Rust_Block_49::S_1562
            | C2Rust_Block_49::S_1564
            | C2Rust_Block_49::S_1566
            | C2Rust_Block_49::S_1568
            | C2Rust_Block_49::S_1570
            | C2Rust_Block_49::S_1572
            | C2Rust_Block_49::S_1574
            | C2Rust_Block_49::S_1576
            | C2Rust_Block_49::S_1578
            | C2Rust_Block_49::S_158
            | C2Rust_Block_49::S_1580
            | C2Rust_Block_49::S_1582
            | C2Rust_Block_49::S_1584
            | C2Rust_Block_49::S_1586
            | C2Rust_Block_49::S_1588
            | C2Rust_Block_49::S_1590
            | C2Rust_Block_49::S_1592
            | C2Rust_Block_49::S_1594
            | C2Rust_Block_49::S_1596
            | C2Rust_Block_49::S_1598
            | C2Rust_Block_49::S_16
            | C2Rust_Block_49::S_160
            | C2Rust_Block_49::S_1600
            | C2Rust_Block_49::S_1602
            | C2Rust_Block_49::S_1604
            | C2Rust_Block_49::S_1606
            | C2Rust_Block_49::S_1608
            | C2Rust_Block_49::S_1610
            | C2Rust_Block_49::S_1612
            | C2Rust_Block_49::S_1614
            | C2Rust_Block_49::S_1616
            | C2Rust_Block_49::S_1618
            | C2Rust_Block_49::S_162
            | C2Rust_Block_49::S_1620
            | C2Rust_Block_49::S_1622
            | C2Rust_Block_49::S_1624
            | C2Rust_Block_49::S_1626
            | C2Rust_Block_49::S_1628
            | C2Rust_Block_49::S_1630
            | C2Rust_Block_49::S_1632
            | C2Rust_Block_49::S_1634
            | C2Rust_Block_49::S_1636
            | C2Rust_Block_49::S_1638
            | C2Rust_Block_49::S_164
            | C2Rust_Block_49::S_1640
            | C2Rust_Block_49::S_1642
            | C2Rust_Block_49::S_1644
            | C2Rust_Block_49::S_1646
            | C2Rust_Block_49::S_1648
            | C2Rust_Block_49::S_1650
            | C2Rust_Block_49::S_1652
            | C2Rust_Block_49::S_1654
            | C2Rust_Block_49::S_1656
            | C2Rust_Block_49::S_1658
            | C2Rust_Block_49::S_166
            | C2Rust_Block_49::S_1660
            | C2Rust_Block_49::S_1662
            | C2Rust_Block_49::S_1664
            | C2Rust_Block_49::S_1666
            | C2Rust_Block_49::S_1668
            | C2Rust_Block_49::S_1670
            | C2Rust_Block_49::S_1672
            | C2Rust_Block_49::S_1674
            | C2Rust_Block_49::S_1676
            | C2Rust_Block_49::S_1678
            | C2Rust_Block_49::S_168
            | C2Rust_Block_49::S_1680
            | C2Rust_Block_49::S_1682
            | C2Rust_Block_49::S_1684
            | C2Rust_Block_49::S_1686
            | C2Rust_Block_49::S_1688
            | C2Rust_Block_49::S_1690
            | C2Rust_Block_49::S_1692
            | C2Rust_Block_49::S_1694
            | C2Rust_Block_49::S_1696
            | C2Rust_Block_49::S_1698
            | C2Rust_Block_49::S_170
            | C2Rust_Block_49::S_1700
            | C2Rust_Block_49::S_1702
            | C2Rust_Block_49::S_1704
            | C2Rust_Block_49::S_1706
            | C2Rust_Block_49::S_1708
            | C2Rust_Block_49::S_1710
            | C2Rust_Block_49::S_1712
            | C2Rust_Block_49::S_1714
            | C2Rust_Block_49::S_1716
            | C2Rust_Block_49::S_1718
            | C2Rust_Block_49::S_172
            | C2Rust_Block_49::S_1720
            | C2Rust_Block_49::S_1722
            | C2Rust_Block_49::S_1724
            | C2Rust_Block_49::S_1726
            | C2Rust_Block_49::S_1728
            | C2Rust_Block_49::S_1730
            | C2Rust_Block_49::S_1732
            | C2Rust_Block_49::S_1734
            | C2Rust_Block_49::S_1736
            | C2Rust_Block_49::S_1738
            | C2Rust_Block_49::S_174
            | C2Rust_Block_49::S_1740
            | C2Rust_Block_49::S_1742
            | C2Rust_Block_49::S_1744
            | C2Rust_Block_49::S_1746
            | C2Rust_Block_49::S_1748
            | C2Rust_Block_49::S_1750
            | C2Rust_Block_49::S_1752
            | C2Rust_Block_49::S_1754
            | C2Rust_Block_49::S_1756
            | C2Rust_Block_49::S_1758
            | C2Rust_Block_49::S_176
            | C2Rust_Block_49::S_1760
            | C2Rust_Block_49::S_1762
            | C2Rust_Block_49::S_1764
            | C2Rust_Block_49::S_1766
            | C2Rust_Block_49::S_1768
            | C2Rust_Block_49::S_1770
            | C2Rust_Block_49::S_1772
            | C2Rust_Block_49::S_1774
            | C2Rust_Block_49::S_1776
            | C2Rust_Block_49::S_1778
            | C2Rust_Block_49::S_178
            | C2Rust_Block_49::S_1780
            | C2Rust_Block_49::S_1782
            | C2Rust_Block_49::S_1784
            | C2Rust_Block_49::S_1786
            | C2Rust_Block_49::S_1788
            | C2Rust_Block_49::S_1790
            | C2Rust_Block_49::S_1792
            | C2Rust_Block_49::S_1794
            | C2Rust_Block_49::S_1796
            | C2Rust_Block_49::S_1798
            | C2Rust_Block_49::S_180
            | C2Rust_Block_49::S_1800
            | C2Rust_Block_49::S_1802
            | C2Rust_Block_49::S_1804
            | C2Rust_Block_49::S_1806
            | C2Rust_Block_49::S_1808
            | C2Rust_Block_49::S_1810
            | C2Rust_Block_49::S_1812
            | C2Rust_Block_49::S_1814
            | C2Rust_Block_49::S_1816
            | C2Rust_Block_49::S_1818
            | C2Rust_Block_49::S_182
            | C2Rust_Block_49::S_1820
            | C2Rust_Block_49::S_1822
            | C2Rust_Block_49::S_1824
            | C2Rust_Block_49::S_1826
            | C2Rust_Block_49::S_1828
            | C2Rust_Block_49::S_1830
            | C2Rust_Block_49::S_1832
            | C2Rust_Block_49::S_1834
            | C2Rust_Block_49::S_1836
            | C2Rust_Block_49::S_1838
            | C2Rust_Block_49::S_184
            | C2Rust_Block_49::S_1840
            | C2Rust_Block_49::S_1842
            | C2Rust_Block_49::S_1844
            | C2Rust_Block_49::S_1846
            | C2Rust_Block_49::S_1848
            | C2Rust_Block_49::S_1850
            | C2Rust_Block_49::S_1852
            | C2Rust_Block_49::S_1854
            | C2Rust_Block_49::S_1856
            | C2Rust_Block_49::S_1858
            | C2Rust_Block_49::S_186
            | C2Rust_Block_49::S_1860
            | C2Rust_Block_49::S_1862
            | C2Rust_Block_49::S_1864
            | C2Rust_Block_49::S_1866
            | C2Rust_Block_49::S_1868
            | C2Rust_Block_49::S_1870
            | C2Rust_Block_49::S_1872
            | C2Rust_Block_49::S_1874
            | C2Rust_Block_49::S_1876
            | C2Rust_Block_49::S_1878
            | C2Rust_Block_49::S_188
            | C2Rust_Block_49::S_1880
            | C2Rust_Block_49::S_1882
            | C2Rust_Block_49::S_1884
            | C2Rust_Block_49::S_1886
            | C2Rust_Block_49::S_1888
            | C2Rust_Block_49::S_1890
            | C2Rust_Block_49::S_1892
            | C2Rust_Block_49::S_1894
            | C2Rust_Block_49::S_1896
            | C2Rust_Block_49::S_1898
            | C2Rust_Block_49::S_190
            | C2Rust_Block_49::S_1900
            | C2Rust_Block_49::S_1902
            | C2Rust_Block_49::S_1904
            | C2Rust_Block_49::S_1906
            | C2Rust_Block_49::S_1908
            | C2Rust_Block_49::S_1910
            | C2Rust_Block_49::S_1912
            | C2Rust_Block_49::S_1914
            | C2Rust_Block_49::S_1916
            | C2Rust_Block_49::S_1918
            | C2Rust_Block_49::S_192
            | C2Rust_Block_49::S_1920
            | C2Rust_Block_49::S_1922
            | C2Rust_Block_49::S_1924
            | C2Rust_Block_49::S_1926
            | C2Rust_Block_49::S_1928
            | C2Rust_Block_49::S_1930
            | C2Rust_Block_49::S_1932
            | C2Rust_Block_49::S_1934
            | C2Rust_Block_49::S_1936
            | C2Rust_Block_49::S_1938
            | C2Rust_Block_49::S_194
            | C2Rust_Block_49::S_1940
            | C2Rust_Block_49::S_1942
            | C2Rust_Block_49::S_1944
            | C2Rust_Block_49::S_1946
            | C2Rust_Block_49::S_1948
            | C2Rust_Block_49::S_1950
            | C2Rust_Block_49::S_1952
            | C2Rust_Block_49::S_1954
            | C2Rust_Block_49::S_1956
            | C2Rust_Block_49::S_1958
            | C2Rust_Block_49::S_196
            | C2Rust_Block_49::S_1960
            | C2Rust_Block_49::S_1962
            | C2Rust_Block_49::S_1964
            | C2Rust_Block_49::S_1966
            | C2Rust_Block_49::S_1968
            | C2Rust_Block_49::S_1970
            | C2Rust_Block_49::S_1972
            | C2Rust_Block_49::S_1974
            | C2Rust_Block_49::S_1976
            | C2Rust_Block_49::S_1978
            | C2Rust_Block_49::S_198
            | C2Rust_Block_49::S_1980
            | C2Rust_Block_49::S_1982
            | C2Rust_Block_49::S_1984
            | C2Rust_Block_49::S_1986
            | C2Rust_Block_49::S_1988
            | C2Rust_Block_49::S_1990
            | C2Rust_Block_49::S_1992
            | C2Rust_Block_49::S_1994
            | C2Rust_Block_49::S_1996
            | C2Rust_Block_49::S_1998
            | C2Rust_Block_49::S_2
            | C2Rust_Block_49::S_200
            | C2Rust_Block_49::S_2000
            | C2Rust_Block_49::S_2002
            | C2Rust_Block_49::S_2004
            | C2Rust_Block_49::S_2006
            | C2Rust_Block_49::S_2008
            | C2Rust_Block_49::S_2010
            | C2Rust_Block_49::S_2012
            | C2Rust_Block_49::S_2014
            | C2Rust_Block_49::S_2016
            | C2Rust_Block_49::S_2018
            | C2Rust_Block_49::S_202
            | C2Rust_Block_49::S_2020
            | C2Rust_Block_49::S_2022
            | C2Rust_Block_49::S_2024
            | C2Rust_Block_49::S_2026
            | C2Rust_Block_49::S_2028
            | C2Rust_Block_49::S_2030
            | C2Rust_Block_49::S_2032
            | C2Rust_Block_49::S_2034
            | C2Rust_Block_49::S_2036
            | C2Rust_Block_49::S_2038
            | C2Rust_Block_49::S_204
            | C2Rust_Block_49::S_2040
            | C2Rust_Block_49::S_2042
            | C2Rust_Block_49::S_2044
            | C2Rust_Block_49::S_2046
            | C2Rust_Block_49::S_2048
            | C2Rust_Block_49::S_2050
            | C2Rust_Block_49::S_2052
            | C2Rust_Block_49::S_2054
            | C2Rust_Block_49::S_2056
            | C2Rust_Block_49::S_2058
            | C2Rust_Block_49::S_206
            | C2Rust_Block_49::S_2060
            | C2Rust_Block_49::S_2062
            | C2Rust_Block_49::S_2064
            | C2Rust_Block_49::S_2066
            | C2Rust_Block_49::S_2068
            | C2Rust_Block_49::S_2070
            | C2Rust_Block_49::S_2072
            | C2Rust_Block_49::S_2074
            | C2Rust_Block_49::S_2076
            | C2Rust_Block_49::S_2078
            | C2Rust_Block_49::S_208
            | C2Rust_Block_49::S_2080
            | C2Rust_Block_49::S_2082
            | C2Rust_Block_49::S_2084
            | C2Rust_Block_49::S_2086
            | C2Rust_Block_49::S_2088
            | C2Rust_Block_49::S_2090
            | C2Rust_Block_49::S_2092
            | C2Rust_Block_49::S_2094
            | C2Rust_Block_49::S_2096
            | C2Rust_Block_49::S_2098
            | C2Rust_Block_49::S_210
            | C2Rust_Block_49::S_2100
            | C2Rust_Block_49::S_2102
            | C2Rust_Block_49::S_2104
            | C2Rust_Block_49::S_2106
            | C2Rust_Block_49::S_2108
            | C2Rust_Block_49::S_2110
            | C2Rust_Block_49::S_2112
            | C2Rust_Block_49::S_2114
            | C2Rust_Block_49::S_2116
            | C2Rust_Block_49::S_2118
            | C2Rust_Block_49::S_212
            | C2Rust_Block_49::S_2120
            | C2Rust_Block_49::S_2122
            | C2Rust_Block_49::S_2124
            | C2Rust_Block_49::S_2126
            | C2Rust_Block_49::S_2128
            | C2Rust_Block_49::S_2130
            | C2Rust_Block_49::S_2132
            | C2Rust_Block_49::S_2134
            | C2Rust_Block_49::S_2136
            | C2Rust_Block_49::S_2138
            | C2Rust_Block_49::S_214
            | C2Rust_Block_49::S_2140
            | C2Rust_Block_49::S_2142
            | C2Rust_Block_49::S_2144
            | C2Rust_Block_49::S_2146
            | C2Rust_Block_49::S_2148
            | C2Rust_Block_49::S_2150
            | C2Rust_Block_49::S_2152
            | C2Rust_Block_49::S_2154
            | C2Rust_Block_49::S_2156
            | C2Rust_Block_49::S_2158
            | C2Rust_Block_49::S_216
            | C2Rust_Block_49::S_2160
            | C2Rust_Block_49::S_2162
            | C2Rust_Block_49::S_2164
            | C2Rust_Block_49::S_2166
            | C2Rust_Block_49::S_2168
            | C2Rust_Block_49::S_2170
            | C2Rust_Block_49::S_2172
            | C2Rust_Block_49::S_2174
            | C2Rust_Block_49::S_2176
            | C2Rust_Block_49::S_2178
            | C2Rust_Block_49::S_218
            | C2Rust_Block_49::S_2180
            | C2Rust_Block_49::S_2182
            | C2Rust_Block_49::S_2184
            | C2Rust_Block_49::S_2186
            | C2Rust_Block_49::S_2188
            | C2Rust_Block_49::S_2190
            | C2Rust_Block_49::S_2192
            | C2Rust_Block_49::S_2194
            | C2Rust_Block_49::S_2196
            | C2Rust_Block_49::S_2198
            | C2Rust_Block_49::S_22
            | C2Rust_Block_49::S_220
            | C2Rust_Block_49::S_2200
            | C2Rust_Block_49::S_2202
            | C2Rust_Block_49::S_2204
            | C2Rust_Block_49::S_2206
            | C2Rust_Block_49::S_2208
            | C2Rust_Block_49::S_2210
            | C2Rust_Block_49::S_2212
            | C2Rust_Block_49::S_2214
            | C2Rust_Block_49::S_2216
            | C2Rust_Block_49::S_2218
            | C2Rust_Block_49::S_222
            | C2Rust_Block_49::S_2220
            | C2Rust_Block_49::S_2222
            | C2Rust_Block_49::S_2224
            | C2Rust_Block_49::S_2226
            | C2Rust_Block_49::S_2228
            | C2Rust_Block_49::S_2230
            | C2Rust_Block_49::S_2232
            | C2Rust_Block_49::S_2234
            | C2Rust_Block_49::S_2236
            | C2Rust_Block_49::S_2238
            | C2Rust_Block_49::S_224
            | C2Rust_Block_49::S_2240
            | C2Rust_Block_49::S_2242
            | C2Rust_Block_49::S_2244
            | C2Rust_Block_49::S_2246
            | C2Rust_Block_49::S_2248
            | C2Rust_Block_49::S_2250
            | C2Rust_Block_49::S_2252
            | C2Rust_Block_49::S_2254
            | C2Rust_Block_49::S_2256
            | C2Rust_Block_49::S_2258
            | C2Rust_Block_49::S_226
            | C2Rust_Block_49::S_2260
            | C2Rust_Block_49::S_2262
            | C2Rust_Block_49::S_2264
            | C2Rust_Block_49::S_2266
            | C2Rust_Block_49::S_2268
            | C2Rust_Block_49::S_2270
            | C2Rust_Block_49::S_2272
            | C2Rust_Block_49::S_2274
            | C2Rust_Block_49::S_2276
            | C2Rust_Block_49::S_2278
            | C2Rust_Block_49::S_228
            | C2Rust_Block_49::S_2280
            | C2Rust_Block_49::S_2282
            | C2Rust_Block_49::S_2284
            | C2Rust_Block_49::S_2286
            | C2Rust_Block_49::S_2288
            | C2Rust_Block_49::S_2290
            | C2Rust_Block_49::S_2292
            | C2Rust_Block_49::S_2294
            | C2Rust_Block_49::S_2296
            | C2Rust_Block_49::S_2298
            | C2Rust_Block_49::S_230
            | C2Rust_Block_49::S_2300
            | C2Rust_Block_49::S_2302
            | C2Rust_Block_49::S_2304
            | C2Rust_Block_49::S_2306
            | C2Rust_Block_49::S_2308
            | C2Rust_Block_49::S_2310
            | C2Rust_Block_49::S_2312
            | C2Rust_Block_49::S_2314
            | C2Rust_Block_49::S_2316
            | C2Rust_Block_49::S_2318
            | C2Rust_Block_49::S_232
            | C2Rust_Block_49::S_2320
            | C2Rust_Block_49::S_2322
            | C2Rust_Block_49::S_2324
            | C2Rust_Block_49::S_2326
            | C2Rust_Block_49::S_2328
            | C2Rust_Block_49::S_2330
            | C2Rust_Block_49::S_2332
            | C2Rust_Block_49::S_2334
            | C2Rust_Block_49::S_2336
            | C2Rust_Block_49::S_2338
            | C2Rust_Block_49::S_234
            | C2Rust_Block_49::S_2340
            | C2Rust_Block_49::S_2342
            | C2Rust_Block_49::S_2344
            | C2Rust_Block_49::S_2346
            | C2Rust_Block_49::S_2348
            | C2Rust_Block_49::S_2350
            | C2Rust_Block_49::S_2352
            | C2Rust_Block_49::S_2354
            | C2Rust_Block_49::S_2356
            | C2Rust_Block_49::S_2358
            | C2Rust_Block_49::S_236
            | C2Rust_Block_49::S_2360
            | C2Rust_Block_49::S_2362
            | C2Rust_Block_49::S_2364
            | C2Rust_Block_49::S_2366
            | C2Rust_Block_49::S_2368
            | C2Rust_Block_49::S_2370
            | C2Rust_Block_49::S_2372
            | C2Rust_Block_49::S_2374
            | C2Rust_Block_49::S_2376
            | C2Rust_Block_49::S_2378
            | C2Rust_Block_49::S_238
            | C2Rust_Block_49::S_2380
            | C2Rust_Block_49::S_2382
            | C2Rust_Block_49::S_2384
            | C2Rust_Block_49::S_2386
            | C2Rust_Block_49::S_2388
            | C2Rust_Block_49::S_2390
            | C2Rust_Block_49::S_2392
            | C2Rust_Block_49::S_2394
            | C2Rust_Block_49::S_2396
            | C2Rust_Block_49::S_2398
            | C2Rust_Block_49::S_24
            | C2Rust_Block_49::S_240
            | C2Rust_Block_49::S_2400
            | C2Rust_Block_49::S_2402
            | C2Rust_Block_49::S_2404
            | C2Rust_Block_49::S_2406
            | C2Rust_Block_49::S_2408
            | C2Rust_Block_49::S_2410
            | C2Rust_Block_49::S_2412
            | C2Rust_Block_49::S_2414
            | C2Rust_Block_49::S_2416
            | C2Rust_Block_49::S_2418
            | C2Rust_Block_49::S_242
            | C2Rust_Block_49::S_2420
            | C2Rust_Block_49::S_2422
            | C2Rust_Block_49::S_2424
            | C2Rust_Block_49::S_2426
            | C2Rust_Block_49::S_2428
            | C2Rust_Block_49::S_2430
            | C2Rust_Block_49::S_2432
            | C2Rust_Block_49::S_2434
            | C2Rust_Block_49::S_2436
            | C2Rust_Block_49::S_2438
            | C2Rust_Block_49::S_244
            | C2Rust_Block_49::S_2440
            | C2Rust_Block_49::S_2442
            | C2Rust_Block_49::S_2444
            | C2Rust_Block_49::S_2446
            | C2Rust_Block_49::S_2448
            | C2Rust_Block_49::S_2450
            | C2Rust_Block_49::S_2452
            | C2Rust_Block_49::S_2454
            | C2Rust_Block_49::S_2456
            | C2Rust_Block_49::S_2458
            | C2Rust_Block_49::S_246
            | C2Rust_Block_49::S_2460
            | C2Rust_Block_49::S_2462
            | C2Rust_Block_49::S_2464
            | C2Rust_Block_49::S_2466
            | C2Rust_Block_49::S_2468
            | C2Rust_Block_49::S_2470
            | C2Rust_Block_49::S_2472
            | C2Rust_Block_49::S_2474
            | C2Rust_Block_49::S_2476
            | C2Rust_Block_49::S_2478
            | C2Rust_Block_49::S_248
            | C2Rust_Block_49::S_2480
            | C2Rust_Block_49::S_2482
            | C2Rust_Block_49::S_2484
            | C2Rust_Block_49::S_2486
            | C2Rust_Block_49::S_2488
            | C2Rust_Block_49::S_2490
            | C2Rust_Block_49::S_2492
            | C2Rust_Block_49::S_2494
            | C2Rust_Block_49::S_2496
            | C2Rust_Block_49::S_2498
            | C2Rust_Block_49::S_250
            | C2Rust_Block_49::S_2500
            | C2Rust_Block_49::S_2502
            | C2Rust_Block_49::S_2504
            | C2Rust_Block_49::S_2506
            | C2Rust_Block_49::S_2508
            | C2Rust_Block_49::S_2510
            | C2Rust_Block_49::S_2512
            | C2Rust_Block_49::S_2514
            | C2Rust_Block_49::S_252
            | C2Rust_Block_49::S_2520
            | C2Rust_Block_49::S_2522
            | C2Rust_Block_49::S_2528
            | C2Rust_Block_49::S_2530
            | C2Rust_Block_49::S_2536
            | C2Rust_Block_49::S_2538
            | C2Rust_Block_49::S_254
            | C2Rust_Block_49::S_2544
            | C2Rust_Block_49::S_2546
            | C2Rust_Block_49::S_2548
            | C2Rust_Block_49::S_2554
            | C2Rust_Block_49::S_2556
            | C2Rust_Block_49::S_256
            | C2Rust_Block_49::S_2562
            | C2Rust_Block_49::S_2564
            | C2Rust_Block_49::S_2566
            | C2Rust_Block_49::S_2568
            | C2Rust_Block_49::S_2570
            | C2Rust_Block_49::S_2572
            | C2Rust_Block_49::S_2574
            | C2Rust_Block_49::S_2576
            | C2Rust_Block_49::S_2578
            | C2Rust_Block_49::S_258
            | C2Rust_Block_49::S_2580
            | C2Rust_Block_49::S_2582
            | C2Rust_Block_49::S_2584
            | C2Rust_Block_49::S_2586
            | C2Rust_Block_49::S_2592
            | C2Rust_Block_49::S_2594
            | C2Rust_Block_49::S_26
            | C2Rust_Block_49::S_260
            | C2Rust_Block_49::S_2600
            | C2Rust_Block_49::S_2602
            | C2Rust_Block_49::S_262
            | C2Rust_Block_49::S_264
            | C2Rust_Block_49::S_266
            | C2Rust_Block_49::S_268
            | C2Rust_Block_49::S_270
            | C2Rust_Block_49::S_272
            | C2Rust_Block_49::S_274
            | C2Rust_Block_49::S_276
            | C2Rust_Block_49::S_278
            | C2Rust_Block_49::S_28
            | C2Rust_Block_49::S_280
            | C2Rust_Block_49::S_282
            | C2Rust_Block_49::S_284
            | C2Rust_Block_49::S_286
            | C2Rust_Block_49::S_288
            | C2Rust_Block_49::S_290
            | C2Rust_Block_49::S_292
            | C2Rust_Block_49::S_294
            | C2Rust_Block_49::S_296
            | C2Rust_Block_49::S_298
            | C2Rust_Block_49::S_30
            | C2Rust_Block_49::S_300
            | C2Rust_Block_49::S_302
            | C2Rust_Block_49::S_304
            | C2Rust_Block_49::S_306
            | C2Rust_Block_49::S_308
            | C2Rust_Block_49::S_310
            | C2Rust_Block_49::S_312
            | C2Rust_Block_49::S_314
            | C2Rust_Block_49::S_316
            | C2Rust_Block_49::S_318
            | C2Rust_Block_49::S_32
            | C2Rust_Block_49::S_320
            | C2Rust_Block_49::S_322
            | C2Rust_Block_49::S_324
            | C2Rust_Block_49::S_326
            | C2Rust_Block_49::S_328
            | C2Rust_Block_49::S_330
            | C2Rust_Block_49::S_332
            | C2Rust_Block_49::S_334
            | C2Rust_Block_49::S_336
            | C2Rust_Block_49::S_338
            | C2Rust_Block_49::S_34
            | C2Rust_Block_49::S_340
            | C2Rust_Block_49::S_342
            | C2Rust_Block_49::S_344
            | C2Rust_Block_49::S_346
            | C2Rust_Block_49::S_348
            | C2Rust_Block_49::S_350
            | C2Rust_Block_49::S_352
            | C2Rust_Block_49::S_354
            | C2Rust_Block_49::S_356
            | C2Rust_Block_49::S_358
            | C2Rust_Block_49::S_36
            | C2Rust_Block_49::S_360
            | C2Rust_Block_49::S_362
            | C2Rust_Block_49::S_364
            | C2Rust_Block_49::S_366
            | C2Rust_Block_49::S_368
            | C2Rust_Block_49::S_370
            | C2Rust_Block_49::S_372
            | C2Rust_Block_49::S_374
            | C2Rust_Block_49::S_376
            | C2Rust_Block_49::S_378
            | C2Rust_Block_49::S_38
            | C2Rust_Block_49::S_380
            | C2Rust_Block_49::S_382
            | C2Rust_Block_49::S_384
            | C2Rust_Block_49::S_386
            | C2Rust_Block_49::S_388
            | C2Rust_Block_49::S_390
            | C2Rust_Block_49::S_392
            | C2Rust_Block_49::S_394
            | C2Rust_Block_49::S_396
            | C2Rust_Block_49::S_398
            | C2Rust_Block_49::S_4
            | C2Rust_Block_49::S_40
            | C2Rust_Block_49::S_400
            | C2Rust_Block_49::S_402
            | C2Rust_Block_49::S_404
            | C2Rust_Block_49::S_406
            | C2Rust_Block_49::S_408
            | C2Rust_Block_49::S_410
            | C2Rust_Block_49::S_412
            | C2Rust_Block_49::S_414
            | C2Rust_Block_49::S_416
            | C2Rust_Block_49::S_418
            | C2Rust_Block_49::S_42
            | C2Rust_Block_49::S_420
            | C2Rust_Block_49::S_422
            | C2Rust_Block_49::S_424
            | C2Rust_Block_49::S_426
            | C2Rust_Block_49::S_428
            | C2Rust_Block_49::S_430
            | C2Rust_Block_49::S_432
            | C2Rust_Block_49::S_434
            | C2Rust_Block_49::S_436
            | C2Rust_Block_49::S_438
            | C2Rust_Block_49::S_44
            | C2Rust_Block_49::S_440
            | C2Rust_Block_49::S_442
            | C2Rust_Block_49::S_444
            | C2Rust_Block_49::S_446
            | C2Rust_Block_49::S_448
            | C2Rust_Block_49::S_450
            | C2Rust_Block_49::S_452
            | C2Rust_Block_49::S_454
            | C2Rust_Block_49::S_456
            | C2Rust_Block_49::S_458
            | C2Rust_Block_49::S_46
            | C2Rust_Block_49::S_460
            | C2Rust_Block_49::S_462
            | C2Rust_Block_49::S_464
            | C2Rust_Block_49::S_466
            | C2Rust_Block_49::S_468
            | C2Rust_Block_49::S_470
            | C2Rust_Block_49::S_472
            | C2Rust_Block_49::S_474
            | C2Rust_Block_49::S_476
            | C2Rust_Block_49::S_478
            | C2Rust_Block_49::S_48
            | C2Rust_Block_49::S_480
            | C2Rust_Block_49::S_482
            | C2Rust_Block_49::S_484
            | C2Rust_Block_49::S_486
            | C2Rust_Block_49::S_488
            | C2Rust_Block_49::S_490
            | C2Rust_Block_49::S_492
            | C2Rust_Block_49::S_494
            | C2Rust_Block_49::S_496
            | C2Rust_Block_49::S_498
            | C2Rust_Block_49::S_50
            | C2Rust_Block_49::S_500
            | C2Rust_Block_49::S_502
            | C2Rust_Block_49::S_504
            | C2Rust_Block_49::S_506
            | C2Rust_Block_49::S_508
            | C2Rust_Block_49::S_510
            | C2Rust_Block_49::S_512
            | C2Rust_Block_49::S_514
            | C2Rust_Block_49::S_516
            | C2Rust_Block_49::S_518
            | C2Rust_Block_49::S_52
            | C2Rust_Block_49::S_520
            | C2Rust_Block_49::S_522
            | C2Rust_Block_49::S_524
            | C2Rust_Block_49::S_526
            | C2Rust_Block_49::S_528
            | C2Rust_Block_49::S_530
            | C2Rust_Block_49::S_532
            | C2Rust_Block_49::S_534
            | C2Rust_Block_49::S_536
            | C2Rust_Block_49::S_538
            | C2Rust_Block_49::S_540
            | C2Rust_Block_49::S_542
            | C2Rust_Block_49::S_544
            | C2Rust_Block_49::S_546
            | C2Rust_Block_49::S_548
            | C2Rust_Block_49::S_550
            | C2Rust_Block_49::S_552
            | C2Rust_Block_49::S_554
            | C2Rust_Block_49::S_556
            | C2Rust_Block_49::S_558
            | C2Rust_Block_49::S_560
            | C2Rust_Block_49::S_562
            | C2Rust_Block_49::S_564
            | C2Rust_Block_49::S_566
            | C2Rust_Block_49::S_568
            | C2Rust_Block_49::S_570
            | C2Rust_Block_49::S_572
            | C2Rust_Block_49::S_574
            | C2Rust_Block_49::S_576
            | C2Rust_Block_49::S_578
            | C2Rust_Block_49::S_58
            | C2Rust_Block_49::S_580
            | C2Rust_Block_49::S_582
            | C2Rust_Block_49::S_584
            | C2Rust_Block_49::S_586
            | C2Rust_Block_49::S_588
            | C2Rust_Block_49::S_590
            | C2Rust_Block_49::S_592
            | C2Rust_Block_49::S_594
            | C2Rust_Block_49::S_596
            | C2Rust_Block_49::S_598
            | C2Rust_Block_49::S_6
            | C2Rust_Block_49::S_60
            | C2Rust_Block_49::S_600
            | C2Rust_Block_49::S_602
            | C2Rust_Block_49::S_604
            | C2Rust_Block_49::S_606
            | C2Rust_Block_49::S_608
            | C2Rust_Block_49::S_610
            | C2Rust_Block_49::S_612
            | C2Rust_Block_49::S_614
            | C2Rust_Block_49::S_616
            | C2Rust_Block_49::S_618
            | C2Rust_Block_49::S_62
            | C2Rust_Block_49::S_620
            | C2Rust_Block_49::S_622
            | C2Rust_Block_49::S_624
            | C2Rust_Block_49::S_626
            | C2Rust_Block_49::S_628
            | C2Rust_Block_49::S_630
            | C2Rust_Block_49::S_632
            | C2Rust_Block_49::S_634
            | C2Rust_Block_49::S_636
            | C2Rust_Block_49::S_638
            | C2Rust_Block_49::S_640
            | C2Rust_Block_49::S_642
            | C2Rust_Block_49::S_644
            | C2Rust_Block_49::S_646
            | C2Rust_Block_49::S_648
            | C2Rust_Block_49::S_650
            | C2Rust_Block_49::S_652
            | C2Rust_Block_49::S_654
            | C2Rust_Block_49::S_656
            | C2Rust_Block_49::S_658
            | C2Rust_Block_49::S_660
            | C2Rust_Block_49::S_662
            | C2Rust_Block_49::S_664
            | C2Rust_Block_49::S_666
            | C2Rust_Block_49::S_668
            | C2Rust_Block_49::S_670
            | C2Rust_Block_49::S_672
            | C2Rust_Block_49::S_674
            | C2Rust_Block_49::S_676
            | C2Rust_Block_49::S_678
            | C2Rust_Block_49::S_68
            | C2Rust_Block_49::S_680
            | C2Rust_Block_49::S_682
            | C2Rust_Block_49::S_684
            | C2Rust_Block_49::S_686
            | C2Rust_Block_49::S_688
            | C2Rust_Block_49::S_690
            | C2Rust_Block_49::S_692
            | C2Rust_Block_49::S_694
            | C2Rust_Block_49::S_696
            | C2Rust_Block_49::S_698
            | C2Rust_Block_49::S_70
            | C2Rust_Block_49::S_700
            | C2Rust_Block_49::S_702
            | C2Rust_Block_49::S_704
            | C2Rust_Block_49::S_706
            | C2Rust_Block_49::S_708
            | C2Rust_Block_49::S_710
            | C2Rust_Block_49::S_712
            | C2Rust_Block_49::S_714
            | C2Rust_Block_49::S_716
            | C2Rust_Block_49::S_718
            | C2Rust_Block_49::S_720
            | C2Rust_Block_49::S_722
            | C2Rust_Block_49::S_724
            | C2Rust_Block_49::S_726
            | C2Rust_Block_49::S_728
            | C2Rust_Block_49::S_730
            | C2Rust_Block_49::S_732
            | C2Rust_Block_49::S_734
            | C2Rust_Block_49::S_736
            | C2Rust_Block_49::S_738
            | C2Rust_Block_49::S_740
            | C2Rust_Block_49::S_742
            | C2Rust_Block_49::S_744
            | C2Rust_Block_49::S_746
            | C2Rust_Block_49::S_748
            | C2Rust_Block_49::S_750
            | C2Rust_Block_49::S_752
            | C2Rust_Block_49::S_754
            | C2Rust_Block_49::S_756
            | C2Rust_Block_49::S_758
            | C2Rust_Block_49::S_76
            | C2Rust_Block_49::S_760
            | C2Rust_Block_49::S_762
            | C2Rust_Block_49::S_764
            | C2Rust_Block_49::S_766
            | C2Rust_Block_49::S_768
            | C2Rust_Block_49::S_770
            | C2Rust_Block_49::S_772
            | C2Rust_Block_49::S_774
            | C2Rust_Block_49::S_776
            | C2Rust_Block_49::S_778
            | C2Rust_Block_49::S_78
            | C2Rust_Block_49::S_780
            | C2Rust_Block_49::S_782
            | C2Rust_Block_49::S_784
            | C2Rust_Block_49::S_786
            | C2Rust_Block_49::S_788
            | C2Rust_Block_49::S_790
            | C2Rust_Block_49::S_792
            | C2Rust_Block_49::S_794
            | C2Rust_Block_49::S_796
            | C2Rust_Block_49::S_798
            | C2Rust_Block_49::S_80
            | C2Rust_Block_49::S_800
            | C2Rust_Block_49::S_802
            | C2Rust_Block_49::S_804
            | C2Rust_Block_49::S_806
            | C2Rust_Block_49::S_808
            | C2Rust_Block_49::S_810
            | C2Rust_Block_49::S_812
            | C2Rust_Block_49::S_814
            | C2Rust_Block_49::S_816
            | C2Rust_Block_49::S_818
            | C2Rust_Block_49::S_820
            | C2Rust_Block_49::S_822
            | C2Rust_Block_49::S_824
            | C2Rust_Block_49::S_826
            | C2Rust_Block_49::S_828
            | C2Rust_Block_49::S_830
            | C2Rust_Block_49::S_832
            | C2Rust_Block_49::S_834
            | C2Rust_Block_49::S_836
            | C2Rust_Block_49::S_838
            | C2Rust_Block_49::S_840
            | C2Rust_Block_49::S_842
            | C2Rust_Block_49::S_844
            | C2Rust_Block_49::S_846
            | C2Rust_Block_49::S_848
            | C2Rust_Block_49::S_850
            | C2Rust_Block_49::S_852
            | C2Rust_Block_49::S_854
            | C2Rust_Block_49::S_856
            | C2Rust_Block_49::S_858
            | C2Rust_Block_49::S_86
            | C2Rust_Block_49::S_860
            | C2Rust_Block_49::S_862
            | C2Rust_Block_49::S_864
            | C2Rust_Block_49::S_866
            | C2Rust_Block_49::S_868
            | C2Rust_Block_49::S_870
            | C2Rust_Block_49::S_872
            | C2Rust_Block_49::S_874
            | C2Rust_Block_49::S_876
            | C2Rust_Block_49::S_878
            | C2Rust_Block_49::S_88
            | C2Rust_Block_49::S_880
            | C2Rust_Block_49::S_882
            | C2Rust_Block_49::S_884
            | C2Rust_Block_49::S_886
            | C2Rust_Block_49::S_888
            | C2Rust_Block_49::S_890
            | C2Rust_Block_49::S_892
            | C2Rust_Block_49::S_894
            | C2Rust_Block_49::S_896
            | C2Rust_Block_49::S_898
            | C2Rust_Block_49::S_90
            | C2Rust_Block_49::S_900
            | C2Rust_Block_49::S_902
            | C2Rust_Block_49::S_904
            | C2Rust_Block_49::S_906
            | C2Rust_Block_49::S_908
            | C2Rust_Block_49::S_910
            | C2Rust_Block_49::S_912
            | C2Rust_Block_49::S_914
            | C2Rust_Block_49::S_916
            | C2Rust_Block_49::S_918
            | C2Rust_Block_49::S_92
            | C2Rust_Block_49::S_920
            | C2Rust_Block_49::S_922
            | C2Rust_Block_49::S_924
            | C2Rust_Block_49::S_926
            | C2Rust_Block_49::S_928
            | C2Rust_Block_49::S_930
            | C2Rust_Block_49::S_932
            | C2Rust_Block_49::S_934
            | C2Rust_Block_49::S_936
            | C2Rust_Block_49::S_938
            | C2Rust_Block_49::S_94
            | C2Rust_Block_49::S_940
            | C2Rust_Block_49::S_942
            | C2Rust_Block_49::S_944
            | C2Rust_Block_49::S_946
            | C2Rust_Block_49::S_948
            | C2Rust_Block_49::S_950
            | C2Rust_Block_49::S_952
            | C2Rust_Block_49::S_954
            | C2Rust_Block_49::S_956
            | C2Rust_Block_49::S_958
            | C2Rust_Block_49::S_960
            | C2Rust_Block_49::S_962
            | C2Rust_Block_49::S_964
            | C2Rust_Block_49::S_966
            | C2Rust_Block_49::S_968
            | C2Rust_Block_49::S_970
            | C2Rust_Block_49::S_972
            | C2Rust_Block_49::S_974
            | C2Rust_Block_49::S_976
            | C2Rust_Block_49::S_978
            | C2Rust_Block_49::S_980
            | C2Rust_Block_49::S_982
            | C2Rust_Block_49::S_984
            | C2Rust_Block_49::S_986
            | C2Rust_Block_49::S_988
            | C2Rust_Block_49::S_990
            | C2Rust_Block_49::S_992
            | C2Rust_Block_49::S_994
            | C2Rust_Block_49::S_996
            | C2Rust_Block_49::S_998 => {
                unreachable!("GamePKG compacted dispatch state reached")
            }
        }
    };
}
#[no_mangle]
pub unsafe extern "C" fn sub_00261100() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b191c as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x549234 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00261120() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b2108 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x549240 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
