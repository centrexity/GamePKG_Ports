extern "C" {
    fn memcpy(
        __dest: *mut ::core::ffi::c_void,
        __src: *const ::core::ffi::c_void,
        __n: size_t,
    ) -> *mut ::core::ffi::c_void;
    fn frexp(
        __x: ::core::ffi::c_double,
        __exponent: *mut ::core::ffi::c_int,
    ) -> ::core::ffi::c_double;
    fn ldexp(
        __x: ::core::ffi::c_double,
        __exponent: ::core::ffi::c_int,
    ) -> ::core::ffi::c_double;
    fn fabs(__x: ::core::ffi::c_double) -> ::core::ffi::c_double;
    static mut g_xbox_mem_offset: ptrdiff_t;
    static mut g_xbox_code_lo: uint32_t;
    static mut g_xbox_code_hi: uint32_t;
    fn gamepkg_tls_g_eax() -> *mut uint32_t;
    fn gamepkg_tls_g_esp() -> *mut uint32_t;
    fn gamepkg_tls_g_edx() -> *mut uint32_t;
    fn gamepkg_tls_g_ecx() -> *mut uint32_t;
    fn gamepkg_tls_g_esi() -> *mut uint32_t;
    fn gamepkg_tls_g_ebx() -> *mut uint32_t;
    fn gamepkg_tls_g_edi() -> *mut uint32_t;
    fn gamepkg_tls_g_fp_stack() -> *mut [::core::ffi::c_double; 8];
    fn gamepkg_tls_g_fp_top() -> *mut ::core::ffi::c_int;
    fn gamepkg_tls_g_seh_ebp() -> *mut uint32_t;
    fn gamepkg_tls_g_ebp() -> *mut uint32_t;
    fn gamepkg_tls_g_df() -> *mut ::core::ffi::c_int;
    fn gamepkg_tls_g_fp_control_word() -> *mut uint16_t;
    static mut g_icall_trace: [uint32_t; 16];
    static mut g_icall_trace_idx: uint32_t;
    static mut g_icall_count: uint64_t;
    fn recomp_icall_fail_log(va: uint32_t);
    fn recomp_icall_not_code_log(va: uint32_t);
    fn recomp_lookup(xbox_va: uint32_t) -> recomp_func_t;
    fn recomp_lookup_kernel(xbox_va: uint32_t) -> recomp_func_t;
    fn recomp_lookup_manual(xbox_va: uint32_t) -> recomp_func_t;
    fn sub_001D154C();
    fn sub_001D1608();
    fn sub_001D19FD();
    fn sub_001F6470();
    fn sub_001F64A0();
    fn sub_001F6550();
    fn sub_001F8520();
    fn sub_001F8550();
    fn sub_001F8970();
    fn sub_001F8B10();
    fn sub_001F8B70();
    fn sub_001F8E20();
    fn sub_001FD6C0();
    fn sub_001FE270();
    fn sub_001FE480();
    fn sub_001FE4C0();
    fn sub_001FE500();
    fn sub_001FEA30();
    fn sub_001FEB70();
    fn sub_001FEBF0();
    fn sub_001FEDC0();
    fn sub_001FFD80();
    fn sub_001FFF00();
    fn sub_00200C70();
    fn sub_00200CD0();
    fn sub_00200E00();
    fn sub_00201DF0();
    fn sub_00201EC0();
    fn sub_00201EF0();
    fn sub_00201F00();
    fn sub_00201F20();
    fn sub_00201F80();
    fn sub_00201F90();
    fn sub_00202270();
    fn sub_002025B0();
    fn sub_00202610();
    fn sub_00204630();
    fn sub_00243880();
}
pub type int8_t = i8;
pub type int16_t = i16;
pub type int32_t = i32;
pub type uint8_t = u8;
pub type uint16_t = u16;
pub type uint32_t = u32;
pub type uint64_t = u64;
pub type uintptr_t = usize;
pub type ptrdiff_t = isize;
pub type size_t = usize;
pub type recomp_func_t = Option<unsafe extern "C" fn() -> ()>;
#[inline]
unsafe extern "C" fn recomp_fp_round24(
    mut x: ::core::ffi::c_double,
) -> ::core::ffi::c_double {
    let mut ax: ::core::ffi::c_double = fabs(x);
    let mut e: ::core::ffi::c_int = 0;
    's_6: {
        if ax <= 3.4028234663852886e38f64 && ax >= 1.1754943508222875e-38f64
            || ax == 0.0f64 || x != x
            || ax == ::core::f32::INFINITY as ::core::ffi::c_double
        {
            break 's_6;
        }
        x = frexp(x, &raw mut e);
        return ldexp(x as ::core::ffi::c_float as ::core::ffi::c_double, e);
    }
    return x as ::core::ffi::c_float as ::core::ffi::c_double;
}
pub const ICALL_TRACE_SIZE: ::core::ffi::c_int = 16 as ::core::ffi::c_int;
#[no_mangle]
pub unsafe extern "C" fn sub_001F90F0() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (0x76411c as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv_0: uint32_t = 0xffffffff as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    let mut _pv_1: uint32_t = (*__gamepkg_tls_g_eax);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    let mut _pv_2: uint32_t = 0x1f9102 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_2,
    );
    sub_001D1608();
    (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_esi).wrapping_add(0x154 as uint32_t);
    let mut _pv_3: uint32_t = (*__gamepkg_tls_g_ecx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_3,
    );
    _fb = 0xec as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi).wrapping_add(0xec as uint32_t);
    _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    let mut _pv_4: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_4,
    );
    let mut _pv_5: uint32_t = 0x1f9115 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_5,
    );
    sub_00200E00();
    (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (0x76411c as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    _fb = 8 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t);
    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    let mut _pv_6: uint32_t = 0 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_6,
    );
    let mut _pv_7: uint32_t = 1 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_7,
    );
    let mut _pv_8: uint32_t = (*__gamepkg_tls_g_edx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_8,
    );
    let mut _pv_9: uint32_t = 0x1f9128 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_9,
    );
    sub_001D154C();
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001F9130() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_esi).wrapping_add(0xec as uint32_t);
    let mut _pv_0: uint32_t = (*__gamepkg_tls_g_eax);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    let mut _pv_1: uint32_t = 0x1f9141 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    sub_00201DF0();
    _fb = 4 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001F9150() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_ecx) = 0 as uint32_t;
    _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_ecx),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_ecx),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_ecx),
    );
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001F9170() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_ebx = unsafe { gamepkg_tls_g_ebx() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let mut ebp: uint32_t = 0;
    let mut _flags: ::core::ffi::c_int = 0;
    let mut _fa: uint32_t = 0;
    let mut _fb: uint32_t = 0;
    let mut _fas: int32_t = 0;
    let mut _fbs: int32_t = 0;
    let mut _pv: uint32_t = 0;
    let mut _pv_0: uint32_t = 0;
    let mut _pv_1: uint32_t = 0;
    let mut _pv_2: uint32_t = 0;
    let mut _pv_3: uint32_t = 0;
    let mut _pv_4: uint32_t = 0;
    let mut _pv_5: uint32_t = 0;
    let mut _pv_6: uint32_t = 0;
    let mut _pv_7: uint32_t = 0;
    let mut _pv_8: uint32_t = 0;
    let mut _pv_9: uint32_t = 0;
    let mut _pv_10: uint32_t = 0;
    let mut _pv_11: uint32_t = 0;
    let mut _pv_12: uint32_t = 0;
    let mut _pv_13: uint32_t = 0;
    let mut _pv_14: uint32_t = 0;
    let mut _pv_15: uint32_t = 0;
    let mut _pv_16: uint32_t = 0;
    enum C2Rust_Block_4 {
        S_0,
        S_2,
        S_4,
        S_6,
        S_8,
        S_18,
        S_24,
        S_26,
        S_32,
        S_34,
        S_36,
        S_46,
        S_48,
        S_50,
        S_60,
        S_62,
        S_64,
        S_74,
        S_76,
        S_78,
        S_84,
        S_86,
        S_88,
        S_90,
        S_92,
        S_94,
        S_96,
        S_98,
        S_100,
        S_102,
        S_104,
        S_106,
        S_108,
        S_110,
        S_112,
        S_114,
        S_116,
        S_118,
        S_120,
        S_122,
        S_124,
        S_126,
        S_128,
        S_130,
        S_139,
        S_145,
        S_147,
        S_149,
        S_159,
        S_161,
        S_163,
        S_169,
        S_175,
        S_177,
        S_179,
        S_189,
        S_191,
        S_193,
        S_199,
        S_205,
        S_207,
        S_209,
        S_211,
        S_213,
        S_221,
        S_223,
        S_225,
        S_227,
        S_229,
        S_238,
        S_240,
        S_242,
        S_244,
        S_246,
        S_248,
        S_250,
        S_252,
        S_254,
        S_256,
        S_262,
        S_268,
        S_270,
        S_272,
        S_282,
        S_284,
        S_286,
        S_296,
        S_298,
        S_300,
        S_306,
        S_316,
        S_318,
        S_320,
        S_326,
        S_328,
        S_330,
        S_332,
        S_334,
        S_340,
        S_342,
        S_344,
        S_354,
        S_356,
        S_358,
        S_364,
        S_370,
        S_372,
        S_374,
        S_376,
        S_378,
        S_380,
        S_386,
        S_388,
        S_390,
        S_400,
        S_402,
        S_404,
        S_414,
        S_416,
        S_418,
        S_428,
        S_430,
        S_432,
        S_438,
        S_448,
        S_450,
        S_460,
        S_462,
        S_472,
        S_474,
        S_484,
        S_486,
        S_492,
        S_494,
    }
    let mut c2rust_current_block_4: C2Rust_Block_4;
    c2rust_current_block_4 = C2Rust_Block_4::S_0;
    loop {
        match c2rust_current_block_4 {
            C2Rust_Block_4::S_0 => {
                ebp = 0 as uint32_t;
                c2rust_current_block_4 = C2Rust_Block_4::S_2;
            }
            C2Rust_Block_4::S_2 => {
                ebp = (*__gamepkg_tls_g_ebp);
                c2rust_current_block_4 = C2Rust_Block_4::S_4;
            }
            C2Rust_Block_4::S_4 => {
                _flags = 0 as ::core::ffi::c_int;
                c2rust_current_block_4 = C2Rust_Block_4::S_6;
            }
            C2Rust_Block_4::S_6 => {
                _fa = 0 as uint32_t;
                _fb = 0 as uint32_t;
                c2rust_current_block_4 = C2Rust_Block_4::S_8;
            }
            C2Rust_Block_4::S_8 => {
                _fas = 0 as int32_t;
                _fbs = 0 as int32_t;
                c2rust_current_block_4 = C2Rust_Block_4::S_18;
            }
            C2Rust_Block_4::S_18 => {
                ebp = (*__gamepkg_tls_g_seh_ebp);
                c2rust_current_block_4 = C2Rust_Block_4::S_24;
            }
            C2Rust_Block_4::S_24 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_4 = C2Rust_Block_4::S_26;
            }
            C2Rust_Block_4::S_26 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_4 = C2Rust_Block_4::S_32;
            }
            C2Rust_Block_4::S_32 => {
                _pv = (*__gamepkg_tls_g_ebx);
                c2rust_current_block_4 = C2Rust_Block_4::S_34;
            }
            C2Rust_Block_4::S_34 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_4 = C2Rust_Block_4::S_36;
            }
            C2Rust_Block_4::S_36 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv,
                );
                c2rust_current_block_4 = C2Rust_Block_4::S_46;
            }
            C2Rust_Block_4::S_46 => {
                _pv_0 = ebp;
                c2rust_current_block_4 = C2Rust_Block_4::S_48;
            }
            C2Rust_Block_4::S_48 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_4 = C2Rust_Block_4::S_50;
            }
            C2Rust_Block_4::S_50 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_0,
                );
                c2rust_current_block_4 = C2Rust_Block_4::S_60;
            }
            C2Rust_Block_4::S_60 => {
                _pv_1 = (*__gamepkg_tls_g_esi);
                c2rust_current_block_4 = C2Rust_Block_4::S_62;
            }
            C2Rust_Block_4::S_62 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_4 = C2Rust_Block_4::S_64;
            }
            C2Rust_Block_4::S_64 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_1,
                );
                c2rust_current_block_4 = C2Rust_Block_4::S_74;
            }
            C2Rust_Block_4::S_74 => {
                _pv_2 = (*__gamepkg_tls_g_edi);
                c2rust_current_block_4 = C2Rust_Block_4::S_76;
            }
            C2Rust_Block_4::S_76 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_4 = C2Rust_Block_4::S_78;
            }
            C2Rust_Block_4::S_78 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_2,
                );
                c2rust_current_block_4 = C2Rust_Block_4::S_84;
            }
            C2Rust_Block_4::S_84 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x14 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_4 = C2Rust_Block_4::S_86;
            }
            C2Rust_Block_4::S_86 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edi).wrapping_add(0x28 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_ecx),
                );
                c2rust_current_block_4 = C2Rust_Block_4::S_88;
            }
            C2Rust_Block_4::S_88 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_4 = C2Rust_Block_4::S_90;
            }
            C2Rust_Block_4::S_90 => {
                (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_edi)
                    .wrapping_add(0x28 as uint32_t);
                c2rust_current_block_4 = C2Rust_Block_4::S_92;
            }
            C2Rust_Block_4::S_92 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_edx),
                );
                c2rust_current_block_4 = C2Rust_Block_4::S_94;
            }
            C2Rust_Block_4::S_94 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_4 = C2Rust_Block_4::S_96;
            }
            C2Rust_Block_4::S_96 => {
                ebp = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edx) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_4 = C2Rust_Block_4::S_98;
            }
            C2Rust_Block_4::S_98 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_edi)
                    .wrapping_add(0x30 as uint32_t);
                c2rust_current_block_4 = C2Rust_Block_4::S_100;
            }
            C2Rust_Block_4::S_100 => {
                (*__gamepkg_tls_g_ebx) = (*__gamepkg_tls_g_ecx);
                c2rust_current_block_4 = C2Rust_Block_4::S_102;
            }
            C2Rust_Block_4::S_102 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ebx) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ebp,
                );
                c2rust_current_block_4 = C2Rust_Block_4::S_104;
            }
            C2Rust_Block_4::S_104 => {
                ebp = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edx).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_4 = C2Rust_Block_4::S_106;
            }
            C2Rust_Block_4::S_106 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ebx).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ebp,
                );
                c2rust_current_block_4 = C2Rust_Block_4::S_108;
            }
            C2Rust_Block_4::S_108 => {
                ebp = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edx).wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_4 = C2Rust_Block_4::S_110;
            }
            C2Rust_Block_4::S_110 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ebx).wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ebp,
                );
                c2rust_current_block_4 = C2Rust_Block_4::S_112;
            }
            C2Rust_Block_4::S_112 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edx).wrapping_add(0xc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_4 = C2Rust_Block_4::S_114;
            }
            C2Rust_Block_4::S_114 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ebx).wrapping_add(0xc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_edx),
                );
                c2rust_current_block_4 = C2Rust_Block_4::S_116;
            }
            C2Rust_Block_4::S_116 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_ecx),
                );
                c2rust_current_block_4 = C2Rust_Block_4::S_118;
            }
            C2Rust_Block_4::S_118 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_4 = C2Rust_Block_4::S_120;
            }
            C2Rust_Block_4::S_120 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_4 = C2Rust_Block_4::S_122;
            }
            C2Rust_Block_4::S_122 => {
                _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                c2rust_current_block_4 = C2Rust_Block_4::S_124;
            }
            C2Rust_Block_4::S_124 => {
                _fb = 1 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_4 = C2Rust_Block_4::S_126;
            }
            C2Rust_Block_4::S_126 => {
                _fas = _fa as int32_t;
                c2rust_current_block_4 = C2Rust_Block_4::S_128;
            }
            C2Rust_Block_4::S_128 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_4 = C2Rust_Block_4::S_130;
            }
            C2Rust_Block_4::S_130 => {
                if _fa != _fb {
                    c2rust_current_block_4 = C2Rust_Block_4::S_221;
                } else {
                    c2rust_current_block_4 = C2Rust_Block_4::S_139;
                }
            }
            C2Rust_Block_4::S_139 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_4 = C2Rust_Block_4::S_145;
            }
            C2Rust_Block_4::S_145 => {
                _pv_3 = 0x80 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_4 = C2Rust_Block_4::S_147;
            }
            C2Rust_Block_4::S_147 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_4 = C2Rust_Block_4::S_149;
            }
            C2Rust_Block_4::S_149 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_3,
                );
                c2rust_current_block_4 = C2Rust_Block_4::S_159;
            }
            C2Rust_Block_4::S_159 => {
                _pv_4 = (*__gamepkg_tls_g_eax);
                c2rust_current_block_4 = C2Rust_Block_4::S_161;
            }
            C2Rust_Block_4::S_161 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_4 = C2Rust_Block_4::S_163;
            }
            C2Rust_Block_4::S_163 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_4,
                );
                c2rust_current_block_4 = C2Rust_Block_4::S_169;
            }
            C2Rust_Block_4::S_169 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_edi)
                    .wrapping_add(0x40 as uint32_t);
                c2rust_current_block_4 = C2Rust_Block_4::S_175;
            }
            C2Rust_Block_4::S_175 => {
                _pv_5 = (*__gamepkg_tls_g_ecx);
                c2rust_current_block_4 = C2Rust_Block_4::S_177;
            }
            C2Rust_Block_4::S_177 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_4 = C2Rust_Block_4::S_179;
            }
            C2Rust_Block_4::S_179 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_5,
                );
                c2rust_current_block_4 = C2Rust_Block_4::S_189;
            }
            C2Rust_Block_4::S_189 => {
                _pv_6 = 0x1f91c4 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_4 = C2Rust_Block_4::S_191;
            }
            C2Rust_Block_4::S_191 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_4 = C2Rust_Block_4::S_193;
            }
            C2Rust_Block_4::S_193 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_6,
                );
                c2rust_current_block_4 = C2Rust_Block_4::S_199;
            }
            C2Rust_Block_4::S_199 => {
                sub_00243880();
                c2rust_current_block_4 = C2Rust_Block_4::S_205;
            }
            C2Rust_Block_4::S_205 => {
                _fb = 0xc as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_4 = C2Rust_Block_4::S_207;
            }
            C2Rust_Block_4::S_207 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_4 = C2Rust_Block_4::S_209;
            }
            C2Rust_Block_4::S_209 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(0xc as uint32_t);
                c2rust_current_block_4 = C2Rust_Block_4::S_211;
            }
            C2Rust_Block_4::S_211 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_4 = C2Rust_Block_4::S_213;
            }
            C2Rust_Block_4::S_213 => {
                _fas = _fa as int32_t;
                c2rust_current_block_4 = C2Rust_Block_4::S_262;
            }
            C2Rust_Block_4::S_221 => {
                _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                c2rust_current_block_4 = C2Rust_Block_4::S_223;
            }
            C2Rust_Block_4::S_223 => {
                _fb = 2 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_4 = C2Rust_Block_4::S_225;
            }
            C2Rust_Block_4::S_225 => {
                _fas = _fa as int32_t;
                c2rust_current_block_4 = C2Rust_Block_4::S_227;
            }
            C2Rust_Block_4::S_227 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_4 = C2Rust_Block_4::S_229;
            }
            C2Rust_Block_4::S_229 => {
                if _fa != _fb {
                    c2rust_current_block_4 = C2Rust_Block_4::S_262;
                } else {
                    c2rust_current_block_4 = C2Rust_Block_4::S_238;
                }
            }
            C2Rust_Block_4::S_238 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_4 = C2Rust_Block_4::S_240;
            }
            C2Rust_Block_4::S_240 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_4 = C2Rust_Block_4::S_242;
            }
            C2Rust_Block_4::S_242 => {
                (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_edi)
                    .wrapping_add(0xdc as uint32_t);
                c2rust_current_block_4 = C2Rust_Block_4::S_244;
            }
            C2Rust_Block_4::S_244 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edx) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_ecx),
                );
                c2rust_current_block_4 = C2Rust_Block_4::S_246;
            }
            C2Rust_Block_4::S_246 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_4 = C2Rust_Block_4::S_248;
            }
            C2Rust_Block_4::S_248 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edx).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_ecx),
                );
                c2rust_current_block_4 = C2Rust_Block_4::S_250;
            }
            C2Rust_Block_4::S_250 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax).wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_4 = C2Rust_Block_4::S_252;
            }
            C2Rust_Block_4::S_252 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edx).wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_ecx),
                );
                c2rust_current_block_4 = C2Rust_Block_4::S_254;
            }
            C2Rust_Block_4::S_254 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax).wrapping_add(0xc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_4 = C2Rust_Block_4::S_256;
            }
            C2Rust_Block_4::S_256 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edx).wrapping_add(0xc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_4 = C2Rust_Block_4::S_262;
            }
            C2Rust_Block_4::S_262 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x76411c as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_4 = C2Rust_Block_4::S_268;
            }
            C2Rust_Block_4::S_268 => {
                _pv_7 = 0xffffffff as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_4 = C2Rust_Block_4::S_270;
            }
            C2Rust_Block_4::S_270 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_4 = C2Rust_Block_4::S_272;
            }
            C2Rust_Block_4::S_272 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_7,
                );
                c2rust_current_block_4 = C2Rust_Block_4::S_282;
            }
            C2Rust_Block_4::S_282 => {
                _pv_8 = (*__gamepkg_tls_g_ecx);
                c2rust_current_block_4 = C2Rust_Block_4::S_284;
            }
            C2Rust_Block_4::S_284 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_4 = C2Rust_Block_4::S_286;
            }
            C2Rust_Block_4::S_286 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_8,
                );
                c2rust_current_block_4 = C2Rust_Block_4::S_296;
            }
            C2Rust_Block_4::S_296 => {
                _pv_9 = 0x1f91fa as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_4 = C2Rust_Block_4::S_298;
            }
            C2Rust_Block_4::S_298 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_4 = C2Rust_Block_4::S_300;
            }
            C2Rust_Block_4::S_300 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_9,
                );
                c2rust_current_block_4 = C2Rust_Block_4::S_306;
            }
            C2Rust_Block_4::S_306 => {
                sub_001D1608();
                c2rust_current_block_4 = C2Rust_Block_4::S_316;
            }
            C2Rust_Block_4::S_316 => {
                _pv_10 = (*__gamepkg_tls_g_esi);
                c2rust_current_block_4 = C2Rust_Block_4::S_318;
            }
            C2Rust_Block_4::S_318 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_4 = C2Rust_Block_4::S_320;
            }
            C2Rust_Block_4::S_320 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_10,
                );
                c2rust_current_block_4 = C2Rust_Block_4::S_326;
            }
            C2Rust_Block_4::S_326 => {
                _fb = 0x15c as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_4 = C2Rust_Block_4::S_328;
            }
            C2Rust_Block_4::S_328 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_4 = C2Rust_Block_4::S_330;
            }
            C2Rust_Block_4::S_330 => {
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
                    .wrapping_add(0x15c as uint32_t);
                c2rust_current_block_4 = C2Rust_Block_4::S_332;
            }
            C2Rust_Block_4::S_332 => {
                _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                c2rust_current_block_4 = C2Rust_Block_4::S_334;
            }
            C2Rust_Block_4::S_334 => {
                _fas = _fa as int32_t;
                c2rust_current_block_4 = C2Rust_Block_4::S_340;
            }
            C2Rust_Block_4::S_340 => {
                _pv_11 = (*__gamepkg_tls_g_edi);
                c2rust_current_block_4 = C2Rust_Block_4::S_342;
            }
            C2Rust_Block_4::S_342 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_4 = C2Rust_Block_4::S_344;
            }
            C2Rust_Block_4::S_344 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_11,
                );
                c2rust_current_block_4 = C2Rust_Block_4::S_354;
            }
            C2Rust_Block_4::S_354 => {
                _pv_12 = 0x1f9207 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_4 = C2Rust_Block_4::S_356;
            }
            C2Rust_Block_4::S_356 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_4 = C2Rust_Block_4::S_358;
            }
            C2Rust_Block_4::S_358 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_12,
                );
                c2rust_current_block_4 = C2Rust_Block_4::S_364;
            }
            C2Rust_Block_4::S_364 => {
                sub_00201EF0();
                c2rust_current_block_4 = C2Rust_Block_4::S_370;
            }
            C2Rust_Block_4::S_370 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x76411c as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_4 = C2Rust_Block_4::S_372;
            }
            C2Rust_Block_4::S_372 => {
                _fb = 8 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_4 = C2Rust_Block_4::S_374;
            }
            C2Rust_Block_4::S_374 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_4 = C2Rust_Block_4::S_376;
            }
            C2Rust_Block_4::S_376 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(8 as uint32_t);
                c2rust_current_block_4 = C2Rust_Block_4::S_378;
            }
            C2Rust_Block_4::S_378 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_4 = C2Rust_Block_4::S_380;
            }
            C2Rust_Block_4::S_380 => {
                _fas = _fa as int32_t;
                c2rust_current_block_4 = C2Rust_Block_4::S_386;
            }
            C2Rust_Block_4::S_386 => {
                _pv_13 = 0 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_4 = C2Rust_Block_4::S_388;
            }
            C2Rust_Block_4::S_388 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_4 = C2Rust_Block_4::S_390;
            }
            C2Rust_Block_4::S_390 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_13,
                );
                c2rust_current_block_4 = C2Rust_Block_4::S_400;
            }
            C2Rust_Block_4::S_400 => {
                _pv_14 = 1 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_4 = C2Rust_Block_4::S_402;
            }
            C2Rust_Block_4::S_402 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_4 = C2Rust_Block_4::S_404;
            }
            C2Rust_Block_4::S_404 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_14,
                );
                c2rust_current_block_4 = C2Rust_Block_4::S_414;
            }
            C2Rust_Block_4::S_414 => {
                _pv_15 = (*__gamepkg_tls_g_edx);
                c2rust_current_block_4 = C2Rust_Block_4::S_416;
            }
            C2Rust_Block_4::S_416 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_4 = C2Rust_Block_4::S_418;
            }
            C2Rust_Block_4::S_418 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_15,
                );
                c2rust_current_block_4 = C2Rust_Block_4::S_428;
            }
            C2Rust_Block_4::S_428 => {
                _pv_16 = 0x1f921a as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_4 = C2Rust_Block_4::S_430;
            }
            C2Rust_Block_4::S_430 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_4 = C2Rust_Block_4::S_432;
            }
            C2Rust_Block_4::S_432 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_16,
                );
                c2rust_current_block_4 = C2Rust_Block_4::S_438;
            }
            C2Rust_Block_4::S_438 => {
                sub_001D154C();
                c2rust_current_block_4 = C2Rust_Block_4::S_448;
            }
            C2Rust_Block_4::S_448 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_4 = C2Rust_Block_4::S_450;
            }
            C2Rust_Block_4::S_450 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_4 = C2Rust_Block_4::S_460;
            }
            C2Rust_Block_4::S_460 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_4 = C2Rust_Block_4::S_462;
            }
            C2Rust_Block_4::S_462 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_4 = C2Rust_Block_4::S_472;
            }
            C2Rust_Block_4::S_472 => {
                ebp = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_4 = C2Rust_Block_4::S_474;
            }
            C2Rust_Block_4::S_474 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_4 = C2Rust_Block_4::S_484;
            }
            C2Rust_Block_4::S_484 => {
                (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_4 = C2Rust_Block_4::S_486;
            }
            C2Rust_Block_4::S_486 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_4 = C2Rust_Block_4::S_492;
            }
            C2Rust_Block_4::S_492 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_4 = C2Rust_Block_4::S_494;
            }
            C2Rust_Block_4::S_494 => return,
        }
    };
}
#[no_mangle]
pub unsafe extern "C" fn sub_001F9220() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_fp_control_word = unsafe { gamepkg_tls_g_fp_control_word() };
    let __gamepkg_tls_g_fp_stack = unsafe { gamepkg_tls_g_fp_stack() };
    let __gamepkg_tls_g_fp_top = unsafe { gamepkg_tls_g_fp_top() };
    let mut _flags: ::core::ffi::c_int = 0;
    let mut _fa: uint32_t = 0;
    let mut _fb: uint32_t = 0;
    let mut _fas: int32_t = 0;
    let mut _fbs: int32_t = 0;
    let mut _pv: uint32_t = 0;
    let mut _pv_0: uint32_t = 0;
    let mut _pv_1: uint32_t = 0;
    let mut _pv_2: uint32_t = 0;
    let mut _pv_3: uint32_t = 0;
    let mut _pv_4: uint32_t = 0;
    let mut _pv_5: uint32_t = 0;
    let mut _pv_6: uint32_t = 0;
    let mut _pv_7: uint32_t = 0;
    let mut _pv_8: uint32_t = 0;
    let mut _pv_9: uint32_t = 0;
    let mut _pv_10: uint32_t = 0;
    let mut _pv_11: uint32_t = 0;
    let mut _pv_12: uint32_t = 0;
    let mut _fp_value: ::core::ffi::c_double = 0.;
    let mut _fp_value_0: ::core::ffi::c_double = 0.;
    enum C2Rust_Block_5 {
        S_0,
        S_2,
        S_4,
        S_18,
        S_24,
        S_26,
        S_28,
        S_38,
        S_40,
        S_42,
        S_52,
        S_54,
        S_56,
        S_66,
        S_68,
        S_70,
        S_80,
        S_82,
        S_84,
        S_90,
        S_96,
        S_98,
        S_104,
        S_106,
        S_108,
        S_114,
        S_120,
        S_122,
        S_124,
        S_134,
        S_136,
        S_138,
        S_144,
        S_150,
        S_152,
        S_154,
        S_156,
        S_158,
        S_160,
        S_162,
        S_164,
        S_166,
        S_168,
        S_174,
        S_176,
        S_178,
        S_188,
        S_190,
        S_192,
        S_198,
        S_207,
        S_209,
        S_211,
        S_213,
        S_219,
        S_221,
        S_223,
        S_233,
        S_235,
        S_237,
        S_243,
        S_253,
        S_255,
        S_265,
        S_267,
        S_273,
        S_275,
        S_281,
        S_287,
        S_289,
        S_291,
        S_301,
        S_303,
        S_305,
        S_311,
        S_317,
        S_319,
        S_321,
        S_323,
        S_325,
        S_327,
        S_329,
        S_331,
        S_333,
        S_335,
        S_337,
        S_339,
        S_341,
        S_350,
        S_352,
        S_354,
        S_356,
        S_358,
        S_367,
        S_369,
        S_377,
        S_383,
        S_385,
        S_387,
        S_393,
        S_395,
        S_397,
        S_399,
        S_401,
        S_410,
        S_416,
        S_418,
        S_420,
        S_422,
        S_424,
        S_426,
        S_428,
        S_430,
        S_432,
        S_438,
        S_440,
        S_442,
        S_448,
        S_457,
        S_463,
        S_465,
        S_467,
        S_469,
        S_475,
        S_477,
        S_479,
        S_481,
        S_483,
        S_485,
        S_494,
        S_496,
        S_498,
        S_500,
        S_502,
        S_511,
        S_513,
        S_515,
        S_517,
        S_519,
        S_528,
        S_534,
        S_536,
        S_542,
        S_548,
        S_550,
        S_556,
        S_558,
        S_564,
        S_566,
        S_568,
        S_570,
        S_572,
        S_574,
        S_576,
        S_582,
        S_584,
        S_590,
        S_596,
        S_598,
        S_604,
        S_606,
        S_612,
        S_614,
        S_616,
        S_618,
        S_620,
        S_622,
        S_624,
        S_626,
        S_636,
        S_638,
        S_648,
        S_650,
        S_656,
        S_658,
    }
    let mut c2rust_current_block_5: C2Rust_Block_5;
    c2rust_current_block_5 = C2Rust_Block_5::S_0;
    loop {
        match c2rust_current_block_5 {
            C2Rust_Block_5::S_0 => {
                _flags = 0 as ::core::ffi::c_int;
                c2rust_current_block_5 = C2Rust_Block_5::S_2;
            }
            C2Rust_Block_5::S_2 => {
                _fa = 0 as uint32_t;
                _fb = 0 as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_4;
            }
            C2Rust_Block_5::S_4 => {
                _fas = 0 as int32_t;
                _fbs = 0 as int32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_18;
            }
            C2Rust_Block_5::S_18 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x76411c as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_24;
            }
            C2Rust_Block_5::S_24 => {
                _pv = (*__gamepkg_tls_g_esi);
                c2rust_current_block_5 = C2Rust_Block_5::S_26;
            }
            C2Rust_Block_5::S_26 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_5 = C2Rust_Block_5::S_28;
            }
            C2Rust_Block_5::S_28 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv,
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_38;
            }
            C2Rust_Block_5::S_38 => {
                _pv_0 = (*__gamepkg_tls_g_edi);
                c2rust_current_block_5 = C2Rust_Block_5::S_40;
            }
            C2Rust_Block_5::S_40 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_5 = C2Rust_Block_5::S_42;
            }
            C2Rust_Block_5::S_42 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_0,
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_52;
            }
            C2Rust_Block_5::S_52 => {
                _pv_1 = 0xffffffff as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_54;
            }
            C2Rust_Block_5::S_54 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_5 = C2Rust_Block_5::S_56;
            }
            C2Rust_Block_5::S_56 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_1,
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_66;
            }
            C2Rust_Block_5::S_66 => {
                _pv_2 = (*__gamepkg_tls_g_eax);
                c2rust_current_block_5 = C2Rust_Block_5::S_68;
            }
            C2Rust_Block_5::S_68 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_5 = C2Rust_Block_5::S_70;
            }
            C2Rust_Block_5::S_70 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_2,
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_80;
            }
            C2Rust_Block_5::S_80 => {
                _pv_3 = 0x1f922f as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_82;
            }
            C2Rust_Block_5::S_82 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_5 = C2Rust_Block_5::S_84;
            }
            C2Rust_Block_5::S_84 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_3,
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_90;
            }
            C2Rust_Block_5::S_90 => {
                sub_001D1608();
                c2rust_current_block_5 = C2Rust_Block_5::S_96;
            }
            C2Rust_Block_5::S_96 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_98;
            }
            C2Rust_Block_5::S_98 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_esi)
                    .wrapping_add(0x154 as uint32_t);
                c2rust_current_block_5 = C2Rust_Block_5::S_104;
            }
            C2Rust_Block_5::S_104 => {
                _pv_4 = (*__gamepkg_tls_g_ecx);
                c2rust_current_block_5 = C2Rust_Block_5::S_106;
            }
            C2Rust_Block_5::S_106 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_5 = C2Rust_Block_5::S_108;
            }
            C2Rust_Block_5::S_108 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_4,
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_114;
            }
            C2Rust_Block_5::S_114 => {
                (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_esi)
                    .wrapping_add(0xec as uint32_t);
                c2rust_current_block_5 = C2Rust_Block_5::S_120;
            }
            C2Rust_Block_5::S_120 => {
                _pv_5 = (*__gamepkg_tls_g_edx);
                c2rust_current_block_5 = C2Rust_Block_5::S_122;
            }
            C2Rust_Block_5::S_122 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_5 = C2Rust_Block_5::S_124;
            }
            C2Rust_Block_5::S_124 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_5,
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_134;
            }
            C2Rust_Block_5::S_134 => {
                _pv_6 = 0x1f9246 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_136;
            }
            C2Rust_Block_5::S_136 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_5 = C2Rust_Block_5::S_138;
            }
            C2Rust_Block_5::S_138 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_6,
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_144;
            }
            C2Rust_Block_5::S_144 => {
                sub_00200C70();
                c2rust_current_block_5 = C2Rust_Block_5::S_150;
            }
            C2Rust_Block_5::S_150 => {
                _fb = 8 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_152;
            }
            C2Rust_Block_5::S_152 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_154;
            }
            C2Rust_Block_5::S_154 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(8 as uint32_t);
                c2rust_current_block_5 = C2Rust_Block_5::S_156;
            }
            C2Rust_Block_5::S_156 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_158;
            }
            C2Rust_Block_5::S_158 => {
                _fas = _fa as int32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_160;
            }
            C2Rust_Block_5::S_160 => {
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_eax);
                c2rust_current_block_5 = C2Rust_Block_5::S_162;
            }
            C2Rust_Block_5::S_162 => {
                _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_164;
            }
            C2Rust_Block_5::S_164 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_166;
            }
            C2Rust_Block_5::S_166 => {
                _fas = _fa as int32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_168;
            }
            C2Rust_Block_5::S_168 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_174;
            }
            C2Rust_Block_5::S_174 => {
                _pv_7 = 0 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_176;
            }
            C2Rust_Block_5::S_176 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_5 = C2Rust_Block_5::S_178;
            }
            C2Rust_Block_5::S_178 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_7,
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_188;
            }
            C2Rust_Block_5::S_188 => {
                _pv_8 = 1 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_190;
            }
            C2Rust_Block_5::S_190 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_5 = C2Rust_Block_5::S_192;
            }
            C2Rust_Block_5::S_192 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_8,
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_198;
            }
            C2Rust_Block_5::S_198 => {
                if _fa != _fb {
                    c2rust_current_block_5 = C2Rust_Block_5::S_281;
                } else {
                    c2rust_current_block_5 = C2Rust_Block_5::S_207;
                }
            }
            C2Rust_Block_5::S_207 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x18 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_209;
            }
            C2Rust_Block_5::S_209 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax).wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_edi),
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_211;
            }
            C2Rust_Block_5::S_211 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_edi),
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_213;
            }
            C2Rust_Block_5::S_213 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x76411c as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_219;
            }
            C2Rust_Block_5::S_219 => {
                _pv_9 = (*__gamepkg_tls_g_eax);
                c2rust_current_block_5 = C2Rust_Block_5::S_221;
            }
            C2Rust_Block_5::S_221 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_5 = C2Rust_Block_5::S_223;
            }
            C2Rust_Block_5::S_223 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_9,
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_233;
            }
            C2Rust_Block_5::S_233 => {
                _pv_10 = 0x1f9267 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_235;
            }
            C2Rust_Block_5::S_235 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_5 = C2Rust_Block_5::S_237;
            }
            C2Rust_Block_5::S_237 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_10,
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_243;
            }
            C2Rust_Block_5::S_243 => {
                sub_001D154C();
                c2rust_current_block_5 = C2Rust_Block_5::S_253;
            }
            C2Rust_Block_5::S_253 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_255;
            }
            C2Rust_Block_5::S_255 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_5 = C2Rust_Block_5::S_265;
            }
            C2Rust_Block_5::S_265 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_267;
            }
            C2Rust_Block_5::S_267 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_5 = C2Rust_Block_5::S_273;
            }
            C2Rust_Block_5::S_273 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_5 = C2Rust_Block_5::S_275;
            }
            C2Rust_Block_5::S_275 => return,
            C2Rust_Block_5::S_281 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x76411c as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_287;
            }
            C2Rust_Block_5::S_287 => {
                _pv_11 = (*__gamepkg_tls_g_ecx);
                c2rust_current_block_5 = C2Rust_Block_5::S_289;
            }
            C2Rust_Block_5::S_289 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_5 = C2Rust_Block_5::S_291;
            }
            C2Rust_Block_5::S_291 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_11,
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_301;
            }
            C2Rust_Block_5::S_301 => {
                _pv_12 = 0x1f9276 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_303;
            }
            C2Rust_Block_5::S_303 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_5 = C2Rust_Block_5::S_305;
            }
            C2Rust_Block_5::S_305 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_12,
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_311;
            }
            C2Rust_Block_5::S_311 => {
                sub_001D154C();
                c2rust_current_block_5 = C2Rust_Block_5::S_317;
            }
            C2Rust_Block_5::S_317 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x10 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_319;
            }
            C2Rust_Block_5::S_319 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x100 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_321;
            }
            C2Rust_Block_5::S_321 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax).wrapping_add(0xc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_323;
            }
            C2Rust_Block_5::S_323 => {
                _fb = 0x5c as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_325;
            }
            C2Rust_Block_5::S_325 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_327;
            }
            C2Rust_Block_5::S_327 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx)
                    .wrapping_add(0x5c as uint32_t);
                c2rust_current_block_5 = C2Rust_Block_5::S_329;
            }
            C2Rust_Block_5::S_329 => {
                _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_331;
            }
            C2Rust_Block_5::S_331 => {
                _fas = _fa as int32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_333;
            }
            C2Rust_Block_5::S_333 => {
                (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_edx).wrapping_sub(1);
                c2rust_current_block_5 = C2Rust_Block_5::S_335;
            }
            C2Rust_Block_5::S_335 => {
                _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_337;
            }
            C2Rust_Block_5::S_337 => {
                _fas = _fa as int32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_339;
            }
            C2Rust_Block_5::S_339 => {
                _fb = (_fa == 0x7fffffff as uint32_t) as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_341;
            }
            C2Rust_Block_5::S_341 => {
                if _fa == 0 as uint32_t {
                    c2rust_current_block_5 = C2Rust_Block_5::S_377;
                } else {
                    c2rust_current_block_5 = C2Rust_Block_5::S_350;
                }
            }
            C2Rust_Block_5::S_350 => {
                (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_edx).wrapping_sub(1);
                c2rust_current_block_5 = C2Rust_Block_5::S_352;
            }
            C2Rust_Block_5::S_352 => {
                _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_354;
            }
            C2Rust_Block_5::S_354 => {
                _fas = _fa as int32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_356;
            }
            C2Rust_Block_5::S_356 => {
                _fb = (_fa == 0x7fffffff as uint32_t) as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_358;
            }
            C2Rust_Block_5::S_358 => {
                if _fa != 0 as uint32_t {
                    c2rust_current_block_5 = C2Rust_Block_5::S_475;
                } else {
                    c2rust_current_block_5 = C2Rust_Block_5::S_367;
                }
            }
            C2Rust_Block_5::S_367 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edi).wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_369;
            }
            C2Rust_Block_5::S_369 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax).wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_edx),
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_475;
            }
            C2Rust_Block_5::S_377 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edi).wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_383;
            }
            C2Rust_Block_5::S_383 => {
                _fp_value = ::core::ptr::read_volatile::<
                    int32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        int32_t,
                    >(
                        ((*__gamepkg_tls_g_edi).wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) as ::core::ffi::c_double;
                c2rust_current_block_5 = C2Rust_Block_5::S_385;
            }
            C2Rust_Block_5::S_385 => {
                (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top)
                    as ::core::ffi::c_uint)
                    .wrapping_add(7 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
                    as ::core::ffi::c_int;
                c2rust_current_block_5 = C2Rust_Block_5::S_387;
            }
            C2Rust_Block_5::S_387 => {
                (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = _fp_value;
                c2rust_current_block_5 = C2Rust_Block_5::S_393;
            }
            C2Rust_Block_5::S_393 => {
                _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_395;
            }
            C2Rust_Block_5::S_395 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_397;
            }
            C2Rust_Block_5::S_397 => {
                _fas = _fa as int32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_399;
            }
            C2Rust_Block_5::S_399 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_401;
            }
            C2Rust_Block_5::S_401 => {
                if if if ::core::mem::size_of::<int32_t>()
                    < ::core::mem::size_of::<int32_t>()
                {
                    ::core::mem::size_of::<int32_t>()
                } else {
                    ::core::mem::size_of::<int32_t>()
                } == 1usize
                {
                    _fas as uint32_t as uint8_t as int8_t as int32_t
                } else if if ::core::mem::size_of::<int32_t>()
                    < ::core::mem::size_of::<int32_t>()
                {
                    ::core::mem::size_of::<int32_t>()
                } else {
                    ::core::mem::size_of::<int32_t>()
                } == 2usize
                {
                    _fas as uint32_t as uint16_t as int16_t as int32_t
                } else {
                    _fas as uint32_t as int32_t
                }
                    >= if if ::core::mem::size_of::<int32_t>()
                        < ::core::mem::size_of::<int32_t>()
                    {
                        ::core::mem::size_of::<int32_t>()
                    } else {
                        ::core::mem::size_of::<int32_t>()
                    } == 1usize
                    {
                        _fbs as uint32_t as uint8_t as int8_t as int32_t
                    } else if if ::core::mem::size_of::<int32_t>()
                        < ::core::mem::size_of::<int32_t>()
                    {
                        ::core::mem::size_of::<int32_t>()
                    } else {
                        ::core::mem::size_of::<int32_t>()
                    } == 2usize
                    {
                        _fbs as uint32_t as uint16_t as int16_t as int32_t
                    } else {
                        _fbs as uint32_t as int32_t
                    }
                {
                    c2rust_current_block_5 = C2Rust_Block_5::S_416;
                } else {
                    c2rust_current_block_5 = C2Rust_Block_5::S_410;
                }
            }
            C2Rust_Block_5::S_410 => {
                (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = if (*__gamepkg_tls_g_fp_control_word)
                    as ::core::ffi::c_uint & 0x300 as ::core::ffi::c_uint != 0
                {
                    (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                        + ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b16a8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ) as ::core::ffi::c_double
                } else {
                    recomp_fp_round24(
                        (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                            + ::core::ptr::read_volatile::<
                                ::core::ffi::c_float,
                            >(
                                ::core::ptr::with_exposed_provenance_mut::<
                                    ::core::ffi::c_float,
                                >(
                                    (0x3b16a8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                                ),
                            ) as ::core::ffi::c_double,
                    )
                };
                c2rust_current_block_5 = C2Rust_Block_5::S_416;
            }
            C2Rust_Block_5::S_416 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0xf8 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_418;
            }
            C2Rust_Block_5::S_418 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edx).wrapping_add(0x18 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_420;
            }
            C2Rust_Block_5::S_420 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edx).wrapping_add(0x14 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_422;
            }
            C2Rust_Block_5::S_422 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edx) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_424;
            }
            C2Rust_Block_5::S_424 => {
                _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_426;
            }
            C2Rust_Block_5::S_426 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_428;
            }
            C2Rust_Block_5::S_428 => {
                _fas = _fa as int32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_430;
            }
            C2Rust_Block_5::S_430 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_432;
            }
            C2Rust_Block_5::S_432 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x10 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_edx),
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_438;
            }
            C2Rust_Block_5::S_438 => {
                _fp_value_0 = ::core::ptr::read_volatile::<
                    int32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        int32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x10 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) as ::core::ffi::c_double;
                c2rust_current_block_5 = C2Rust_Block_5::S_440;
            }
            C2Rust_Block_5::S_440 => {
                (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top)
                    as ::core::ffi::c_uint)
                    .wrapping_add(7 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
                    as ::core::ffi::c_int;
                c2rust_current_block_5 = C2Rust_Block_5::S_442;
            }
            C2Rust_Block_5::S_442 => {
                (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = _fp_value_0;
                c2rust_current_block_5 = C2Rust_Block_5::S_448;
            }
            C2Rust_Block_5::S_448 => {
                if if if ::core::mem::size_of::<int32_t>()
                    < ::core::mem::size_of::<int32_t>()
                {
                    ::core::mem::size_of::<int32_t>()
                } else {
                    ::core::mem::size_of::<int32_t>()
                } == 1usize
                {
                    _fas as uint32_t as uint8_t as int8_t as int32_t
                } else if if ::core::mem::size_of::<int32_t>()
                    < ::core::mem::size_of::<int32_t>()
                {
                    ::core::mem::size_of::<int32_t>()
                } else {
                    ::core::mem::size_of::<int32_t>()
                } == 2usize
                {
                    _fas as uint32_t as uint16_t as int16_t as int32_t
                } else {
                    _fas as uint32_t as int32_t
                }
                    >= if if ::core::mem::size_of::<int32_t>()
                        < ::core::mem::size_of::<int32_t>()
                    {
                        ::core::mem::size_of::<int32_t>()
                    } else {
                        ::core::mem::size_of::<int32_t>()
                    } == 1usize
                    {
                        _fbs as uint32_t as uint8_t as int8_t as int32_t
                    } else if if ::core::mem::size_of::<int32_t>()
                        < ::core::mem::size_of::<int32_t>()
                    {
                        ::core::mem::size_of::<int32_t>()
                    } else {
                        ::core::mem::size_of::<int32_t>()
                    } == 2usize
                    {
                        _fbs as uint32_t as uint16_t as int16_t as int32_t
                    } else {
                        _fbs as uint32_t as int32_t
                    }
                {
                    c2rust_current_block_5 = C2Rust_Block_5::S_463;
                } else {
                    c2rust_current_block_5 = C2Rust_Block_5::S_457;
                }
            }
            C2Rust_Block_5::S_457 => {
                (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = if (*__gamepkg_tls_g_fp_control_word)
                    as ::core::ffi::c_uint & 0x300 as ::core::ffi::c_uint != 0
                {
                    (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                        + ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b16a8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ) as ::core::ffi::c_double
                } else {
                    recomp_fp_round24(
                        (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                            + ::core::ptr::read_volatile::<
                                ::core::ffi::c_float,
                            >(
                                ::core::ptr::with_exposed_provenance_mut::<
                                    ::core::ffi::c_float,
                                >(
                                    (0x3b16a8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                                ),
                            ) as ::core::ffi::c_double,
                    )
                };
                c2rust_current_block_5 = C2Rust_Block_5::S_463;
            }
            C2Rust_Block_5::S_463 => {
                (*__gamepkg_tls_g_fp_stack)[(((*__gamepkg_tls_g_fp_top)
                    + 1 as ::core::ffi::c_int) as ::core::ffi::c_uint
                    & 7 as ::core::ffi::c_uint) as usize] = if (*__gamepkg_tls_g_fp_control_word)
                    as ::core::ffi::c_uint & 0x300 as ::core::ffi::c_uint != 0
                {
                    (*__gamepkg_tls_g_fp_stack)[(((*__gamepkg_tls_g_fp_top)
                        + 1 as ::core::ffi::c_int) as ::core::ffi::c_uint
                        & 7 as ::core::ffi::c_uint) as usize]
                        / (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                } else {
                    recomp_fp_round24(
                        (*__gamepkg_tls_g_fp_stack)[(((*__gamepkg_tls_g_fp_top)
                            + 1 as ::core::ffi::c_int) as ::core::ffi::c_uint
                            & 7 as ::core::ffi::c_uint) as usize]
                            / (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top)
                                as usize],
                    )
                };
                c2rust_current_block_5 = C2Rust_Block_5::S_465;
            }
            C2Rust_Block_5::S_465 => {
                (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top)
                    as ::core::ffi::c_uint)
                    .wrapping_add(1 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
                    as ::core::ffi::c_int;
                c2rust_current_block_5 = C2Rust_Block_5::S_467;
            }
            C2Rust_Block_5::S_467 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        ::core::ffi::c_float,
                    >(
                        ((*__gamepkg_tls_g_eax).wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                        as ::core::ffi::c_float,
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_469;
            }
            C2Rust_Block_5::S_469 => {
                (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top)
                    as ::core::ffi::c_uint)
                    .wrapping_add(1 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
                    as ::core::ffi::c_int;
                c2rust_current_block_5 = C2Rust_Block_5::S_475;
            }
            C2Rust_Block_5::S_475 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_477;
            }
            C2Rust_Block_5::S_477 => {
                (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_edx).wrapping_sub(1);
                c2rust_current_block_5 = C2Rust_Block_5::S_479;
            }
            C2Rust_Block_5::S_479 => {
                _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_481;
            }
            C2Rust_Block_5::S_481 => {
                _fas = _fa as int32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_483;
            }
            C2Rust_Block_5::S_483 => {
                _fb = (_fa == 0x7fffffff as uint32_t) as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_485;
            }
            C2Rust_Block_5::S_485 => {
                if _fa == 0 as uint32_t {
                    c2rust_current_block_5 = C2Rust_Block_5::S_612;
                } else {
                    c2rust_current_block_5 = C2Rust_Block_5::S_494;
                }
            }
            C2Rust_Block_5::S_494 => {
                (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_edx).wrapping_sub(1);
                c2rust_current_block_5 = C2Rust_Block_5::S_496;
            }
            C2Rust_Block_5::S_496 => {
                _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_498;
            }
            C2Rust_Block_5::S_498 => {
                _fas = _fa as int32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_500;
            }
            C2Rust_Block_5::S_500 => {
                _fb = (_fa == 0x7fffffff as uint32_t) as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_502;
            }
            C2Rust_Block_5::S_502 => {
                if _fa == 0 as uint32_t {
                    c2rust_current_block_5 = C2Rust_Block_5::S_564;
                } else {
                    c2rust_current_block_5 = C2Rust_Block_5::S_511;
                }
            }
            C2Rust_Block_5::S_511 => {
                (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_edx).wrapping_sub(1);
                c2rust_current_block_5 = C2Rust_Block_5::S_513;
            }
            C2Rust_Block_5::S_513 => {
                _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_515;
            }
            C2Rust_Block_5::S_515 => {
                _fas = _fa as int32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_517;
            }
            C2Rust_Block_5::S_517 => {
                _fb = (_fa == 0x7fffffff as uint32_t) as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_519;
            }
            C2Rust_Block_5::S_519 => {
                if _fa != 0 as uint32_t {
                    c2rust_current_block_5 = C2Rust_Block_5::S_636;
                } else {
                    c2rust_current_block_5 = C2Rust_Block_5::S_528;
                }
            }
            C2Rust_Block_5::S_528 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edi) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_534;
            }
            C2Rust_Block_5::S_534 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_536;
            }
            C2Rust_Block_5::S_536 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_5 = C2Rust_Block_5::S_542;
            }
            C2Rust_Block_5::S_542 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_ecx),
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_548;
            }
            C2Rust_Block_5::S_548 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_550;
            }
            C2Rust_Block_5::S_550 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_5 = C2Rust_Block_5::S_556;
            }
            C2Rust_Block_5::S_556 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_5 = C2Rust_Block_5::S_558;
            }
            C2Rust_Block_5::S_558 => return,
            C2Rust_Block_5::S_564 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ecx).wrapping_add(0x12c as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_566;
            }
            C2Rust_Block_5::S_566 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edi) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_568;
            }
            C2Rust_Block_5::S_568 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edx).wrapping_add(0x10 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_570;
            }
            C2Rust_Block_5::S_570 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx)
                    << 5 as ::core::ffi::c_int;
                c2rust_current_block_5 = C2Rust_Block_5::S_572;
            }
            C2Rust_Block_5::S_572 => {
                _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_574;
            }
            C2Rust_Block_5::S_574 => {
                _fas = _fa as int32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_576;
            }
            C2Rust_Block_5::S_576 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ecx).wrapping_add((*__gamepkg_tls_g_edx))
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_582;
            }
            C2Rust_Block_5::S_582 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_584;
            }
            C2Rust_Block_5::S_584 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_5 = C2Rust_Block_5::S_590;
            }
            C2Rust_Block_5::S_590 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_ecx),
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_596;
            }
            C2Rust_Block_5::S_596 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_598;
            }
            C2Rust_Block_5::S_598 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_5 = C2Rust_Block_5::S_604;
            }
            C2Rust_Block_5::S_604 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_5 = C2Rust_Block_5::S_606;
            }
            C2Rust_Block_5::S_606 => return,
            C2Rust_Block_5::S_612 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ecx).wrapping_add(0x12c as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_614;
            }
            C2Rust_Block_5::S_614 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edi) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_616;
            }
            C2Rust_Block_5::S_616 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edx).wrapping_add(0x10 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_618;
            }
            C2Rust_Block_5::S_618 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx)
                    << 5 as ::core::ffi::c_int;
                c2rust_current_block_5 = C2Rust_Block_5::S_620;
            }
            C2Rust_Block_5::S_620 => {
                _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_622;
            }
            C2Rust_Block_5::S_622 => {
                _fas = _fa as int32_t;
                c2rust_current_block_5 = C2Rust_Block_5::S_624;
            }
            C2Rust_Block_5::S_624 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edx)
                            .wrapping_add((*__gamepkg_tls_g_ecx))
                            .wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_626;
            }
            C2Rust_Block_5::S_626 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_ecx),
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_636;
            }
            C2Rust_Block_5::S_636 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_638;
            }
            C2Rust_Block_5::S_638 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_5 = C2Rust_Block_5::S_648;
            }
            C2Rust_Block_5::S_648 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_5 = C2Rust_Block_5::S_650;
            }
            C2Rust_Block_5::S_650 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_5 = C2Rust_Block_5::S_656;
            }
            C2Rust_Block_5::S_656 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_5 = C2Rust_Block_5::S_658;
            }
            C2Rust_Block_5::S_658 => return,
        }
    };
}
#[no_mangle]
pub unsafe extern "C" fn sub_001F9310() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (0x76411c as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv: uint32_t = 0xffffffff as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    let mut _pv_0: uint32_t = (*__gamepkg_tls_g_eax);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    let mut _pv_1: uint32_t = 0x1f931d as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    sub_001D1608();
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv_2: uint32_t = (*__gamepkg_tls_g_ecx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_2,
    );
    _fb = 0x15c as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_edx).wrapping_add(0x15c as uint32_t);
    _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    let mut _pv_3: uint32_t = (*__gamepkg_tls_g_edx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_3,
    );
    let mut _pv_4: uint32_t = 0x1f9332 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_4,
    );
    sub_00201F80();
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (0x76411c as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    _fb = 8 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t);
    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    let mut _pv_5: uint32_t = 0 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_5,
    );
    let mut _pv_6: uint32_t = 1 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_6,
    );
    let mut _pv_7: uint32_t = (*__gamepkg_tls_g_eax);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_7,
    );
    let mut _pv_8: uint32_t = 0x1f9344 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_8,
    );
    sub_001D154C();
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001F9350() {
    let __gamepkg_tls_g_df = unsafe { gamepkg_tls_g_df() };
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebx = unsafe { gamepkg_tls_g_ebx() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (0x76411c as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv: uint32_t = 0xffffffff as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    let mut _pv_0: uint32_t = (*__gamepkg_tls_g_eax);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    let mut _pv_1: uint32_t = 0x1f935d as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    sub_001D1608();
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    's_338: {
        if _fa == _fb {
            break 's_338;
        }
        let mut _pv_2: uint32_t = (*__gamepkg_tls_g_ebx);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_2,
        );
        let mut _pv_3: uint32_t = (*__gamepkg_tls_g_esi);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_3,
        );
        (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_eax).wrapping_add(8 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
        _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fbs = _fb as int32_t;
        let mut _pv_4: uint32_t = (*__gamepkg_tls_g_edi);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_4,
        );
        's_219: {
            if _fa == _fb {
                break 's_219;
            }
            (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edx)
                .wrapping_add(0xc0 as uint32_t);
            (*__gamepkg_tls_g_ecx) = 7 as uint32_t;
            's_213: {
                's_158: {
                    if (*__gamepkg_tls_g_df) == 0 {
                        break 's_158;
                    }
                    let mut _i_0: uint32_t = 0;
                    _i_0 = 0 as uint32_t;
                    while _i_0 < (*__gamepkg_tls_g_ecx) {
                        ::core::ptr::write_volatile(
                            ::core::ptr::with_exposed_provenance_mut::<
                                uint32_t,
                            >(
                                ((*__gamepkg_tls_g_edi)
                                    .wrapping_sub(_i_0.wrapping_mul(4 as uint32_t))
                                    as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                            ::core::ptr::read_volatile::<
                                uint32_t,
                            >(
                                ::core::ptr::with_exposed_provenance_mut::<
                                    uint32_t,
                                >(
                                    ((*__gamepkg_tls_g_esi)
                                        .wrapping_sub(_i_0.wrapping_mul(4 as uint32_t))
                                        as uintptr_t)
                                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                                ),
                            ),
                        );
                        _i_0 = _i_0.wrapping_add(1);
                    }
                    (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi)
                        .wrapping_sub(
                            (*__gamepkg_tls_g_ecx).wrapping_mul(4 as uint32_t),
                        );
                    (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
                        .wrapping_sub(
                            (*__gamepkg_tls_g_ecx).wrapping_mul(4 as uint32_t),
                        );
                    break 's_213;
                }
                let mut _d: *mut uint8_t = ::core::ptr::with_exposed_provenance_mut::<
                    uint8_t,
                >(
                    ((*__gamepkg_tls_g_edi) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                );
                let mut _s: *mut uint8_t = ::core::ptr::with_exposed_provenance_mut::<
                    uint8_t,
                >(
                    ((*__gamepkg_tls_g_esi) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                );
                let mut _n: uint32_t = (*__gamepkg_tls_g_ecx)
                    .wrapping_mul(4 as uint32_t);
                's_185: {
                    's_164: {
                        if _d.offset(_n as isize) <= _s || _s.offset(_n as isize) <= _d {
                            break 's_164;
                        }
                        let mut _i: uint32_t = 0;
                        _i = 0 as uint32_t;
                        loop {
                            if _i >= (*__gamepkg_tls_g_ecx) {
                                break 's_185;
                            }
                            ::core::ptr::write_volatile(
                                ::core::ptr::with_exposed_provenance_mut::<
                                    uint32_t,
                                >(
                                    ((*__gamepkg_tls_g_edi)
                                        .wrapping_add(_i.wrapping_mul(4 as uint32_t)) as uintptr_t)
                                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                                ),
                                ::core::ptr::read_volatile::<
                                    uint32_t,
                                >(
                                    ::core::ptr::with_exposed_provenance_mut::<
                                        uint32_t,
                                    >(
                                        ((*__gamepkg_tls_g_esi)
                                            .wrapping_add(_i.wrapping_mul(4 as uint32_t)) as uintptr_t)
                                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                                    ),
                                ),
                            );
                            _i = _i.wrapping_add(1);
                        }
                    }
                    memcpy(
                        _d as *mut ::core::ffi::c_void,
                        _s as *const ::core::ffi::c_void,
                        _n as size_t,
                    );
                }
                (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi)
                    .wrapping_add((*__gamepkg_tls_g_ecx).wrapping_mul(4 as uint32_t));
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
                    .wrapping_add((*__gamepkg_tls_g_ecx).wrapping_mul(4 as uint32_t));
            }
            (*__gamepkg_tls_g_ecx) = 0 as uint32_t;
        }
        (*__gamepkg_tls_g_ebx) = (*__gamepkg_tls_g_edx).wrapping_add(0x240 as uint32_t);
        (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_eax);
        (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_ebx);
        (*__gamepkg_tls_g_ecx) = 0xc as uint32_t;
        's_286: {
            's_265: {
                if (*__gamepkg_tls_g_df) != 0 {
                    break 's_265;
                }
                let mut _d_0: *mut uint8_t = ::core::ptr::with_exposed_provenance_mut::<
                    uint8_t,
                >(
                    ((*__gamepkg_tls_g_edi) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                );
                let mut _s_0: *mut uint8_t = ::core::ptr::with_exposed_provenance_mut::<
                    uint8_t,
                >(
                    ((*__gamepkg_tls_g_esi) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                );
                let mut _n_0: uint32_t = (*__gamepkg_tls_g_ecx)
                    .wrapping_mul(4 as uint32_t);
                's_258: {
                    's_237: {
                        if _d_0.offset(_n_0 as isize) <= _s_0
                            || _s_0.offset(_n_0 as isize) <= _d_0
                        {
                            break 's_237;
                        }
                        let mut _i_1: uint32_t = 0;
                        _i_1 = 0 as uint32_t;
                        loop {
                            if _i_1 >= (*__gamepkg_tls_g_ecx) {
                                break 's_258;
                            }
                            ::core::ptr::write_volatile(
                                ::core::ptr::with_exposed_provenance_mut::<
                                    uint32_t,
                                >(
                                    ((*__gamepkg_tls_g_edi)
                                        .wrapping_add(_i_1.wrapping_mul(4 as uint32_t))
                                        as uintptr_t)
                                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                                ),
                                ::core::ptr::read_volatile::<
                                    uint32_t,
                                >(
                                    ::core::ptr::with_exposed_provenance_mut::<
                                        uint32_t,
                                    >(
                                        ((*__gamepkg_tls_g_esi)
                                            .wrapping_add(_i_1.wrapping_mul(4 as uint32_t))
                                            as uintptr_t)
                                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                                    ),
                                ),
                            );
                            _i_1 = _i_1.wrapping_add(1);
                        }
                    }
                    memcpy(
                        _d_0 as *mut ::core::ffi::c_void,
                        _s_0 as *const ::core::ffi::c_void,
                        _n_0 as size_t,
                    );
                }
                (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi)
                    .wrapping_add((*__gamepkg_tls_g_ecx).wrapping_mul(4 as uint32_t));
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
                    .wrapping_add((*__gamepkg_tls_g_ecx).wrapping_mul(4 as uint32_t));
                break 's_286;
            }
            let mut _i_2: uint32_t = 0;
            _i_2 = 0 as uint32_t;
            while _i_2 < (*__gamepkg_tls_g_ecx) {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edi)
                            .wrapping_sub(_i_2.wrapping_mul(4 as uint32_t)) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esi)
                                .wrapping_sub(_i_2.wrapping_mul(4 as uint32_t))
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ),
                );
                _i_2 = _i_2.wrapping_add(1);
            }
            (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi)
                .wrapping_sub((*__gamepkg_tls_g_ecx).wrapping_mul(4 as uint32_t));
            (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
                .wrapping_sub((*__gamepkg_tls_g_ecx).wrapping_mul(4 as uint32_t));
        }
        (*__gamepkg_tls_g_ecx) = 0 as uint32_t;
        (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_ebx);
        (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_edx).wrapping_add(0xc0 as uint32_t);
        (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_eax).wrapping_add(8 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            (*__gamepkg_tls_g_ecx),
        );
        (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    }
    let mut _pv_5: uint32_t = (*__gamepkg_tls_g_eax);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_5,
    );
    _fb = 0x15c as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_edx).wrapping_add(0x15c as uint32_t);
    _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    let mut _pv_6: uint32_t = (*__gamepkg_tls_g_edx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_6,
    );
    let mut _pv_7: uint32_t = 0x1f93ac as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_7,
    );
    sub_00201EC0();
    (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (0x76411c as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    _fb = 8 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t);
    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    let mut _pv_8: uint32_t = 0 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_8,
    );
    let mut _pv_9: uint32_t = 1 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_9,
    );
    let mut _pv_10: uint32_t = (*__gamepkg_tls_g_edx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_10,
    );
    let mut _pv_11: uint32_t = 0x1f93bf as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_11,
    );
    sub_001D154C();
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001F93C0() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (0x76411c as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv: uint32_t = 0xffffffff as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    let mut _pv_0: uint32_t = (*__gamepkg_tls_g_eax);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    let mut _pv_1: uint32_t = 0x1f93cd as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    sub_001D1608();
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv_2: uint32_t = (*__gamepkg_tls_g_ecx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_2,
    );
    _fb = 0x15c as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_edx).wrapping_add(0x15c as uint32_t);
    _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    let mut _pv_3: uint32_t = (*__gamepkg_tls_g_edx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_3,
    );
    let mut _pv_4: uint32_t = 0x1f93e2 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_4,
    );
    sub_00201F90();
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (0x76411c as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    _fb = 8 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t);
    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    let mut _pv_5: uint32_t = 0 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_5,
    );
    let mut _pv_6: uint32_t = 1 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_6,
    );
    let mut _pv_7: uint32_t = (*__gamepkg_tls_g_eax);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_7,
    );
    let mut _pv_8: uint32_t = 0x1f93f4 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_8,
    );
    sub_001D154C();
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001F9400() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0x234 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001F9410() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (0x76411c as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv: uint32_t = 0xffffffff as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    let mut _pv_0: uint32_t = (*__gamepkg_tls_g_eax);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    let mut _pv_1: uint32_t = 0x1f941d as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    sub_001D1608();
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv_2: uint32_t = (*__gamepkg_tls_g_ecx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_2,
    );
    let mut _pv_3: uint32_t = (*__gamepkg_tls_g_edx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_3,
    );
    (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_eax).wrapping_add(0x154 as uint32_t);
    let mut _pv_4: uint32_t = (*__gamepkg_tls_g_ecx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_4,
    );
    _fb = 0x15c as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax).wrapping_add(0x15c as uint32_t);
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    let mut _pv_5: uint32_t = (*__gamepkg_tls_g_eax);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_5,
    );
    let mut _pv_6: uint32_t = 0x1f943e as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_6,
    );
    sub_00201F20();
    (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (0x76411c as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    _fb = 0x10 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(0x10 as uint32_t);
    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    let mut _pv_7: uint32_t = 0 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_7,
    );
    let mut _pv_8: uint32_t = 1 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_8,
    );
    let mut _pv_9: uint32_t = (*__gamepkg_tls_g_edx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_9,
    );
    let mut _pv_10: uint32_t = 0x1f9451 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_10,
    );
    sub_001D154C();
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001F9460() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (0x76411c as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv: uint32_t = 0xffffffff as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    let mut _pv_0: uint32_t = (*__gamepkg_tls_g_eax);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    let mut _pv_1: uint32_t = 0x1f946d as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    sub_001D1608();
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_eax).wrapping_add(0x154 as uint32_t);
    let mut _pv_2: uint32_t = (*__gamepkg_tls_g_ecx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_2,
    );
    let mut _pv_3: uint32_t = (*__gamepkg_tls_g_edx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_3,
    );
    _fb = 0x15c as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax).wrapping_add(0x15c as uint32_t);
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    let mut _pv_4: uint32_t = (*__gamepkg_tls_g_eax);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_4,
    );
    let mut _pv_5: uint32_t = 0x1f9488 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_5,
    );
    sub_00201F00();
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (0x76411c as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    _fb = 0xc as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t);
    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    let mut _pv_6: uint32_t = 0 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_6,
    );
    let mut _pv_7: uint32_t = 1 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_7,
    );
    let mut _pv_8: uint32_t = (*__gamepkg_tls_g_eax);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_8,
    );
    let mut _pv_9: uint32_t = 0x1f949a as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_9,
    );
    sub_001D154C();
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001F94A0() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebx = unsafe { gamepkg_tls_g_ebx() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_fp_control_word = unsafe { gamepkg_tls_g_fp_control_word() };
    let __gamepkg_tls_g_fp_stack = unsafe { gamepkg_tls_g_fp_stack() };
    let __gamepkg_tls_g_fp_top = unsafe { gamepkg_tls_g_fp_top() };
    let mut _flags: ::core::ffi::c_int = 0;
    let mut _fa: uint32_t = 0;
    let mut _fb: uint32_t = 0;
    let mut _fas: int32_t = 0;
    let mut _fbs: int32_t = 0;
    let mut _pv: uint32_t = 0;
    let mut _pv_0: uint32_t = 0;
    let mut _pv_1: uint32_t = 0;
    let mut _pv_2: uint32_t = 0;
    let mut _pv_3: uint32_t = 0;
    let mut _pv_4: uint32_t = 0;
    let mut _pv_5: uint32_t = 0;
    let mut _pv_6: uint32_t = 0;
    let mut _pv_7: uint32_t = 0;
    let mut _pv_8: uint32_t = 0;
    let mut _pv_9: uint32_t = 0;
    let mut _pv_10: uint32_t = 0;
    let mut _pv_11: uint32_t = 0;
    let mut _pv_12: uint32_t = 0;
    let mut _pv_13: uint32_t = 0;
    let mut _pv_14: uint32_t = 0;
    let mut _dividend: uint64_t = 0;
    let mut _dividend_0: uint64_t = 0;
    let mut _fp_value: ::core::ffi::c_double = 0.;
    let mut _fp_value_0: ::core::ffi::c_double = 0.;
    let mut _pv_15: uint32_t = 0;
    let mut _pv_16: uint32_t = 0;
    let mut _pv_17: uint32_t = 0;
    let mut _pv_18: uint32_t = 0;
    let mut _pv_19: uint32_t = 0;
    let mut _pv_20: uint32_t = 0;
    let mut _pv_21: uint32_t = 0;
    let mut _pv_22: uint32_t = 0;
    enum C2Rust_Block_12 {
        S_0,
        S_2,
        S_4,
        S_18,
        S_24,
        S_26,
        S_28,
        S_38,
        S_40,
        S_42,
        S_52,
        S_54,
        S_56,
        S_66,
        S_68,
        S_70,
        S_80,
        S_82,
        S_84,
        S_90,
        S_92,
        S_94,
        S_100,
        S_102,
        S_104,
        S_110,
        S_116,
        S_118,
        S_120,
        S_122,
        S_124,
        S_126,
        S_128,
        S_130,
        S_132,
        S_141,
        S_143,
        S_145,
        S_147,
        S_149,
        S_158,
        S_160,
        S_162,
        S_164,
        S_166,
        S_175,
        S_183,
        S_189,
        S_191,
        S_193,
        S_199,
        S_205,
        S_207,
        S_209,
        S_219,
        S_221,
        S_223,
        S_229,
        S_241,
        S_247,
        S_249,
        S_251,
        S_257,
        S_263,
        S_265,
        S_267,
        S_277,
        S_279,
        S_281,
        S_287,
        S_293,
        S_295,
        S_297,
        S_299,
        S_301,
        S_303,
        S_309,
        S_315,
        S_317,
        S_319,
        S_329,
        S_331,
        S_333,
        S_343,
        S_345,
        S_347,
        S_357,
        S_359,
        S_361,
        S_367,
        S_373,
        S_375,
        S_377,
        S_379,
        S_381,
        S_383,
        S_385,
        S_387,
        S_389,
        S_391,
        S_393,
        S_395,
        S_397,
        S_399,
        S_401,
        S_403,
        S_405,
        S_414,
        S_416,
        S_418,
        S_420,
        S_422,
        S_424,
        S_433,
        S_435,
        S_437,
        S_439,
        S_441,
        S_443,
        S_445,
        S_447,
        S_449,
        S_451,
        S_453,
        S_455,
        S_457,
        S_459,
        S_461,
        S_470,
        S_476,
        S_478,
        S_480,
        S_482,
        S_484,
        S_486,
        S_488,
        S_491,
        S_493,
        S_495,
        S_499,
        S_501,
        S_503,
        S_506,
        S_508,
        S_510,
        S_514,
        S_516,
        S_518,
        S_520,
        S_522,
        S_524,
        S_526,
        S_535,
        S_537,
        S_539,
        S_541,
        S_543,
        S_549,
        S_551,
        S_553,
        S_559,
        S_568,
        S_574,
        S_576,
        S_578,
        S_584,
        S_586,
        S_588,
        S_594,
        S_596,
        S_598,
        S_600,
        S_602,
        S_611,
        S_617,
        S_619,
        S_621,
        S_623,
        S_629,
        S_635,
        S_637,
        S_639,
        S_649,
        S_651,
        S_653,
        S_663,
        S_665,
        S_667,
        S_677,
        S_679,
        S_681,
        S_687,
        S_697,
        S_699,
        S_709,
        S_711,
        S_721,
        S_723,
        S_729,
        S_731,
        S_741,
        S_743,
        S_745,
        S_751,
        S_753,
        S_755,
        S_757,
        S_763,
        S_765,
        S_767,
        S_777,
        S_779,
        S_781,
        S_791,
        S_793,
        S_795,
        S_801,
        S_811,
        S_813,
        S_823,
        S_825,
        S_835,
        S_837,
        S_843,
        S_845,
    }
    let mut c2rust_current_block_12: C2Rust_Block_12;
    c2rust_current_block_12 = C2Rust_Block_12::S_0;
    loop {
        match c2rust_current_block_12 {
            C2Rust_Block_12::S_0 => {
                _flags = 0 as ::core::ffi::c_int;
                c2rust_current_block_12 = C2Rust_Block_12::S_2;
            }
            C2Rust_Block_12::S_2 => {
                _fa = 0 as uint32_t;
                _fb = 0 as uint32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_4;
            }
            C2Rust_Block_12::S_4 => {
                _fas = 0 as int32_t;
                _fbs = 0 as int32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_18;
            }
            C2Rust_Block_12::S_18 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x76411c as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_12 = C2Rust_Block_12::S_24;
            }
            C2Rust_Block_12::S_24 => {
                _pv = (*__gamepkg_tls_g_ebx);
                c2rust_current_block_12 = C2Rust_Block_12::S_26;
            }
            C2Rust_Block_12::S_26 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_12 = C2Rust_Block_12::S_28;
            }
            C2Rust_Block_12::S_28 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv,
                );
                c2rust_current_block_12 = C2Rust_Block_12::S_38;
            }
            C2Rust_Block_12::S_38 => {
                _pv_0 = (*__gamepkg_tls_g_esi);
                c2rust_current_block_12 = C2Rust_Block_12::S_40;
            }
            C2Rust_Block_12::S_40 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_12 = C2Rust_Block_12::S_42;
            }
            C2Rust_Block_12::S_42 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_0,
                );
                c2rust_current_block_12 = C2Rust_Block_12::S_52;
            }
            C2Rust_Block_12::S_52 => {
                _pv_1 = (*__gamepkg_tls_g_edi);
                c2rust_current_block_12 = C2Rust_Block_12::S_54;
            }
            C2Rust_Block_12::S_54 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_12 = C2Rust_Block_12::S_56;
            }
            C2Rust_Block_12::S_56 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_1,
                );
                c2rust_current_block_12 = C2Rust_Block_12::S_66;
            }
            C2Rust_Block_12::S_66 => {
                _pv_2 = 0xffffffff as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_68;
            }
            C2Rust_Block_12::S_68 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_12 = C2Rust_Block_12::S_70;
            }
            C2Rust_Block_12::S_70 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_2,
                );
                c2rust_current_block_12 = C2Rust_Block_12::S_80;
            }
            C2Rust_Block_12::S_80 => {
                _pv_3 = (*__gamepkg_tls_g_eax);
                c2rust_current_block_12 = C2Rust_Block_12::S_82;
            }
            C2Rust_Block_12::S_82 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_12 = C2Rust_Block_12::S_84;
            }
            C2Rust_Block_12::S_84 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_3,
                );
                c2rust_current_block_12 = C2Rust_Block_12::S_90;
            }
            C2Rust_Block_12::S_90 => {
                (*__gamepkg_tls_g_edi) = 0 as uint32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_92;
            }
            C2Rust_Block_12::S_92 => {
                _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_94;
            }
            C2Rust_Block_12::S_94 => {
                _fas = _fa as int32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_100;
            }
            C2Rust_Block_12::S_100 => {
                _pv_4 = 0x1f94b2 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_102;
            }
            C2Rust_Block_12::S_102 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_12 = C2Rust_Block_12::S_104;
            }
            C2Rust_Block_12::S_104 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_4,
                );
                c2rust_current_block_12 = C2Rust_Block_12::S_110;
            }
            C2Rust_Block_12::S_110 => {
                sub_001D1608();
                c2rust_current_block_12 = C2Rust_Block_12::S_116;
            }
            C2Rust_Block_12::S_116 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x14 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_12 = C2Rust_Block_12::S_118;
            }
            C2Rust_Block_12::S_118 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_12 = C2Rust_Block_12::S_120;
            }
            C2Rust_Block_12::S_120 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax).wrapping_sub(1);
                c2rust_current_block_12 = C2Rust_Block_12::S_122;
            }
            C2Rust_Block_12::S_122 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_124;
            }
            C2Rust_Block_12::S_124 => {
                _fas = _fa as int32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_126;
            }
            C2Rust_Block_12::S_126 => {
                _fb = (_fa == 0x7fffffff as uint32_t) as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_128;
            }
            C2Rust_Block_12::S_128 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x10 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_12 = C2Rust_Block_12::S_130;
            }
            C2Rust_Block_12::S_130 => {
                (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ecx).wrapping_add(0x100 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_12 = C2Rust_Block_12::S_132;
            }
            C2Rust_Block_12::S_132 => {
                if _fa == 0 as uint32_t {
                    c2rust_current_block_12 = C2Rust_Block_12::S_241;
                } else {
                    c2rust_current_block_12 = C2Rust_Block_12::S_141;
                }
            }
            C2Rust_Block_12::S_141 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax).wrapping_sub(1);
                c2rust_current_block_12 = C2Rust_Block_12::S_143;
            }
            C2Rust_Block_12::S_143 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_145;
            }
            C2Rust_Block_12::S_145 => {
                _fas = _fa as int32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_147;
            }
            C2Rust_Block_12::S_147 => {
                _fb = (_fa == 0x7fffffff as uint32_t) as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_149;
            }
            C2Rust_Block_12::S_149 => {
                if _fa == 0 as uint32_t {
                    c2rust_current_block_12 = C2Rust_Block_12::S_183;
                } else {
                    c2rust_current_block_12 = C2Rust_Block_12::S_158;
                }
            }
            C2Rust_Block_12::S_158 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax).wrapping_sub(1);
                c2rust_current_block_12 = C2Rust_Block_12::S_160;
            }
            C2Rust_Block_12::S_160 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_162;
            }
            C2Rust_Block_12::S_162 => {
                _fas = _fa as int32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_164;
            }
            C2Rust_Block_12::S_164 => {
                _fb = (_fa == 0x7fffffff as uint32_t) as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_166;
            }
            C2Rust_Block_12::S_166 => {
                if _fa != 0 as uint32_t {
                    c2rust_current_block_12 = C2Rust_Block_12::S_309;
                } else {
                    c2rust_current_block_12 = C2Rust_Block_12::S_175;
                }
            }
            C2Rust_Block_12::S_175 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_12 = C2Rust_Block_12::S_309;
            }
            C2Rust_Block_12::S_183 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_12 = C2Rust_Block_12::S_189;
            }
            C2Rust_Block_12::S_189 => {
                _pv_5 = (*__gamepkg_tls_g_edx);
                c2rust_current_block_12 = C2Rust_Block_12::S_191;
            }
            C2Rust_Block_12::S_191 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_12 = C2Rust_Block_12::S_193;
            }
            C2Rust_Block_12::S_193 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_5,
                );
                c2rust_current_block_12 = C2Rust_Block_12::S_199;
            }
            C2Rust_Block_12::S_199 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_ebx)
                    .wrapping_add(0x5c as uint32_t);
                c2rust_current_block_12 = C2Rust_Block_12::S_205;
            }
            C2Rust_Block_12::S_205 => {
                _pv_6 = (*__gamepkg_tls_g_eax);
                c2rust_current_block_12 = C2Rust_Block_12::S_207;
            }
            C2Rust_Block_12::S_207 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_12 = C2Rust_Block_12::S_209;
            }
            C2Rust_Block_12::S_209 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_6,
                );
                c2rust_current_block_12 = C2Rust_Block_12::S_219;
            }
            C2Rust_Block_12::S_219 => {
                _pv_7 = 0x1f94dc as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_221;
            }
            C2Rust_Block_12::S_221 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_12 = C2Rust_Block_12::S_223;
            }
            C2Rust_Block_12::S_223 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_7,
                );
                c2rust_current_block_12 = C2Rust_Block_12::S_229;
            }
            C2Rust_Block_12::S_229 => {
                sub_002025B0();
                c2rust_current_block_12 = C2Rust_Block_12::S_293;
            }
            C2Rust_Block_12::S_241 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_12 = C2Rust_Block_12::S_247;
            }
            C2Rust_Block_12::S_247 => {
                _pv_8 = (*__gamepkg_tls_g_ecx);
                c2rust_current_block_12 = C2Rust_Block_12::S_249;
            }
            C2Rust_Block_12::S_249 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_12 = C2Rust_Block_12::S_251;
            }
            C2Rust_Block_12::S_251 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_8,
                );
                c2rust_current_block_12 = C2Rust_Block_12::S_257;
            }
            C2Rust_Block_12::S_257 => {
                (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_ebx)
                    .wrapping_add(0x5c as uint32_t);
                c2rust_current_block_12 = C2Rust_Block_12::S_263;
            }
            C2Rust_Block_12::S_263 => {
                _pv_9 = (*__gamepkg_tls_g_edx);
                c2rust_current_block_12 = C2Rust_Block_12::S_265;
            }
            C2Rust_Block_12::S_265 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_12 = C2Rust_Block_12::S_267;
            }
            C2Rust_Block_12::S_267 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_9,
                );
                c2rust_current_block_12 = C2Rust_Block_12::S_277;
            }
            C2Rust_Block_12::S_277 => {
                _pv_10 = 0x1f94ea as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_279;
            }
            C2Rust_Block_12::S_279 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_12 = C2Rust_Block_12::S_281;
            }
            C2Rust_Block_12::S_281 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_10,
                );
                c2rust_current_block_12 = C2Rust_Block_12::S_287;
            }
            C2Rust_Block_12::S_287 => {
                sub_00202610();
                c2rust_current_block_12 = C2Rust_Block_12::S_293;
            }
            C2Rust_Block_12::S_293 => {
                _fb = 8 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_295;
            }
            C2Rust_Block_12::S_295 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_297;
            }
            C2Rust_Block_12::S_297 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(8 as uint32_t);
                c2rust_current_block_12 = C2Rust_Block_12::S_299;
            }
            C2Rust_Block_12::S_299 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_301;
            }
            C2Rust_Block_12::S_301 => {
                _fas = _fa as int32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_303;
            }
            C2Rust_Block_12::S_303 => {
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_eax);
                c2rust_current_block_12 = C2Rust_Block_12::S_309;
            }
            C2Rust_Block_12::S_309 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ebx).wrapping_add(0x58 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_12 = C2Rust_Block_12::S_315;
            }
            C2Rust_Block_12::S_315 => {
                _pv_11 = 2 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_317;
            }
            C2Rust_Block_12::S_317 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_12 = C2Rust_Block_12::S_319;
            }
            C2Rust_Block_12::S_319 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_11,
                );
                c2rust_current_block_12 = C2Rust_Block_12::S_329;
            }
            C2Rust_Block_12::S_329 => {
                _pv_12 = (*__gamepkg_tls_g_eax);
                c2rust_current_block_12 = C2Rust_Block_12::S_331;
            }
            C2Rust_Block_12::S_331 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_12 = C2Rust_Block_12::S_333;
            }
            C2Rust_Block_12::S_333 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_12,
                );
                c2rust_current_block_12 = C2Rust_Block_12::S_343;
            }
            C2Rust_Block_12::S_343 => {
                _pv_13 = (*__gamepkg_tls_g_ebx);
                c2rust_current_block_12 = C2Rust_Block_12::S_345;
            }
            C2Rust_Block_12::S_345 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_12 = C2Rust_Block_12::S_347;
            }
            C2Rust_Block_12::S_347 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_13,
                );
                c2rust_current_block_12 = C2Rust_Block_12::S_357;
            }
            C2Rust_Block_12::S_357 => {
                _pv_14 = 0x1f94fb as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_359;
            }
            C2Rust_Block_12::S_359 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_12 = C2Rust_Block_12::S_361;
            }
            C2Rust_Block_12::S_361 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_14,
                );
                c2rust_current_block_12 = C2Rust_Block_12::S_367;
            }
            C2Rust_Block_12::S_367 => {
                sub_00202270();
                c2rust_current_block_12 = C2Rust_Block_12::S_373;
            }
            C2Rust_Block_12::S_373 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_eax);
                c2rust_current_block_12 = C2Rust_Block_12::S_375;
            }
            C2Rust_Block_12::S_375 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ecx).wrapping_add(0x10 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_12 = C2Rust_Block_12::S_377;
            }
            C2Rust_Block_12::S_377 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_edi);
                c2rust_current_block_12 = C2Rust_Block_12::S_379;
            }
            C2Rust_Block_12::S_379 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
                    << 5 as ::core::ffi::c_int;
                c2rust_current_block_12 = C2Rust_Block_12::S_381;
            }
            C2Rust_Block_12::S_381 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_383;
            }
            C2Rust_Block_12::S_383 => {
                _fas = _fa as int32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_385;
            }
            C2Rust_Block_12::S_385 => {
                _fb = 0xc as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_387;
            }
            C2Rust_Block_12::S_387 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_389;
            }
            C2Rust_Block_12::S_389 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(0xc as uint32_t);
                c2rust_current_block_12 = C2Rust_Block_12::S_391;
            }
            C2Rust_Block_12::S_391 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_393;
            }
            C2Rust_Block_12::S_393 => {
                _fas = _fa as int32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_395;
            }
            C2Rust_Block_12::S_395 => {
                _fb = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_397;
            }
            C2Rust_Block_12::S_397 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_399;
            }
            C2Rust_Block_12::S_399 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
                    .wrapping_add((*__gamepkg_tls_g_edx));
                c2rust_current_block_12 = C2Rust_Block_12::S_401;
            }
            C2Rust_Block_12::S_401 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_403;
            }
            C2Rust_Block_12::S_403 => {
                _fas = _fa as int32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_405;
            }
            C2Rust_Block_12::S_405 => {
                if _fa == 0 as uint32_t {
                    c2rust_current_block_12 = C2Rust_Block_12::S_741;
                } else {
                    c2rust_current_block_12 = C2Rust_Block_12::S_414;
                }
            }
            C2Rust_Block_12::S_414 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ecx).wrapping_add(0x14 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_12 = C2Rust_Block_12::S_416;
            }
            C2Rust_Block_12::S_416 => {
                _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_418;
            }
            C2Rust_Block_12::S_418 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_420;
            }
            C2Rust_Block_12::S_420 => {
                _fas = _fa as int32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_422;
            }
            C2Rust_Block_12::S_422 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_424;
            }
            C2Rust_Block_12::S_424 => {
                if _fa == _fb {
                    c2rust_current_block_12 = C2Rust_Block_12::S_741;
                } else {
                    c2rust_current_block_12 = C2Rust_Block_12::S_433;
                }
            }
            C2Rust_Block_12::S_433 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax).wrapping_add(0xc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_12 = C2Rust_Block_12::S_435;
            }
            C2Rust_Block_12::S_435 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edx) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_12 = C2Rust_Block_12::S_437;
            }
            C2Rust_Block_12::S_437 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_12 = C2Rust_Block_12::S_439;
            }
            C2Rust_Block_12::S_439 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ecx).wrapping_add(0x14 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_12 = C2Rust_Block_12::S_441;
            }
            C2Rust_Block_12::S_441 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_edi),
                );
                c2rust_current_block_12 = C2Rust_Block_12::S_443;
            }
            C2Rust_Block_12::S_443 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x10 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_edx),
                );
                c2rust_current_block_12 = C2Rust_Block_12::S_445;
            }
            C2Rust_Block_12::S_445 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    3 as uint32_t,
                );
                c2rust_current_block_12 = C2Rust_Block_12::S_447;
            }
            C2Rust_Block_12::S_447 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ecx).wrapping_add(0x18 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_12 = C2Rust_Block_12::S_449;
            }
            C2Rust_Block_12::S_449 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax).wrapping_add(0x14 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_12 = C2Rust_Block_12::S_451;
            }
            C2Rust_Block_12::S_451 => {
                _fa = (::core::ptr::read_volatile::<
                    uint8_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint8_t,
                    >(
                        ((*__gamepkg_tls_g_eax).wrapping_add(0x18 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) as ::core::ffi::c_int & 4 as ::core::ffi::c_int) as uint32_t
                    & 0xff as uint32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_453;
            }
            C2Rust_Block_12::S_453 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_455;
            }
            C2Rust_Block_12::S_455 => {
                _fas = _fa as int8_t as int32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_457;
            }
            C2Rust_Block_12::S_457 => {
                _fbs = _fb as int8_t as int32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_459;
            }
            C2Rust_Block_12::S_459 => {
                (*__gamepkg_tls_g_edi) = 1 as uint32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_461;
            }
            C2Rust_Block_12::S_461 => {
                if _fa != _fb {
                    c2rust_current_block_12 = C2Rust_Block_12::S_476;
                } else {
                    c2rust_current_block_12 = C2Rust_Block_12::S_470;
                }
            }
            C2Rust_Block_12::S_470 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint8_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint8_t,
                    >(
                        ((*__gamepkg_tls_g_eax).wrapping_add(0xd as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) as uint32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_476;
            }
            C2Rust_Block_12::S_476 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ecx).wrapping_add(0x18 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_12 = C2Rust_Block_12::S_478;
            }
            C2Rust_Block_12::S_478 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edx).wrapping_add(0xc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_12 = C2Rust_Block_12::S_480;
            }
            C2Rust_Block_12::S_480 => {
                (*__gamepkg_tls_g_eax) = ((*__gamepkg_tls_g_eax) as int32_t
                    * ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esi).wrapping_add(8 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ) as int32_t) as uint32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_482;
            }
            C2Rust_Block_12::S_482 => {
                (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
                    uint16_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint16_t,
                    >(
                        ((*__gamepkg_tls_g_edx).wrapping_add(0x1a as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) as uint32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_484;
            }
            C2Rust_Block_12::S_484 => {
                (*__gamepkg_tls_g_edx) = 0 as uint32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_486;
            }
            C2Rust_Block_12::S_486 => {
                _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_488;
            }
            C2Rust_Block_12::S_488 => {
                _fas = _fa as int32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_491;
            }
            C2Rust_Block_12::S_491 => {
                _dividend = ((*__gamepkg_tls_g_edx) as uint64_t)
                    << 32 as ::core::ffi::c_int | (*__gamepkg_tls_g_eax) as uint64_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_493;
            }
            C2Rust_Block_12::S_493 => {
                (*__gamepkg_tls_g_eax) = _dividend
                    .wrapping_div((*__gamepkg_tls_g_ebx) as uint64_t) as uint32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_495;
            }
            C2Rust_Block_12::S_495 => {
                (*__gamepkg_tls_g_edx) = _dividend
                    .wrapping_rem((*__gamepkg_tls_g_ebx) as uint64_t) as uint32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_499;
            }
            C2Rust_Block_12::S_499 => {
                (*__gamepkg_tls_g_edx) = 0 as uint32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_501;
            }
            C2Rust_Block_12::S_501 => {
                _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_503;
            }
            C2Rust_Block_12::S_503 => {
                _fas = _fa as int32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_506;
            }
            C2Rust_Block_12::S_506 => {
                _dividend_0 = ((*__gamepkg_tls_g_edx) as uint64_t)
                    << 32 as ::core::ffi::c_int | (*__gamepkg_tls_g_eax) as uint64_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_508;
            }
            C2Rust_Block_12::S_508 => {
                (*__gamepkg_tls_g_eax) = _dividend_0
                    .wrapping_div((*__gamepkg_tls_g_edi) as uint64_t) as uint32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_510;
            }
            C2Rust_Block_12::S_510 => {
                (*__gamepkg_tls_g_edx) = _dividend_0
                    .wrapping_rem((*__gamepkg_tls_g_edi) as uint64_t) as uint32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_514;
            }
            C2Rust_Block_12::S_514 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0xc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_12 = C2Rust_Block_12::S_516;
            }
            C2Rust_Block_12::S_516 => {
                (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_edx).wrapping_sub(1);
                c2rust_current_block_12 = C2Rust_Block_12::S_518;
            }
            C2Rust_Block_12::S_518 => {
                _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_520;
            }
            C2Rust_Block_12::S_520 => {
                _fas = _fa as int32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_522;
            }
            C2Rust_Block_12::S_522 => {
                _fb = (_fa == 0x7fffffff as uint32_t) as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_524;
            }
            C2Rust_Block_12::S_524 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_12 = C2Rust_Block_12::S_526;
            }
            C2Rust_Block_12::S_526 => {
                if _fa != 0 as uint32_t {
                    c2rust_current_block_12 = C2Rust_Block_12::S_629;
                } else {
                    c2rust_current_block_12 = C2Rust_Block_12::S_535;
                }
            }
            C2Rust_Block_12::S_535 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_537;
            }
            C2Rust_Block_12::S_537 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_539;
            }
            C2Rust_Block_12::S_539 => {
                _fas = _fa as int32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_541;
            }
            C2Rust_Block_12::S_541 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_543;
            }
            C2Rust_Block_12::S_543 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x10 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_12 = C2Rust_Block_12::S_549;
            }
            C2Rust_Block_12::S_549 => {
                _fp_value = ::core::ptr::read_volatile::<
                    int32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        int32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x10 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) as ::core::ffi::c_double;
                c2rust_current_block_12 = C2Rust_Block_12::S_551;
            }
            C2Rust_Block_12::S_551 => {
                (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top)
                    as ::core::ffi::c_uint)
                    .wrapping_add(7 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
                    as ::core::ffi::c_int;
                c2rust_current_block_12 = C2Rust_Block_12::S_553;
            }
            C2Rust_Block_12::S_553 => {
                (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = _fp_value;
                c2rust_current_block_12 = C2Rust_Block_12::S_559;
            }
            C2Rust_Block_12::S_559 => {
                if if if ::core::mem::size_of::<int32_t>()
                    < ::core::mem::size_of::<int32_t>()
                {
                    ::core::mem::size_of::<int32_t>()
                } else {
                    ::core::mem::size_of::<int32_t>()
                } == 1usize
                {
                    _fas as uint32_t as uint8_t as int8_t as int32_t
                } else if if ::core::mem::size_of::<int32_t>()
                    < ::core::mem::size_of::<int32_t>()
                {
                    ::core::mem::size_of::<int32_t>()
                } else {
                    ::core::mem::size_of::<int32_t>()
                } == 2usize
                {
                    _fas as uint32_t as uint16_t as int16_t as int32_t
                } else {
                    _fas as uint32_t as int32_t
                }
                    >= if if ::core::mem::size_of::<int32_t>()
                        < ::core::mem::size_of::<int32_t>()
                    {
                        ::core::mem::size_of::<int32_t>()
                    } else {
                        ::core::mem::size_of::<int32_t>()
                    } == 1usize
                    {
                        _fbs as uint32_t as uint8_t as int8_t as int32_t
                    } else if if ::core::mem::size_of::<int32_t>()
                        < ::core::mem::size_of::<int32_t>()
                    {
                        ::core::mem::size_of::<int32_t>()
                    } else {
                        ::core::mem::size_of::<int32_t>()
                    } == 2usize
                    {
                        _fbs as uint32_t as uint16_t as int16_t as int32_t
                    } else {
                        _fbs as uint32_t as int32_t
                    }
                {
                    c2rust_current_block_12 = C2Rust_Block_12::S_574;
                } else {
                    c2rust_current_block_12 = C2Rust_Block_12::S_568;
                }
            }
            C2Rust_Block_12::S_568 => {
                (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = if (*__gamepkg_tls_g_fp_control_word)
                    as ::core::ffi::c_uint & 0x300 as ::core::ffi::c_uint != 0
                {
                    (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                        + ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b16a8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ) as ::core::ffi::c_double
                } else {
                    recomp_fp_round24(
                        (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                            + ::core::ptr::read_volatile::<
                                ::core::ffi::c_float,
                            >(
                                ::core::ptr::with_exposed_provenance_mut::<
                                    ::core::ffi::c_float,
                                >(
                                    (0x3b16a8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                                ),
                            ) as ::core::ffi::c_double,
                    )
                };
                c2rust_current_block_12 = C2Rust_Block_12::S_574;
            }
            C2Rust_Block_12::S_574 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ecx).wrapping_add(0x18 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_12 = C2Rust_Block_12::S_576;
            }
            C2Rust_Block_12::S_576 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ecx).wrapping_add(0x14 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_12 = C2Rust_Block_12::S_578;
            }
            C2Rust_Block_12::S_578 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edx) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_12 = C2Rust_Block_12::S_584;
            }
            C2Rust_Block_12::S_584 => {
                _fp_value_0 = ::core::ptr::read_volatile::<
                    int32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        int32_t,
                    >(
                        ((*__gamepkg_tls_g_edx) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) as ::core::ffi::c_double;
                c2rust_current_block_12 = C2Rust_Block_12::S_586;
            }
            C2Rust_Block_12::S_586 => {
                (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top)
                    as ::core::ffi::c_uint)
                    .wrapping_add(7 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
                    as ::core::ffi::c_int;
                c2rust_current_block_12 = C2Rust_Block_12::S_588;
            }
            C2Rust_Block_12::S_588 => {
                (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = _fp_value_0;
                c2rust_current_block_12 = C2Rust_Block_12::S_594;
            }
            C2Rust_Block_12::S_594 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_596;
            }
            C2Rust_Block_12::S_596 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_598;
            }
            C2Rust_Block_12::S_598 => {
                _fas = _fa as int32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_600;
            }
            C2Rust_Block_12::S_600 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_602;
            }
            C2Rust_Block_12::S_602 => {
                if if if ::core::mem::size_of::<int32_t>()
                    < ::core::mem::size_of::<int32_t>()
                {
                    ::core::mem::size_of::<int32_t>()
                } else {
                    ::core::mem::size_of::<int32_t>()
                } == 1usize
                {
                    _fas as uint32_t as uint8_t as int8_t as int32_t
                } else if if ::core::mem::size_of::<int32_t>()
                    < ::core::mem::size_of::<int32_t>()
                {
                    ::core::mem::size_of::<int32_t>()
                } else {
                    ::core::mem::size_of::<int32_t>()
                } == 2usize
                {
                    _fas as uint32_t as uint16_t as int16_t as int32_t
                } else {
                    _fas as uint32_t as int32_t
                }
                    >= if if ::core::mem::size_of::<int32_t>()
                        < ::core::mem::size_of::<int32_t>()
                    {
                        ::core::mem::size_of::<int32_t>()
                    } else {
                        ::core::mem::size_of::<int32_t>()
                    } == 1usize
                    {
                        _fbs as uint32_t as uint8_t as int8_t as int32_t
                    } else if if ::core::mem::size_of::<int32_t>()
                        < ::core::mem::size_of::<int32_t>()
                    {
                        ::core::mem::size_of::<int32_t>()
                    } else {
                        ::core::mem::size_of::<int32_t>()
                    } == 2usize
                    {
                        _fbs as uint32_t as uint16_t as int16_t as int32_t
                    } else {
                        _fbs as uint32_t as int32_t
                    }
                {
                    c2rust_current_block_12 = C2Rust_Block_12::S_617;
                } else {
                    c2rust_current_block_12 = C2Rust_Block_12::S_611;
                }
            }
            C2Rust_Block_12::S_611 => {
                (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize] = if (*__gamepkg_tls_g_fp_control_word)
                    as ::core::ffi::c_uint & 0x300 as ::core::ffi::c_uint != 0
                {
                    (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                        + ::core::ptr::read_volatile::<
                            ::core::ffi::c_float,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                ::core::ffi::c_float,
                            >(
                                (0x3b16a8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ) as ::core::ffi::c_double
                } else {
                    recomp_fp_round24(
                        (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                            + ::core::ptr::read_volatile::<
                                ::core::ffi::c_float,
                            >(
                                ::core::ptr::with_exposed_provenance_mut::<
                                    ::core::ffi::c_float,
                                >(
                                    (0x3b16a8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                                ),
                            ) as ::core::ffi::c_double,
                    )
                };
                c2rust_current_block_12 = C2Rust_Block_12::S_617;
            }
            C2Rust_Block_12::S_617 => {
                (*__gamepkg_tls_g_fp_stack)[(((*__gamepkg_tls_g_fp_top)
                    + 1 as ::core::ffi::c_int) as ::core::ffi::c_uint
                    & 7 as ::core::ffi::c_uint) as usize] = if (*__gamepkg_tls_g_fp_control_word)
                    as ::core::ffi::c_uint & 0x300 as ::core::ffi::c_uint != 0
                {
                    (*__gamepkg_tls_g_fp_stack)[(((*__gamepkg_tls_g_fp_top)
                        + 1 as ::core::ffi::c_int) as ::core::ffi::c_uint
                        & 7 as ::core::ffi::c_uint) as usize]
                        / (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                } else {
                    recomp_fp_round24(
                        (*__gamepkg_tls_g_fp_stack)[(((*__gamepkg_tls_g_fp_top)
                            + 1 as ::core::ffi::c_int) as ::core::ffi::c_uint
                            & 7 as ::core::ffi::c_uint) as usize]
                            / (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top)
                                as usize],
                    )
                };
                c2rust_current_block_12 = C2Rust_Block_12::S_619;
            }
            C2Rust_Block_12::S_619 => {
                (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top)
                    as ::core::ffi::c_uint)
                    .wrapping_add(1 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
                    as ::core::ffi::c_int;
                c2rust_current_block_12 = C2Rust_Block_12::S_621;
            }
            C2Rust_Block_12::S_621 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        ::core::ffi::c_float,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_fp_stack)[(*__gamepkg_tls_g_fp_top) as usize]
                        as ::core::ffi::c_float,
                );
                c2rust_current_block_12 = C2Rust_Block_12::S_623;
            }
            C2Rust_Block_12::S_623 => {
                (*__gamepkg_tls_g_fp_top) = (((*__gamepkg_tls_g_fp_top)
                    as ::core::ffi::c_uint)
                    .wrapping_add(1 as ::core::ffi::c_uint) & 7 as ::core::ffi::c_uint)
                    as ::core::ffi::c_int;
                c2rust_current_block_12 = C2Rust_Block_12::S_629;
            }
            C2Rust_Block_12::S_629 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x76411c as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_12 = C2Rust_Block_12::S_635;
            }
            C2Rust_Block_12::S_635 => {
                _pv_15 = 0 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_637;
            }
            C2Rust_Block_12::S_637 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_12 = C2Rust_Block_12::S_639;
            }
            C2Rust_Block_12::S_639 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_15,
                );
                c2rust_current_block_12 = C2Rust_Block_12::S_649;
            }
            C2Rust_Block_12::S_649 => {
                _pv_16 = 1 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_651;
            }
            C2Rust_Block_12::S_651 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_12 = C2Rust_Block_12::S_653;
            }
            C2Rust_Block_12::S_653 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_16,
                );
                c2rust_current_block_12 = C2Rust_Block_12::S_663;
            }
            C2Rust_Block_12::S_663 => {
                _pv_17 = (*__gamepkg_tls_g_ecx);
                c2rust_current_block_12 = C2Rust_Block_12::S_665;
            }
            C2Rust_Block_12::S_665 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_12 = C2Rust_Block_12::S_667;
            }
            C2Rust_Block_12::S_667 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_17,
                );
                c2rust_current_block_12 = C2Rust_Block_12::S_677;
            }
            C2Rust_Block_12::S_677 => {
                _pv_18 = 0x1f95a1 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_679;
            }
            C2Rust_Block_12::S_679 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_12 = C2Rust_Block_12::S_681;
            }
            C2Rust_Block_12::S_681 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_18,
                );
                c2rust_current_block_12 = C2Rust_Block_12::S_687;
            }
            C2Rust_Block_12::S_687 => {
                sub_001D154C();
                c2rust_current_block_12 = C2Rust_Block_12::S_697;
            }
            C2Rust_Block_12::S_697 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_12 = C2Rust_Block_12::S_699;
            }
            C2Rust_Block_12::S_699 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_12 = C2Rust_Block_12::S_709;
            }
            C2Rust_Block_12::S_709 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_12 = C2Rust_Block_12::S_711;
            }
            C2Rust_Block_12::S_711 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_12 = C2Rust_Block_12::S_721;
            }
            C2Rust_Block_12::S_721 => {
                (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_12 = C2Rust_Block_12::S_723;
            }
            C2Rust_Block_12::S_723 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_12 = C2Rust_Block_12::S_729;
            }
            C2Rust_Block_12::S_729 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_12 = C2Rust_Block_12::S_731;
            }
            C2Rust_Block_12::S_731 => return,
            C2Rust_Block_12::S_741 => {
                _pv_19 = 0 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_743;
            }
            C2Rust_Block_12::S_743 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_12 = C2Rust_Block_12::S_745;
            }
            C2Rust_Block_12::S_745 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_19,
                );
                c2rust_current_block_12 = C2Rust_Block_12::S_751;
            }
            C2Rust_Block_12::S_751 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    0 as uint32_t,
                );
                c2rust_current_block_12 = C2Rust_Block_12::S_753;
            }
            C2Rust_Block_12::S_753 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0xc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    0 as uint32_t,
                );
                c2rust_current_block_12 = C2Rust_Block_12::S_755;
            }
            C2Rust_Block_12::S_755 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x10 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    0 as uint32_t,
                );
                c2rust_current_block_12 = C2Rust_Block_12::S_757;
            }
            C2Rust_Block_12::S_757 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x76411c as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_12 = C2Rust_Block_12::S_763;
            }
            C2Rust_Block_12::S_763 => {
                _pv_20 = 1 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_765;
            }
            C2Rust_Block_12::S_765 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_12 = C2Rust_Block_12::S_767;
            }
            C2Rust_Block_12::S_767 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_20,
                );
                c2rust_current_block_12 = C2Rust_Block_12::S_777;
            }
            C2Rust_Block_12::S_777 => {
                _pv_21 = (*__gamepkg_tls_g_edx);
                c2rust_current_block_12 = C2Rust_Block_12::S_779;
            }
            C2Rust_Block_12::S_779 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_12 = C2Rust_Block_12::S_781;
            }
            C2Rust_Block_12::S_781 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_21,
                );
                c2rust_current_block_12 = C2Rust_Block_12::S_791;
            }
            C2Rust_Block_12::S_791 => {
                _pv_22 = 0x1f95ca as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_12 = C2Rust_Block_12::S_793;
            }
            C2Rust_Block_12::S_793 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_12 = C2Rust_Block_12::S_795;
            }
            C2Rust_Block_12::S_795 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_22,
                );
                c2rust_current_block_12 = C2Rust_Block_12::S_801;
            }
            C2Rust_Block_12::S_801 => {
                sub_001D154C();
                c2rust_current_block_12 = C2Rust_Block_12::S_811;
            }
            C2Rust_Block_12::S_811 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_12 = C2Rust_Block_12::S_813;
            }
            C2Rust_Block_12::S_813 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_12 = C2Rust_Block_12::S_823;
            }
            C2Rust_Block_12::S_823 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_12 = C2Rust_Block_12::S_825;
            }
            C2Rust_Block_12::S_825 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_12 = C2Rust_Block_12::S_835;
            }
            C2Rust_Block_12::S_835 => {
                (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_12 = C2Rust_Block_12::S_837;
            }
            C2Rust_Block_12::S_837 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_12 = C2Rust_Block_12::S_843;
            }
            C2Rust_Block_12::S_843 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_12 = C2Rust_Block_12::S_845;
            }
            C2Rust_Block_12::S_845 => return,
        }
    };
}
#[no_mangle]
pub unsafe extern "C" fn sub_001F95D0() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (0x76411c as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    let mut _pv_0: uint32_t = 0xffffffff as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    let mut _pv_1: uint32_t = (*__gamepkg_tls_g_eax);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    let mut _pv_2: uint32_t = 0x1f95de as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_2,
    );
    sub_001D1608();
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ecx).wrapping_add(0x100 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0x58 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv_3: uint32_t = 2 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_3,
    );
    let mut _pv_4: uint32_t = (*__gamepkg_tls_g_edx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_4,
    );
    let mut _pv_5: uint32_t = (*__gamepkg_tls_g_eax);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_5,
    );
    let mut _pv_6: uint32_t = 0x1f95f4 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_6,
    );
    sub_00202270();
    (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0x18 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0x14 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_edx).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    _fb = 0xc as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t);
    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
    _fb = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    's_393: {
        if _fa >= _fb {
            break 's_393;
        }
        (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_eax).wrapping_add(0x18 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx)
            .wrapping_add((*__gamepkg_tls_g_ecx).wrapping_mul(4 as uint32_t));
        (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
            .wrapping_add((*__gamepkg_tls_g_ecx).wrapping_mul(8 as uint32_t));
        _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
        _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fbs = _fb as int32_t;
        if _fa == _fb {
            break 's_393;
        }
        (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_eax).wrapping_add(0x14 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        _fa = (::core::ptr::read_volatile::<
            uint8_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint8_t,
            >(
                ((*__gamepkg_tls_g_eax).wrapping_add(0x18 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ) as ::core::ffi::c_int & 4 as ::core::ffi::c_int) as uint32_t
            & 0xff as uint32_t;
        _fb = 0 as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
        _fas = _fa as int8_t as int32_t;
        _fbs = _fb as int8_t as int32_t;
        's_313: {
            if _fa == _fb {
                break 's_313;
            }
            (*__gamepkg_tls_g_eax) = 1 as uint32_t;
            let mut _pv_7: uint32_t = 0 as ::core::ffi::c_int as uint32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_7,
            );
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_edx).wrapping_add(0xc as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                (*__gamepkg_tls_g_eax),
            );
            (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    (0x76411c as ::core::ffi::c_int as uint32_t as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            let mut _pv_8: uint32_t = (*__gamepkg_tls_g_eax);
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_8,
            );
            let mut _pv_9: uint32_t = (*__gamepkg_tls_g_ecx);
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_9,
            );
            let mut _pv_10: uint32_t = 0x1f9633 as ::core::ffi::c_uint as uint32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_10,
            );
            sub_001D154C();
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
            return;
        }
        (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
            uint8_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint8_t,
            >(
                ((*__gamepkg_tls_g_eax).wrapping_add(0xd as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ) as uint32_t;
        let mut _pv_11: uint32_t = 0 as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_11,
        );
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_edx).wrapping_add(0xc as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            (*__gamepkg_tls_g_eax),
        );
        (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                (0x76411c as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        let mut _pv_12: uint32_t = 1 as ::core::ffi::c_int as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_12,
        );
        let mut _pv_13: uint32_t = (*__gamepkg_tls_g_ecx);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_13,
        );
        let mut _pv_14: uint32_t = 0x1f964b as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_14,
        );
        sub_001D154C();
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        return;
    }
    let mut _pv_15: uint32_t = 0 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_15,
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_edx).wrapping_add(0xc as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        0 as uint32_t,
    );
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (0x76411c as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv_16: uint32_t = 1 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_16,
    );
    let mut _pv_17: uint32_t = (*__gamepkg_tls_g_ecx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_17,
    );
    let mut _pv_18: uint32_t = 0x1f9663 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_18,
    );
    sub_001D154C();
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001F9670() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv: uint32_t = (*__gamepkg_tls_g_eax);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_eax).wrapping_add(0x154 as uint32_t);
    let mut _pv_0: uint32_t = (*__gamepkg_tls_g_ecx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    _fb = 0xec as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax).wrapping_add(0xec as uint32_t);
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    let mut _pv_1: uint32_t = (*__gamepkg_tls_g_eax);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    let mut _pv_2: uint32_t = 0x1f968b as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_2,
    );
    sub_00200CD0();
    _fb = 0xc as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t);
    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001F9690() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv_0: uint32_t = (*__gamepkg_tls_g_eax);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    let mut _pv_1: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    let mut _pv_2: uint32_t = 0x1f96a0 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_2,
    );
    sub_001F9170();
    _fb = 8 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t);
    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001F96B0() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv_0: uint32_t = (*__gamepkg_tls_g_eax);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    let mut _pv_1: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    let mut _pv_2: uint32_t = 0x1f96c0 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_2,
    );
    sub_001F9220();
    _fb = 8 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t);
    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001F96D0() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (0x76411c as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv_0: uint32_t = 0xffffffff as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    let mut _pv_1: uint32_t = (*__gamepkg_tls_g_ecx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    let mut _pv_2: uint32_t = 0x1f96e5 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_2,
    );
    sub_001D1608();
    let mut _pv_3: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_3,
    );
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_esi).wrapping_add(0x15c as uint32_t);
    let mut _pv_4: uint32_t = (*__gamepkg_tls_g_edx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_4,
    );
    let mut _pv_5: uint32_t = 0x1f96f6 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_5,
    );
    sub_00201F80();
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (0x76411c as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    _fb = 8 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t);
    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    let mut _pv_6: uint32_t = 0 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_6,
    );
    let mut _pv_7: uint32_t = 1 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_7,
    );
    let mut _pv_8: uint32_t = (*__gamepkg_tls_g_eax);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_8,
    );
    let mut _pv_9: uint32_t = 0x1f9708 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_9,
    );
    sub_001D154C();
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001F9710() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv_0: uint32_t = (*__gamepkg_tls_g_eax);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    let mut _pv_1: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    let mut _pv_2: uint32_t = 0x1f9720 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_2,
    );
    sub_001F9350();
    _fb = 8 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t);
    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001F9730() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (0x76411c as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv_0: uint32_t = 0xffffffff as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    let mut _pv_1: uint32_t = (*__gamepkg_tls_g_ecx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    let mut _pv_2: uint32_t = 0x1f9745 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_2,
    );
    sub_001D1608();
    let mut _pv_3: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_3,
    );
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_esi).wrapping_add(0x15c as uint32_t);
    let mut _pv_4: uint32_t = (*__gamepkg_tls_g_edx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_4,
    );
    let mut _pv_5: uint32_t = 0x1f9756 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_5,
    );
    sub_00201F90();
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (0x76411c as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    _fb = 8 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t);
    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    let mut _pv_6: uint32_t = 0 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_6,
    );
    let mut _pv_7: uint32_t = 1 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_7,
    );
    let mut _pv_8: uint32_t = (*__gamepkg_tls_g_eax);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_8,
    );
    let mut _pv_9: uint32_t = 0x1f9768 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_9,
    );
    sub_001D154C();
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001F9770() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0x234 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_edx) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_ecx),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001F9790() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0x238 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_edx) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_ecx),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001F97B0() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0x23c as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_edx) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_ecx),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001F97D0() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (0x76411c as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    let mut _pv_0: uint32_t = 0xffffffff as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    let mut _pv_1: uint32_t = (*__gamepkg_tls_g_eax);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    let mut _pv_2: uint32_t = 0x1f97de as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_2,
    );
    sub_001D1608();
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0x10 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv_3: uint32_t = (*__gamepkg_tls_g_ecx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_3,
    );
    let mut _pv_4: uint32_t = (*__gamepkg_tls_g_edx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_4,
    );
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_esi).wrapping_add(0x154 as uint32_t);
    let mut _pv_5: uint32_t = (*__gamepkg_tls_g_eax);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_5,
    );
    (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_esi).wrapping_add(0x15c as uint32_t);
    let mut _pv_6: uint32_t = (*__gamepkg_tls_g_ecx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_6,
    );
    let mut _pv_7: uint32_t = 0x1f9800 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_7,
    );
    sub_00201F20();
    (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (0x76411c as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    _fb = 0x10 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(0x10 as uint32_t);
    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    let mut _pv_8: uint32_t = 0 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_8,
    );
    let mut _pv_9: uint32_t = 1 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_9,
    );
    let mut _pv_10: uint32_t = (*__gamepkg_tls_g_edx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_10,
    );
    let mut _pv_11: uint32_t = 0x1f9813 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_11,
    );
    sub_001D154C();
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001F9820() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ecx) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax)
                .wrapping_add((*__gamepkg_tls_g_edx).wrapping_mul(4 as uint32_t))
                .wrapping_add(0x174 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ecx).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_edx),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001F9840() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (0x76411c as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    let mut _pv_0: uint32_t = 0xffffffff as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    let mut _pv_1: uint32_t = (*__gamepkg_tls_g_edx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0x18 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_ecx),
    );
    let mut _pv_2: uint32_t = 0x1f9859 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_2,
    );
    sub_001D1608();
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0x10 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_esi).wrapping_add(0x154 as uint32_t);
    let mut _pv_3: uint32_t = (*__gamepkg_tls_g_eax);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_3,
    );
    let mut _pv_4: uint32_t = (*__gamepkg_tls_g_ecx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_4,
    );
    (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_esi).wrapping_add(0x15c as uint32_t);
    let mut _pv_5: uint32_t = (*__gamepkg_tls_g_edx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_5,
    );
    let mut _pv_6: uint32_t = 0x1f9875 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_6,
    );
    sub_00201F00();
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (0x76411c as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    _fb = 0xc as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t);
    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    let mut _pv_7: uint32_t = 0 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_7,
    );
    let mut _pv_8: uint32_t = 1 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_8,
    );
    let mut _pv_9: uint32_t = (*__gamepkg_tls_g_eax);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_9,
    );
    let mut _pv_10: uint32_t = 0x1f9887 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_10,
    );
    sub_001D154C();
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001F9890() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0x120 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_edx) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_ecx),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001F98B0() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (0x76411c as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    let mut _pv_0: uint32_t = (*__gamepkg_tls_g_edi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    let mut _pv_1: uint32_t = 0xffffffff as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    let mut _pv_2: uint32_t = (*__gamepkg_tls_g_eax);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_2,
    );
    let mut _pv_3: uint32_t = 0x1f98bf as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_3,
    );
    sub_001D1608();
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x100 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0x58 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv_4: uint32_t = 2 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_4,
    );
    let mut _pv_5: uint32_t = (*__gamepkg_tls_g_ecx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_5,
    );
    let mut _pv_6: uint32_t = (*__gamepkg_tls_g_eax);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_6,
    );
    let mut _pv_7: uint32_t = 0x1f98d5 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_7,
    );
    sub_00202270();
    (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (0x76411c as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0xc as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    _fb = 0xc as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t);
    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    let mut _pv_8: uint32_t = 0 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_8,
    );
    let mut _pv_9: uint32_t = 1 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_9,
    );
    let mut _pv_10: uint32_t = (*__gamepkg_tls_g_edx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_10,
    );
    let mut _pv_11: uint32_t = 0x1f98eb as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_11,
    );
    sub_001D154C();
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0x14 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_edi),
    );
    (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001F9900() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv_0: uint32_t = (*__gamepkg_tls_g_eax);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    let mut _pv_1: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    let mut _pv_2: uint32_t = 0x1f9910 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_2,
    );
    sub_001F94A0();
    _fb = 8 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t);
    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001F9920() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv_0: uint32_t = (*__gamepkg_tls_g_eax);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    let mut _pv_1: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    let mut _pv_2: uint32_t = 0x1f9930 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_2,
    );
    sub_001F95D0();
    _fb = 8 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t);
    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001F9940() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv_0: uint32_t = (*__gamepkg_tls_g_eax);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_esi).wrapping_add(0x154 as uint32_t);
    let mut _pv_1: uint32_t = (*__gamepkg_tls_g_ecx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_esi).wrapping_add(0xec as uint32_t);
    let mut _pv_2: uint32_t = (*__gamepkg_tls_g_edx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_2,
    );
    let mut _pv_3: uint32_t = 0x1f995d as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_3,
    );
    sub_00200CD0();
    _fb = 0xc as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t);
    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001F9970() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0;
    let mut _fa: uint32_t = 0;
    let mut _fb: uint32_t = 0;
    let mut _fas: int32_t = 0;
    let mut _fbs: int32_t = 0;
    let mut _pv: uint32_t = 0;
    let mut _pv_0: uint32_t = 0;
    let mut _pv_1: uint32_t = 0;
    let mut _pv_2: uint32_t = 0;
    let mut _pv_3: uint32_t = 0;
    let mut _pv_4: uint32_t = 0;
    let mut _pv_5: uint32_t = 0;
    let mut _pv_6: uint32_t = 0;
    let mut _pv_7: uint32_t = 0;
    let mut _pv_8: uint32_t = 0;
    let mut _pv_9: uint32_t = 0;
    let mut _pv_10: uint32_t = 0;
    let mut _pv_11: uint32_t = 0;
    let mut _pv_12: uint32_t = 0;
    let mut _pv_13: uint32_t = 0;
    let mut _pv_14: uint32_t = 0;
    let mut _pv_15: uint32_t = 0;
    let mut _pv_16: uint32_t = 0;
    let mut _pv_17: uint32_t = 0;
    let mut _pv_18: uint32_t = 0;
    let mut _pv_19: uint32_t = 0;
    let mut _pv_20: uint32_t = 0;
    let mut _pv_21: uint32_t = 0;
    let mut _pv_22: uint32_t = 0;
    let mut _pv_23: uint32_t = 0;
    let mut _pv_24: uint32_t = 0;
    let mut _pv_25: uint32_t = 0;
    let mut _pv_26: uint32_t = 0;
    let mut _pv_27: uint32_t = 0;
    let mut _pv_28: uint32_t = 0;
    let mut _pv_29: uint32_t = 0;
    let mut _pv_30: uint32_t = 0;
    let mut _pv_31: uint32_t = 0;
    let mut _pv_32: uint32_t = 0;
    let mut _pv_33: uint32_t = 0;
    let mut _pv_34: uint32_t = 0;
    let mut _pv_35: uint32_t = 0;
    let mut _pv_36: uint32_t = 0;
    let mut _pv_37: uint32_t = 0;
    let mut _pv_38: uint32_t = 0;
    enum C2Rust_Block_31 {
        S_0,
        S_2,
        S_4,
        S_22,
        S_24,
        S_26,
        S_36,
        S_38,
        S_40,
        S_50,
        S_52,
        S_54,
        S_64,
        S_66,
        S_68,
        S_78,
        S_80,
        S_82,
        S_88,
        S_98,
        S_100,
        S_102,
        S_108,
        S_114,
        S_116,
        S_118,
        S_124,
        S_130,
        S_132,
        S_134,
        S_136,
        S_138,
        S_140,
        S_142,
        S_144,
        S_146,
        S_148,
        S_150,
        S_152,
        S_154,
        S_156,
        S_158,
        S_171,
        S_173,
        S_175,
        S_185,
        S_187,
        S_189,
        S_195,
        S_201,
        S_203,
        S_205,
        S_207,
        S_209,
        S_211,
        S_213,
        S_215,
        S_217,
        S_219,
        S_221,
        S_229,
        S_235,
        S_237,
        S_239,
        S_241,
        S_247,
        S_249,
        S_251,
        S_257,
        S_270,
        S_272,
        S_274,
        S_280,
        S_286,
        S_288,
        S_290,
        S_292,
        S_294,
        S_296,
        S_298,
        S_300,
        S_302,
        S_304,
        S_306,
        S_308,
        S_310,
        S_312,
        S_314,
        S_327,
        S_329,
        S_331,
        S_341,
        S_343,
        S_345,
        S_351,
        S_357,
        S_359,
        S_361,
        S_363,
        S_365,
        S_367,
        S_369,
        S_371,
        S_373,
        S_375,
        S_377,
        S_379,
        S_387,
        S_393,
        S_395,
        S_397,
        S_399,
        S_405,
        S_407,
        S_409,
        S_415,
        S_417,
        S_419,
        S_421,
        S_423,
        S_436,
        S_438,
        S_440,
        S_446,
        S_452,
        S_454,
        S_456,
        S_458,
        S_460,
        S_462,
        S_464,
        S_466,
        S_468,
        S_470,
        S_472,
        S_474,
        S_476,
        S_478,
        S_480,
        S_493,
        S_495,
        S_497,
        S_507,
        S_509,
        S_511,
        S_517,
        S_523,
        S_525,
        S_527,
        S_529,
        S_531,
        S_533,
        S_535,
        S_537,
        S_539,
        S_541,
        S_543,
        S_545,
        S_547,
        S_549,
        S_551,
        S_553,
        S_555,
        S_557,
        S_559,
        S_561,
        S_563,
        S_565,
        S_567,
        S_569,
        S_571,
        S_579,
        S_581,
        S_583,
        S_585,
        S_587,
        S_589,
        S_591,
        S_593,
        S_595,
        S_597,
        S_599,
        S_601,
        S_603,
        S_605,
        S_607,
        S_619,
        S_621,
        S_623,
        S_629,
        S_635,
        S_637,
        S_639,
        S_641,
        S_643,
        S_645,
        S_647,
        S_649,
        S_651,
        S_653,
        S_655,
        S_657,
        S_659,
        S_661,
        S_663,
        S_676,
        S_678,
        S_680,
        S_690,
        S_692,
        S_694,
        S_700,
        S_706,
        S_708,
        S_710,
        S_712,
        S_714,
        S_716,
        S_718,
        S_720,
        S_722,
        S_724,
        S_726,
        S_728,
        S_730,
        S_732,
        S_734,
        S_736,
        S_738,
        S_740,
        S_742,
        S_744,
        S_746,
        S_748,
        S_750,
        S_752,
        S_760,
        S_762,
        S_764,
        S_766,
        S_768,
        S_770,
        S_772,
        S_774,
        S_776,
        S_778,
        S_780,
        S_782,
        S_784,
        S_786,
        S_798,
        S_800,
        S_802,
        S_808,
        S_814,
        S_816,
        S_818,
        S_820,
        S_822,
        S_824,
        S_826,
        S_828,
        S_830,
        S_832,
        S_834,
        S_836,
        S_838,
        S_840,
        S_842,
        S_855,
        S_857,
        S_859,
        S_869,
        S_871,
        S_873,
        S_879,
        S_885,
        S_887,
        S_889,
        S_891,
        S_893,
        S_895,
        S_897,
        S_899,
        S_901,
        S_903,
        S_905,
        S_913,
        S_919,
        S_921,
        S_923,
        S_925,
        S_931,
        S_933,
        S_935,
        S_941,
        S_954,
        S_956,
        S_958,
        S_964,
        S_970,
        S_972,
        S_974,
        S_976,
        S_978,
        S_980,
        S_982,
        S_984,
        S_986,
        S_988,
        S_990,
        S_992,
        S_994,
        S_996,
        S_998,
        S_1011,
        S_1013,
        S_1015,
        S_1025,
        S_1027,
        S_1029,
        S_1035,
        S_1041,
        S_1043,
        S_1045,
        S_1047,
        S_1049,
        S_1051,
        S_1053,
        S_1055,
        S_1057,
        S_1059,
        S_1061,
        S_1063,
        S_1065,
        S_1067,
        S_1069,
        S_1071,
        S_1073,
        S_1075,
        S_1077,
        S_1079,
        S_1087,
        S_1089,
        S_1091,
        S_1093,
        S_1095,
        S_1097,
        S_1099,
        S_1101,
        S_1103,
        S_1105,
        S_1117,
        S_1119,
        S_1121,
        S_1127,
        S_1133,
        S_1135,
        S_1137,
        S_1139,
        S_1141,
        S_1143,
        S_1145,
        S_1147,
        S_1149,
        S_1151,
        S_1153,
        S_1155,
        S_1157,
        S_1159,
        S_1161,
        S_1174,
        S_1176,
        S_1178,
        S_1188,
        S_1190,
        S_1192,
        S_1198,
        S_1204,
        S_1206,
        S_1208,
        S_1210,
        S_1212,
        S_1214,
        S_1216,
        S_1218,
        S_1220,
        S_1222,
        S_1224,
        S_1232,
        S_1238,
        S_1240,
        S_1242,
        S_1244,
        S_1246,
        S_1252,
        S_1254,
        S_1256,
        S_1258,
        S_1264,
        S_1266,
        S_1268,
        S_1274,
        S_1276,
        S_1278,
        S_1280,
        S_1282,
        S_1284,
        S_1286,
        S_1288,
        S_1290,
        S_1292,
        S_1298,
        S_1300,
        S_1302,
        S_1312,
        S_1314,
        S_1316,
        S_1322,
        S_1324,
        S_1330,
        S_1332,
        S_1334,
        S_1340,
        S_1346,
        S_1348,
        S_1350,
        S_1352,
        S_1354,
        S_1356,
        S_1358,
        S_1360,
        S_1362,
        S_1364,
        S_1377,
        S_1379,
        S_1381,
        S_1391,
        S_1393,
        S_1395,
        S_1405,
        S_1407,
        S_1409,
        S_1419,
        S_1421,
        S_1423,
        S_1429,
        S_1435,
        S_1437,
        S_1439,
        S_1441,
        S_1443,
        S_1445,
        S_1447,
        S_1449,
        S_1451,
        S_1453,
        S_1462,
        S_1468,
        S_1470,
        S_1476,
        S_1478,
        S_1484,
        S_1490,
        S_1492,
        S_1494,
        S_1504,
        S_1506,
        S_1508,
        S_1514,
        S_1524,
        S_1526,
        S_1532,
        S_1534,
    }
    let mut c2rust_current_block_31: C2Rust_Block_31;
    c2rust_current_block_31 = C2Rust_Block_31::S_0;
    loop {
        match c2rust_current_block_31 {
            C2Rust_Block_31::S_0 => {
                _flags = 0 as ::core::ffi::c_int;
                c2rust_current_block_31 = C2Rust_Block_31::S_2;
            }
            C2Rust_Block_31::S_2 => {
                _fa = 0 as uint32_t;
                _fb = 0 as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_4;
            }
            C2Rust_Block_31::S_4 => {
                _fas = 0 as int32_t;
                _fbs = 0 as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_22;
            }
            C2Rust_Block_31::S_22 => {
                _pv = (*__gamepkg_tls_g_ecx);
                c2rust_current_block_31 = C2Rust_Block_31::S_24;
            }
            C2Rust_Block_31::S_24 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_31 = C2Rust_Block_31::S_26;
            }
            C2Rust_Block_31::S_26 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv,
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_36;
            }
            C2Rust_Block_31::S_36 => {
                _pv_0 = 0 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_38;
            }
            C2Rust_Block_31::S_38 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_31 = C2Rust_Block_31::S_40;
            }
            C2Rust_Block_31::S_40 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_0,
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_50;
            }
            C2Rust_Block_31::S_50 => {
                _pv_1 = 0x36dbc8 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_52;
            }
            C2Rust_Block_31::S_52 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_31 = C2Rust_Block_31::S_54;
            }
            C2Rust_Block_31::S_54 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_1,
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_64;
            }
            C2Rust_Block_31::S_64 => {
                _pv_2 = (*__gamepkg_tls_g_esi);
                c2rust_current_block_31 = C2Rust_Block_31::S_66;
            }
            C2Rust_Block_31::S_66 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_31 = C2Rust_Block_31::S_68;
            }
            C2Rust_Block_31::S_68 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_2,
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_78;
            }
            C2Rust_Block_31::S_78 => {
                _pv_3 = 0x1f997e as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_80;
            }
            C2Rust_Block_31::S_80 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_31 = C2Rust_Block_31::S_82;
            }
            C2Rust_Block_31::S_82 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_3,
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_88;
            }
            C2Rust_Block_31::S_88 => {
                sub_001F8550();
                c2rust_current_block_31 = C2Rust_Block_31::S_98;
            }
            C2Rust_Block_31::S_98 => {
                _pv_4 = 0x28 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_100;
            }
            C2Rust_Block_31::S_100 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_31 = C2Rust_Block_31::S_102;
            }
            C2Rust_Block_31::S_102 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_4,
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_108;
            }
            C2Rust_Block_31::S_108 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x40 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    0x24c as uint32_t,
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_114;
            }
            C2Rust_Block_31::S_114 => {
                _pv_5 = 0x1f998c as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_116;
            }
            C2Rust_Block_31::S_116 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_31 = C2Rust_Block_31::S_118;
            }
            C2Rust_Block_31::S_118 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_5,
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_124;
            }
            C2Rust_Block_31::S_124 => {
                sub_001FFF00();
                c2rust_current_block_31 = C2Rust_Block_31::S_130;
            }
            C2Rust_Block_31::S_130 => {
                (*__gamepkg_tls_g_edx) = 1 as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_132;
            }
            C2Rust_Block_31::S_132 => {
                _fb = 0x10 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_134;
            }
            C2Rust_Block_31::S_134 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_136;
            }
            C2Rust_Block_31::S_136 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(0x10 as uint32_t);
                c2rust_current_block_31 = C2Rust_Block_31::S_138;
            }
            C2Rust_Block_31::S_138 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_140;
            }
            C2Rust_Block_31::S_140 => {
                _fas = _fa as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_142;
            }
            C2Rust_Block_31::S_142 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_eax);
                c2rust_current_block_31 = C2Rust_Block_31::S_144;
            }
            C2Rust_Block_31::S_144 => {
                (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_edx)
                    << ((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t
                        as ::core::ffi::c_int;
                c2rust_current_block_31 = C2Rust_Block_31::S_146;
            }
            C2Rust_Block_31::S_146 => {
                _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_148;
            }
            C2Rust_Block_31::S_148 => {
                _fas = _fa as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_150;
            }
            C2Rust_Block_31::S_150 => {
                _fa = ((*__gamepkg_tls_g_edx) & 0xffff as uint32_t) as uint16_t
                    as uint32_t & 0xffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_152;
            }
            C2Rust_Block_31::S_152 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_154;
            }
            C2Rust_Block_31::S_154 => {
                _fas = _fa as int16_t as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_156;
            }
            C2Rust_Block_31::S_156 => {
                _fbs = _fb as int16_t as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_158;
            }
            C2Rust_Block_31::S_158 => {
                if _fa == _fb {
                    c2rust_current_block_31 = C2Rust_Block_31::S_229;
                } else {
                    c2rust_current_block_31 = C2Rust_Block_31::S_171;
                }
            }
            C2Rust_Block_31::S_171 => {
                _pv_6 = 0x28 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_173;
            }
            C2Rust_Block_31::S_173 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_31 = C2Rust_Block_31::S_175;
            }
            C2Rust_Block_31::S_175 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_6,
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_185;
            }
            C2Rust_Block_31::S_185 => {
                _pv_7 = 0x1f99a4 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_187;
            }
            C2Rust_Block_31::S_187 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_31 = C2Rust_Block_31::S_189;
            }
            C2Rust_Block_31::S_189 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_7,
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_195;
            }
            C2Rust_Block_31::S_195 => {
                sub_001FFF00();
                c2rust_current_block_31 = C2Rust_Block_31::S_201;
            }
            C2Rust_Block_31::S_201 => {
                (*__gamepkg_tls_g_edx) = 1 as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_203;
            }
            C2Rust_Block_31::S_203 => {
                _fb = 4 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_205;
            }
            C2Rust_Block_31::S_205 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_207;
            }
            C2Rust_Block_31::S_207 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_31 = C2Rust_Block_31::S_209;
            }
            C2Rust_Block_31::S_209 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_211;
            }
            C2Rust_Block_31::S_211 => {
                _fas = _fa as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_213;
            }
            C2Rust_Block_31::S_213 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_eax);
                c2rust_current_block_31 = C2Rust_Block_31::S_215;
            }
            C2Rust_Block_31::S_215 => {
                (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_edx)
                    << ((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t
                        as ::core::ffi::c_int;
                c2rust_current_block_31 = C2Rust_Block_31::S_217;
            }
            C2Rust_Block_31::S_217 => {
                _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_219;
            }
            C2Rust_Block_31::S_219 => {
                _fas = _fa as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_221;
            }
            C2Rust_Block_31::S_221 => {
                (*__gamepkg_tls_g_eax) = ((*__gamepkg_tls_g_edx) & 0xffff as uint32_t)
                    as uint16_t as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_235;
            }
            C2Rust_Block_31::S_229 => {
                (*__gamepkg_tls_g_eax) = 1 as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_235;
            }
            C2Rust_Block_31::S_235 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffff0000 as uint32_t
                    & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_237;
            }
            C2Rust_Block_31::S_237 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_239;
            }
            C2Rust_Block_31::S_239 => {
                _fas = _fa as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_241;
            }
            C2Rust_Block_31::S_241 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_247;
            }
            C2Rust_Block_31::S_247 => {
                _pv_8 = 0x28 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_249;
            }
            C2Rust_Block_31::S_249 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_31 = C2Rust_Block_31::S_251;
            }
            C2Rust_Block_31::S_251 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_8,
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_257;
            }
            C2Rust_Block_31::S_257 => {
                if _fa == _fb {
                    c2rust_current_block_31 = C2Rust_Block_31::S_798;
                } else {
                    c2rust_current_block_31 = C2Rust_Block_31::S_270;
                }
            }
            C2Rust_Block_31::S_270 => {
                _pv_9 = 0x1f99cc as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_272;
            }
            C2Rust_Block_31::S_272 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_31 = C2Rust_Block_31::S_274;
            }
            C2Rust_Block_31::S_274 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_9,
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_280;
            }
            C2Rust_Block_31::S_280 => {
                sub_001FFF00();
                c2rust_current_block_31 = C2Rust_Block_31::S_286;
            }
            C2Rust_Block_31::S_286 => {
                (*__gamepkg_tls_g_edx) = 1 as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_288;
            }
            C2Rust_Block_31::S_288 => {
                _fb = 4 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_290;
            }
            C2Rust_Block_31::S_290 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_292;
            }
            C2Rust_Block_31::S_292 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_31 = C2Rust_Block_31::S_294;
            }
            C2Rust_Block_31::S_294 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_296;
            }
            C2Rust_Block_31::S_296 => {
                _fas = _fa as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_298;
            }
            C2Rust_Block_31::S_298 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_eax);
                c2rust_current_block_31 = C2Rust_Block_31::S_300;
            }
            C2Rust_Block_31::S_300 => {
                (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_edx)
                    << ((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t
                        as ::core::ffi::c_int;
                c2rust_current_block_31 = C2Rust_Block_31::S_302;
            }
            C2Rust_Block_31::S_302 => {
                _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_304;
            }
            C2Rust_Block_31::S_304 => {
                _fas = _fa as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_306;
            }
            C2Rust_Block_31::S_306 => {
                _fa = ((*__gamepkg_tls_g_edx) & 0xffff as uint32_t) as uint16_t
                    as uint32_t & 0xffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_308;
            }
            C2Rust_Block_31::S_308 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_310;
            }
            C2Rust_Block_31::S_310 => {
                _fas = _fa as int16_t as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_312;
            }
            C2Rust_Block_31::S_312 => {
                _fbs = _fb as int16_t as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_314;
            }
            C2Rust_Block_31::S_314 => {
                if _fa == _fb {
                    c2rust_current_block_31 = C2Rust_Block_31::S_387;
                } else {
                    c2rust_current_block_31 = C2Rust_Block_31::S_327;
                }
            }
            C2Rust_Block_31::S_327 => {
                _pv_10 = 0x28 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_329;
            }
            C2Rust_Block_31::S_329 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_31 = C2Rust_Block_31::S_331;
            }
            C2Rust_Block_31::S_331 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_10,
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_341;
            }
            C2Rust_Block_31::S_341 => {
                _pv_11 = 0x1f99e4 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_343;
            }
            C2Rust_Block_31::S_343 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_31 = C2Rust_Block_31::S_345;
            }
            C2Rust_Block_31::S_345 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_11,
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_351;
            }
            C2Rust_Block_31::S_351 => {
                sub_001FFF00();
                c2rust_current_block_31 = C2Rust_Block_31::S_357;
            }
            C2Rust_Block_31::S_357 => {
                (*__gamepkg_tls_g_edx) = 1 as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_359;
            }
            C2Rust_Block_31::S_359 => {
                _fb = 4 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_361;
            }
            C2Rust_Block_31::S_361 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_363;
            }
            C2Rust_Block_31::S_363 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_31 = C2Rust_Block_31::S_365;
            }
            C2Rust_Block_31::S_365 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_367;
            }
            C2Rust_Block_31::S_367 => {
                _fas = _fa as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_369;
            }
            C2Rust_Block_31::S_369 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_eax);
                c2rust_current_block_31 = C2Rust_Block_31::S_371;
            }
            C2Rust_Block_31::S_371 => {
                (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_edx)
                    << ((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t
                        as ::core::ffi::c_int;
                c2rust_current_block_31 = C2Rust_Block_31::S_373;
            }
            C2Rust_Block_31::S_373 => {
                _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_375;
            }
            C2Rust_Block_31::S_375 => {
                _fas = _fa as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_377;
            }
            C2Rust_Block_31::S_377 => {
                (*__gamepkg_tls_g_eax) = ((*__gamepkg_tls_g_edx) & 0xffff as uint32_t)
                    as uint16_t as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_379;
            }
            C2Rust_Block_31::S_379 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_393;
            }
            C2Rust_Block_31::S_387 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    1 as uint32_t,
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_393;
            }
            C2Rust_Block_31::S_393 => {
                (*__gamepkg_tls_g_ecx) = 0 as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_395;
            }
            C2Rust_Block_31::S_395 => {
                _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_397;
            }
            C2Rust_Block_31::S_397 => {
                _fas = _fa as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_399;
            }
            C2Rust_Block_31::S_399 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx) & 0xffff00ff as uint32_t
                    | (::core::ptr::read_volatile::<
                        uint8_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            ((*__gamepkg_tls_g_esp).wrapping_add(3 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ) as uint32_t) << 8 as ::core::ffi::c_int;
                c2rust_current_block_31 = C2Rust_Block_31::S_405;
            }
            C2Rust_Block_31::S_405 => {
                _pv_12 = 0x28 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_407;
            }
            C2Rust_Block_31::S_407 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_31 = C2Rust_Block_31::S_409;
            }
            C2Rust_Block_31::S_409 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_12,
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_415;
            }
            C2Rust_Block_31::S_415 => {
                _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_417;
            }
            C2Rust_Block_31::S_417 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_419;
            }
            C2Rust_Block_31::S_419 => {
                _fas = _fa as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_421;
            }
            C2Rust_Block_31::S_421 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_423;
            }
            C2Rust_Block_31::S_423 => {
                if _fa == _fb {
                    c2rust_current_block_31 = C2Rust_Block_31::S_619;
                } else {
                    c2rust_current_block_31 = C2Rust_Block_31::S_436;
                }
            }
            C2Rust_Block_31::S_436 => {
                _pv_13 = 0x1f9a10 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_438;
            }
            C2Rust_Block_31::S_438 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_31 = C2Rust_Block_31::S_440;
            }
            C2Rust_Block_31::S_440 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_13,
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_446;
            }
            C2Rust_Block_31::S_446 => {
                sub_001FFF00();
                c2rust_current_block_31 = C2Rust_Block_31::S_452;
            }
            C2Rust_Block_31::S_452 => {
                (*__gamepkg_tls_g_edx) = 1 as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_454;
            }
            C2Rust_Block_31::S_454 => {
                _fb = 4 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_456;
            }
            C2Rust_Block_31::S_456 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_458;
            }
            C2Rust_Block_31::S_458 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_31 = C2Rust_Block_31::S_460;
            }
            C2Rust_Block_31::S_460 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_462;
            }
            C2Rust_Block_31::S_462 => {
                _fas = _fa as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_464;
            }
            C2Rust_Block_31::S_464 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_eax);
                c2rust_current_block_31 = C2Rust_Block_31::S_466;
            }
            C2Rust_Block_31::S_466 => {
                (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_edx)
                    << ((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t
                        as ::core::ffi::c_int;
                c2rust_current_block_31 = C2Rust_Block_31::S_468;
            }
            C2Rust_Block_31::S_468 => {
                _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_470;
            }
            C2Rust_Block_31::S_470 => {
                _fas = _fa as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_472;
            }
            C2Rust_Block_31::S_472 => {
                _fa = ((*__gamepkg_tls_g_edx) & 0xffff as uint32_t) as uint16_t
                    as uint32_t & 0xffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_474;
            }
            C2Rust_Block_31::S_474 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_476;
            }
            C2Rust_Block_31::S_476 => {
                _fas = _fa as int16_t as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_478;
            }
            C2Rust_Block_31::S_478 => {
                _fbs = _fb as int16_t as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_480;
            }
            C2Rust_Block_31::S_480 => {
                if _fa == _fb {
                    c2rust_current_block_31 = C2Rust_Block_31::S_579;
                } else {
                    c2rust_current_block_31 = C2Rust_Block_31::S_493;
                }
            }
            C2Rust_Block_31::S_493 => {
                _pv_14 = 0x28 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_495;
            }
            C2Rust_Block_31::S_495 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_31 = C2Rust_Block_31::S_497;
            }
            C2Rust_Block_31::S_497 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_14,
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_507;
            }
            C2Rust_Block_31::S_507 => {
                _pv_15 = 0x1f9a28 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_509;
            }
            C2Rust_Block_31::S_509 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_31 = C2Rust_Block_31::S_511;
            }
            C2Rust_Block_31::S_511 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_15,
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_517;
            }
            C2Rust_Block_31::S_517 => {
                sub_001FFF00();
                c2rust_current_block_31 = C2Rust_Block_31::S_523;
            }
            C2Rust_Block_31::S_523 => {
                (*__gamepkg_tls_g_edx) = 1 as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_525;
            }
            C2Rust_Block_31::S_525 => {
                _fb = 4 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_527;
            }
            C2Rust_Block_31::S_527 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_529;
            }
            C2Rust_Block_31::S_529 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_31 = C2Rust_Block_31::S_531;
            }
            C2Rust_Block_31::S_531 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_533;
            }
            C2Rust_Block_31::S_533 => {
                _fas = _fa as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_535;
            }
            C2Rust_Block_31::S_535 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_eax);
                c2rust_current_block_31 = C2Rust_Block_31::S_537;
            }
            C2Rust_Block_31::S_537 => {
                (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_edx)
                    << ((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t
                        as ::core::ffi::c_int;
                c2rust_current_block_31 = C2Rust_Block_31::S_539;
            }
            C2Rust_Block_31::S_539 => {
                _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_541;
            }
            C2Rust_Block_31::S_541 => {
                _fas = _fa as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_543;
            }
            C2Rust_Block_31::S_543 => {
                (*__gamepkg_tls_g_eax) = ((*__gamepkg_tls_g_edx) & 0xffff as uint32_t)
                    as uint16_t as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_545;
            }
            C2Rust_Block_31::S_545 => {
                (*__gamepkg_tls_g_eax) = ((*__gamepkg_tls_g_eax) as int32_t
                    >> (0x18 as ::core::ffi::c_uint & 31 as ::core::ffi::c_uint))
                    as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_547;
            }
            C2Rust_Block_31::S_547 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_549;
            }
            C2Rust_Block_31::S_549 => {
                _fas = _fa as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_551;
            }
            C2Rust_Block_31::S_551 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    int8_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        int8_t,
                    >(
                        ((*__gamepkg_tls_g_eax).wrapping_add(0x3c0848 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) as int32_t as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_553;
            }
            C2Rust_Block_31::S_553 => {
                _fb = 7 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_555;
            }
            C2Rust_Block_31::S_555 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_557;
            }
            C2Rust_Block_31::S_557 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
                    .wrapping_add(7 as uint32_t);
                c2rust_current_block_31 = C2Rust_Block_31::S_559;
            }
            C2Rust_Block_31::S_559 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_561;
            }
            C2Rust_Block_31::S_561 => {
                _fas = _fa as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_563;
            }
            C2Rust_Block_31::S_563 => {
                _fb = 0x10 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_565;
            }
            C2Rust_Block_31::S_565 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_567;
            }
            C2Rust_Block_31::S_567 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
                    .wrapping_add(0x10 as uint32_t);
                c2rust_current_block_31 = C2Rust_Block_31::S_569;
            }
            C2Rust_Block_31::S_569 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_571;
            }
            C2Rust_Block_31::S_571 => {
                _fas = _fa as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_1252;
            }
            C2Rust_Block_31::S_579 => {
                (*__gamepkg_tls_g_eax) = 1 as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_581;
            }
            C2Rust_Block_31::S_581 => {
                (*__gamepkg_tls_g_eax) = ((*__gamepkg_tls_g_eax) as int32_t
                    >> (0x18 as ::core::ffi::c_uint & 31 as ::core::ffi::c_uint))
                    as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_583;
            }
            C2Rust_Block_31::S_583 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_585;
            }
            C2Rust_Block_31::S_585 => {
                _fas = _fa as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_587;
            }
            C2Rust_Block_31::S_587 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    int8_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        int8_t,
                    >(
                        ((*__gamepkg_tls_g_eax).wrapping_add(0x3c0848 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) as int32_t as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_589;
            }
            C2Rust_Block_31::S_589 => {
                _fb = 7 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_591;
            }
            C2Rust_Block_31::S_591 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_593;
            }
            C2Rust_Block_31::S_593 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
                    .wrapping_add(7 as uint32_t);
                c2rust_current_block_31 = C2Rust_Block_31::S_595;
            }
            C2Rust_Block_31::S_595 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_597;
            }
            C2Rust_Block_31::S_597 => {
                _fas = _fa as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_599;
            }
            C2Rust_Block_31::S_599 => {
                _fb = 0x10 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_601;
            }
            C2Rust_Block_31::S_601 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_603;
            }
            C2Rust_Block_31::S_603 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
                    .wrapping_add(0x10 as uint32_t);
                c2rust_current_block_31 = C2Rust_Block_31::S_605;
            }
            C2Rust_Block_31::S_605 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_607;
            }
            C2Rust_Block_31::S_607 => {
                _fas = _fa as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_1252;
            }
            C2Rust_Block_31::S_619 => {
                _pv_16 = 0x1f9a6b as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_621;
            }
            C2Rust_Block_31::S_621 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_31 = C2Rust_Block_31::S_623;
            }
            C2Rust_Block_31::S_623 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_16,
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_629;
            }
            C2Rust_Block_31::S_629 => {
                sub_001FFF00();
                c2rust_current_block_31 = C2Rust_Block_31::S_635;
            }
            C2Rust_Block_31::S_635 => {
                (*__gamepkg_tls_g_edx) = 1 as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_637;
            }
            C2Rust_Block_31::S_637 => {
                _fb = 4 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_639;
            }
            C2Rust_Block_31::S_639 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_641;
            }
            C2Rust_Block_31::S_641 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_31 = C2Rust_Block_31::S_643;
            }
            C2Rust_Block_31::S_643 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_645;
            }
            C2Rust_Block_31::S_645 => {
                _fas = _fa as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_647;
            }
            C2Rust_Block_31::S_647 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_eax);
                c2rust_current_block_31 = C2Rust_Block_31::S_649;
            }
            C2Rust_Block_31::S_649 => {
                (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_edx)
                    << ((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t
                        as ::core::ffi::c_int;
                c2rust_current_block_31 = C2Rust_Block_31::S_651;
            }
            C2Rust_Block_31::S_651 => {
                _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_653;
            }
            C2Rust_Block_31::S_653 => {
                _fas = _fa as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_655;
            }
            C2Rust_Block_31::S_655 => {
                _fa = ((*__gamepkg_tls_g_edx) & 0xffff as uint32_t) as uint16_t
                    as uint32_t & 0xffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_657;
            }
            C2Rust_Block_31::S_657 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_659;
            }
            C2Rust_Block_31::S_659 => {
                _fas = _fa as int16_t as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_661;
            }
            C2Rust_Block_31::S_661 => {
                _fbs = _fb as int16_t as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_663;
            }
            C2Rust_Block_31::S_663 => {
                if _fa == _fb {
                    c2rust_current_block_31 = C2Rust_Block_31::S_760;
                } else {
                    c2rust_current_block_31 = C2Rust_Block_31::S_676;
                }
            }
            C2Rust_Block_31::S_676 => {
                _pv_17 = 0x28 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_678;
            }
            C2Rust_Block_31::S_678 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_31 = C2Rust_Block_31::S_680;
            }
            C2Rust_Block_31::S_680 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_17,
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_690;
            }
            C2Rust_Block_31::S_690 => {
                _pv_18 = 0x1f9a83 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_692;
            }
            C2Rust_Block_31::S_692 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_31 = C2Rust_Block_31::S_694;
            }
            C2Rust_Block_31::S_694 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_18,
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_700;
            }
            C2Rust_Block_31::S_700 => {
                sub_001FFF00();
                c2rust_current_block_31 = C2Rust_Block_31::S_706;
            }
            C2Rust_Block_31::S_706 => {
                (*__gamepkg_tls_g_edx) = 1 as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_708;
            }
            C2Rust_Block_31::S_708 => {
                _fb = 4 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_710;
            }
            C2Rust_Block_31::S_710 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_712;
            }
            C2Rust_Block_31::S_712 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_31 = C2Rust_Block_31::S_714;
            }
            C2Rust_Block_31::S_714 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_716;
            }
            C2Rust_Block_31::S_716 => {
                _fas = _fa as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_718;
            }
            C2Rust_Block_31::S_718 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_eax);
                c2rust_current_block_31 = C2Rust_Block_31::S_720;
            }
            C2Rust_Block_31::S_720 => {
                (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_edx)
                    << ((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t
                        as ::core::ffi::c_int;
                c2rust_current_block_31 = C2Rust_Block_31::S_722;
            }
            C2Rust_Block_31::S_722 => {
                _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_724;
            }
            C2Rust_Block_31::S_724 => {
                _fas = _fa as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_726;
            }
            C2Rust_Block_31::S_726 => {
                (*__gamepkg_tls_g_eax) = ((*__gamepkg_tls_g_edx) & 0xffff as uint32_t)
                    as uint16_t as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_728;
            }
            C2Rust_Block_31::S_728 => {
                (*__gamepkg_tls_g_eax) = ((*__gamepkg_tls_g_eax) as int32_t
                    >> (0x10 as ::core::ffi::c_uint & 31 as ::core::ffi::c_uint))
                    as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_730;
            }
            C2Rust_Block_31::S_730 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_732;
            }
            C2Rust_Block_31::S_732 => {
                _fas = _fa as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_734;
            }
            C2Rust_Block_31::S_734 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    int8_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        int8_t,
                    >(
                        ((*__gamepkg_tls_g_eax).wrapping_add(0x3c0848 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) as int32_t as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_736;
            }
            C2Rust_Block_31::S_736 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax).wrapping_sub(1);
                c2rust_current_block_31 = C2Rust_Block_31::S_738;
            }
            C2Rust_Block_31::S_738 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_740;
            }
            C2Rust_Block_31::S_740 => {
                _fas = _fa as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_742;
            }
            C2Rust_Block_31::S_742 => {
                _fb = (_fa == 0x7fffffff as uint32_t) as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_744;
            }
            C2Rust_Block_31::S_744 => {
                _fb = 0x10 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_746;
            }
            C2Rust_Block_31::S_746 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_748;
            }
            C2Rust_Block_31::S_748 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
                    .wrapping_add(0x10 as uint32_t);
                c2rust_current_block_31 = C2Rust_Block_31::S_750;
            }
            C2Rust_Block_31::S_750 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_752;
            }
            C2Rust_Block_31::S_752 => {
                _fas = _fa as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_1252;
            }
            C2Rust_Block_31::S_760 => {
                (*__gamepkg_tls_g_eax) = 1 as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_762;
            }
            C2Rust_Block_31::S_762 => {
                (*__gamepkg_tls_g_eax) = ((*__gamepkg_tls_g_eax) as int32_t
                    >> (0x10 as ::core::ffi::c_uint & 31 as ::core::ffi::c_uint))
                    as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_764;
            }
            C2Rust_Block_31::S_764 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_766;
            }
            C2Rust_Block_31::S_766 => {
                _fas = _fa as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_768;
            }
            C2Rust_Block_31::S_768 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    int8_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        int8_t,
                    >(
                        ((*__gamepkg_tls_g_eax).wrapping_add(0x3c0848 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) as int32_t as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_770;
            }
            C2Rust_Block_31::S_770 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax).wrapping_sub(1);
                c2rust_current_block_31 = C2Rust_Block_31::S_772;
            }
            C2Rust_Block_31::S_772 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_774;
            }
            C2Rust_Block_31::S_774 => {
                _fas = _fa as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_776;
            }
            C2Rust_Block_31::S_776 => {
                _fb = (_fa == 0x7fffffff as uint32_t) as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_778;
            }
            C2Rust_Block_31::S_778 => {
                _fb = 0x10 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_780;
            }
            C2Rust_Block_31::S_780 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_782;
            }
            C2Rust_Block_31::S_782 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
                    .wrapping_add(0x10 as uint32_t);
                c2rust_current_block_31 = C2Rust_Block_31::S_784;
            }
            C2Rust_Block_31::S_784 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_786;
            }
            C2Rust_Block_31::S_786 => {
                _fas = _fa as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_1252;
            }
            C2Rust_Block_31::S_798 => {
                _pv_19 = 0x1f9ac2 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_800;
            }
            C2Rust_Block_31::S_800 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_31 = C2Rust_Block_31::S_802;
            }
            C2Rust_Block_31::S_802 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_19,
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_808;
            }
            C2Rust_Block_31::S_808 => {
                sub_001FFF00();
                c2rust_current_block_31 = C2Rust_Block_31::S_814;
            }
            C2Rust_Block_31::S_814 => {
                (*__gamepkg_tls_g_edx) = 1 as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_816;
            }
            C2Rust_Block_31::S_816 => {
                _fb = 4 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_818;
            }
            C2Rust_Block_31::S_818 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_820;
            }
            C2Rust_Block_31::S_820 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_31 = C2Rust_Block_31::S_822;
            }
            C2Rust_Block_31::S_822 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_824;
            }
            C2Rust_Block_31::S_824 => {
                _fas = _fa as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_826;
            }
            C2Rust_Block_31::S_826 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_eax);
                c2rust_current_block_31 = C2Rust_Block_31::S_828;
            }
            C2Rust_Block_31::S_828 => {
                (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_edx)
                    << ((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t
                        as ::core::ffi::c_int;
                c2rust_current_block_31 = C2Rust_Block_31::S_830;
            }
            C2Rust_Block_31::S_830 => {
                _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_832;
            }
            C2Rust_Block_31::S_832 => {
                _fas = _fa as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_834;
            }
            C2Rust_Block_31::S_834 => {
                _fa = ((*__gamepkg_tls_g_edx) & 0xffff as uint32_t) as uint16_t
                    as uint32_t & 0xffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_836;
            }
            C2Rust_Block_31::S_836 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_838;
            }
            C2Rust_Block_31::S_838 => {
                _fas = _fa as int16_t as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_840;
            }
            C2Rust_Block_31::S_840 => {
                _fbs = _fb as int16_t as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_842;
            }
            C2Rust_Block_31::S_842 => {
                if _fa == _fb {
                    c2rust_current_block_31 = C2Rust_Block_31::S_913;
                } else {
                    c2rust_current_block_31 = C2Rust_Block_31::S_855;
                }
            }
            C2Rust_Block_31::S_855 => {
                _pv_20 = 0x28 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_857;
            }
            C2Rust_Block_31::S_857 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_31 = C2Rust_Block_31::S_859;
            }
            C2Rust_Block_31::S_859 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_20,
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_869;
            }
            C2Rust_Block_31::S_869 => {
                _pv_21 = 0x1f9ada as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_871;
            }
            C2Rust_Block_31::S_871 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_31 = C2Rust_Block_31::S_873;
            }
            C2Rust_Block_31::S_873 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_21,
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_879;
            }
            C2Rust_Block_31::S_879 => {
                sub_001FFF00();
                c2rust_current_block_31 = C2Rust_Block_31::S_885;
            }
            C2Rust_Block_31::S_885 => {
                (*__gamepkg_tls_g_edx) = 1 as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_887;
            }
            C2Rust_Block_31::S_887 => {
                _fb = 4 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_889;
            }
            C2Rust_Block_31::S_889 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_891;
            }
            C2Rust_Block_31::S_891 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_31 = C2Rust_Block_31::S_893;
            }
            C2Rust_Block_31::S_893 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_895;
            }
            C2Rust_Block_31::S_895 => {
                _fas = _fa as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_897;
            }
            C2Rust_Block_31::S_897 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_eax);
                c2rust_current_block_31 = C2Rust_Block_31::S_899;
            }
            C2Rust_Block_31::S_899 => {
                (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_edx)
                    << ((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t
                        as ::core::ffi::c_int;
                c2rust_current_block_31 = C2Rust_Block_31::S_901;
            }
            C2Rust_Block_31::S_901 => {
                _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_903;
            }
            C2Rust_Block_31::S_903 => {
                _fas = _fa as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_905;
            }
            C2Rust_Block_31::S_905 => {
                (*__gamepkg_tls_g_eax) = ((*__gamepkg_tls_g_edx) & 0xffff as uint32_t)
                    as uint16_t as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_919;
            }
            C2Rust_Block_31::S_913 => {
                (*__gamepkg_tls_g_eax) = 1 as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_919;
            }
            C2Rust_Block_31::S_919 => {
                _fa = (((*__gamepkg_tls_g_eax) >> 8 as ::core::ffi::c_int
                    & 0xff as uint32_t) as uint8_t as ::core::ffi::c_int
                    & 0xff as ::core::ffi::c_int) as uint32_t & 0xff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_921;
            }
            C2Rust_Block_31::S_921 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_923;
            }
            C2Rust_Block_31::S_923 => {
                _fas = _fa as int8_t as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_925;
            }
            C2Rust_Block_31::S_925 => {
                _fbs = _fb as int8_t as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_931;
            }
            C2Rust_Block_31::S_931 => {
                _pv_22 = 0x28 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_933;
            }
            C2Rust_Block_31::S_933 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_31 = C2Rust_Block_31::S_935;
            }
            C2Rust_Block_31::S_935 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_22,
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_941;
            }
            C2Rust_Block_31::S_941 => {
                if _fa == _fb {
                    c2rust_current_block_31 = C2Rust_Block_31::S_1117;
                } else {
                    c2rust_current_block_31 = C2Rust_Block_31::S_954;
                }
            }
            C2Rust_Block_31::S_954 => {
                _pv_23 = 0x1f9afc as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_956;
            }
            C2Rust_Block_31::S_956 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_31 = C2Rust_Block_31::S_958;
            }
            C2Rust_Block_31::S_958 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_23,
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_964;
            }
            C2Rust_Block_31::S_964 => {
                sub_001FFF00();
                c2rust_current_block_31 = C2Rust_Block_31::S_970;
            }
            C2Rust_Block_31::S_970 => {
                (*__gamepkg_tls_g_edx) = 1 as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_972;
            }
            C2Rust_Block_31::S_972 => {
                _fb = 4 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_974;
            }
            C2Rust_Block_31::S_974 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_976;
            }
            C2Rust_Block_31::S_976 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_31 = C2Rust_Block_31::S_978;
            }
            C2Rust_Block_31::S_978 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_980;
            }
            C2Rust_Block_31::S_980 => {
                _fas = _fa as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_982;
            }
            C2Rust_Block_31::S_982 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_eax);
                c2rust_current_block_31 = C2Rust_Block_31::S_984;
            }
            C2Rust_Block_31::S_984 => {
                (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_edx)
                    << ((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t
                        as ::core::ffi::c_int;
                c2rust_current_block_31 = C2Rust_Block_31::S_986;
            }
            C2Rust_Block_31::S_986 => {
                _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_988;
            }
            C2Rust_Block_31::S_988 => {
                _fas = _fa as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_990;
            }
            C2Rust_Block_31::S_990 => {
                _fa = ((*__gamepkg_tls_g_edx) & 0xffff as uint32_t) as uint16_t
                    as uint32_t & 0xffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_992;
            }
            C2Rust_Block_31::S_992 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_994;
            }
            C2Rust_Block_31::S_994 => {
                _fas = _fa as int16_t as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_996;
            }
            C2Rust_Block_31::S_996 => {
                _fbs = _fb as int16_t as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_998;
            }
            C2Rust_Block_31::S_998 => {
                if _fa == _fb {
                    c2rust_current_block_31 = C2Rust_Block_31::S_1087;
                } else {
                    c2rust_current_block_31 = C2Rust_Block_31::S_1011;
                }
            }
            C2Rust_Block_31::S_1011 => {
                _pv_24 = 0x28 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_1013;
            }
            C2Rust_Block_31::S_1013 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_31 = C2Rust_Block_31::S_1015;
            }
            C2Rust_Block_31::S_1015 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_24,
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_1025;
            }
            C2Rust_Block_31::S_1025 => {
                _pv_25 = 0x1f9b14 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_1027;
            }
            C2Rust_Block_31::S_1027 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_31 = C2Rust_Block_31::S_1029;
            }
            C2Rust_Block_31::S_1029 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_25,
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_1035;
            }
            C2Rust_Block_31::S_1035 => {
                sub_001FFF00();
                c2rust_current_block_31 = C2Rust_Block_31::S_1041;
            }
            C2Rust_Block_31::S_1041 => {
                (*__gamepkg_tls_g_edx) = 1 as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_1043;
            }
            C2Rust_Block_31::S_1043 => {
                _fb = 4 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_1045;
            }
            C2Rust_Block_31::S_1045 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_1047;
            }
            C2Rust_Block_31::S_1047 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_31 = C2Rust_Block_31::S_1049;
            }
            C2Rust_Block_31::S_1049 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_1051;
            }
            C2Rust_Block_31::S_1051 => {
                _fas = _fa as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_1053;
            }
            C2Rust_Block_31::S_1053 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_eax);
                c2rust_current_block_31 = C2Rust_Block_31::S_1055;
            }
            C2Rust_Block_31::S_1055 => {
                (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_edx)
                    << ((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t
                        as ::core::ffi::c_int;
                c2rust_current_block_31 = C2Rust_Block_31::S_1057;
            }
            C2Rust_Block_31::S_1057 => {
                _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_1059;
            }
            C2Rust_Block_31::S_1059 => {
                _fas = _fa as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_1061;
            }
            C2Rust_Block_31::S_1061 => {
                (*__gamepkg_tls_g_eax) = ((*__gamepkg_tls_g_edx) & 0xffff as uint32_t)
                    as uint16_t as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_1063;
            }
            C2Rust_Block_31::S_1063 => {
                (*__gamepkg_tls_g_eax) = ((*__gamepkg_tls_g_eax) as int32_t
                    >> (8 as ::core::ffi::c_uint & 31 as ::core::ffi::c_uint))
                    as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_1065;
            }
            C2Rust_Block_31::S_1065 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_1067;
            }
            C2Rust_Block_31::S_1067 => {
                _fas = _fa as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_1069;
            }
            C2Rust_Block_31::S_1069 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    int8_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        int8_t,
                    >(
                        ((*__gamepkg_tls_g_eax).wrapping_add(0x3c0848 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) as int32_t as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_1071;
            }
            C2Rust_Block_31::S_1071 => {
                _fb = 7 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_1073;
            }
            C2Rust_Block_31::S_1073 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_1075;
            }
            C2Rust_Block_31::S_1075 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
                    .wrapping_add(7 as uint32_t);
                c2rust_current_block_31 = C2Rust_Block_31::S_1077;
            }
            C2Rust_Block_31::S_1077 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_1079;
            }
            C2Rust_Block_31::S_1079 => {
                _fas = _fa as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_1252;
            }
            C2Rust_Block_31::S_1087 => {
                (*__gamepkg_tls_g_eax) = 1 as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_1089;
            }
            C2Rust_Block_31::S_1089 => {
                (*__gamepkg_tls_g_eax) = ((*__gamepkg_tls_g_eax) as int32_t
                    >> (8 as ::core::ffi::c_uint & 31 as ::core::ffi::c_uint))
                    as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_1091;
            }
            C2Rust_Block_31::S_1091 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_1093;
            }
            C2Rust_Block_31::S_1093 => {
                _fas = _fa as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_1095;
            }
            C2Rust_Block_31::S_1095 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    int8_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        int8_t,
                    >(
                        ((*__gamepkg_tls_g_eax).wrapping_add(0x3c0848 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) as int32_t as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_1097;
            }
            C2Rust_Block_31::S_1097 => {
                _fb = 7 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_1099;
            }
            C2Rust_Block_31::S_1099 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_1101;
            }
            C2Rust_Block_31::S_1101 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
                    .wrapping_add(7 as uint32_t);
                c2rust_current_block_31 = C2Rust_Block_31::S_1103;
            }
            C2Rust_Block_31::S_1103 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_1105;
            }
            C2Rust_Block_31::S_1105 => {
                _fas = _fa as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_1252;
            }
            C2Rust_Block_31::S_1117 => {
                _pv_26 = 0x1f9b4b as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_1119;
            }
            C2Rust_Block_31::S_1119 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_31 = C2Rust_Block_31::S_1121;
            }
            C2Rust_Block_31::S_1121 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_26,
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_1127;
            }
            C2Rust_Block_31::S_1127 => {
                sub_001FFF00();
                c2rust_current_block_31 = C2Rust_Block_31::S_1133;
            }
            C2Rust_Block_31::S_1133 => {
                (*__gamepkg_tls_g_edx) = 1 as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_1135;
            }
            C2Rust_Block_31::S_1135 => {
                _fb = 4 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_1137;
            }
            C2Rust_Block_31::S_1137 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_1139;
            }
            C2Rust_Block_31::S_1139 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_31 = C2Rust_Block_31::S_1141;
            }
            C2Rust_Block_31::S_1141 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_1143;
            }
            C2Rust_Block_31::S_1143 => {
                _fas = _fa as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_1145;
            }
            C2Rust_Block_31::S_1145 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_eax);
                c2rust_current_block_31 = C2Rust_Block_31::S_1147;
            }
            C2Rust_Block_31::S_1147 => {
                (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_edx)
                    << ((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t
                        as ::core::ffi::c_int;
                c2rust_current_block_31 = C2Rust_Block_31::S_1149;
            }
            C2Rust_Block_31::S_1149 => {
                _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_1151;
            }
            C2Rust_Block_31::S_1151 => {
                _fas = _fa as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_1153;
            }
            C2Rust_Block_31::S_1153 => {
                _fa = ((*__gamepkg_tls_g_edx) & 0xffff as uint32_t) as uint16_t
                    as uint32_t & 0xffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_1155;
            }
            C2Rust_Block_31::S_1155 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_1157;
            }
            C2Rust_Block_31::S_1157 => {
                _fas = _fa as int16_t as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_1159;
            }
            C2Rust_Block_31::S_1159 => {
                _fbs = _fb as int16_t as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_1161;
            }
            C2Rust_Block_31::S_1161 => {
                if _fa == _fb {
                    c2rust_current_block_31 = C2Rust_Block_31::S_1232;
                } else {
                    c2rust_current_block_31 = C2Rust_Block_31::S_1174;
                }
            }
            C2Rust_Block_31::S_1174 => {
                _pv_27 = 0x28 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_1176;
            }
            C2Rust_Block_31::S_1176 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_31 = C2Rust_Block_31::S_1178;
            }
            C2Rust_Block_31::S_1178 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_27,
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_1188;
            }
            C2Rust_Block_31::S_1188 => {
                _pv_28 = 0x1f9b63 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_1190;
            }
            C2Rust_Block_31::S_1190 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_31 = C2Rust_Block_31::S_1192;
            }
            C2Rust_Block_31::S_1192 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_28,
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_1198;
            }
            C2Rust_Block_31::S_1198 => {
                sub_001FFF00();
                c2rust_current_block_31 = C2Rust_Block_31::S_1204;
            }
            C2Rust_Block_31::S_1204 => {
                (*__gamepkg_tls_g_edx) = 1 as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_1206;
            }
            C2Rust_Block_31::S_1206 => {
                _fb = 4 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_1208;
            }
            C2Rust_Block_31::S_1208 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_1210;
            }
            C2Rust_Block_31::S_1210 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_31 = C2Rust_Block_31::S_1212;
            }
            C2Rust_Block_31::S_1212 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_1214;
            }
            C2Rust_Block_31::S_1214 => {
                _fas = _fa as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_1216;
            }
            C2Rust_Block_31::S_1216 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_eax);
                c2rust_current_block_31 = C2Rust_Block_31::S_1218;
            }
            C2Rust_Block_31::S_1218 => {
                (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_edx)
                    << ((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t
                        as ::core::ffi::c_int;
                c2rust_current_block_31 = C2Rust_Block_31::S_1220;
            }
            C2Rust_Block_31::S_1220 => {
                _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_1222;
            }
            C2Rust_Block_31::S_1222 => {
                _fas = _fa as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_1224;
            }
            C2Rust_Block_31::S_1224 => {
                (*__gamepkg_tls_g_eax) = ((*__gamepkg_tls_g_edx) & 0xffff as uint32_t)
                    as uint16_t as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_1238;
            }
            C2Rust_Block_31::S_1232 => {
                (*__gamepkg_tls_g_eax) = 1 as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_1238;
            }
            C2Rust_Block_31::S_1238 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    int8_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        int8_t,
                    >(
                        ((*__gamepkg_tls_g_eax).wrapping_add(0x3c0848 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) as int32_t as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_1240;
            }
            C2Rust_Block_31::S_1240 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax).wrapping_sub(1);
                c2rust_current_block_31 = C2Rust_Block_31::S_1242;
            }
            C2Rust_Block_31::S_1242 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_1244;
            }
            C2Rust_Block_31::S_1244 => {
                _fas = _fa as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_1246;
            }
            C2Rust_Block_31::S_1246 => {
                _fb = (_fa == 0x7fffffff as uint32_t) as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_1252;
            }
            C2Rust_Block_31::S_1252 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x40 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_1254;
            }
            C2Rust_Block_31::S_1254 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
                    << 0x1c as ::core::ffi::c_int;
                c2rust_current_block_31 = C2Rust_Block_31::S_1256;
            }
            C2Rust_Block_31::S_1256 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_1258;
            }
            C2Rust_Block_31::S_1258 => {
                _fas = _fa as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_1264;
            }
            C2Rust_Block_31::S_1264 => {
                _pv_29 = 1 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_1266;
            }
            C2Rust_Block_31::S_1266 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_31 = C2Rust_Block_31::S_1268;
            }
            C2Rust_Block_31::S_1268 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_29,
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_1274;
            }
            C2Rust_Block_31::S_1274 => {
                (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_edx) | (*__gamepkg_tls_g_eax);
                c2rust_current_block_31 = C2Rust_Block_31::S_1276;
            }
            C2Rust_Block_31::S_1276 => {
                _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_1278;
            }
            C2Rust_Block_31::S_1278 => {
                _fas = _fa as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_1280;
            }
            C2Rust_Block_31::S_1280 => {
                (*__gamepkg_tls_g_eax) = 0x764128 as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_1282;
            }
            C2Rust_Block_31::S_1282 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x40 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_edx),
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_1284;
            }
            C2Rust_Block_31::S_1284 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x28 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    0x1f90b0 as uint32_t,
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_1286;
            }
            C2Rust_Block_31::S_1286 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x34 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    0x1f90f0 as uint32_t,
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_1288;
            }
            C2Rust_Block_31::S_1288 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x30 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    0x1f9130 as uint32_t,
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_1290;
            }
            C2Rust_Block_31::S_1290 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x3c as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    0x1f9150 as uint32_t,
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_1292;
            }
            C2Rust_Block_31::S_1292 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint16_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x44 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    0xc as uint16_t,
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_1298;
            }
            C2Rust_Block_31::S_1298 => {
                _pv_30 = 1 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_1300;
            }
            C2Rust_Block_31::S_1300 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_31 = C2Rust_Block_31::S_1302;
            }
            C2Rust_Block_31::S_1302 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_30,
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_1312;
            }
            C2Rust_Block_31::S_1312 => {
                _pv_31 = 0x76411c as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_1314;
            }
            C2Rust_Block_31::S_1314 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_31 = C2Rust_Block_31::S_1316;
            }
            C2Rust_Block_31::S_1316 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_31,
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_1322;
            }
            C2Rust_Block_31::S_1322 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x764128 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_1324;
            }
            C2Rust_Block_31::S_1324 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x76412c as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_1330;
            }
            C2Rust_Block_31::S_1330 => {
                _pv_32 = 0x1f9bcb as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_1332;
            }
            C2Rust_Block_31::S_1332 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_31 = C2Rust_Block_31::S_1334;
            }
            C2Rust_Block_31::S_1334 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_32,
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_1340;
            }
            C2Rust_Block_31::S_1340 => {
                sub_00204630();
                c2rust_current_block_31 = C2Rust_Block_31::S_1346;
            }
            C2Rust_Block_31::S_1346 => {
                _fb = 0xc as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_1348;
            }
            C2Rust_Block_31::S_1348 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_1350;
            }
            C2Rust_Block_31::S_1350 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(0xc as uint32_t);
                c2rust_current_block_31 = C2Rust_Block_31::S_1352;
            }
            C2Rust_Block_31::S_1352 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_1354;
            }
            C2Rust_Block_31::S_1354 => {
                _fas = _fa as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_1356;
            }
            C2Rust_Block_31::S_1356 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_1358;
            }
            C2Rust_Block_31::S_1358 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_1360;
            }
            C2Rust_Block_31::S_1360 => {
                _fas = _fa as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_1362;
            }
            C2Rust_Block_31::S_1362 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_1364;
            }
            C2Rust_Block_31::S_1364 => {
                if _fa == _fb {
                    c2rust_current_block_31 = C2Rust_Block_31::S_1524;
                } else {
                    c2rust_current_block_31 = C2Rust_Block_31::S_1377;
                }
            }
            C2Rust_Block_31::S_1377 => {
                _pv_33 = 1 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_1379;
            }
            C2Rust_Block_31::S_1379 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_31 = C2Rust_Block_31::S_1381;
            }
            C2Rust_Block_31::S_1381 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_33,
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_1391;
            }
            C2Rust_Block_31::S_1391 => {
                _pv_34 = 0 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_1393;
            }
            C2Rust_Block_31::S_1393 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_31 = C2Rust_Block_31::S_1395;
            }
            C2Rust_Block_31::S_1395 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_34,
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_1405;
            }
            C2Rust_Block_31::S_1405 => {
                _pv_35 = 0x764130 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_1407;
            }
            C2Rust_Block_31::S_1407 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_31 = C2Rust_Block_31::S_1409;
            }
            C2Rust_Block_31::S_1409 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_35,
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_1419;
            }
            C2Rust_Block_31::S_1419 => {
                _pv_36 = 0x1f9be0 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_1421;
            }
            C2Rust_Block_31::S_1421 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_31 = C2Rust_Block_31::S_1423;
            }
            C2Rust_Block_31::S_1423 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_36,
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_1429;
            }
            C2Rust_Block_31::S_1429 => {
                sub_00204630();
                c2rust_current_block_31 = C2Rust_Block_31::S_1435;
            }
            C2Rust_Block_31::S_1435 => {
                _fb = 0xc as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_1437;
            }
            C2Rust_Block_31::S_1437 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_1439;
            }
            C2Rust_Block_31::S_1439 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(0xc as uint32_t);
                c2rust_current_block_31 = C2Rust_Block_31::S_1441;
            }
            C2Rust_Block_31::S_1441 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_1443;
            }
            C2Rust_Block_31::S_1443 => {
                _fas = _fa as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_1445;
            }
            C2Rust_Block_31::S_1445 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_1447;
            }
            C2Rust_Block_31::S_1447 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_1449;
            }
            C2Rust_Block_31::S_1449 => {
                _fas = _fa as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_1451;
            }
            C2Rust_Block_31::S_1451 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_1453;
            }
            C2Rust_Block_31::S_1453 => {
                if _fa == _fb {
                    c2rust_current_block_31 = C2Rust_Block_31::S_1484;
                } else {
                    c2rust_current_block_31 = C2Rust_Block_31::S_1462;
                }
            }
            C2Rust_Block_31::S_1462 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x764120 as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    0 as uint32_t,
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_1468;
            }
            C2Rust_Block_31::S_1468 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_1470;
            }
            C2Rust_Block_31::S_1470 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_31 = C2Rust_Block_31::S_1476;
            }
            C2Rust_Block_31::S_1476 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_31 = C2Rust_Block_31::S_1478;
            }
            C2Rust_Block_31::S_1478 => return,
            C2Rust_Block_31::S_1484 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (0x76411c as ::core::ffi::c_int as uint32_t as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_1490;
            }
            C2Rust_Block_31::S_1490 => {
                _pv_37 = (*__gamepkg_tls_g_eax);
                c2rust_current_block_31 = C2Rust_Block_31::S_1492;
            }
            C2Rust_Block_31::S_1492 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_31 = C2Rust_Block_31::S_1494;
            }
            C2Rust_Block_31::S_1494 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_37,
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_1504;
            }
            C2Rust_Block_31::S_1504 => {
                _pv_38 = 0x1f9bfe as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_31 = C2Rust_Block_31::S_1506;
            }
            C2Rust_Block_31::S_1506 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_31 = C2Rust_Block_31::S_1508;
            }
            C2Rust_Block_31::S_1508 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_38,
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_1514;
            }
            C2Rust_Block_31::S_1514 => {
                sub_001D19FD();
                c2rust_current_block_31 = C2Rust_Block_31::S_1524;
            }
            C2Rust_Block_31::S_1524 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_31 = C2Rust_Block_31::S_1526;
            }
            C2Rust_Block_31::S_1526 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_31 = C2Rust_Block_31::S_1532;
            }
            C2Rust_Block_31::S_1532 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_31 = C2Rust_Block_31::S_1534;
            }
            C2Rust_Block_31::S_1534 => return,
        }
    };
}
#[no_mangle]
pub unsafe extern "C" fn sub_001F9C00() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    let mut _pv_0: uint32_t = 0x3080f as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    let mut _pv_1: uint32_t = 0 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    let mut _pv_2: uint32_t = 0 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_2,
    );
    let mut _pv_3: uint32_t = 0x41b6e0 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_3,
    );
    let mut _pv_4: uint32_t = 0 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_4,
    );
    let mut _pv_5: uint32_t = 0 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_5,
    );
    let mut _pv_6: uint32_t = 0x36ea28 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_6,
    );
    let mut _pv_7: uint32_t = 0 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_7,
    );
    let mut _pv_8: uint32_t = 0x1f9c1f as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_8,
    );
    sub_001F8B10();
    _fb = 0xc as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t);
    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    let mut _pv_9: uint32_t = (*__gamepkg_tls_g_eax);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_9,
    );
    let mut _pv_10: uint32_t = 0x1f9c28 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_10,
    );
    sub_001F8E20();
    (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_eax);
    _fb = 0x18 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(0x18 as uint32_t);
    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_261: {
        if _fa != _fb {
            break 's_261;
        }
        (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        return;
    }
    let mut _pv_11: uint32_t = 0x1f9c38 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_11,
    );
    sub_001F9970();
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001F9C40() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0;
    let mut _fa: uint32_t = 0;
    let mut _fb: uint32_t = 0;
    let mut _fas: int32_t = 0;
    let mut _fbs: int32_t = 0;
    let mut _pv: uint32_t = 0;
    let mut _pv_0: uint32_t = 0;
    let mut _pv_1: uint32_t = 0;
    let mut _pv_2: uint32_t = 0;
    let mut _pv_3: uint32_t = 0;
    let mut _pv_4: uint32_t = 0;
    let mut _pv_5: uint32_t = 0;
    let mut _pv_6: uint32_t = 0;
    let mut _pv_7: uint32_t = 0;
    let mut _pv_8: uint32_t = 0;
    let mut _pv_9: uint32_t = 0;
    let mut _pv_10: uint32_t = 0;
    let mut _pv_11: uint32_t = 0;
    let mut _pv_12: uint32_t = 0;
    let mut _pv_13: uint32_t = 0;
    let mut _pv_14: uint32_t = 0;
    let mut _pv_15: uint32_t = 0;
    let mut _pv_16: uint32_t = 0;
    let mut _pv_17: uint32_t = 0;
    let mut _pv_18: uint32_t = 0;
    let mut _pv_19: uint32_t = 0;
    let mut _pv_20: uint32_t = 0;
    let mut _pv_21: uint32_t = 0;
    let mut _pv_22: uint32_t = 0;
    let mut _pv_23: uint32_t = 0;
    let mut _pv_24: uint32_t = 0;
    enum C2Rust_Block_33 {
        S_0,
        S_2,
        S_4,
        S_22,
        S_24,
        S_26,
        S_36,
        S_38,
        S_40,
        S_50,
        S_52,
        S_54,
        S_64,
        S_66,
        S_68,
        S_78,
        S_80,
        S_82,
        S_92,
        S_94,
        S_96,
        S_106,
        S_108,
        S_110,
        S_120,
        S_122,
        S_124,
        S_134,
        S_136,
        S_138,
        S_148,
        S_150,
        S_152,
        S_158,
        S_164,
        S_166,
        S_168,
        S_170,
        S_172,
        S_178,
        S_180,
        S_182,
        S_192,
        S_194,
        S_196,
        S_202,
        S_208,
        S_210,
        S_212,
        S_214,
        S_216,
        S_218,
        S_220,
        S_222,
        S_224,
        S_226,
        S_228,
        S_241,
        S_243,
        S_245,
        S_251,
        S_261,
        S_263,
        S_265,
        S_275,
        S_277,
        S_279,
        S_289,
        S_291,
        S_293,
        S_303,
        S_305,
        S_307,
        S_317,
        S_319,
        S_321,
        S_331,
        S_333,
        S_335,
        S_341,
        S_347,
        S_349,
        S_351,
        S_353,
        S_355,
        S_357,
        S_359,
        S_361,
        S_363,
        S_365,
        S_378,
        S_380,
        S_382,
        S_392,
        S_394,
        S_396,
        S_402,
        S_408,
        S_410,
        S_412,
        S_414,
        S_416,
        S_422,
        S_424,
        S_426,
        S_432,
        S_434,
        S_440,
        S_442,
        S_452,
        S_454,
        S_456,
        S_466,
        S_468,
        S_470,
        S_476,
        S_486,
        S_488,
        S_490,
        S_500,
        S_502,
        S_504,
        S_514,
        S_516,
        S_518,
        S_524,
        S_530,
        S_532,
        S_534,
        S_536,
        S_538,
        S_540,
        S_546,
        S_548,
        S_554,
        S_556,
    }
    let mut c2rust_current_block_33: C2Rust_Block_33;
    c2rust_current_block_33 = C2Rust_Block_33::S_0;
    loop {
        match c2rust_current_block_33 {
            C2Rust_Block_33::S_0 => {
                _flags = 0 as ::core::ffi::c_int;
                c2rust_current_block_33 = C2Rust_Block_33::S_2;
            }
            C2Rust_Block_33::S_2 => {
                _fa = 0 as uint32_t;
                _fb = 0 as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_4;
            }
            C2Rust_Block_33::S_4 => {
                _fas = 0 as int32_t;
                _fbs = 0 as int32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_22;
            }
            C2Rust_Block_33::S_22 => {
                _pv = (*__gamepkg_tls_g_esi);
                c2rust_current_block_33 = C2Rust_Block_33::S_24;
            }
            C2Rust_Block_33::S_24 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_33 = C2Rust_Block_33::S_26;
            }
            C2Rust_Block_33::S_26 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv,
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_36;
            }
            C2Rust_Block_33::S_36 => {
                _pv_0 = 0x3080f as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_38;
            }
            C2Rust_Block_33::S_38 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_33 = C2Rust_Block_33::S_40;
            }
            C2Rust_Block_33::S_40 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_0,
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_50;
            }
            C2Rust_Block_33::S_50 => {
                _pv_1 = 0x41b6c0 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_52;
            }
            C2Rust_Block_33::S_52 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_33 = C2Rust_Block_33::S_54;
            }
            C2Rust_Block_33::S_54 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_1,
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_64;
            }
            C2Rust_Block_33::S_64 => {
                _pv_2 = 0x41b6c8 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_66;
            }
            C2Rust_Block_33::S_66 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_33 = C2Rust_Block_33::S_68;
            }
            C2Rust_Block_33::S_68 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_2,
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_78;
            }
            C2Rust_Block_33::S_78 => {
                _pv_3 = 0x41b6e0 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_80;
            }
            C2Rust_Block_33::S_80 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_33 = C2Rust_Block_33::S_82;
            }
            C2Rust_Block_33::S_82 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_3,
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_92;
            }
            C2Rust_Block_33::S_92 => {
                _pv_4 = 0xc as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_94;
            }
            C2Rust_Block_33::S_94 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_33 = C2Rust_Block_33::S_96;
            }
            C2Rust_Block_33::S_96 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_4,
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_106;
            }
            C2Rust_Block_33::S_106 => {
                _pv_5 = 0 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_108;
            }
            C2Rust_Block_33::S_108 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_33 = C2Rust_Block_33::S_110;
            }
            C2Rust_Block_33::S_110 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_5,
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_120;
            }
            C2Rust_Block_33::S_120 => {
                _pv_6 = 0x36ea28 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_122;
            }
            C2Rust_Block_33::S_122 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_33 = C2Rust_Block_33::S_124;
            }
            C2Rust_Block_33::S_124 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_6,
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_134;
            }
            C2Rust_Block_33::S_134 => {
                _pv_7 = 0 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_136;
            }
            C2Rust_Block_33::S_136 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_33 = C2Rust_Block_33::S_138;
            }
            C2Rust_Block_33::S_138 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_7,
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_148;
            }
            C2Rust_Block_33::S_148 => {
                _pv_8 = 0x1f9c65 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_150;
            }
            C2Rust_Block_33::S_150 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_33 = C2Rust_Block_33::S_152;
            }
            C2Rust_Block_33::S_152 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_8,
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_158;
            }
            C2Rust_Block_33::S_158 => {
                sub_001F8B10();
                c2rust_current_block_33 = C2Rust_Block_33::S_164;
            }
            C2Rust_Block_33::S_164 => {
                _fb = 0xc as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_166;
            }
            C2Rust_Block_33::S_166 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_168;
            }
            C2Rust_Block_33::S_168 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(0xc as uint32_t);
                c2rust_current_block_33 = C2Rust_Block_33::S_170;
            }
            C2Rust_Block_33::S_170 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_172;
            }
            C2Rust_Block_33::S_172 => {
                _fas = _fa as int32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_178;
            }
            C2Rust_Block_33::S_178 => {
                _pv_9 = (*__gamepkg_tls_g_eax);
                c2rust_current_block_33 = C2Rust_Block_33::S_180;
            }
            C2Rust_Block_33::S_180 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_33 = C2Rust_Block_33::S_182;
            }
            C2Rust_Block_33::S_182 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_9,
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_192;
            }
            C2Rust_Block_33::S_192 => {
                _pv_10 = 0x1f9c6e as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_194;
            }
            C2Rust_Block_33::S_194 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_33 = C2Rust_Block_33::S_196;
            }
            C2Rust_Block_33::S_196 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_10,
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_202;
            }
            C2Rust_Block_33::S_202 => {
                sub_001F8E20();
                c2rust_current_block_33 = C2Rust_Block_33::S_208;
            }
            C2Rust_Block_33::S_208 => {
                (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_eax);
                c2rust_current_block_33 = C2Rust_Block_33::S_210;
            }
            C2Rust_Block_33::S_210 => {
                _fb = 0x18 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_212;
            }
            C2Rust_Block_33::S_212 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_214;
            }
            C2Rust_Block_33::S_214 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(0x18 as uint32_t);
                c2rust_current_block_33 = C2Rust_Block_33::S_216;
            }
            C2Rust_Block_33::S_216 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_218;
            }
            C2Rust_Block_33::S_218 => {
                _fas = _fa as int32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_220;
            }
            C2Rust_Block_33::S_220 => {
                _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_222;
            }
            C2Rust_Block_33::S_222 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_224;
            }
            C2Rust_Block_33::S_224 => {
                _fas = _fa as int32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_226;
            }
            C2Rust_Block_33::S_226 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_228;
            }
            C2Rust_Block_33::S_228 => {
                if _fa == _fb {
                    c2rust_current_block_33 = C2Rust_Block_33::S_422;
                } else {
                    c2rust_current_block_33 = C2Rust_Block_33::S_241;
                }
            }
            C2Rust_Block_33::S_241 => {
                _pv_11 = 0x1f9c7c as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_243;
            }
            C2Rust_Block_33::S_243 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_33 = C2Rust_Block_33::S_245;
            }
            C2Rust_Block_33::S_245 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_11,
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_251;
            }
            C2Rust_Block_33::S_251 => {
                sub_001F9970();
                c2rust_current_block_33 = C2Rust_Block_33::S_261;
            }
            C2Rust_Block_33::S_261 => {
                _pv_12 = 0xa as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_263;
            }
            C2Rust_Block_33::S_263 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_33 = C2Rust_Block_33::S_265;
            }
            C2Rust_Block_33::S_265 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_12,
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_275;
            }
            C2Rust_Block_33::S_275 => {
                _pv_13 = 0x3c1490 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_277;
            }
            C2Rust_Block_33::S_277 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_33 = C2Rust_Block_33::S_279;
            }
            C2Rust_Block_33::S_279 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_13,
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_289;
            }
            C2Rust_Block_33::S_289 => {
                _pv_14 = 6 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_291;
            }
            C2Rust_Block_33::S_291 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_33 = C2Rust_Block_33::S_293;
            }
            C2Rust_Block_33::S_293 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_14,
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_303;
            }
            C2Rust_Block_33::S_303 => {
                _pv_15 = 0x3c1400 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_305;
            }
            C2Rust_Block_33::S_305 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_33 = C2Rust_Block_33::S_307;
            }
            C2Rust_Block_33::S_307 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_15,
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_317;
            }
            C2Rust_Block_33::S_317 => {
                _pv_16 = (*__gamepkg_tls_g_esi);
                c2rust_current_block_33 = C2Rust_Block_33::S_319;
            }
            C2Rust_Block_33::S_319 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_33 = C2Rust_Block_33::S_321;
            }
            C2Rust_Block_33::S_321 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_16,
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_331;
            }
            C2Rust_Block_33::S_331 => {
                _pv_17 = 0x1f9c90 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_333;
            }
            C2Rust_Block_33::S_333 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_33 = C2Rust_Block_33::S_335;
            }
            C2Rust_Block_33::S_335 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_17,
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_341;
            }
            C2Rust_Block_33::S_341 => {
                sub_001F8B70();
                c2rust_current_block_33 = C2Rust_Block_33::S_347;
            }
            C2Rust_Block_33::S_347 => {
                _fb = 0x14 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_349;
            }
            C2Rust_Block_33::S_349 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_351;
            }
            C2Rust_Block_33::S_351 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(0x14 as uint32_t);
                c2rust_current_block_33 = C2Rust_Block_33::S_353;
            }
            C2Rust_Block_33::S_353 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_355;
            }
            C2Rust_Block_33::S_355 => {
                _fas = _fa as int32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_357;
            }
            C2Rust_Block_33::S_357 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_359;
            }
            C2Rust_Block_33::S_359 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_361;
            }
            C2Rust_Block_33::S_361 => {
                _fas = _fa as int32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_363;
            }
            C2Rust_Block_33::S_363 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_365;
            }
            C2Rust_Block_33::S_365 => {
                if _fa != _fb {
                    c2rust_current_block_33 = C2Rust_Block_33::S_452;
                } else {
                    c2rust_current_block_33 = C2Rust_Block_33::S_378;
                }
            }
            C2Rust_Block_33::S_378 => {
                _pv_18 = (*__gamepkg_tls_g_esi);
                c2rust_current_block_33 = C2Rust_Block_33::S_380;
            }
            C2Rust_Block_33::S_380 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_33 = C2Rust_Block_33::S_382;
            }
            C2Rust_Block_33::S_382 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_18,
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_392;
            }
            C2Rust_Block_33::S_392 => {
                _pv_19 = 0x1f9c9d as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_394;
            }
            C2Rust_Block_33::S_394 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_33 = C2Rust_Block_33::S_396;
            }
            C2Rust_Block_33::S_396 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_19,
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_402;
            }
            C2Rust_Block_33::S_402 => {
                sub_001F8970();
                c2rust_current_block_33 = C2Rust_Block_33::S_408;
            }
            C2Rust_Block_33::S_408 => {
                _fb = 4 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_410;
            }
            C2Rust_Block_33::S_410 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_412;
            }
            C2Rust_Block_33::S_412 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_33 = C2Rust_Block_33::S_414;
            }
            C2Rust_Block_33::S_414 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_416;
            }
            C2Rust_Block_33::S_416 => {
                _fas = _fa as int32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_422;
            }
            C2Rust_Block_33::S_422 => {
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_424;
            }
            C2Rust_Block_33::S_424 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_426;
            }
            C2Rust_Block_33::S_426 => {
                _fas = _fa as int32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_432;
            }
            C2Rust_Block_33::S_432 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_434;
            }
            C2Rust_Block_33::S_434 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_33 = C2Rust_Block_33::S_440;
            }
            C2Rust_Block_33::S_440 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_33 = C2Rust_Block_33::S_442;
            }
            C2Rust_Block_33::S_442 => return,
            C2Rust_Block_33::S_452 => {
                _pv_20 = 0x36e290 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_454;
            }
            C2Rust_Block_33::S_454 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_33 = C2Rust_Block_33::S_456;
            }
            C2Rust_Block_33::S_456 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_20,
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_466;
            }
            C2Rust_Block_33::S_466 => {
                _pv_21 = 0x1f9cae as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_468;
            }
            C2Rust_Block_33::S_468 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_33 = C2Rust_Block_33::S_470;
            }
            C2Rust_Block_33::S_470 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_21,
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_476;
            }
            C2Rust_Block_33::S_476 => {
                sub_001FD6C0();
                c2rust_current_block_33 = C2Rust_Block_33::S_486;
            }
            C2Rust_Block_33::S_486 => {
                _pv_22 = (*__gamepkg_tls_g_eax);
                c2rust_current_block_33 = C2Rust_Block_33::S_488;
            }
            C2Rust_Block_33::S_488 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_33 = C2Rust_Block_33::S_490;
            }
            C2Rust_Block_33::S_490 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_22,
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_500;
            }
            C2Rust_Block_33::S_500 => {
                _pv_23 = (*__gamepkg_tls_g_esi);
                c2rust_current_block_33 = C2Rust_Block_33::S_502;
            }
            C2Rust_Block_33::S_502 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_33 = C2Rust_Block_33::S_504;
            }
            C2Rust_Block_33::S_504 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_23,
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_514;
            }
            C2Rust_Block_33::S_514 => {
                _pv_24 = 0x1f9cb5 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_516;
            }
            C2Rust_Block_33::S_516 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_33 = C2Rust_Block_33::S_518;
            }
            C2Rust_Block_33::S_518 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_24,
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_524;
            }
            C2Rust_Block_33::S_524 => {
                sub_001F8520();
                c2rust_current_block_33 = C2Rust_Block_33::S_530;
            }
            C2Rust_Block_33::S_530 => {
                _fb = 0xc as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_532;
            }
            C2Rust_Block_33::S_532 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_534;
            }
            C2Rust_Block_33::S_534 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(0xc as uint32_t);
                c2rust_current_block_33 = C2Rust_Block_33::S_536;
            }
            C2Rust_Block_33::S_536 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_538;
            }
            C2Rust_Block_33::S_538 => {
                _fas = _fa as int32_t;
                c2rust_current_block_33 = C2Rust_Block_33::S_540;
            }
            C2Rust_Block_33::S_540 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_esi);
                c2rust_current_block_33 = C2Rust_Block_33::S_546;
            }
            C2Rust_Block_33::S_546 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_33 = C2Rust_Block_33::S_548;
            }
            C2Rust_Block_33::S_548 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_33 = C2Rust_Block_33::S_554;
            }
            C2Rust_Block_33::S_554 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_33 = C2Rust_Block_33::S_556;
            }
            C2Rust_Block_33::S_556 => return,
        }
    };
}
#[no_mangle]
pub unsafe extern "C" fn sub_001F9CC0() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _pv: uint32_t = 0x40805 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    let mut _pv_0: uint32_t = 0x41b744 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    let mut _pv_1: uint32_t = 0 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    let mut _pv_2: uint32_t = 8 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_2,
    );
    let mut _pv_3: uint32_t = 8 as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_3,
    );
    let mut _pv_4: uint32_t = 0x6c as ::core::ffi::c_int as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_4,
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (0x41b768 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        1 as uint32_t,
    );
    let mut _pv_5: uint32_t = 0x1f9ce1 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_5,
    );
    sub_001FEBF0();
    _fb = 0x18 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(0x18 as uint32_t);
    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_161: {
        if _fa == _fb {
            break 's_161;
        }
        (*__gamepkg_tls_g_eax) = 1 as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        return;
    }
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            (0x41b768 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        0 as uint32_t,
    );
    (*__gamepkg_tls_g_eax) = 0 as uint32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001F9D00() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_ebx = unsafe { gamepkg_tls_g_ebx() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let mut ebp: uint32_t = 0;
    let mut _flags: ::core::ffi::c_int = 0;
    let mut _fa: uint32_t = 0;
    let mut _fb: uint32_t = 0;
    let mut _fas: int32_t = 0;
    let mut _fbs: int32_t = 0;
    let mut _pv: uint32_t = 0;
    let mut _pv_0: uint32_t = 0;
    let mut _pv_1: uint32_t = 0;
    let mut _pv_2: uint32_t = 0;
    let mut _pv_3: uint32_t = 0;
    let mut _pv_4: uint32_t = 0;
    let mut _pv_5: uint32_t = 0;
    let mut _pv_6: uint32_t = 0;
    let mut _pv_7: uint32_t = 0;
    let mut _pv_8: uint32_t = 0;
    let mut _pv_9: uint32_t = 0;
    let mut _icall_esp: uint32_t = 0;
    let mut _pv_10: uint32_t = 0;
    let mut _pv_11: uint32_t = 0;
    let mut _icall_target: uint32_t = 0;
    let mut _pv_12: uint32_t = 0;
    let mut _va: uint32_t = 0;
    let mut _fn: recomp_func_t = None;
    enum C2Rust_Block_35 {
        S_0,
        S_2,
        S_4,
        S_6,
        S_8,
        S_18,
        S_28,
        S_30,
        S_32,
        S_42,
        S_44,
        S_46,
        S_56,
        S_58,
        S_60,
        S_70,
        S_72,
        S_74,
        S_80,
        S_86,
        S_88,
        S_90,
        S_92,
        S_94,
        S_96,
        S_98,
        S_100,
        S_102,
        S_104,
        S_117,
        S_119,
        S_121,
        S_131,
        S_133,
        S_135,
        S_149,
        S_151,
        S_153,
        S_163,
        S_165,
        S_167,
        S_173,
        S_179,
        S_181,
        S_183,
        S_185,
        S_187,
        S_189,
        S_191,
        S_193,
        S_195,
        S_197,
        S_199,
        S_201,
        S_214,
        S_216,
        S_218,
        S_220,
        S_222,
        S_228,
        S_230,
        S_232,
        S_242,
        S_244,
        S_246,
        S_256,
        S_258,
        S_260,
        S_266,
        S_272,
        S_274,
        S_276,
        S_278,
        S_280,
        S_282,
        S_284,
        S_286,
        S_288,
        S_290,
        S_299,
        S_302,
        S_308,
        S_310,
        S_312,
        S_322,
        S_324,
        S_326,
        S_333,
        S_339,
        S_341,
        S_343,
        S_353,
        S_355,
        S_357,
        S_359,
        S_361,
        S_364,
        S_366,
        S_368,
        S_376,
        S_378,
        S_380,
        S_384,
        S_386,
        S_390,
        S_396,
        S_403,
        S_405,
        S_407,
        S_425,
        S_427,
        S_429,
        S_431,
        S_433,
        S_435,
        S_437,
        S_439,
        S_441,
        S_443,
        S_452,
        S_454,
        S_456,
        S_458,
        S_460,
        S_469,
        S_475,
        S_477,
        S_479,
        S_481,
        S_483,
        S_485,
        S_487,
        S_489,
        S_491,
        S_504,
        S_506,
        S_516,
        S_518,
        S_528,
        S_534,
        S_536,
        S_546,
        S_548,
        S_558,
        S_560,
        S_566,
        S_568,
    }
    let mut c2rust_current_block_35: C2Rust_Block_35;
    c2rust_current_block_35 = C2Rust_Block_35::S_0;
    loop {
        match c2rust_current_block_35 {
            C2Rust_Block_35::S_0 => {
                ebp = 0 as uint32_t;
                c2rust_current_block_35 = C2Rust_Block_35::S_2;
            }
            C2Rust_Block_35::S_2 => {
                ebp = (*__gamepkg_tls_g_ebp);
                c2rust_current_block_35 = C2Rust_Block_35::S_4;
            }
            C2Rust_Block_35::S_4 => {
                _flags = 0 as ::core::ffi::c_int;
                c2rust_current_block_35 = C2Rust_Block_35::S_6;
            }
            C2Rust_Block_35::S_6 => {
                _fa = 0 as uint32_t;
                _fb = 0 as uint32_t;
                c2rust_current_block_35 = C2Rust_Block_35::S_8;
            }
            C2Rust_Block_35::S_8 => {
                _fas = 0 as int32_t;
                _fbs = 0 as int32_t;
                c2rust_current_block_35 = C2Rust_Block_35::S_18;
            }
            C2Rust_Block_35::S_18 => {
                ebp = (*__gamepkg_tls_g_seh_ebp);
                c2rust_current_block_35 = C2Rust_Block_35::S_28;
            }
            C2Rust_Block_35::S_28 => {
                _pv = (*__gamepkg_tls_g_ecx);
                c2rust_current_block_35 = C2Rust_Block_35::S_30;
            }
            C2Rust_Block_35::S_30 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_35 = C2Rust_Block_35::S_32;
            }
            C2Rust_Block_35::S_32 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv,
                );
                c2rust_current_block_35 = C2Rust_Block_35::S_42;
            }
            C2Rust_Block_35::S_42 => {
                _pv_0 = ebp;
                c2rust_current_block_35 = C2Rust_Block_35::S_44;
            }
            C2Rust_Block_35::S_44 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_35 = C2Rust_Block_35::S_46;
            }
            C2Rust_Block_35::S_46 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_0,
                );
                c2rust_current_block_35 = C2Rust_Block_35::S_56;
            }
            C2Rust_Block_35::S_56 => {
                _pv_1 = (*__gamepkg_tls_g_edi);
                c2rust_current_block_35 = C2Rust_Block_35::S_58;
            }
            C2Rust_Block_35::S_58 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_35 = C2Rust_Block_35::S_60;
            }
            C2Rust_Block_35::S_60 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_1,
                );
                c2rust_current_block_35 = C2Rust_Block_35::S_70;
            }
            C2Rust_Block_35::S_70 => {
                _pv_2 = 0x1f9d08 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_35 = C2Rust_Block_35::S_72;
            }
            C2Rust_Block_35::S_72 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_35 = C2Rust_Block_35::S_74;
            }
            C2Rust_Block_35::S_74 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_2,
                );
                c2rust_current_block_35 = C2Rust_Block_35::S_80;
            }
            C2Rust_Block_35::S_80 => {
                sub_001F64A0();
                c2rust_current_block_35 = C2Rust_Block_35::S_86;
            }
            C2Rust_Block_35::S_86 => {
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_eax);
                c2rust_current_block_35 = C2Rust_Block_35::S_88;
            }
            C2Rust_Block_35::S_88 => {
                ebp = 0 as uint32_t;
                c2rust_current_block_35 = C2Rust_Block_35::S_90;
            }
            C2Rust_Block_35::S_90 => {
                _fa = ebp & 0xffffffff as uint32_t;
                c2rust_current_block_35 = C2Rust_Block_35::S_92;
            }
            C2Rust_Block_35::S_92 => {
                _fas = _fa as int32_t;
                c2rust_current_block_35 = C2Rust_Block_35::S_94;
            }
            C2Rust_Block_35::S_94 => {
                _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                c2rust_current_block_35 = C2Rust_Block_35::S_96;
            }
            C2Rust_Block_35::S_96 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_35 = C2Rust_Block_35::S_98;
            }
            C2Rust_Block_35::S_98 => {
                _fas = _fa as int32_t;
                c2rust_current_block_35 = C2Rust_Block_35::S_100;
            }
            C2Rust_Block_35::S_100 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_35 = C2Rust_Block_35::S_102;
            }
            C2Rust_Block_35::S_102 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_edi),
                );
                c2rust_current_block_35 = C2Rust_Block_35::S_104;
            }
            C2Rust_Block_35::S_104 => {
                if _fa <= _fb {
                    c2rust_current_block_35 = C2Rust_Block_35::S_528;
                } else {
                    c2rust_current_block_35 = C2Rust_Block_35::S_117;
                }
            }
            C2Rust_Block_35::S_117 => {
                _pv_3 = (*__gamepkg_tls_g_ebx);
                c2rust_current_block_35 = C2Rust_Block_35::S_119;
            }
            C2Rust_Block_35::S_119 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_35 = C2Rust_Block_35::S_121;
            }
            C2Rust_Block_35::S_121 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_3,
                );
                c2rust_current_block_35 = C2Rust_Block_35::S_131;
            }
            C2Rust_Block_35::S_131 => {
                _pv_4 = (*__gamepkg_tls_g_esi);
                c2rust_current_block_35 = C2Rust_Block_35::S_133;
            }
            C2Rust_Block_35::S_133 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_35 = C2Rust_Block_35::S_135;
            }
            C2Rust_Block_35::S_135 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_4,
                );
                c2rust_current_block_35 = C2Rust_Block_35::S_149;
            }
            C2Rust_Block_35::S_149 => {
                _pv_5 = ebp;
                c2rust_current_block_35 = C2Rust_Block_35::S_151;
            }
            C2Rust_Block_35::S_151 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_35 = C2Rust_Block_35::S_153;
            }
            C2Rust_Block_35::S_153 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_5,
                );
                c2rust_current_block_35 = C2Rust_Block_35::S_163;
            }
            C2Rust_Block_35::S_163 => {
                _pv_6 = 0x1f9d1c as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_35 = C2Rust_Block_35::S_165;
            }
            C2Rust_Block_35::S_165 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_35 = C2Rust_Block_35::S_167;
            }
            C2Rust_Block_35::S_167 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_6,
                );
                c2rust_current_block_35 = C2Rust_Block_35::S_173;
            }
            C2Rust_Block_35::S_173 => {
                sub_001F6470();
                c2rust_current_block_35 = C2Rust_Block_35::S_179;
            }
            C2Rust_Block_35::S_179 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax).wrapping_add(0x10 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_35 = C2Rust_Block_35::S_181;
            }
            C2Rust_Block_35::S_181 => {
                (*__gamepkg_tls_g_ebx) = (*__gamepkg_tls_g_eax)
                    .wrapping_add(0xc as uint32_t);
                c2rust_current_block_35 = C2Rust_Block_35::S_183;
            }
            C2Rust_Block_35::S_183 => {
                _fb = 4 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_35 = C2Rust_Block_35::S_185;
            }
            C2Rust_Block_35::S_185 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_35 = C2Rust_Block_35::S_187;
            }
            C2Rust_Block_35::S_187 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_35 = C2Rust_Block_35::S_189;
            }
            C2Rust_Block_35::S_189 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_35 = C2Rust_Block_35::S_191;
            }
            C2Rust_Block_35::S_191 => {
                _fas = _fa as int32_t;
                c2rust_current_block_35 = C2Rust_Block_35::S_193;
            }
            C2Rust_Block_35::S_193 => {
                _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
                c2rust_current_block_35 = C2Rust_Block_35::S_195;
            }
            C2Rust_Block_35::S_195 => {
                _fb = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
                c2rust_current_block_35 = C2Rust_Block_35::S_197;
            }
            C2Rust_Block_35::S_197 => {
                _fas = _fa as int32_t;
                c2rust_current_block_35 = C2Rust_Block_35::S_199;
            }
            C2Rust_Block_35::S_199 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_35 = C2Rust_Block_35::S_201;
            }
            C2Rust_Block_35::S_201 => {
                if _fa == _fb {
                    c2rust_current_block_35 = C2Rust_Block_35::S_475;
                } else {
                    c2rust_current_block_35 = C2Rust_Block_35::S_214;
                }
            }
            C2Rust_Block_35::S_214 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_35 = C2Rust_Block_35::S_216;
            }
            C2Rust_Block_35::S_216 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x18 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_35 = C2Rust_Block_35::S_218;
            }
            C2Rust_Block_35::S_218 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edi).wrapping_add(0xc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_35 = C2Rust_Block_35::S_220;
            }
            C2Rust_Block_35::S_220 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ecx) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_35 = C2Rust_Block_35::S_222;
            }
            C2Rust_Block_35::S_222 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_35 = C2Rust_Block_35::S_228;
            }
            C2Rust_Block_35::S_228 => {
                _pv_7 = (*__gamepkg_tls_g_eax);
                c2rust_current_block_35 = C2Rust_Block_35::S_230;
            }
            C2Rust_Block_35::S_230 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_35 = C2Rust_Block_35::S_232;
            }
            C2Rust_Block_35::S_232 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_7,
                );
                c2rust_current_block_35 = C2Rust_Block_35::S_242;
            }
            C2Rust_Block_35::S_242 => {
                _pv_8 = (*__gamepkg_tls_g_edx);
                c2rust_current_block_35 = C2Rust_Block_35::S_244;
            }
            C2Rust_Block_35::S_244 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_35 = C2Rust_Block_35::S_246;
            }
            C2Rust_Block_35::S_246 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_8,
                );
                c2rust_current_block_35 = C2Rust_Block_35::S_256;
            }
            C2Rust_Block_35::S_256 => {
                _pv_9 = 0x1f9d46 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_35 = C2Rust_Block_35::S_258;
            }
            C2Rust_Block_35::S_258 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_35 = C2Rust_Block_35::S_260;
            }
            C2Rust_Block_35::S_260 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_9,
                );
                c2rust_current_block_35 = C2Rust_Block_35::S_266;
            }
            C2Rust_Block_35::S_266 => {
                sub_001FE270();
                c2rust_current_block_35 = C2Rust_Block_35::S_272;
            }
            C2Rust_Block_35::S_272 => {
                _fb = 8 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_35 = C2Rust_Block_35::S_274;
            }
            C2Rust_Block_35::S_274 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_35 = C2Rust_Block_35::S_276;
            }
            C2Rust_Block_35::S_276 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(8 as uint32_t);
                c2rust_current_block_35 = C2Rust_Block_35::S_278;
            }
            C2Rust_Block_35::S_278 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_35 = C2Rust_Block_35::S_280;
            }
            C2Rust_Block_35::S_280 => {
                _fas = _fa as int32_t;
                c2rust_current_block_35 = C2Rust_Block_35::S_282;
            }
            C2Rust_Block_35::S_282 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_35 = C2Rust_Block_35::S_284;
            }
            C2Rust_Block_35::S_284 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_35 = C2Rust_Block_35::S_286;
            }
            C2Rust_Block_35::S_286 => {
                _fas = _fa as int32_t;
                c2rust_current_block_35 = C2Rust_Block_35::S_288;
            }
            C2Rust_Block_35::S_288 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_35 = C2Rust_Block_35::S_290;
            }
            C2Rust_Block_35::S_290 => {
                if _fa != _fb {
                    c2rust_current_block_35 = C2Rust_Block_35::S_452;
                } else {
                    c2rust_current_block_35 = C2Rust_Block_35::S_299;
                }
            }
            C2Rust_Block_35::S_299 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x20 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_35 = C2Rust_Block_35::S_302;
            }
            C2Rust_Block_35::S_302 => {
                _icall_esp = (*__gamepkg_tls_g_esp);
                c2rust_current_block_35 = C2Rust_Block_35::S_308;
            }
            C2Rust_Block_35::S_308 => {
                _pv_10 = (*__gamepkg_tls_g_eax);
                c2rust_current_block_35 = C2Rust_Block_35::S_310;
            }
            C2Rust_Block_35::S_310 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_35 = C2Rust_Block_35::S_312;
            }
            C2Rust_Block_35::S_312 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_10,
                );
                c2rust_current_block_35 = C2Rust_Block_35::S_322;
            }
            C2Rust_Block_35::S_322 => {
                _pv_11 = (*__gamepkg_tls_g_edi);
                c2rust_current_block_35 = C2Rust_Block_35::S_324;
            }
            C2Rust_Block_35::S_324 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_35 = C2Rust_Block_35::S_326;
            }
            C2Rust_Block_35::S_326 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_11,
                );
                c2rust_current_block_35 = C2Rust_Block_35::S_333;
            }
            C2Rust_Block_35::S_333 => {
                _icall_target = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x24 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_35 = C2Rust_Block_35::S_339;
            }
            C2Rust_Block_35::S_339 => {
                _pv_12 = 0x1f9d57 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_35 = C2Rust_Block_35::S_341;
            }
            C2Rust_Block_35::S_341 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_35 = C2Rust_Block_35::S_343;
            }
            C2Rust_Block_35::S_343 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_12,
                );
                c2rust_current_block_35 = C2Rust_Block_35::S_353;
            }
            C2Rust_Block_35::S_353 => {
                _va = _icall_target;
                c2rust_current_block_35 = C2Rust_Block_35::S_355;
            }
            C2Rust_Block_35::S_355 => {
                ::core::ptr::write_volatile(
                    &raw mut g_icall_trace[(::core::ptr::read_volatile::<
                        uint32_t,
                    >(&raw const g_icall_trace_idx)
                        & (ICALL_TRACE_SIZE - 1 as ::core::ffi::c_int) as uint32_t)
                        as usize],
                    _va,
                );
                c2rust_current_block_35 = C2Rust_Block_35::S_357;
            }
            C2Rust_Block_35::S_357 => {
                ::core::ptr::write_volatile(
                    &raw mut g_icall_trace_idx,
                    ::core::ptr::read_volatile::<uint32_t>(&raw const g_icall_trace_idx)
                        .wrapping_add(1),
                );
                c2rust_current_block_35 = C2Rust_Block_35::S_359;
            }
            C2Rust_Block_35::S_359 => {
                ::core::ptr::write_volatile(
                    &raw mut g_icall_count,
                    ::core::ptr::read_volatile::<uint64_t>(&raw const g_icall_count)
                        .wrapping_add(1),
                );
                c2rust_current_block_35 = C2Rust_Block_35::S_361;
            }
            C2Rust_Block_35::S_361 => {
                if !(_va >= 0xfe000000 as uint32_t || g_xbox_code_hi == 0 as uint32_t
                    || _va >= g_xbox_code_lo && _va < g_xbox_code_hi)
                {
                    c2rust_current_block_35 = C2Rust_Block_35::S_364;
                } else {
                    c2rust_current_block_35 = C2Rust_Block_35::S_376;
                }
            }
            C2Rust_Block_35::S_364 => {
                recomp_icall_not_code_log(_va);
                c2rust_current_block_35 = C2Rust_Block_35::S_366;
            }
            C2Rust_Block_35::S_366 => {
                (*__gamepkg_tls_g_esp) = _icall_esp;
                c2rust_current_block_35 = C2Rust_Block_35::S_368;
            }
            C2Rust_Block_35::S_368 => {
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                c2rust_current_block_35 = C2Rust_Block_35::S_425;
            }
            C2Rust_Block_35::S_376 => {
                _fn = recomp_lookup_manual(_va);
                c2rust_current_block_35 = C2Rust_Block_35::S_378;
            }
            C2Rust_Block_35::S_378 => {
                if _fn.is_none() {
                    c2rust_current_block_35 = C2Rust_Block_35::S_380;
                } else {
                    c2rust_current_block_35 = C2Rust_Block_35::S_384;
                }
            }
            C2Rust_Block_35::S_380 => {
                _fn = recomp_lookup(_va);
                c2rust_current_block_35 = C2Rust_Block_35::S_384;
            }
            C2Rust_Block_35::S_384 => {
                if _fn.is_none() {
                    c2rust_current_block_35 = C2Rust_Block_35::S_386;
                } else {
                    c2rust_current_block_35 = C2Rust_Block_35::S_390;
                }
            }
            C2Rust_Block_35::S_386 => {
                _fn = recomp_lookup_kernel(_va);
                c2rust_current_block_35 = C2Rust_Block_35::S_390;
            }
            C2Rust_Block_35::S_390 => {
                if _fn.is_some() {
                    c2rust_current_block_35 = C2Rust_Block_35::S_396;
                } else {
                    c2rust_current_block_35 = C2Rust_Block_35::S_403;
                }
            }
            C2Rust_Block_35::S_396 => {
                _fn.expect("non-null function pointer")();
                c2rust_current_block_35 = C2Rust_Block_35::S_425;
            }
            C2Rust_Block_35::S_403 => {
                recomp_icall_fail_log(_va);
                c2rust_current_block_35 = C2Rust_Block_35::S_405;
            }
            C2Rust_Block_35::S_405 => {
                (*__gamepkg_tls_g_esp) = _icall_esp;
                c2rust_current_block_35 = C2Rust_Block_35::S_407;
            }
            C2Rust_Block_35::S_407 => {
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                c2rust_current_block_35 = C2Rust_Block_35::S_425;
            }
            C2Rust_Block_35::S_425 => {
                _fb = 8 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_35 = C2Rust_Block_35::S_427;
            }
            C2Rust_Block_35::S_427 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_35 = C2Rust_Block_35::S_429;
            }
            C2Rust_Block_35::S_429 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(8 as uint32_t);
                c2rust_current_block_35 = C2Rust_Block_35::S_431;
            }
            C2Rust_Block_35::S_431 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_35 = C2Rust_Block_35::S_433;
            }
            C2Rust_Block_35::S_433 => {
                _fas = _fa as int32_t;
                c2rust_current_block_35 = C2Rust_Block_35::S_435;
            }
            C2Rust_Block_35::S_435 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_35 = C2Rust_Block_35::S_437;
            }
            C2Rust_Block_35::S_437 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_35 = C2Rust_Block_35::S_439;
            }
            C2Rust_Block_35::S_439 => {
                _fas = _fa as int32_t;
                c2rust_current_block_35 = C2Rust_Block_35::S_441;
            }
            C2Rust_Block_35::S_441 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_35 = C2Rust_Block_35::S_443;
            }
            C2Rust_Block_35::S_443 => {
                if _fa == _fb {
                    c2rust_current_block_35 = C2Rust_Block_35::S_469;
                } else {
                    c2rust_current_block_35 = C2Rust_Block_35::S_452;
                }
            }
            C2Rust_Block_35::S_452 => {
                _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
                c2rust_current_block_35 = C2Rust_Block_35::S_454;
            }
            C2Rust_Block_35::S_454 => {
                _fb = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
                c2rust_current_block_35 = C2Rust_Block_35::S_456;
            }
            C2Rust_Block_35::S_456 => {
                _fas = _fa as int32_t;
                c2rust_current_block_35 = C2Rust_Block_35::S_458;
            }
            C2Rust_Block_35::S_458 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_35 = C2Rust_Block_35::S_460;
            }
            C2Rust_Block_35::S_460 => {
                if _fa != _fb {
                    c2rust_current_block_35 = C2Rust_Block_35::S_214;
                } else {
                    c2rust_current_block_35 = C2Rust_Block_35::S_469;
                }
            }
            C2Rust_Block_35::S_469 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x10 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_35 = C2Rust_Block_35::S_475;
            }
            C2Rust_Block_35::S_475 => {
                ebp = ebp.wrapping_add(1);
                c2rust_current_block_35 = C2Rust_Block_35::S_477;
            }
            C2Rust_Block_35::S_477 => {
                _fa = ebp & 0xffffffff as uint32_t;
                c2rust_current_block_35 = C2Rust_Block_35::S_479;
            }
            C2Rust_Block_35::S_479 => {
                _fas = _fa as int32_t;
                c2rust_current_block_35 = C2Rust_Block_35::S_481;
            }
            C2Rust_Block_35::S_481 => {
                _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_35 = C2Rust_Block_35::S_483;
            }
            C2Rust_Block_35::S_483 => {
                _fa = ebp & 0xffffffff as uint32_t;
                c2rust_current_block_35 = C2Rust_Block_35::S_485;
            }
            C2Rust_Block_35::S_485 => {
                _fb = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
                c2rust_current_block_35 = C2Rust_Block_35::S_487;
            }
            C2Rust_Block_35::S_487 => {
                _fas = _fa as int32_t;
                c2rust_current_block_35 = C2Rust_Block_35::S_489;
            }
            C2Rust_Block_35::S_489 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_35 = C2Rust_Block_35::S_491;
            }
            C2Rust_Block_35::S_491 => {
                if _fa < _fb {
                    c2rust_current_block_35 = C2Rust_Block_35::S_149;
                } else {
                    c2rust_current_block_35 = C2Rust_Block_35::S_504;
                }
            }
            C2Rust_Block_35::S_504 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_35 = C2Rust_Block_35::S_506;
            }
            C2Rust_Block_35::S_506 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_35 = C2Rust_Block_35::S_516;
            }
            C2Rust_Block_35::S_516 => {
                (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_35 = C2Rust_Block_35::S_518;
            }
            C2Rust_Block_35::S_518 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_35 = C2Rust_Block_35::S_528;
            }
            C2Rust_Block_35::S_528 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x10 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_35 = C2Rust_Block_35::S_534;
            }
            C2Rust_Block_35::S_534 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_35 = C2Rust_Block_35::S_536;
            }
            C2Rust_Block_35::S_536 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_35 = C2Rust_Block_35::S_546;
            }
            C2Rust_Block_35::S_546 => {
                ebp = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_35 = C2Rust_Block_35::S_548;
            }
            C2Rust_Block_35::S_548 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_35 = C2Rust_Block_35::S_558;
            }
            C2Rust_Block_35::S_558 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_35 = C2Rust_Block_35::S_560;
            }
            C2Rust_Block_35::S_560 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_35 = C2Rust_Block_35::S_566;
            }
            C2Rust_Block_35::S_566 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_35 = C2Rust_Block_35::S_568;
            }
            C2Rust_Block_35::S_568 => return,
        }
    };
}
#[no_mangle]
pub unsafe extern "C" fn sub_001F9D80() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv_0: uint32_t = (*__gamepkg_tls_g_edi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_edi).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv_1: uint32_t = (*__gamepkg_tls_g_eax);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    let mut _pv_2: uint32_t = (*__gamepkg_tls_g_ecx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_2,
    );
    let mut _pv_3: uint32_t = 0x1f9d97 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_3,
    );
    sub_001FE270();
    _fb = 8 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t);
    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_251: {
        if _fa != _fb {
            break 's_251;
        }
        (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_edi) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
        _fb = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fbs = _fb as int32_t;
        if _fa != _fb {
            break 's_251;
        }
        (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 0xffffff00 as uint32_t
            | ::core::ptr::read_volatile::<
                uint8_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint8_t,
                >(
                    ((*__gamepkg_tls_g_edi).wrapping_add(0xc as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            ) as uint32_t;
        _fa = ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t as uint32_t
            & 0xff as uint32_t;
        _fb = ::core::ptr::read_volatile::<
            uint8_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint8_t,
            >(
                ((*__gamepkg_tls_g_esi).wrapping_add(0xc as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ) as uint32_t & 0xff as uint32_t;
        _fas = _fa as int8_t as int32_t;
        _fbs = _fb as int8_t as int32_t;
        if _fa != _fb {
            break 's_251;
        }
        (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx) & 0xffffff00 as uint32_t
            | ::core::ptr::read_volatile::<
                uint8_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint8_t,
                >(
                    ((*__gamepkg_tls_g_edi).wrapping_add(0xd as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            ) as uint32_t;
        _fa = ((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t as uint32_t
            & 0xff as uint32_t;
        _fb = ::core::ptr::read_volatile::<
            uint8_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint8_t,
            >(
                ((*__gamepkg_tls_g_esi).wrapping_add(0xd as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ) as uint32_t & 0xff as uint32_t;
        _fas = _fa as int8_t as int32_t;
        _fbs = _fb as int8_t as int32_t;
        if _fa != _fb {
            break 's_251;
        }
        (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
            uint8_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint8_t,
            >(
                ((*__gamepkg_tls_g_edi).wrapping_add(0x18 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ) as uint32_t;
        (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
            uint8_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint8_t,
            >(
                ((*__gamepkg_tls_g_esi).wrapping_add(0x18 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ) as uint32_t;
        (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_edx) ^ (*__gamepkg_tls_g_eax);
        _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fa = (*__gamepkg_tls_g_edx) & 0xfffffffd as uint32_t & 0xffffffff as uint32_t;
        _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fbs = _fb as int32_t;
        if _fa != _fb {
            break 's_251;
        }
        (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        (*__gamepkg_tls_g_eax) = 1 as uint32_t;
        (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        return;
    }
    (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_eax) = 0 as uint32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001F9DE0() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0;
    let mut _fa: uint32_t = 0;
    let mut _fb: uint32_t = 0;
    let mut _fas: int32_t = 0;
    let mut _fbs: int32_t = 0;
    let mut _cf: ::core::ffi::c_int = 0;
    let mut _pv: uint32_t = 0;
    let mut _pv_0: uint32_t = 0;
    let mut _pv_1: uint32_t = 0;
    let mut _pv_2: uint32_t = 0;
    let mut _pv_3: uint32_t = 0;
    let mut _pv_4: uint32_t = 0;
    let mut _pv_5: uint32_t = 0;
    let mut _pv_6: uint32_t = 0;
    let mut _pv_7: uint32_t = 0;
    let mut _pv_8: uint32_t = 0;
    let mut _pv_9: uint32_t = 0;
    let mut _pv_10: uint32_t = 0;
    let mut _pv_11: uint32_t = 0;
    let mut _pv_12: uint32_t = 0;
    let mut _pv_13: uint32_t = 0;
    let mut _pv_14: uint32_t = 0;
    let mut _pv_15: uint32_t = 0;
    let mut _pv_16: uint32_t = 0;
    let mut _pv_17: uint32_t = 0;
    let mut _pv_18: uint32_t = 0;
    let mut _pv_19: uint32_t = 0;
    let mut _pv_20: uint32_t = 0;
    let mut _dividend: uint64_t = 0;
    enum C2Rust_Block_37 {
        S_0,
        S_2,
        S_4,
        S_14,
        S_24,
        S_26,
        S_28,
        S_34,
        S_36,
        S_42,
        S_44,
        S_46,
        S_56,
        S_58,
        S_60,
        S_70,
        S_72,
        S_74,
        S_80,
        S_86,
        S_88,
        S_90,
        S_92,
        S_94,
        S_96,
        S_98,
        S_100,
        S_102,
        S_104,
        S_106,
        S_108,
        S_117,
        S_121,
        S_125,
        S_127,
        S_129,
        S_135,
        S_137,
        S_143,
        S_145,
        S_151,
        S_157,
        S_159,
        S_161,
        S_171,
        S_173,
        S_175,
        S_185,
        S_187,
        S_189,
        S_195,
        S_201,
        S_203,
        S_205,
        S_207,
        S_209,
        S_211,
        S_213,
        S_215,
        S_217,
        S_219,
        S_221,
        S_223,
        S_232,
        S_238,
        S_240,
        S_246,
        S_248,
        S_254,
        S_260,
        S_262,
        S_264,
        S_274,
        S_276,
        S_278,
        S_288,
        S_290,
        S_292,
        S_298,
        S_304,
        S_306,
        S_308,
        S_310,
        S_312,
        S_314,
        S_316,
        S_318,
        S_320,
        S_322,
        S_324,
        S_326,
        S_335,
        S_341,
        S_343,
        S_349,
        S_351,
        S_357,
        S_363,
        S_365,
        S_367,
        S_377,
        S_379,
        S_381,
        S_391,
        S_393,
        S_395,
        S_401,
        S_407,
        S_409,
        S_411,
        S_413,
        S_415,
        S_417,
        S_419,
        S_421,
        S_423,
        S_425,
        S_427,
        S_429,
        S_438,
        S_444,
        S_446,
        S_452,
        S_454,
        S_460,
        S_466,
        S_468,
        S_470,
        S_480,
        S_482,
        S_484,
        S_494,
        S_496,
        S_498,
        S_504,
        S_510,
        S_512,
        S_514,
        S_516,
        S_518,
        S_520,
        S_522,
        S_524,
        S_526,
        S_528,
        S_530,
        S_532,
        S_541,
        S_547,
        S_549,
        S_551,
        S_561,
        S_563,
        S_565,
        S_575,
        S_577,
        S_579,
        S_585,
        S_591,
        S_593,
        S_595,
        S_597,
        S_599,
        S_601,
        S_603,
        S_605,
        S_607,
        S_609,
        S_611,
        S_613,
        S_622,
        S_628,
        S_630,
        S_632,
        S_642,
        S_644,
        S_646,
        S_656,
        S_658,
        S_660,
        S_666,
        S_672,
        S_674,
        S_676,
        S_678,
        S_680,
        S_682,
        S_684,
        S_686,
        S_688,
        S_690,
        S_692,
        S_694,
        S_703,
        S_705,
        S_707,
        S_709,
        S_711,
        S_713,
        S_715,
        S_724,
        S_732,
        S_738,
        S_740,
        S_742,
        S_744,
        S_746,
        S_748,
        S_750,
        S_759,
        S_765,
        S_769,
        S_773,
        S_775,
        S_777,
        S_779,
        S_781,
        S_783,
        S_785,
        S_788,
        S_790,
        S_792,
        S_800,
        S_802,
        S_808,
        S_810,
        S_816,
        S_818,
        S_820,
        S_822,
        S_828,
        S_830,
        S_836,
        S_838,
        S_844,
        S_846,
        S_848,
        S_850,
        S_852,
        S_854,
        S_856,
        S_858,
        S_860,
        S_866,
        S_868,
        S_874,
        S_876,
        S_878,
        S_880,
        S_882,
        S_884,
        S_886,
        S_888,
        S_890,
        S_892,
        S_894,
        S_896,
        S_898,
        S_900,
        S_902,
    }
    let mut c2rust_current_block_37: C2Rust_Block_37;
    c2rust_current_block_37 = C2Rust_Block_37::S_0;
    loop {
        match c2rust_current_block_37 {
            C2Rust_Block_37::S_0 => {
                _flags = 0 as ::core::ffi::c_int;
                c2rust_current_block_37 = C2Rust_Block_37::S_2;
            }
            C2Rust_Block_37::S_2 => {
                _fa = 0 as uint32_t;
                _fb = 0 as uint32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_4;
            }
            C2Rust_Block_37::S_4 => {
                _fas = 0 as int32_t;
                _fbs = 0 as int32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_14;
            }
            C2Rust_Block_37::S_14 => {
                _cf = 0 as ::core::ffi::c_int;
                c2rust_current_block_37 = C2Rust_Block_37::S_24;
            }
            C2Rust_Block_37::S_24 => {
                _pv = (*__gamepkg_tls_g_esi);
                c2rust_current_block_37 = C2Rust_Block_37::S_26;
            }
            C2Rust_Block_37::S_26 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_37 = C2Rust_Block_37::S_28;
            }
            C2Rust_Block_37::S_28 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv,
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_34;
            }
            C2Rust_Block_37::S_34 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_36;
            }
            C2Rust_Block_37::S_36 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_42;
            }
            C2Rust_Block_37::S_42 => {
                _pv_0 = 0x36dbe8 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_44;
            }
            C2Rust_Block_37::S_44 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_37 = C2Rust_Block_37::S_46;
            }
            C2Rust_Block_37::S_46 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_0,
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_56;
            }
            C2Rust_Block_37::S_56 => {
                _pv_1 = (*__gamepkg_tls_g_eax);
                c2rust_current_block_37 = C2Rust_Block_37::S_58;
            }
            C2Rust_Block_37::S_58 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_37 = C2Rust_Block_37::S_60;
            }
            C2Rust_Block_37::S_60 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_1,
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_70;
            }
            C2Rust_Block_37::S_70 => {
                _pv_2 = 0x1f9df3 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_72;
            }
            C2Rust_Block_37::S_72 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_37 = C2Rust_Block_37::S_74;
            }
            C2Rust_Block_37::S_74 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_2,
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_80;
            }
            C2Rust_Block_37::S_80 => {
                sub_001FE270();
                c2rust_current_block_37 = C2Rust_Block_37::S_86;
            }
            C2Rust_Block_37::S_86 => {
                _fb = 8 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_88;
            }
            C2Rust_Block_37::S_88 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_90;
            }
            C2Rust_Block_37::S_90 => {
                _cf = (((*__gamepkg_tls_g_esp) as uint64_t)
                    .wrapping_add(8 as ::core::ffi::c_int as uint64_t)
                    >> 32 as ::core::ffi::c_int & 1 as uint64_t) as ::core::ffi::c_int;
                c2rust_current_block_37 = C2Rust_Block_37::S_92;
            }
            C2Rust_Block_37::S_92 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(8 as uint32_t);
                c2rust_current_block_37 = C2Rust_Block_37::S_94;
            }
            C2Rust_Block_37::S_94 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_96;
            }
            C2Rust_Block_37::S_96 => {
                _fas = _fa as int32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_98;
            }
            C2Rust_Block_37::S_98 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_100;
            }
            C2Rust_Block_37::S_100 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_102;
            }
            C2Rust_Block_37::S_102 => {
                _fas = _fa as int32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_104;
            }
            C2Rust_Block_37::S_104 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_106;
            }
            C2Rust_Block_37::S_106 => {
                _cf = 0 as ::core::ffi::c_int;
                c2rust_current_block_37 = C2Rust_Block_37::S_108;
            }
            C2Rust_Block_37::S_108 => {
                if _fa != _fb {
                    c2rust_current_block_37 = C2Rust_Block_37::S_151;
                } else {
                    c2rust_current_block_37 = C2Rust_Block_37::S_117;
                }
            }
            C2Rust_Block_37::S_117 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint8_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint8_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0xc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) as uint32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_121;
            }
            C2Rust_Block_37::S_121 => {
                _cf = ((*__gamepkg_tls_g_eax)
                    >> 3 as ::core::ffi::c_int - 1 as ::core::ffi::c_int & 1 as uint32_t)
                    as ::core::ffi::c_int;
                c2rust_current_block_37 = C2Rust_Block_37::S_125;
            }
            C2Rust_Block_37::S_125 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
                    >> 3 as ::core::ffi::c_int;
                c2rust_current_block_37 = C2Rust_Block_37::S_127;
            }
            C2Rust_Block_37::S_127 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_129;
            }
            C2Rust_Block_37::S_129 => {
                _fas = _fa as int32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_135;
            }
            C2Rust_Block_37::S_135 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_137;
            }
            C2Rust_Block_37::S_137 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_37 = C2Rust_Block_37::S_143;
            }
            C2Rust_Block_37::S_143 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_37 = C2Rust_Block_37::S_145;
            }
            C2Rust_Block_37::S_145 => return,
            C2Rust_Block_37::S_151 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_157;
            }
            C2Rust_Block_37::S_157 => {
                _pv_3 = 0x36dbd8 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_159;
            }
            C2Rust_Block_37::S_159 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_37 = C2Rust_Block_37::S_161;
            }
            C2Rust_Block_37::S_161 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_3,
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_171;
            }
            C2Rust_Block_37::S_171 => {
                _pv_4 = (*__gamepkg_tls_g_ecx);
                c2rust_current_block_37 = C2Rust_Block_37::S_173;
            }
            C2Rust_Block_37::S_173 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_37 = C2Rust_Block_37::S_175;
            }
            C2Rust_Block_37::S_175 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_4,
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_185;
            }
            C2Rust_Block_37::S_185 => {
                _pv_5 = 0x1f9e11 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_187;
            }
            C2Rust_Block_37::S_187 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_37 = C2Rust_Block_37::S_189;
            }
            C2Rust_Block_37::S_189 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_5,
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_195;
            }
            C2Rust_Block_37::S_195 => {
                sub_001FE270();
                c2rust_current_block_37 = C2Rust_Block_37::S_201;
            }
            C2Rust_Block_37::S_201 => {
                _fb = 8 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_203;
            }
            C2Rust_Block_37::S_203 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_205;
            }
            C2Rust_Block_37::S_205 => {
                _cf = (((*__gamepkg_tls_g_esp) as uint64_t)
                    .wrapping_add(8 as ::core::ffi::c_int as uint64_t)
                    >> 32 as ::core::ffi::c_int & 1 as uint64_t) as ::core::ffi::c_int;
                c2rust_current_block_37 = C2Rust_Block_37::S_207;
            }
            C2Rust_Block_37::S_207 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(8 as uint32_t);
                c2rust_current_block_37 = C2Rust_Block_37::S_209;
            }
            C2Rust_Block_37::S_209 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_211;
            }
            C2Rust_Block_37::S_211 => {
                _fas = _fa as int32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_213;
            }
            C2Rust_Block_37::S_213 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_215;
            }
            C2Rust_Block_37::S_215 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_217;
            }
            C2Rust_Block_37::S_217 => {
                _fas = _fa as int32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_219;
            }
            C2Rust_Block_37::S_219 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_221;
            }
            C2Rust_Block_37::S_221 => {
                _cf = 0 as ::core::ffi::c_int;
                c2rust_current_block_37 = C2Rust_Block_37::S_223;
            }
            C2Rust_Block_37::S_223 => {
                if _fa != _fb {
                    c2rust_current_block_37 = C2Rust_Block_37::S_254;
                } else {
                    c2rust_current_block_37 = C2Rust_Block_37::S_232;
                }
            }
            C2Rust_Block_37::S_232 => {
                (*__gamepkg_tls_g_eax) = 0x10 as uint32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_238;
            }
            C2Rust_Block_37::S_238 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_240;
            }
            C2Rust_Block_37::S_240 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_37 = C2Rust_Block_37::S_246;
            }
            C2Rust_Block_37::S_246 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_37 = C2Rust_Block_37::S_248;
            }
            C2Rust_Block_37::S_248 => return,
            C2Rust_Block_37::S_254 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_260;
            }
            C2Rust_Block_37::S_260 => {
                _pv_6 = 0x36dbf8 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_262;
            }
            C2Rust_Block_37::S_262 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_37 = C2Rust_Block_37::S_264;
            }
            C2Rust_Block_37::S_264 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_6,
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_274;
            }
            C2Rust_Block_37::S_274 => {
                _pv_7 = (*__gamepkg_tls_g_edx);
                c2rust_current_block_37 = C2Rust_Block_37::S_276;
            }
            C2Rust_Block_37::S_276 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_37 = C2Rust_Block_37::S_278;
            }
            C2Rust_Block_37::S_278 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_7,
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_288;
            }
            C2Rust_Block_37::S_288 => {
                _pv_8 = 0x1f9e2d as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_290;
            }
            C2Rust_Block_37::S_290 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_37 = C2Rust_Block_37::S_292;
            }
            C2Rust_Block_37::S_292 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_8,
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_298;
            }
            C2Rust_Block_37::S_298 => {
                sub_001FE270();
                c2rust_current_block_37 = C2Rust_Block_37::S_304;
            }
            C2Rust_Block_37::S_304 => {
                _fb = 8 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_306;
            }
            C2Rust_Block_37::S_306 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_308;
            }
            C2Rust_Block_37::S_308 => {
                _cf = (((*__gamepkg_tls_g_esp) as uint64_t)
                    .wrapping_add(8 as ::core::ffi::c_int as uint64_t)
                    >> 32 as ::core::ffi::c_int & 1 as uint64_t) as ::core::ffi::c_int;
                c2rust_current_block_37 = C2Rust_Block_37::S_310;
            }
            C2Rust_Block_37::S_310 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(8 as uint32_t);
                c2rust_current_block_37 = C2Rust_Block_37::S_312;
            }
            C2Rust_Block_37::S_312 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_314;
            }
            C2Rust_Block_37::S_314 => {
                _fas = _fa as int32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_316;
            }
            C2Rust_Block_37::S_316 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_318;
            }
            C2Rust_Block_37::S_318 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_320;
            }
            C2Rust_Block_37::S_320 => {
                _fas = _fa as int32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_322;
            }
            C2Rust_Block_37::S_322 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_324;
            }
            C2Rust_Block_37::S_324 => {
                _cf = 0 as ::core::ffi::c_int;
                c2rust_current_block_37 = C2Rust_Block_37::S_326;
            }
            C2Rust_Block_37::S_326 => {
                if _fa != _fb {
                    c2rust_current_block_37 = C2Rust_Block_37::S_357;
                } else {
                    c2rust_current_block_37 = C2Rust_Block_37::S_335;
                }
            }
            C2Rust_Block_37::S_335 => {
                (*__gamepkg_tls_g_eax) = 4 as uint32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_341;
            }
            C2Rust_Block_37::S_341 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_343;
            }
            C2Rust_Block_37::S_343 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_37 = C2Rust_Block_37::S_349;
            }
            C2Rust_Block_37::S_349 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_37 = C2Rust_Block_37::S_351;
            }
            C2Rust_Block_37::S_351 => return,
            C2Rust_Block_37::S_357 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_363;
            }
            C2Rust_Block_37::S_363 => {
                _pv_9 = 0x36dc08 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_365;
            }
            C2Rust_Block_37::S_365 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_37 = C2Rust_Block_37::S_367;
            }
            C2Rust_Block_37::S_367 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_9,
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_377;
            }
            C2Rust_Block_37::S_377 => {
                _pv_10 = (*__gamepkg_tls_g_eax);
                c2rust_current_block_37 = C2Rust_Block_37::S_379;
            }
            C2Rust_Block_37::S_379 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_37 = C2Rust_Block_37::S_381;
            }
            C2Rust_Block_37::S_381 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_10,
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_391;
            }
            C2Rust_Block_37::S_391 => {
                _pv_11 = 0x1f9e49 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_393;
            }
            C2Rust_Block_37::S_393 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_37 = C2Rust_Block_37::S_395;
            }
            C2Rust_Block_37::S_395 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_11,
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_401;
            }
            C2Rust_Block_37::S_401 => {
                sub_001FE270();
                c2rust_current_block_37 = C2Rust_Block_37::S_407;
            }
            C2Rust_Block_37::S_407 => {
                _fb = 8 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_409;
            }
            C2Rust_Block_37::S_409 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_411;
            }
            C2Rust_Block_37::S_411 => {
                _cf = (((*__gamepkg_tls_g_esp) as uint64_t)
                    .wrapping_add(8 as ::core::ffi::c_int as uint64_t)
                    >> 32 as ::core::ffi::c_int & 1 as uint64_t) as ::core::ffi::c_int;
                c2rust_current_block_37 = C2Rust_Block_37::S_413;
            }
            C2Rust_Block_37::S_413 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(8 as uint32_t);
                c2rust_current_block_37 = C2Rust_Block_37::S_415;
            }
            C2Rust_Block_37::S_415 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_417;
            }
            C2Rust_Block_37::S_417 => {
                _fas = _fa as int32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_419;
            }
            C2Rust_Block_37::S_419 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_421;
            }
            C2Rust_Block_37::S_421 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_423;
            }
            C2Rust_Block_37::S_423 => {
                _fas = _fa as int32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_425;
            }
            C2Rust_Block_37::S_425 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_427;
            }
            C2Rust_Block_37::S_427 => {
                _cf = 0 as ::core::ffi::c_int;
                c2rust_current_block_37 = C2Rust_Block_37::S_429;
            }
            C2Rust_Block_37::S_429 => {
                if _fa != _fb {
                    c2rust_current_block_37 = C2Rust_Block_37::S_460;
                } else {
                    c2rust_current_block_37 = C2Rust_Block_37::S_438;
                }
            }
            C2Rust_Block_37::S_438 => {
                (*__gamepkg_tls_g_eax) = 8 as uint32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_444;
            }
            C2Rust_Block_37::S_444 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_446;
            }
            C2Rust_Block_37::S_446 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_37 = C2Rust_Block_37::S_452;
            }
            C2Rust_Block_37::S_452 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_37 = C2Rust_Block_37::S_454;
            }
            C2Rust_Block_37::S_454 => return,
            C2Rust_Block_37::S_460 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_466;
            }
            C2Rust_Block_37::S_466 => {
                _pv_12 = 0x36dc18 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_468;
            }
            C2Rust_Block_37::S_468 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_37 = C2Rust_Block_37::S_470;
            }
            C2Rust_Block_37::S_470 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_12,
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_480;
            }
            C2Rust_Block_37::S_480 => {
                _pv_13 = (*__gamepkg_tls_g_ecx);
                c2rust_current_block_37 = C2Rust_Block_37::S_482;
            }
            C2Rust_Block_37::S_482 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_37 = C2Rust_Block_37::S_484;
            }
            C2Rust_Block_37::S_484 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_13,
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_494;
            }
            C2Rust_Block_37::S_494 => {
                _pv_14 = 0x1f9e65 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_496;
            }
            C2Rust_Block_37::S_496 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_37 = C2Rust_Block_37::S_498;
            }
            C2Rust_Block_37::S_498 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_14,
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_504;
            }
            C2Rust_Block_37::S_504 => {
                sub_001FE270();
                c2rust_current_block_37 = C2Rust_Block_37::S_510;
            }
            C2Rust_Block_37::S_510 => {
                _fb = 8 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_512;
            }
            C2Rust_Block_37::S_512 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_514;
            }
            C2Rust_Block_37::S_514 => {
                _cf = (((*__gamepkg_tls_g_esp) as uint64_t)
                    .wrapping_add(8 as ::core::ffi::c_int as uint64_t)
                    >> 32 as ::core::ffi::c_int & 1 as uint64_t) as ::core::ffi::c_int;
                c2rust_current_block_37 = C2Rust_Block_37::S_516;
            }
            C2Rust_Block_37::S_516 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(8 as uint32_t);
                c2rust_current_block_37 = C2Rust_Block_37::S_518;
            }
            C2Rust_Block_37::S_518 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_520;
            }
            C2Rust_Block_37::S_520 => {
                _fas = _fa as int32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_522;
            }
            C2Rust_Block_37::S_522 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_524;
            }
            C2Rust_Block_37::S_524 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_526;
            }
            C2Rust_Block_37::S_526 => {
                _fas = _fa as int32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_528;
            }
            C2Rust_Block_37::S_528 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_530;
            }
            C2Rust_Block_37::S_530 => {
                _cf = 0 as ::core::ffi::c_int;
                c2rust_current_block_37 = C2Rust_Block_37::S_532;
            }
            C2Rust_Block_37::S_532 => {
                if _fa == _fb {
                    c2rust_current_block_37 = C2Rust_Block_37::S_844;
                } else {
                    c2rust_current_block_37 = C2Rust_Block_37::S_541;
                }
            }
            C2Rust_Block_37::S_541 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_547;
            }
            C2Rust_Block_37::S_547 => {
                _pv_15 = 0x36dc78 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_549;
            }
            C2Rust_Block_37::S_549 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_37 = C2Rust_Block_37::S_551;
            }
            C2Rust_Block_37::S_551 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_15,
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_561;
            }
            C2Rust_Block_37::S_561 => {
                _pv_16 = (*__gamepkg_tls_g_edx);
                c2rust_current_block_37 = C2Rust_Block_37::S_563;
            }
            C2Rust_Block_37::S_563 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_37 = C2Rust_Block_37::S_565;
            }
            C2Rust_Block_37::S_565 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_16,
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_575;
            }
            C2Rust_Block_37::S_575 => {
                _pv_17 = 0x1f9e7a as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_577;
            }
            C2Rust_Block_37::S_577 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_37 = C2Rust_Block_37::S_579;
            }
            C2Rust_Block_37::S_579 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_17,
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_585;
            }
            C2Rust_Block_37::S_585 => {
                sub_001FE270();
                c2rust_current_block_37 = C2Rust_Block_37::S_591;
            }
            C2Rust_Block_37::S_591 => {
                _fb = 8 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_593;
            }
            C2Rust_Block_37::S_593 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_595;
            }
            C2Rust_Block_37::S_595 => {
                _cf = (((*__gamepkg_tls_g_esp) as uint64_t)
                    .wrapping_add(8 as ::core::ffi::c_int as uint64_t)
                    >> 32 as ::core::ffi::c_int & 1 as uint64_t) as ::core::ffi::c_int;
                c2rust_current_block_37 = C2Rust_Block_37::S_597;
            }
            C2Rust_Block_37::S_597 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(8 as uint32_t);
                c2rust_current_block_37 = C2Rust_Block_37::S_599;
            }
            C2Rust_Block_37::S_599 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_601;
            }
            C2Rust_Block_37::S_601 => {
                _fas = _fa as int32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_603;
            }
            C2Rust_Block_37::S_603 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_605;
            }
            C2Rust_Block_37::S_605 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_607;
            }
            C2Rust_Block_37::S_607 => {
                _fas = _fa as int32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_609;
            }
            C2Rust_Block_37::S_609 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_611;
            }
            C2Rust_Block_37::S_611 => {
                _cf = 0 as ::core::ffi::c_int;
                c2rust_current_block_37 = C2Rust_Block_37::S_613;
            }
            C2Rust_Block_37::S_613 => {
                if _fa == _fb {
                    c2rust_current_block_37 = C2Rust_Block_37::S_844;
                } else {
                    c2rust_current_block_37 = C2Rust_Block_37::S_622;
                }
            }
            C2Rust_Block_37::S_622 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_628;
            }
            C2Rust_Block_37::S_628 => {
                _pv_18 = 0x36dc38 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_630;
            }
            C2Rust_Block_37::S_630 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_37 = C2Rust_Block_37::S_632;
            }
            C2Rust_Block_37::S_632 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_18,
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_642;
            }
            C2Rust_Block_37::S_642 => {
                _pv_19 = (*__gamepkg_tls_g_eax);
                c2rust_current_block_37 = C2Rust_Block_37::S_644;
            }
            C2Rust_Block_37::S_644 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_37 = C2Rust_Block_37::S_646;
            }
            C2Rust_Block_37::S_646 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_19,
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_656;
            }
            C2Rust_Block_37::S_656 => {
                _pv_20 = 0x1f9e8f as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_658;
            }
            C2Rust_Block_37::S_658 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_37 = C2Rust_Block_37::S_660;
            }
            C2Rust_Block_37::S_660 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_20,
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_666;
            }
            C2Rust_Block_37::S_666 => {
                sub_001FE270();
                c2rust_current_block_37 = C2Rust_Block_37::S_672;
            }
            C2Rust_Block_37::S_672 => {
                _fb = 8 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_674;
            }
            C2Rust_Block_37::S_674 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_676;
            }
            C2Rust_Block_37::S_676 => {
                _cf = (((*__gamepkg_tls_g_esp) as uint64_t)
                    .wrapping_add(8 as ::core::ffi::c_int as uint64_t)
                    >> 32 as ::core::ffi::c_int & 1 as uint64_t) as ::core::ffi::c_int;
                c2rust_current_block_37 = C2Rust_Block_37::S_678;
            }
            C2Rust_Block_37::S_678 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(8 as uint32_t);
                c2rust_current_block_37 = C2Rust_Block_37::S_680;
            }
            C2Rust_Block_37::S_680 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_682;
            }
            C2Rust_Block_37::S_682 => {
                _fas = _fa as int32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_684;
            }
            C2Rust_Block_37::S_684 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_686;
            }
            C2Rust_Block_37::S_686 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_688;
            }
            C2Rust_Block_37::S_688 => {
                _fas = _fa as int32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_690;
            }
            C2Rust_Block_37::S_690 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_692;
            }
            C2Rust_Block_37::S_692 => {
                _cf = 0 as ::core::ffi::c_int;
                c2rust_current_block_37 = C2Rust_Block_37::S_694;
            }
            C2Rust_Block_37::S_694 => {
                if _fa != _fb {
                    c2rust_current_block_37 = C2Rust_Block_37::S_816;
                } else {
                    c2rust_current_block_37 = C2Rust_Block_37::S_703;
                }
            }
            C2Rust_Block_37::S_703 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x10 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_705;
            }
            C2Rust_Block_37::S_705 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_707;
            }
            C2Rust_Block_37::S_707 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_709;
            }
            C2Rust_Block_37::S_709 => {
                _fas = _fa as int32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_711;
            }
            C2Rust_Block_37::S_711 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_713;
            }
            C2Rust_Block_37::S_713 => {
                _cf = 0 as ::core::ffi::c_int;
                c2rust_current_block_37 = C2Rust_Block_37::S_715;
            }
            C2Rust_Block_37::S_715 => {
                if _fa == _fb {
                    c2rust_current_block_37 = C2Rust_Block_37::S_732;
                } else {
                    c2rust_current_block_37 = C2Rust_Block_37::S_724;
                }
            }
            C2Rust_Block_37::S_724 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_738;
            }
            C2Rust_Block_37::S_732 => {
                (*__gamepkg_tls_g_eax) = 0x1f400 as uint32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_738;
            }
            C2Rust_Block_37::S_738 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_740;
            }
            C2Rust_Block_37::S_740 => {
                _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_742;
            }
            C2Rust_Block_37::S_742 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_744;
            }
            C2Rust_Block_37::S_744 => {
                _fas = _fa as int32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_746;
            }
            C2Rust_Block_37::S_746 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_748;
            }
            C2Rust_Block_37::S_748 => {
                _cf = 0 as ::core::ffi::c_int;
                c2rust_current_block_37 = C2Rust_Block_37::S_750;
            }
            C2Rust_Block_37::S_750 => {
                if _fa != _fb {
                    c2rust_current_block_37 = C2Rust_Block_37::S_765;
                } else {
                    c2rust_current_block_37 = C2Rust_Block_37::S_759;
                }
            }
            C2Rust_Block_37::S_759 => {
                (*__gamepkg_tls_g_esi) = 0xbb80 as uint32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_765;
            }
            C2Rust_Block_37::S_765 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
                    .wrapping_add((*__gamepkg_tls_g_eax).wrapping_mul(8 as uint32_t));
                c2rust_current_block_37 = C2Rust_Block_37::S_769;
            }
            C2Rust_Block_37::S_769 => {
                _cf = ((*__gamepkg_tls_g_eax)
                    >> 32 as ::core::ffi::c_int - 4 as ::core::ffi::c_int
                    & 1 as uint32_t) as ::core::ffi::c_int;
                c2rust_current_block_37 = C2Rust_Block_37::S_773;
            }
            C2Rust_Block_37::S_773 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
                    << 4 as ::core::ffi::c_int;
                c2rust_current_block_37 = C2Rust_Block_37::S_775;
            }
            C2Rust_Block_37::S_775 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_777;
            }
            C2Rust_Block_37::S_777 => {
                _fas = _fa as int32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_779;
            }
            C2Rust_Block_37::S_779 => {
                _cf = 0 as ::core::ffi::c_int;
                c2rust_current_block_37 = C2Rust_Block_37::S_781;
            }
            C2Rust_Block_37::S_781 => {
                (*__gamepkg_tls_g_edx) = 0 as uint32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_783;
            }
            C2Rust_Block_37::S_783 => {
                _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_785;
            }
            C2Rust_Block_37::S_785 => {
                _fas = _fa as int32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_788;
            }
            C2Rust_Block_37::S_788 => {
                _dividend = ((*__gamepkg_tls_g_edx) as uint64_t)
                    << 32 as ::core::ffi::c_int | (*__gamepkg_tls_g_eax) as uint64_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_790;
            }
            C2Rust_Block_37::S_790 => {
                (*__gamepkg_tls_g_eax) = _dividend
                    .wrapping_div((*__gamepkg_tls_g_esi) as uint64_t) as uint32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_792;
            }
            C2Rust_Block_37::S_792 => {
                (*__gamepkg_tls_g_edx) = _dividend
                    .wrapping_rem((*__gamepkg_tls_g_esi) as uint64_t) as uint32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_800;
            }
            C2Rust_Block_37::S_800 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_802;
            }
            C2Rust_Block_37::S_802 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_37 = C2Rust_Block_37::S_808;
            }
            C2Rust_Block_37::S_808 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_37 = C2Rust_Block_37::S_810;
            }
            C2Rust_Block_37::S_810 => return,
            C2Rust_Block_37::S_816 => {
                _cf = 0 as ::core::ffi::c_int;
                c2rust_current_block_37 = C2Rust_Block_37::S_818;
            }
            C2Rust_Block_37::S_818 => {
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_820;
            }
            C2Rust_Block_37::S_820 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_822;
            }
            C2Rust_Block_37::S_822 => {
                _fas = _fa as int32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_828;
            }
            C2Rust_Block_37::S_828 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_830;
            }
            C2Rust_Block_37::S_830 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_37 = C2Rust_Block_37::S_836;
            }
            C2Rust_Block_37::S_836 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_37 = C2Rust_Block_37::S_838;
            }
            C2Rust_Block_37::S_838 => return,
            C2Rust_Block_37::S_844 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 0xffffff00 as uint32_t
                    | ::core::ptr::read_volatile::<
                        uint8_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            ((*__gamepkg_tls_g_esi).wrapping_add(0xd as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ) as uint32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_846;
            }
            C2Rust_Block_37::S_846 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 0xffffff00 as uint32_t
                    | (((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t
                        as ::core::ffi::c_int - 1 as ::core::ffi::c_int) as uint8_t
                        as uint32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_848;
            }
            C2Rust_Block_37::S_848 => {
                _fa = ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t as uint32_t
                    & 0xff as uint32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_850;
            }
            C2Rust_Block_37::S_850 => {
                _fas = _fa as int8_t as int32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_852;
            }
            C2Rust_Block_37::S_852 => {
                _fb = (_fa == 0x7f as uint32_t) as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_854;
            }
            C2Rust_Block_37::S_854 => {
                _cf = (((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t
                    as ::core::ffi::c_int != 0 as ::core::ffi::c_int)
                    as ::core::ffi::c_int;
                c2rust_current_block_37 = C2Rust_Block_37::S_856;
            }
            C2Rust_Block_37::S_856 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 0xffffff00 as uint32_t
                    | -(((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t
                        as int32_t) as uint32_t as uint8_t as uint32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_858;
            }
            C2Rust_Block_37::S_858 => {
                _fa = ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t as uint32_t
                    & 0xff as uint32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_860;
            }
            C2Rust_Block_37::S_860 => {
                _fas = _fa as int8_t as int32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_866;
            }
            C2Rust_Block_37::S_866 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_37 = C2Rust_Block_37::S_868;
            }
            C2Rust_Block_37::S_868 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_37 = C2Rust_Block_37::S_874;
            }
            C2Rust_Block_37::S_874 => {
                (*__gamepkg_tls_g_eax) = (if _cf != 0 {
                    0xffffffff as ::core::ffi::c_uint
                } else {
                    0 as ::core::ffi::c_uint
                }) as uint32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_876;
            }
            C2Rust_Block_37::S_876 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_878;
            }
            C2Rust_Block_37::S_878 => {
                _fas = _fa as int32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_880;
            }
            C2Rust_Block_37::S_880 => {
                _cf = 0 as ::core::ffi::c_int;
                c2rust_current_block_37 = C2Rust_Block_37::S_882;
            }
            C2Rust_Block_37::S_882 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 0xffffffe0 as uint32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_884;
            }
            C2Rust_Block_37::S_884 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_886;
            }
            C2Rust_Block_37::S_886 => {
                _fas = _fa as int32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_888;
            }
            C2Rust_Block_37::S_888 => {
                _fb = 0x24 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_890;
            }
            C2Rust_Block_37::S_890 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_892;
            }
            C2Rust_Block_37::S_892 => {
                _cf = (((*__gamepkg_tls_g_eax) as uint64_t)
                    .wrapping_add(0x24 as ::core::ffi::c_int as uint64_t)
                    >> 32 as ::core::ffi::c_int & 1 as uint64_t) as ::core::ffi::c_int;
                c2rust_current_block_37 = C2Rust_Block_37::S_894;
            }
            C2Rust_Block_37::S_894 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
                    .wrapping_add(0x24 as uint32_t);
                c2rust_current_block_37 = C2Rust_Block_37::S_896;
            }
            C2Rust_Block_37::S_896 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_898;
            }
            C2Rust_Block_37::S_898 => {
                _fas = _fa as int32_t;
                c2rust_current_block_37 = C2Rust_Block_37::S_900;
            }
            C2Rust_Block_37::S_900 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_37 = C2Rust_Block_37::S_902;
            }
            C2Rust_Block_37::S_902 => return,
        }
    };
}
#[no_mangle]
pub unsafe extern "C" fn sub_001F9EE0() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 0xffffff00 as uint32_t
        | ::core::ptr::read_volatile::<
            uint8_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint8_t,
            >(
                ((*__gamepkg_tls_g_esi).wrapping_add(0x18 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ) as uint32_t;
    let mut _pv_0: uint32_t = (*__gamepkg_tls_g_edi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    (*__gamepkg_tls_g_edi) = 0 as uint32_t;
    _fa = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fa = (((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t as ::core::ffi::c_int
        & 2 as ::core::ffi::c_int) as uint32_t & 0xff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
    _fas = _fa as int8_t as int32_t;
    _fbs = _fb as int8_t as int32_t;
    's_140: {
        if _fa != _fb {
            break 's_140;
        }
        (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi).wrapping_add(0x10 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
        _fb = (*__gamepkg_tls_g_edi) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fbs = _fb as int32_t;
        if _fa == _fb {
            break 's_140;
        }
        let mut _pv_1: uint32_t = (*__gamepkg_tls_g_eax);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_1,
        );
        let mut _pv_2: uint32_t = 0x1f9efc as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_2,
        );
        sub_001FEDC0();
        _fb = 4 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fbs = _fb as int32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
    }
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x10 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_edi),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x14 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_edi),
    );
    (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001F9F10() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _cf: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv_0: uint32_t = (*__gamepkg_tls_g_eax);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    let mut _pv_1: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    let mut _pv_2: uint32_t = 0x1f9f20 as ::core::ffi::c_uint as uint32_t;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_2,
    );
    sub_001FE4C0();
    _fb = 8 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    _cf = (((*__gamepkg_tls_g_esp) as uint64_t)
        .wrapping_add(8 as ::core::ffi::c_int as uint64_t) >> 32 as ::core::ffi::c_int
        & 1 as uint64_t) as ::core::ffi::c_int;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t);
    _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    _cf = 0 as ::core::ffi::c_int;
    's_121: {
        if _fa == _fb {
            break 's_121;
        }
        (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp).wrapping_add(0x10 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        let mut _pv_3: uint32_t = (*__gamepkg_tls_g_ecx);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_3,
        );
        let mut _pv_4: uint32_t = (*__gamepkg_tls_g_esi);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_4,
        );
        let mut _pv_5: uint32_t = 0x1f9f34 as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_5,
        );
        sub_001FE480();
        _fb = 8 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fbs = _fb as int32_t;
        _cf = (((*__gamepkg_tls_g_esp) as uint64_t)
            .wrapping_add(8 as ::core::ffi::c_int as uint64_t)
            >> 32 as ::core::ffi::c_int & 1 as uint64_t) as ::core::ffi::c_int;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t);
        _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _cf = ((*__gamepkg_tls_g_eax) != 0 as uint32_t) as ::core::ffi::c_int;
        (*__gamepkg_tls_g_eax) = -((*__gamepkg_tls_g_eax) as int32_t) as uint32_t;
        _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        (*__gamepkg_tls_g_eax) = (if _cf != 0 {
            0xffffffff as ::core::ffi::c_uint
        } else {
            0 as ::core::ffi::c_uint
        }) as uint32_t;
        _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _cf = 0 as ::core::ffi::c_int;
        (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & (*__gamepkg_tls_g_esi);
        _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        return;
    }
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001F9F40() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0;
    let mut _fa: uint32_t = 0;
    let mut _fb: uint32_t = 0;
    let mut _fas: int32_t = 0;
    let mut _fbs: int32_t = 0;
    let mut _pv: uint32_t = 0;
    let mut _pv_0: uint32_t = 0;
    let mut _pv_1: uint32_t = 0;
    let mut _pv_2: uint32_t = 0;
    let mut _icall_esp: uint32_t = 0;
    let mut _pv_3: uint32_t = 0;
    let mut _icall_target: uint32_t = 0;
    let mut _pv_4: uint32_t = 0;
    let mut _va: uint32_t = 0;
    let mut _fn: recomp_func_t = None;
    let mut _pv_5: uint32_t = 0;
    let mut _pv_6: uint32_t = 0;
    let mut _pv_7: uint32_t = 0;
    let mut _pv_8: uint32_t = 0;
    let mut _pv_9: uint32_t = 0;
    let mut _pv_10: uint32_t = 0;
    let mut _pv_11: uint32_t = 0;
    let mut _pv_12: uint32_t = 0;
    let mut _pv_13: uint32_t = 0;
    enum C2Rust_Block_40 {
        S_0,
        S_2,
        S_4,
        S_22,
        S_24,
        S_26,
        S_32,
        S_38,
        S_40,
        S_42,
        S_52,
        S_54,
        S_56,
        S_66,
        S_68,
        S_70,
        S_76,
        S_82,
        S_84,
        S_86,
        S_88,
        S_90,
        S_92,
        S_94,
        S_96,
        S_98,
        S_100,
        S_109,
        S_111,
        S_113,
        S_119,
        S_121,
        S_127,
        S_129,
        S_135,
        S_137,
        S_139,
        S_141,
        S_143,
        S_145,
        S_155,
        S_161,
        S_163,
        S_165,
        S_172,
        S_178,
        S_180,
        S_182,
        S_192,
        S_194,
        S_196,
        S_198,
        S_200,
        S_203,
        S_205,
        S_207,
        S_215,
        S_217,
        S_219,
        S_223,
        S_225,
        S_229,
        S_235,
        S_242,
        S_244,
        S_246,
        S_264,
        S_266,
        S_268,
        S_270,
        S_272,
        S_278,
        S_280,
        S_282,
        S_284,
        S_286,
        S_288,
        S_301,
        S_303,
        S_305,
        S_315,
        S_317,
        S_319,
        S_325,
        S_331,
        S_333,
        S_335,
        S_337,
        S_339,
        S_345,
        S_347,
        S_349,
        S_351,
        S_353,
        S_362,
        S_368,
        S_370,
        S_372,
        S_382,
        S_384,
        S_386,
        S_392,
        S_398,
        S_400,
        S_402,
        S_404,
        S_406,
        S_412,
        S_414,
        S_416,
        S_418,
        S_420,
        S_426,
        S_428,
        S_430,
        S_436,
        S_442,
        S_444,
        S_446,
        S_452,
        S_458,
        S_460,
        S_462,
        S_464,
        S_466,
        S_468,
        S_470,
        S_472,
        S_474,
        S_476,
        S_478,
        S_491,
        S_493,
        S_495,
        S_505,
        S_507,
        S_509,
        S_519,
        S_521,
        S_523,
        S_529,
        S_535,
        S_537,
        S_539,
        S_541,
        S_543,
        S_549,
        S_555,
        S_557,
        S_563,
        S_565,
    }
    let mut c2rust_current_block_40: C2Rust_Block_40;
    c2rust_current_block_40 = C2Rust_Block_40::S_0;
    loop {
        match c2rust_current_block_40 {
            C2Rust_Block_40::S_0 => {
                _flags = 0 as ::core::ffi::c_int;
                c2rust_current_block_40 = C2Rust_Block_40::S_2;
            }
            C2Rust_Block_40::S_2 => {
                _fa = 0 as uint32_t;
                _fb = 0 as uint32_t;
                c2rust_current_block_40 = C2Rust_Block_40::S_4;
            }
            C2Rust_Block_40::S_4 => {
                _fas = 0 as int32_t;
                _fbs = 0 as int32_t;
                c2rust_current_block_40 = C2Rust_Block_40::S_22;
            }
            C2Rust_Block_40::S_22 => {
                _pv = (*__gamepkg_tls_g_esi);
                c2rust_current_block_40 = C2Rust_Block_40::S_24;
            }
            C2Rust_Block_40::S_24 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_40 = C2Rust_Block_40::S_26;
            }
            C2Rust_Block_40::S_26 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv,
                );
                c2rust_current_block_40 = C2Rust_Block_40::S_32;
            }
            C2Rust_Block_40::S_32 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_40 = C2Rust_Block_40::S_38;
            }
            C2Rust_Block_40::S_38 => {
                _pv_0 = 1 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_40 = C2Rust_Block_40::S_40;
            }
            C2Rust_Block_40::S_40 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_40 = C2Rust_Block_40::S_42;
            }
            C2Rust_Block_40::S_42 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_0,
                );
                c2rust_current_block_40 = C2Rust_Block_40::S_52;
            }
            C2Rust_Block_40::S_52 => {
                _pv_1 = (*__gamepkg_tls_g_esi);
                c2rust_current_block_40 = C2Rust_Block_40::S_54;
            }
            C2Rust_Block_40::S_54 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_40 = C2Rust_Block_40::S_56;
            }
            C2Rust_Block_40::S_56 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_1,
                );
                c2rust_current_block_40 = C2Rust_Block_40::S_66;
            }
            C2Rust_Block_40::S_66 => {
                _pv_2 = 0x1f9f4d as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_40 = C2Rust_Block_40::S_68;
            }
            C2Rust_Block_40::S_68 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_40 = C2Rust_Block_40::S_70;
            }
            C2Rust_Block_40::S_70 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_2,
                );
                c2rust_current_block_40 = C2Rust_Block_40::S_76;
            }
            C2Rust_Block_40::S_76 => {
                sub_001F6550();
                c2rust_current_block_40 = C2Rust_Block_40::S_82;
            }
            C2Rust_Block_40::S_82 => {
                _fb = 8 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_40 = C2Rust_Block_40::S_84;
            }
            C2Rust_Block_40::S_84 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_40 = C2Rust_Block_40::S_86;
            }
            C2Rust_Block_40::S_86 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(8 as uint32_t);
                c2rust_current_block_40 = C2Rust_Block_40::S_88;
            }
            C2Rust_Block_40::S_88 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_40 = C2Rust_Block_40::S_90;
            }
            C2Rust_Block_40::S_90 => {
                _fas = _fa as int32_t;
                c2rust_current_block_40 = C2Rust_Block_40::S_92;
            }
            C2Rust_Block_40::S_92 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_40 = C2Rust_Block_40::S_94;
            }
            C2Rust_Block_40::S_94 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_40 = C2Rust_Block_40::S_96;
            }
            C2Rust_Block_40::S_96 => {
                _fas = _fa as int32_t;
                c2rust_current_block_40 = C2Rust_Block_40::S_98;
            }
            C2Rust_Block_40::S_98 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_40 = C2Rust_Block_40::S_100;
            }
            C2Rust_Block_40::S_100 => {
                if _fa == _fb {
                    c2rust_current_block_40 = C2Rust_Block_40::S_135;
                } else {
                    c2rust_current_block_40 = C2Rust_Block_40::S_109;
                }
            }
            C2Rust_Block_40::S_109 => {
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                c2rust_current_block_40 = C2Rust_Block_40::S_111;
            }
            C2Rust_Block_40::S_111 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_40 = C2Rust_Block_40::S_113;
            }
            C2Rust_Block_40::S_113 => {
                _fas = _fa as int32_t;
                c2rust_current_block_40 = C2Rust_Block_40::S_119;
            }
            C2Rust_Block_40::S_119 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_40 = C2Rust_Block_40::S_121;
            }
            C2Rust_Block_40::S_121 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_40 = C2Rust_Block_40::S_127;
            }
            C2Rust_Block_40::S_127 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_40 = C2Rust_Block_40::S_129;
            }
            C2Rust_Block_40::S_129 => return,
            C2Rust_Block_40::S_135 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x30 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_40 = C2Rust_Block_40::S_137;
            }
            C2Rust_Block_40::S_137 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_40 = C2Rust_Block_40::S_139;
            }
            C2Rust_Block_40::S_139 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_40 = C2Rust_Block_40::S_141;
            }
            C2Rust_Block_40::S_141 => {
                _fas = _fa as int32_t;
                c2rust_current_block_40 = C2Rust_Block_40::S_143;
            }
            C2Rust_Block_40::S_143 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_40 = C2Rust_Block_40::S_145;
            }
            C2Rust_Block_40::S_145 => {
                if _fa == _fb {
                    c2rust_current_block_40 = C2Rust_Block_40::S_278;
                } else {
                    c2rust_current_block_40 = C2Rust_Block_40::S_155;
                }
            }
            C2Rust_Block_40::S_155 => {
                _icall_esp = (*__gamepkg_tls_g_esp);
                c2rust_current_block_40 = C2Rust_Block_40::S_161;
            }
            C2Rust_Block_40::S_161 => {
                _pv_3 = (*__gamepkg_tls_g_esi);
                c2rust_current_block_40 = C2Rust_Block_40::S_163;
            }
            C2Rust_Block_40::S_163 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_40 = C2Rust_Block_40::S_165;
            }
            C2Rust_Block_40::S_165 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_3,
                );
                c2rust_current_block_40 = C2Rust_Block_40::S_172;
            }
            C2Rust_Block_40::S_172 => {
                _icall_target = (*__gamepkg_tls_g_eax);
                c2rust_current_block_40 = C2Rust_Block_40::S_178;
            }
            C2Rust_Block_40::S_178 => {
                _pv_4 = 0x1f9f62 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_40 = C2Rust_Block_40::S_180;
            }
            C2Rust_Block_40::S_180 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_40 = C2Rust_Block_40::S_182;
            }
            C2Rust_Block_40::S_182 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_4,
                );
                c2rust_current_block_40 = C2Rust_Block_40::S_192;
            }
            C2Rust_Block_40::S_192 => {
                _va = _icall_target;
                c2rust_current_block_40 = C2Rust_Block_40::S_194;
            }
            C2Rust_Block_40::S_194 => {
                ::core::ptr::write_volatile(
                    &raw mut g_icall_trace[(::core::ptr::read_volatile::<
                        uint32_t,
                    >(&raw const g_icall_trace_idx)
                        & (ICALL_TRACE_SIZE - 1 as ::core::ffi::c_int) as uint32_t)
                        as usize],
                    _va,
                );
                c2rust_current_block_40 = C2Rust_Block_40::S_196;
            }
            C2Rust_Block_40::S_196 => {
                ::core::ptr::write_volatile(
                    &raw mut g_icall_trace_idx,
                    ::core::ptr::read_volatile::<uint32_t>(&raw const g_icall_trace_idx)
                        .wrapping_add(1),
                );
                c2rust_current_block_40 = C2Rust_Block_40::S_198;
            }
            C2Rust_Block_40::S_198 => {
                ::core::ptr::write_volatile(
                    &raw mut g_icall_count,
                    ::core::ptr::read_volatile::<uint64_t>(&raw const g_icall_count)
                        .wrapping_add(1),
                );
                c2rust_current_block_40 = C2Rust_Block_40::S_200;
            }
            C2Rust_Block_40::S_200 => {
                if !(_va >= 0xfe000000 as uint32_t || g_xbox_code_hi == 0 as uint32_t
                    || _va >= g_xbox_code_lo && _va < g_xbox_code_hi)
                {
                    c2rust_current_block_40 = C2Rust_Block_40::S_203;
                } else {
                    c2rust_current_block_40 = C2Rust_Block_40::S_215;
                }
            }
            C2Rust_Block_40::S_203 => {
                recomp_icall_not_code_log(_va);
                c2rust_current_block_40 = C2Rust_Block_40::S_205;
            }
            C2Rust_Block_40::S_205 => {
                (*__gamepkg_tls_g_esp) = _icall_esp;
                c2rust_current_block_40 = C2Rust_Block_40::S_207;
            }
            C2Rust_Block_40::S_207 => {
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                c2rust_current_block_40 = C2Rust_Block_40::S_264;
            }
            C2Rust_Block_40::S_215 => {
                _fn = recomp_lookup_manual(_va);
                c2rust_current_block_40 = C2Rust_Block_40::S_217;
            }
            C2Rust_Block_40::S_217 => {
                if _fn.is_none() {
                    c2rust_current_block_40 = C2Rust_Block_40::S_219;
                } else {
                    c2rust_current_block_40 = C2Rust_Block_40::S_223;
                }
            }
            C2Rust_Block_40::S_219 => {
                _fn = recomp_lookup(_va);
                c2rust_current_block_40 = C2Rust_Block_40::S_223;
            }
            C2Rust_Block_40::S_223 => {
                if _fn.is_none() {
                    c2rust_current_block_40 = C2Rust_Block_40::S_225;
                } else {
                    c2rust_current_block_40 = C2Rust_Block_40::S_229;
                }
            }
            C2Rust_Block_40::S_225 => {
                _fn = recomp_lookup_kernel(_va);
                c2rust_current_block_40 = C2Rust_Block_40::S_229;
            }
            C2Rust_Block_40::S_229 => {
                if _fn.is_some() {
                    c2rust_current_block_40 = C2Rust_Block_40::S_235;
                } else {
                    c2rust_current_block_40 = C2Rust_Block_40::S_242;
                }
            }
            C2Rust_Block_40::S_235 => {
                _fn.expect("non-null function pointer")();
                c2rust_current_block_40 = C2Rust_Block_40::S_264;
            }
            C2Rust_Block_40::S_242 => {
                recomp_icall_fail_log(_va);
                c2rust_current_block_40 = C2Rust_Block_40::S_244;
            }
            C2Rust_Block_40::S_244 => {
                (*__gamepkg_tls_g_esp) = _icall_esp;
                c2rust_current_block_40 = C2Rust_Block_40::S_246;
            }
            C2Rust_Block_40::S_246 => {
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                c2rust_current_block_40 = C2Rust_Block_40::S_264;
            }
            C2Rust_Block_40::S_264 => {
                _fb = 4 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_40 = C2Rust_Block_40::S_266;
            }
            C2Rust_Block_40::S_266 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_40 = C2Rust_Block_40::S_268;
            }
            C2Rust_Block_40::S_268 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_40 = C2Rust_Block_40::S_270;
            }
            C2Rust_Block_40::S_270 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_40 = C2Rust_Block_40::S_272;
            }
            C2Rust_Block_40::S_272 => {
                _fas = _fa as int32_t;
                c2rust_current_block_40 = C2Rust_Block_40::S_278;
            }
            C2Rust_Block_40::S_278 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x4c as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_40 = C2Rust_Block_40::S_280;
            }
            C2Rust_Block_40::S_280 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_40 = C2Rust_Block_40::S_282;
            }
            C2Rust_Block_40::S_282 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_40 = C2Rust_Block_40::S_284;
            }
            C2Rust_Block_40::S_284 => {
                _fas = _fa as int32_t;
                c2rust_current_block_40 = C2Rust_Block_40::S_286;
            }
            C2Rust_Block_40::S_286 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_40 = C2Rust_Block_40::S_288;
            }
            C2Rust_Block_40::S_288 => {
                if _fa == _fb {
                    c2rust_current_block_40 = C2Rust_Block_40::S_345;
                } else {
                    c2rust_current_block_40 = C2Rust_Block_40::S_301;
                }
            }
            C2Rust_Block_40::S_301 => {
                _pv_5 = (*__gamepkg_tls_g_eax);
                c2rust_current_block_40 = C2Rust_Block_40::S_303;
            }
            C2Rust_Block_40::S_303 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_40 = C2Rust_Block_40::S_305;
            }
            C2Rust_Block_40::S_305 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_5,
                );
                c2rust_current_block_40 = C2Rust_Block_40::S_315;
            }
            C2Rust_Block_40::S_315 => {
                _pv_6 = 0x1f9f72 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_40 = C2Rust_Block_40::S_317;
            }
            C2Rust_Block_40::S_317 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_40 = C2Rust_Block_40::S_319;
            }
            C2Rust_Block_40::S_319 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_6,
                );
                c2rust_current_block_40 = C2Rust_Block_40::S_325;
            }
            C2Rust_Block_40::S_325 => {
                sub_001FEB70();
                c2rust_current_block_40 = C2Rust_Block_40::S_331;
            }
            C2Rust_Block_40::S_331 => {
                _fb = 4 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_40 = C2Rust_Block_40::S_333;
            }
            C2Rust_Block_40::S_333 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_40 = C2Rust_Block_40::S_335;
            }
            C2Rust_Block_40::S_335 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_40 = C2Rust_Block_40::S_337;
            }
            C2Rust_Block_40::S_337 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_40 = C2Rust_Block_40::S_339;
            }
            C2Rust_Block_40::S_339 => {
                _fas = _fa as int32_t;
                c2rust_current_block_40 = C2Rust_Block_40::S_345;
            }
            C2Rust_Block_40::S_345 => {
                _fa = (::core::ptr::read_volatile::<
                    uint8_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint8_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x58 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) as ::core::ffi::c_int & 1 as ::core::ffi::c_int) as uint32_t
                    & 0xff as uint32_t;
                c2rust_current_block_40 = C2Rust_Block_40::S_347;
            }
            C2Rust_Block_40::S_347 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
                c2rust_current_block_40 = C2Rust_Block_40::S_349;
            }
            C2Rust_Block_40::S_349 => {
                _fas = _fa as int8_t as int32_t;
                c2rust_current_block_40 = C2Rust_Block_40::S_351;
            }
            C2Rust_Block_40::S_351 => {
                _fbs = _fb as int8_t as int32_t;
                c2rust_current_block_40 = C2Rust_Block_40::S_353;
            }
            C2Rust_Block_40::S_353 => {
                if _fa == _fb {
                    c2rust_current_block_40 = C2Rust_Block_40::S_412;
                } else {
                    c2rust_current_block_40 = C2Rust_Block_40::S_362;
                }
            }
            C2Rust_Block_40::S_362 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x38 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_40 = C2Rust_Block_40::S_368;
            }
            C2Rust_Block_40::S_368 => {
                _pv_7 = (*__gamepkg_tls_g_eax);
                c2rust_current_block_40 = C2Rust_Block_40::S_370;
            }
            C2Rust_Block_40::S_370 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_40 = C2Rust_Block_40::S_372;
            }
            C2Rust_Block_40::S_372 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_7,
                );
                c2rust_current_block_40 = C2Rust_Block_40::S_382;
            }
            C2Rust_Block_40::S_382 => {
                _pv_8 = 0x1f9f84 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_40 = C2Rust_Block_40::S_384;
            }
            C2Rust_Block_40::S_384 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_40 = C2Rust_Block_40::S_386;
            }
            C2Rust_Block_40::S_386 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_8,
                );
                c2rust_current_block_40 = C2Rust_Block_40::S_392;
            }
            C2Rust_Block_40::S_392 => {
                sub_001FEDC0();
                c2rust_current_block_40 = C2Rust_Block_40::S_398;
            }
            C2Rust_Block_40::S_398 => {
                _fb = 4 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_40 = C2Rust_Block_40::S_400;
            }
            C2Rust_Block_40::S_400 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_40 = C2Rust_Block_40::S_402;
            }
            C2Rust_Block_40::S_402 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_40 = C2Rust_Block_40::S_404;
            }
            C2Rust_Block_40::S_404 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_40 = C2Rust_Block_40::S_406;
            }
            C2Rust_Block_40::S_406 => {
                _fas = _fa as int32_t;
                c2rust_current_block_40 = C2Rust_Block_40::S_412;
            }
            C2Rust_Block_40::S_412 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x54 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_40 = C2Rust_Block_40::S_414;
            }
            C2Rust_Block_40::S_414 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x50 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_40 = C2Rust_Block_40::S_416;
            }
            C2Rust_Block_40::S_416 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ecx) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_edx),
                );
                c2rust_current_block_40 = C2Rust_Block_40::S_418;
            }
            C2Rust_Block_40::S_418 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x50 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_40 = C2Rust_Block_40::S_420;
            }
            C2Rust_Block_40::S_420 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0x54 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_40 = C2Rust_Block_40::S_426;
            }
            C2Rust_Block_40::S_426 => {
                _pv_9 = (*__gamepkg_tls_g_esi);
                c2rust_current_block_40 = C2Rust_Block_40::S_428;
            }
            C2Rust_Block_40::S_428 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_40 = C2Rust_Block_40::S_430;
            }
            C2Rust_Block_40::S_430 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_9,
                );
                c2rust_current_block_40 = C2Rust_Block_40::S_436;
            }
            C2Rust_Block_40::S_436 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_ecx),
                );
                c2rust_current_block_40 = C2Rust_Block_40::S_442;
            }
            C2Rust_Block_40::S_442 => {
                _pv_10 = 0x1f9f9e as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_40 = C2Rust_Block_40::S_444;
            }
            C2Rust_Block_40::S_444 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_40 = C2Rust_Block_40::S_446;
            }
            C2Rust_Block_40::S_446 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_10,
                );
                c2rust_current_block_40 = C2Rust_Block_40::S_452;
            }
            C2Rust_Block_40::S_452 => {
                sub_001FE500();
                c2rust_current_block_40 = C2Rust_Block_40::S_458;
            }
            C2Rust_Block_40::S_458 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 0xffffff00 as uint32_t
                    | ::core::ptr::read_volatile::<
                        uint8_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            ((*__gamepkg_tls_g_esi).wrapping_add(0x58 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ) as uint32_t;
                c2rust_current_block_40 = C2Rust_Block_40::S_460;
            }
            C2Rust_Block_40::S_460 => {
                _fb = 4 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_40 = C2Rust_Block_40::S_462;
            }
            C2Rust_Block_40::S_462 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_40 = C2Rust_Block_40::S_464;
            }
            C2Rust_Block_40::S_464 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_40 = C2Rust_Block_40::S_466;
            }
            C2Rust_Block_40::S_466 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_40 = C2Rust_Block_40::S_468;
            }
            C2Rust_Block_40::S_468 => {
                _fas = _fa as int32_t;
                c2rust_current_block_40 = C2Rust_Block_40::S_470;
            }
            C2Rust_Block_40::S_470 => {
                _fa = (((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t
                    as ::core::ffi::c_int & 2 as ::core::ffi::c_int) as uint32_t
                    & 0xff as uint32_t;
                c2rust_current_block_40 = C2Rust_Block_40::S_472;
            }
            C2Rust_Block_40::S_472 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
                c2rust_current_block_40 = C2Rust_Block_40::S_474;
            }
            C2Rust_Block_40::S_474 => {
                _fas = _fa as int8_t as int32_t;
                c2rust_current_block_40 = C2Rust_Block_40::S_476;
            }
            C2Rust_Block_40::S_476 => {
                _fbs = _fb as int8_t as int32_t;
                c2rust_current_block_40 = C2Rust_Block_40::S_478;
            }
            C2Rust_Block_40::S_478 => {
                if _fa == _fb {
                    c2rust_current_block_40 = C2Rust_Block_40::S_549;
                } else {
                    c2rust_current_block_40 = C2Rust_Block_40::S_491;
                }
            }
            C2Rust_Block_40::S_491 => {
                _pv_11 = (*__gamepkg_tls_g_esi);
                c2rust_current_block_40 = C2Rust_Block_40::S_493;
            }
            C2Rust_Block_40::S_493 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_40 = C2Rust_Block_40::S_495;
            }
            C2Rust_Block_40::S_495 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_11,
                );
                c2rust_current_block_40 = C2Rust_Block_40::S_505;
            }
            C2Rust_Block_40::S_505 => {
                _pv_12 = 0x41b744 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_40 = C2Rust_Block_40::S_507;
            }
            C2Rust_Block_40::S_507 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_40 = C2Rust_Block_40::S_509;
            }
            C2Rust_Block_40::S_509 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_12,
                );
                c2rust_current_block_40 = C2Rust_Block_40::S_519;
            }
            C2Rust_Block_40::S_519 => {
                _pv_13 = 0x1f9fb3 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_40 = C2Rust_Block_40::S_521;
            }
            C2Rust_Block_40::S_521 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_40 = C2Rust_Block_40::S_523;
            }
            C2Rust_Block_40::S_523 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_13,
                );
                c2rust_current_block_40 = C2Rust_Block_40::S_529;
            }
            C2Rust_Block_40::S_529 => {
                sub_001FEA30();
                c2rust_current_block_40 = C2Rust_Block_40::S_535;
            }
            C2Rust_Block_40::S_535 => {
                _fb = 8 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_40 = C2Rust_Block_40::S_537;
            }
            C2Rust_Block_40::S_537 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_40 = C2Rust_Block_40::S_539;
            }
            C2Rust_Block_40::S_539 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(8 as uint32_t);
                c2rust_current_block_40 = C2Rust_Block_40::S_541;
            }
            C2Rust_Block_40::S_541 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_40 = C2Rust_Block_40::S_543;
            }
            C2Rust_Block_40::S_543 => {
                _fas = _fa as int32_t;
                c2rust_current_block_40 = C2Rust_Block_40::S_549;
            }
            C2Rust_Block_40::S_549 => {
                (*__gamepkg_tls_g_eax) = 1 as uint32_t;
                c2rust_current_block_40 = C2Rust_Block_40::S_555;
            }
            C2Rust_Block_40::S_555 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_40 = C2Rust_Block_40::S_557;
            }
            C2Rust_Block_40::S_557 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_40 = C2Rust_Block_40::S_563;
            }
            C2Rust_Block_40::S_563 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_40 = C2Rust_Block_40::S_565;
            }
            C2Rust_Block_40::S_565 => return,
        }
    };
}
#[no_mangle]
pub unsafe extern "C" fn sub_001F9FC0() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_ebx = unsafe { gamepkg_tls_g_ebx() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let mut ebp: uint32_t = 0 as uint32_t;
    ebp = (*__gamepkg_tls_g_ebp);
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    ebp = (*__gamepkg_tls_g_seh_ebp);
    let mut _pv: uint32_t = (*__gamepkg_tls_g_ebx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv_0: uint32_t = ebp;
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    _fb = 0x20 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_ebx) = (*__gamepkg_tls_g_ebx).wrapping_add(0x20 as uint32_t);
    _fa = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    let mut _pv_1: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_1,
    );
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ebx) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
    _fb = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    let mut _pv_2: uint32_t = (*__gamepkg_tls_g_edi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_2,
    );
    's_221: {
        if _fa == _fb {
            break 's_221;
        }
        ebp = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp).wrapping_add(0x1c as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        loop {
            (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    (ebp as uintptr_t).wrapping_add(g_xbox_mem_offset as uintptr_t)
                        as usize,
                ),
            );
            (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esi)
                        .wrapping_add(-80 as ::core::ffi::c_int as uint32_t)
                        as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_esi)
                .wrapping_add(-80 as ::core::ffi::c_int as uint32_t);
            let mut _pv_3: uint32_t = (*__gamepkg_tls_g_eax);
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_3,
            );
            let mut _pv_4: uint32_t = (*__gamepkg_tls_g_ecx);
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_4,
            );
            let mut _pv_5: uint32_t = 0x1f9fe5 as ::core::ffi::c_uint as uint32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_5,
            );
            sub_001FE270();
            _fb = 8 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
            _fbs = _fb as int32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t);
            _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
            _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            _fbs = _fb as int32_t;
            's_198: {
                if _fa != _fb {
                    break 's_198;
                }
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        (ebp.wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_edi),
                );
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                ebp = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                (*__gamepkg_tls_g_eax) = 1 as uint32_t;
                (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                return;
            }
            (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esi) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
            _fb = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            _fbs = _fb as int32_t;
            if _fa == _fb {
                break 's_221;
            }
        }
    }
    (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    ebp = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_eax) = 0 as uint32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001FA010() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebx = unsafe { gamepkg_tls_g_ebx() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_edx) = 0 as uint32_t;
    _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fb = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    's_67: {
        if _fa == _fb {
            break 's_67;
        }
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_eax) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            (*__gamepkg_tls_g_edx),
        );
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_eax).wrapping_add(4 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            (*__gamepkg_tls_g_edx),
        );
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_eax).wrapping_add(8 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            (*__gamepkg_tls_g_edx),
        );
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint8_t,
            >(
                ((*__gamepkg_tls_g_eax).wrapping_add(0xc as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            ((*__gamepkg_tls_g_edx) & 0xff as uint32_t) as uint8_t,
        );
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint8_t,
            >(
                ((*__gamepkg_tls_g_eax).wrapping_add(0xd as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            ((*__gamepkg_tls_g_edx) & 0xff as uint32_t) as uint8_t,
        );
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint8_t,
            >(
                ((*__gamepkg_tls_g_eax).wrapping_add(0x18 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            ((*__gamepkg_tls_g_edx) & 0xff as uint32_t) as uint8_t,
        );
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint8_t,
            >(
                ((*__gamepkg_tls_g_eax).wrapping_add(0x19 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            ((*__gamepkg_tls_g_edx) & 0xff as uint32_t) as uint8_t,
        );
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_eax).wrapping_add(0x10 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            (*__gamepkg_tls_g_edx),
        );
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_eax).wrapping_add(0x14 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            (*__gamepkg_tls_g_edx),
        );
    }
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    let mut _pv: uint32_t = (*__gamepkg_tls_g_ebx);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    (*__gamepkg_tls_g_ebx) = (*__gamepkg_tls_g_ebx) & 0xffffff00 as uint32_t
        | ::core::ptr::read_volatile::<
            uint8_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint8_t,
            >(
                ((*__gamepkg_tls_g_ecx).wrapping_add(4 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ) as uint32_t;
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint8_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0xc as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        ((*__gamepkg_tls_g_ebx) & 0xff as uint32_t) as uint8_t,
    );
    let mut _pv_0: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ecx) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_esi),
    );
    (*__gamepkg_tls_g_ebx) = (*__gamepkg_tls_g_ebx) & 0xffffff00 as uint32_t
        | ::core::ptr::read_volatile::<
            uint8_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint8_t,
            >(
                ((*__gamepkg_tls_g_ecx).wrapping_add(5 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ) as uint32_t;
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint8_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0x18 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        ((*__gamepkg_tls_g_edx) & 0xff as uint32_t) as uint8_t,
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint8_t,
        >(
            ((*__gamepkg_tls_g_eax).wrapping_add(0xd as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        ((*__gamepkg_tls_g_ebx) & 0xff as uint32_t) as uint8_t,
    );
    (*__gamepkg_tls_g_ebx) = (*__gamepkg_tls_g_ebx) & 0xffffff00 as uint32_t
        | ::core::ptr::read_volatile::<
            uint8_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint8_t,
            >(
                ((*__gamepkg_tls_g_ecx).wrapping_add(0x10 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ) as uint32_t;
    (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_edx) & 0xffffff00 as uint32_t
        | 1 as ::core::ffi::c_int as uint8_t as uint32_t;
    _fa = (((*__gamepkg_tls_g_edx) & 0xff as uint32_t) as uint8_t as ::core::ffi::c_int
        & ((*__gamepkg_tls_g_ebx) & 0xff as uint32_t) as uint8_t as ::core::ffi::c_int)
        as uint32_t & 0xff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
    _fas = _fa as int8_t as int32_t;
    _fbs = _fb as int8_t as int32_t;
    's_138: {
        if _fa == _fb {
            break 's_138;
        }
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint8_t,
            >(
                ((*__gamepkg_tls_g_eax).wrapping_add(0x18 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            ((*__gamepkg_tls_g_edx) & 0xff as uint32_t) as uint8_t,
        );
    }
    (*__gamepkg_tls_g_ebx) = (*__gamepkg_tls_g_ebx) & 0xffffff00 as uint32_t
        | ::core::ptr::read_volatile::<
            uint8_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint8_t,
            >(
                ((*__gamepkg_tls_g_ecx).wrapping_add(0x10 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ) as uint32_t;
    (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_edx) & 0xffffff00 as uint32_t
        | 4 as ::core::ffi::c_int as uint8_t as uint32_t;
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    _fa = (((*__gamepkg_tls_g_edx) & 0xff as uint32_t) as uint8_t as ::core::ffi::c_int
        & ((*__gamepkg_tls_g_ebx) & 0xff as uint32_t) as uint8_t as ::core::ffi::c_int)
        as uint32_t & 0xff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
    _fas = _fa as int8_t as int32_t;
    _fbs = _fb as int8_t as int32_t;
    (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    's_193: {
        if _fa == _fb {
            break 's_193;
        }
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint8_t,
            >(
                ((*__gamepkg_tls_g_eax).wrapping_add(0x18 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            (::core::ptr::read_volatile::<
                uint8_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint8_t,
                >(
                    ((*__gamepkg_tls_g_eax).wrapping_add(0x18 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            ) as ::core::ffi::c_int
                | ((*__gamepkg_tls_g_edx) & 0xff as uint32_t) as uint8_t
                    as ::core::ffi::c_int) as uint8_t,
        );
        _fa = ::core::ptr::read_volatile::<
            uint8_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint8_t,
            >(
                ((*__gamepkg_tls_g_eax).wrapping_add(0x18 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ) as uint32_t & 0xff as uint32_t;
        _fas = _fa as int8_t as int32_t;
    }
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001FA070() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx) & 0xffffff00 as uint32_t
        | ::core::ptr::read_volatile::<
            uint8_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint8_t,
            >(
                ((*__gamepkg_tls_g_esi).wrapping_add(5 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ) as uint32_t;
    let mut _pv_0: uint32_t = (*__gamepkg_tls_g_edi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0x10 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 0xffffff00 as uint32_t
        | ::core::ptr::read_volatile::<
            uint8_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint8_t,
            >(
                ((*__gamepkg_tls_g_edi).wrapping_add(0xd as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ) as uint32_t;
    _fa = ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t as uint32_t
        & 0xff as uint32_t;
    _fb = ((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t as uint32_t
        & 0xff as uint32_t;
    _fas = _fa as int8_t as int32_t;
    _fbs = _fb as int8_t as int32_t;
    's_268: {
        if _fa != _fb {
            break 's_268;
        }
        (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx) & 0xffffff00 as uint32_t
            | ::core::ptr::read_volatile::<
                uint8_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint8_t,
                >(
                    ((*__gamepkg_tls_g_edi).wrapping_add(0xc as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            ) as uint32_t;
        _fa = ((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t as uint32_t
            & 0xff as uint32_t;
        _fb = ::core::ptr::read_volatile::<
            uint8_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint8_t,
            >(
                ((*__gamepkg_tls_g_esi).wrapping_add(4 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ) as uint32_t & 0xff as uint32_t;
        _fas = _fa as int8_t as int32_t;
        _fbs = _fb as int8_t as int32_t;
        if _fa != _fb {
            break 's_268;
        }
        (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_edi) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
        _fb = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi).wrapping_add(8 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fbs = _fb as int32_t;
        if _fa < _fb {
            break 's_268;
        }
        _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
        _fb = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi).wrapping_add(0xc as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fbs = _fb as int32_t;
        if _fa > _fb {
            break 's_268;
        }
        (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_edi).wrapping_add(4 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        let mut _pv_1: uint32_t = (*__gamepkg_tls_g_edx);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_1,
        );
        let mut _pv_2: uint32_t = (*__gamepkg_tls_g_eax);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_2,
        );
        let mut _pv_3: uint32_t = 0x1fa0a4 as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_3,
        );
        sub_001FE270();
        _fb = 8 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fbs = _fb as int32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t);
        _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
        _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fbs = _fb as int32_t;
        if _fa != _fb {
            break 's_268;
        }
        (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx) & 0xffffff00 as uint32_t
            | ::core::ptr::read_volatile::<
                uint8_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint8_t,
                >(
                    ((*__gamepkg_tls_g_esi).wrapping_add(0x10 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            ) as uint32_t;
        (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx) & 0xffffff00 as uint32_t
            | (((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t
                as ::core::ffi::c_int
                ^ ::core::ptr::read_volatile::<
                    uint8_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint8_t,
                    >(
                        ((*__gamepkg_tls_g_edi).wrapping_add(0x18 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) as ::core::ffi::c_int) as uint8_t as uint32_t;
        _fa = ((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t as uint32_t
            & 0xff as uint32_t;
        _fas = _fa as int8_t as int32_t;
        _fa = (((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t
            as ::core::ffi::c_int & 1 as ::core::ffi::c_int) as uint32_t
            & 0xff as uint32_t;
        _fb = 0 as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
        _fas = _fa as int8_t as int32_t;
        _fbs = _fb as int8_t as int32_t;
        if _fa != _fb {
            break 's_268;
        }
        (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        (*__gamepkg_tls_g_eax) = 1 as uint32_t;
        (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        return;
    }
    (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_eax) = 0 as uint32_t;
    _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001FA0D0() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    _fa = (::core::ptr::read_volatile::<
        uint8_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint8_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x58 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    ) as ::core::ffi::c_int & 1 as ::core::ffi::c_int) as uint32_t & 0xff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
    _fas = _fa as int8_t as int32_t;
    _fbs = _fb as int8_t as int32_t;
    's_128: {
        if _fa == _fb {
            break 's_128;
        }
        (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi).wrapping_add(0x38 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
        _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fbs = _fb as int32_t;
        's_118: {
            if _fa == _fb {
                break 's_118;
            }
            let mut _pv_0: uint32_t = (*__gamepkg_tls_g_eax);
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_0,
            );
            let mut _pv_1: uint32_t = 0x1fa0e8 as ::core::ffi::c_uint as uint32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
            ::core::ptr::write_volatile(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
                _pv_1,
            );
            sub_001FEDC0();
            _fb = 4 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
            _fbs = _fb as int32_t;
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
            _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
        }
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi).wrapping_add(0x58 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esi).wrapping_add(0x58 as uint32_t) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            ) & 0xfffffffe as uint32_t,
        );
        _fa = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi).wrapping_add(0x58 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
    }
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0x10 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x38 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_eax),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x34 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_ecx),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esi).wrapping_add(0x3c as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        0 as uint32_t,
    );
    (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001FA110() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ecx).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    (*__gamepkg_tls_g_eax) = 0x1c as uint32_t;
    's_47: {
        if _fa == _fb {
            break 's_47;
        }
        (*__gamepkg_tls_g_eax) = 0x2c as uint32_t;
    }
    (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_ecx).wrapping_add(0x10 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
    _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    _fbs = _fb as int32_t;
    's_80: {
        if _fa == _fb {
            break 's_80;
        }
        _fb = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_ecx).wrapping_add(0x14 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ) & 0xffffffff as uint32_t;
        _fbs = _fb as int32_t;
        (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax)
            .wrapping_add(
                ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ecx).wrapping_add(0x14 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ),
            );
        _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
    }
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001FA130() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebp = unsafe { gamepkg_tls_g_ebp() };
    let __gamepkg_tls_g_ebx = unsafe { gamepkg_tls_g_ebx() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_seh_ebp = unsafe { gamepkg_tls_g_seh_ebp() };
    let mut ebp: uint32_t = 0;
    let mut _flags: ::core::ffi::c_int = 0;
    let mut _fa: uint32_t = 0;
    let mut _fb: uint32_t = 0;
    let mut _fas: int32_t = 0;
    let mut _fbs: int32_t = 0;
    let mut _pv: uint32_t = 0;
    let mut _pv_0: uint32_t = 0;
    let mut _pv_1: uint32_t = 0;
    let mut _pv_2: uint32_t = 0;
    let mut _pv_3: uint32_t = 0;
    let mut _pv_4: uint32_t = 0;
    let mut _pv_5: uint32_t = 0;
    enum C2Rust_Block_46 {
        S_0,
        S_2,
        S_4,
        S_6,
        S_8,
        S_18,
        S_24,
        S_30,
        S_32,
        S_34,
        S_40,
        S_42,
        S_44,
        S_46,
        S_48,
        S_50,
        S_52,
        S_54,
        S_56,
        S_65,
        S_71,
        S_73,
        S_75,
        S_81,
        S_83,
        S_85,
        S_87,
        S_89,
        S_91,
        S_93,
        S_95,
        S_97,
        S_110,
        S_112,
        S_114,
        S_120,
        S_126,
        S_128,
        S_130,
        S_140,
        S_142,
        S_144,
        S_146,
        S_148,
        S_150,
        S_152,
        S_154,
        S_163,
        S_165,
        S_167,
        S_169,
        S_171,
        S_173,
        S_182,
        S_184,
        S_186,
        S_188,
        S_190,
        S_192,
        S_201,
        S_203,
        S_205,
        S_207,
        S_209,
        S_218,
        S_220,
        S_226,
        S_228,
        S_230,
        S_240,
        S_242,
        S_244,
        S_254,
        S_256,
        S_258,
        S_264,
        S_270,
        S_272,
        S_274,
        S_276,
        S_278,
        S_280,
        S_282,
        S_284,
        S_286,
        S_288,
        S_297,
        S_299,
        S_301,
        S_303,
        S_305,
        S_307,
        S_309,
        S_311,
        S_313,
        S_322,
        S_324,
        S_326,
        S_328,
        S_330,
        S_332,
        S_334,
        S_336,
        S_338,
        S_351,
        S_353,
        S_363,
        S_365,
        S_375,
        S_377,
        S_383,
        S_385,
        S_387,
        S_393,
        S_395,
        S_401,
        S_403,
        S_413,
        S_415,
        S_425,
        S_427,
        S_437,
        S_439,
        S_445,
        S_451,
        S_453,
        S_459,
        S_461,
        S_467,
        S_473,
        S_475,
        S_481,
        S_483,
        S_493,
        S_495,
        S_501,
        S_507,
        S_509,
        S_515,
        S_517,
    }
    let mut c2rust_current_block_46: C2Rust_Block_46;
    c2rust_current_block_46 = C2Rust_Block_46::S_0;
    loop {
        match c2rust_current_block_46 {
            C2Rust_Block_46::S_0 => {
                ebp = 0 as uint32_t;
                c2rust_current_block_46 = C2Rust_Block_46::S_2;
            }
            C2Rust_Block_46::S_2 => {
                ebp = (*__gamepkg_tls_g_ebp);
                c2rust_current_block_46 = C2Rust_Block_46::S_4;
            }
            C2Rust_Block_46::S_4 => {
                _flags = 0 as ::core::ffi::c_int;
                c2rust_current_block_46 = C2Rust_Block_46::S_6;
            }
            C2Rust_Block_46::S_6 => {
                _fa = 0 as uint32_t;
                _fb = 0 as uint32_t;
                c2rust_current_block_46 = C2Rust_Block_46::S_8;
            }
            C2Rust_Block_46::S_8 => {
                _fas = 0 as int32_t;
                _fbs = 0 as int32_t;
                c2rust_current_block_46 = C2Rust_Block_46::S_18;
            }
            C2Rust_Block_46::S_18 => {
                ebp = (*__gamepkg_tls_g_seh_ebp);
                c2rust_current_block_46 = C2Rust_Block_46::S_24;
            }
            C2Rust_Block_46::S_24 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_46 = C2Rust_Block_46::S_30;
            }
            C2Rust_Block_46::S_30 => {
                _pv = ebp;
                c2rust_current_block_46 = C2Rust_Block_46::S_32;
            }
            C2Rust_Block_46::S_32 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_46 = C2Rust_Block_46::S_34;
            }
            C2Rust_Block_46::S_34 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv,
                );
                c2rust_current_block_46 = C2Rust_Block_46::S_40;
            }
            C2Rust_Block_46::S_40 => {
                ebp = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax).wrapping_add(0x34 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_46 = C2Rust_Block_46::S_42;
            }
            C2Rust_Block_46::S_42 => {
                (*__gamepkg_tls_g_ecx) = 0 as uint32_t;
                c2rust_current_block_46 = C2Rust_Block_46::S_44;
            }
            C2Rust_Block_46::S_44 => {
                _fa = (*__gamepkg_tls_g_ecx) & 0xffffffff as uint32_t;
                c2rust_current_block_46 = C2Rust_Block_46::S_46;
            }
            C2Rust_Block_46::S_46 => {
                _fas = _fa as int32_t;
                c2rust_current_block_46 = C2Rust_Block_46::S_48;
            }
            C2Rust_Block_46::S_48 => {
                _fa = ebp & 0xffffffff as uint32_t;
                c2rust_current_block_46 = C2Rust_Block_46::S_50;
            }
            C2Rust_Block_46::S_50 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_46 = C2Rust_Block_46::S_52;
            }
            C2Rust_Block_46::S_52 => {
                _fas = _fa as int32_t;
                c2rust_current_block_46 = C2Rust_Block_46::S_54;
            }
            C2Rust_Block_46::S_54 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_46 = C2Rust_Block_46::S_56;
            }
            C2Rust_Block_46::S_56 => {
                if _fa == _fb {
                    c2rust_current_block_46 = C2Rust_Block_46::S_467;
                } else {
                    c2rust_current_block_46 = C2Rust_Block_46::S_65;
                }
            }
            C2Rust_Block_46::S_65 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_eax).wrapping_add(0x38 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_46 = C2Rust_Block_46::S_71;
            }
            C2Rust_Block_46::S_71 => {
                _pv_0 = (*__gamepkg_tls_g_ebx);
                c2rust_current_block_46 = C2Rust_Block_46::S_73;
            }
            C2Rust_Block_46::S_73 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_46 = C2Rust_Block_46::S_75;
            }
            C2Rust_Block_46::S_75 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_0,
                );
                c2rust_current_block_46 = C2Rust_Block_46::S_81;
            }
            C2Rust_Block_46::S_81 => {
                (*__gamepkg_tls_g_ebx) = 0 as uint32_t;
                c2rust_current_block_46 = C2Rust_Block_46::S_83;
            }
            C2Rust_Block_46::S_83 => {
                _fa = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
                c2rust_current_block_46 = C2Rust_Block_46::S_85;
            }
            C2Rust_Block_46::S_85 => {
                _fas = _fa as int32_t;
                c2rust_current_block_46 = C2Rust_Block_46::S_87;
            }
            C2Rust_Block_46::S_87 => {
                _fa = ebp & 0xffffffff as uint32_t;
                c2rust_current_block_46 = C2Rust_Block_46::S_89;
            }
            C2Rust_Block_46::S_89 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_46 = C2Rust_Block_46::S_91;
            }
            C2Rust_Block_46::S_91 => {
                _fas = _fa as int32_t;
                c2rust_current_block_46 = C2Rust_Block_46::S_93;
            }
            C2Rust_Block_46::S_93 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_46 = C2Rust_Block_46::S_95;
            }
            C2Rust_Block_46::S_95 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_46 = C2Rust_Block_46::S_97;
            }
            C2Rust_Block_46::S_97 => {
                if _fa <= _fb {
                    c2rust_current_block_46 = C2Rust_Block_46::S_493;
                } else {
                    c2rust_current_block_46 = C2Rust_Block_46::S_110;
                }
            }
            C2Rust_Block_46::S_110 => {
                _pv_1 = (*__gamepkg_tls_g_edi);
                c2rust_current_block_46 = C2Rust_Block_46::S_112;
            }
            C2Rust_Block_46::S_112 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_46 = C2Rust_Block_46::S_114;
            }
            C2Rust_Block_46::S_114 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_1,
                );
                c2rust_current_block_46 = C2Rust_Block_46::S_120;
            }
            C2Rust_Block_46::S_120 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x14 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_46 = C2Rust_Block_46::S_126;
            }
            C2Rust_Block_46::S_126 => {
                _pv_2 = (*__gamepkg_tls_g_esi);
                c2rust_current_block_46 = C2Rust_Block_46::S_128;
            }
            C2Rust_Block_46::S_128 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_46 = C2Rust_Block_46::S_130;
            }
            C2Rust_Block_46::S_130 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_2,
                );
                c2rust_current_block_46 = C2Rust_Block_46::S_140;
            }
            C2Rust_Block_46::S_140 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x14 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_46 = C2Rust_Block_46::S_142;
            }
            C2Rust_Block_46::S_142 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ecx)
                            .wrapping_add(
                                (*__gamepkg_tls_g_ebx).wrapping_mul(4 as uint32_t),
                            ) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_46 = C2Rust_Block_46::S_144;
            }
            C2Rust_Block_46::S_144 => {
                (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_edx) & 0xffffff00 as uint32_t
                    | ::core::ptr::read_volatile::<
                        uint8_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            ((*__gamepkg_tls_g_edi).wrapping_add(0xd as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ) as uint32_t;
                c2rust_current_block_46 = C2Rust_Block_46::S_146;
            }
            C2Rust_Block_46::S_146 => {
                _fa = ((*__gamepkg_tls_g_edx) & 0xff as uint32_t) as uint8_t as uint32_t
                    & 0xff as uint32_t;
                c2rust_current_block_46 = C2Rust_Block_46::S_148;
            }
            C2Rust_Block_46::S_148 => {
                _fb = ::core::ptr::read_volatile::<
                    uint8_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint8_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(5 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) as uint32_t & 0xff as uint32_t;
                c2rust_current_block_46 = C2Rust_Block_46::S_150;
            }
            C2Rust_Block_46::S_150 => {
                _fas = _fa as int8_t as int32_t;
                c2rust_current_block_46 = C2Rust_Block_46::S_152;
            }
            C2Rust_Block_46::S_152 => {
                _fbs = _fb as int8_t as int32_t;
                c2rust_current_block_46 = C2Rust_Block_46::S_154;
            }
            C2Rust_Block_46::S_154 => {
                if _fa != _fb {
                    c2rust_current_block_46 = C2Rust_Block_46::S_322;
                } else {
                    c2rust_current_block_46 = C2Rust_Block_46::S_163;
                }
            }
            C2Rust_Block_46::S_163 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 0xffffff00 as uint32_t
                    | ::core::ptr::read_volatile::<
                        uint8_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            ((*__gamepkg_tls_g_edi).wrapping_add(0xc as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ) as uint32_t;
                c2rust_current_block_46 = C2Rust_Block_46::S_165;
            }
            C2Rust_Block_46::S_165 => {
                _fa = ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t as uint32_t
                    & 0xff as uint32_t;
                c2rust_current_block_46 = C2Rust_Block_46::S_167;
            }
            C2Rust_Block_46::S_167 => {
                _fb = ::core::ptr::read_volatile::<
                    uint8_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint8_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) as uint32_t & 0xff as uint32_t;
                c2rust_current_block_46 = C2Rust_Block_46::S_169;
            }
            C2Rust_Block_46::S_169 => {
                _fas = _fa as int8_t as int32_t;
                c2rust_current_block_46 = C2Rust_Block_46::S_171;
            }
            C2Rust_Block_46::S_171 => {
                _fbs = _fb as int8_t as int32_t;
                c2rust_current_block_46 = C2Rust_Block_46::S_173;
            }
            C2Rust_Block_46::S_173 => {
                if _fa != _fb {
                    c2rust_current_block_46 = C2Rust_Block_46::S_322;
                } else {
                    c2rust_current_block_46 = C2Rust_Block_46::S_182;
                }
            }
            C2Rust_Block_46::S_182 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edi) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_46 = C2Rust_Block_46::S_184;
            }
            C2Rust_Block_46::S_184 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_46 = C2Rust_Block_46::S_186;
            }
            C2Rust_Block_46::S_186 => {
                _fb = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(8 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                c2rust_current_block_46 = C2Rust_Block_46::S_188;
            }
            C2Rust_Block_46::S_188 => {
                _fas = _fa as int32_t;
                c2rust_current_block_46 = C2Rust_Block_46::S_190;
            }
            C2Rust_Block_46::S_190 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_46 = C2Rust_Block_46::S_192;
            }
            C2Rust_Block_46::S_192 => {
                if _fa < _fb {
                    c2rust_current_block_46 = C2Rust_Block_46::S_322;
                } else {
                    c2rust_current_block_46 = C2Rust_Block_46::S_201;
                }
            }
            C2Rust_Block_46::S_201 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_46 = C2Rust_Block_46::S_203;
            }
            C2Rust_Block_46::S_203 => {
                _fb = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi).wrapping_add(0xc as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                c2rust_current_block_46 = C2Rust_Block_46::S_205;
            }
            C2Rust_Block_46::S_205 => {
                _fas = _fa as int32_t;
                c2rust_current_block_46 = C2Rust_Block_46::S_207;
            }
            C2Rust_Block_46::S_207 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_46 = C2Rust_Block_46::S_209;
            }
            C2Rust_Block_46::S_209 => {
                if _fa > _fb {
                    c2rust_current_block_46 = C2Rust_Block_46::S_322;
                } else {
                    c2rust_current_block_46 = C2Rust_Block_46::S_218;
                }
            }
            C2Rust_Block_46::S_218 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esi) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_46 = C2Rust_Block_46::S_220;
            }
            C2Rust_Block_46::S_220 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edi).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_46 = C2Rust_Block_46::S_226;
            }
            C2Rust_Block_46::S_226 => {
                _pv_3 = (*__gamepkg_tls_g_ecx);
                c2rust_current_block_46 = C2Rust_Block_46::S_228;
            }
            C2Rust_Block_46::S_228 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_46 = C2Rust_Block_46::S_230;
            }
            C2Rust_Block_46::S_230 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_3,
                );
                c2rust_current_block_46 = C2Rust_Block_46::S_240;
            }
            C2Rust_Block_46::S_240 => {
                _pv_4 = (*__gamepkg_tls_g_edx);
                c2rust_current_block_46 = C2Rust_Block_46::S_242;
            }
            C2Rust_Block_46::S_242 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_46 = C2Rust_Block_46::S_244;
            }
            C2Rust_Block_46::S_244 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_4,
                );
                c2rust_current_block_46 = C2Rust_Block_46::S_254;
            }
            C2Rust_Block_46::S_254 => {
                _pv_5 = 0x1fa181 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_46 = C2Rust_Block_46::S_256;
            }
            C2Rust_Block_46::S_256 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_46 = C2Rust_Block_46::S_258;
            }
            C2Rust_Block_46::S_258 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_5,
                );
                c2rust_current_block_46 = C2Rust_Block_46::S_264;
            }
            C2Rust_Block_46::S_264 => {
                sub_001FE270();
                c2rust_current_block_46 = C2Rust_Block_46::S_270;
            }
            C2Rust_Block_46::S_270 => {
                _fb = 8 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_46 = C2Rust_Block_46::S_272;
            }
            C2Rust_Block_46::S_272 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_46 = C2Rust_Block_46::S_274;
            }
            C2Rust_Block_46::S_274 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(8 as uint32_t);
                c2rust_current_block_46 = C2Rust_Block_46::S_276;
            }
            C2Rust_Block_46::S_276 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_46 = C2Rust_Block_46::S_278;
            }
            C2Rust_Block_46::S_278 => {
                _fas = _fa as int32_t;
                c2rust_current_block_46 = C2Rust_Block_46::S_280;
            }
            C2Rust_Block_46::S_280 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_46 = C2Rust_Block_46::S_282;
            }
            C2Rust_Block_46::S_282 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_46 = C2Rust_Block_46::S_284;
            }
            C2Rust_Block_46::S_284 => {
                _fas = _fa as int32_t;
                c2rust_current_block_46 = C2Rust_Block_46::S_286;
            }
            C2Rust_Block_46::S_286 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_46 = C2Rust_Block_46::S_288;
            }
            C2Rust_Block_46::S_288 => {
                if _fa != _fb {
                    c2rust_current_block_46 = C2Rust_Block_46::S_322;
                } else {
                    c2rust_current_block_46 = C2Rust_Block_46::S_297;
                }
            }
            C2Rust_Block_46::S_297 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 0xffffff00 as uint32_t
                    | ::core::ptr::read_volatile::<
                        uint8_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            ((*__gamepkg_tls_g_esi).wrapping_add(0x10 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ) as uint32_t;
                c2rust_current_block_46 = C2Rust_Block_46::S_299;
            }
            C2Rust_Block_46::S_299 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 0xffffff00 as uint32_t
                    | (((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t
                        as ::core::ffi::c_int
                        ^ ::core::ptr::read_volatile::<
                            uint8_t,
                        >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                uint8_t,
                            >(
                                ((*__gamepkg_tls_g_edi).wrapping_add(0x18 as uint32_t)
                                    as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        ) as ::core::ffi::c_int) as uint8_t as uint32_t;
                c2rust_current_block_46 = C2Rust_Block_46::S_301;
            }
            C2Rust_Block_46::S_301 => {
                _fa = ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t as uint32_t
                    & 0xff as uint32_t;
                c2rust_current_block_46 = C2Rust_Block_46::S_303;
            }
            C2Rust_Block_46::S_303 => {
                _fas = _fa as int8_t as int32_t;
                c2rust_current_block_46 = C2Rust_Block_46::S_305;
            }
            C2Rust_Block_46::S_305 => {
                _fa = (((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t
                    as ::core::ffi::c_int & 1 as ::core::ffi::c_int) as uint32_t
                    & 0xff as uint32_t;
                c2rust_current_block_46 = C2Rust_Block_46::S_307;
            }
            C2Rust_Block_46::S_307 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xff as uint32_t;
                c2rust_current_block_46 = C2Rust_Block_46::S_309;
            }
            C2Rust_Block_46::S_309 => {
                _fas = _fa as int8_t as int32_t;
                c2rust_current_block_46 = C2Rust_Block_46::S_311;
            }
            C2Rust_Block_46::S_311 => {
                _fbs = _fb as int8_t as int32_t;
                c2rust_current_block_46 = C2Rust_Block_46::S_313;
            }
            C2Rust_Block_46::S_313 => {
                if _fa == _fb {
                    c2rust_current_block_46 = C2Rust_Block_46::S_413;
                } else {
                    c2rust_current_block_46 = C2Rust_Block_46::S_322;
                }
            }
            C2Rust_Block_46::S_322 => {
                (*__gamepkg_tls_g_ebx) = (*__gamepkg_tls_g_ebx).wrapping_add(1);
                c2rust_current_block_46 = C2Rust_Block_46::S_324;
            }
            C2Rust_Block_46::S_324 => {
                _fa = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
                c2rust_current_block_46 = C2Rust_Block_46::S_326;
            }
            C2Rust_Block_46::S_326 => {
                _fas = _fa as int32_t;
                c2rust_current_block_46 = C2Rust_Block_46::S_328;
            }
            C2Rust_Block_46::S_328 => {
                _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_46 = C2Rust_Block_46::S_330;
            }
            C2Rust_Block_46::S_330 => {
                _fa = (*__gamepkg_tls_g_ebx) & 0xffffffff as uint32_t;
                c2rust_current_block_46 = C2Rust_Block_46::S_332;
            }
            C2Rust_Block_46::S_332 => {
                _fb = ebp & 0xffffffff as uint32_t;
                c2rust_current_block_46 = C2Rust_Block_46::S_334;
            }
            C2Rust_Block_46::S_334 => {
                _fas = _fa as int32_t;
                c2rust_current_block_46 = C2Rust_Block_46::S_336;
            }
            C2Rust_Block_46::S_336 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_46 = C2Rust_Block_46::S_338;
            }
            C2Rust_Block_46::S_338 => {
                if _fa < _fb {
                    c2rust_current_block_46 = C2Rust_Block_46::S_140;
                } else {
                    c2rust_current_block_46 = C2Rust_Block_46::S_351;
                }
            }
            C2Rust_Block_46::S_351 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_46 = C2Rust_Block_46::S_353;
            }
            C2Rust_Block_46::S_353 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_46 = C2Rust_Block_46::S_363;
            }
            C2Rust_Block_46::S_363 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_46 = C2Rust_Block_46::S_365;
            }
            C2Rust_Block_46::S_365 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_46 = C2Rust_Block_46::S_375;
            }
            C2Rust_Block_46::S_375 => {
                (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_46 = C2Rust_Block_46::S_377;
            }
            C2Rust_Block_46::S_377 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_46 = C2Rust_Block_46::S_383;
            }
            C2Rust_Block_46::S_383 => {
                (*__gamepkg_tls_g_eax) = 0 as uint32_t;
                c2rust_current_block_46 = C2Rust_Block_46::S_385;
            }
            C2Rust_Block_46::S_385 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_46 = C2Rust_Block_46::S_387;
            }
            C2Rust_Block_46::S_387 => {
                _fas = _fa as int32_t;
                c2rust_current_block_46 = C2Rust_Block_46::S_393;
            }
            C2Rust_Block_46::S_393 => {
                ebp = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_46 = C2Rust_Block_46::S_395;
            }
            C2Rust_Block_46::S_395 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_46 = C2Rust_Block_46::S_401;
            }
            C2Rust_Block_46::S_401 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_46 = C2Rust_Block_46::S_403;
            }
            C2Rust_Block_46::S_403 => return,
            C2Rust_Block_46::S_413 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_46 = C2Rust_Block_46::S_415;
            }
            C2Rust_Block_46::S_415 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_46 = C2Rust_Block_46::S_425;
            }
            C2Rust_Block_46::S_425 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_46 = C2Rust_Block_46::S_427;
            }
            C2Rust_Block_46::S_427 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_46 = C2Rust_Block_46::S_437;
            }
            C2Rust_Block_46::S_437 => {
                (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_46 = C2Rust_Block_46::S_439;
            }
            C2Rust_Block_46::S_439 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_46 = C2Rust_Block_46::S_445;
            }
            C2Rust_Block_46::S_445 => {
                (*__gamepkg_tls_g_eax) = 1 as uint32_t;
                c2rust_current_block_46 = C2Rust_Block_46::S_451;
            }
            C2Rust_Block_46::S_451 => {
                ebp = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_46 = C2Rust_Block_46::S_453;
            }
            C2Rust_Block_46::S_453 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_46 = C2Rust_Block_46::S_459;
            }
            C2Rust_Block_46::S_459 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_46 = C2Rust_Block_46::S_461;
            }
            C2Rust_Block_46::S_461 => return,
            C2Rust_Block_46::S_467 => {
                (*__gamepkg_tls_g_eax) = 1 as uint32_t;
                c2rust_current_block_46 = C2Rust_Block_46::S_473;
            }
            C2Rust_Block_46::S_473 => {
                ebp = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_46 = C2Rust_Block_46::S_475;
            }
            C2Rust_Block_46::S_475 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_46 = C2Rust_Block_46::S_481;
            }
            C2Rust_Block_46::S_481 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_46 = C2Rust_Block_46::S_483;
            }
            C2Rust_Block_46::S_483 => return,
            C2Rust_Block_46::S_493 => {
                (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_46 = C2Rust_Block_46::S_495;
            }
            C2Rust_Block_46::S_495 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_46 = C2Rust_Block_46::S_501;
            }
            C2Rust_Block_46::S_501 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_ecx);
                c2rust_current_block_46 = C2Rust_Block_46::S_507;
            }
            C2Rust_Block_46::S_507 => {
                ebp = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_46 = C2Rust_Block_46::S_509;
            }
            C2Rust_Block_46::S_509 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_46 = C2Rust_Block_46::S_515;
            }
            C2Rust_Block_46::S_515 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_46 = C2Rust_Block_46::S_517;
            }
            C2Rust_Block_46::S_517 => return,
        }
    };
}
#[no_mangle]
pub unsafe extern "C" fn sub_001FA1C0() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0 as ::core::ffi::c_int;
    let mut _fa: uint32_t = 0 as uint32_t;
    let mut _fb: uint32_t = 0 as uint32_t;
    let mut _fas: int32_t = 0 as int32_t;
    let mut _fbs: int32_t = 0 as int32_t;
    let mut _pv: uint32_t = (*__gamepkg_tls_g_esi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv,
    );
    let mut _pv_0: uint32_t = (*__gamepkg_tls_g_edi);
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        _pv_0,
    );
    (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(0xc as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esi) = 0 as uint32_t;
    _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
    _fas = _fa as int32_t;
    's_60: loop {
        (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi)
                    .wrapping_mul(4 as uint32_t)
                    .wrapping_add(0x3c1584 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        let mut _pv_1: uint32_t = (*__gamepkg_tls_g_edi);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_1,
        );
        let mut _pv_2: uint32_t = (*__gamepkg_tls_g_eax);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_2,
        );
        let mut _pv_3: uint32_t = 0x1fa1de as ::core::ffi::c_uint as uint32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_sub(4 as uint32_t);
        ::core::ptr::write_volatile(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
            _pv_3,
        );
        sub_001FE270();
        _fb = 8 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fbs = _fb as int32_t;
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(8 as uint32_t);
        _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
        _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
        _fas = _fa as int32_t;
        _fbs = _fb as int32_t;
        's_200: {
            if _fa == _fb {
                break 's_200;
            }
            (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi).wrapping_add(1);
            _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
            _fa = (*__gamepkg_tls_g_esi) & 0xffffffff as uint32_t;
            _fb = 9 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            _fbs = _fb as int32_t;
            if _fa < _fb {
                continue 's_60;
            }
            (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
            (*__gamepkg_tls_g_eax) = 0 as uint32_t;
            _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
            _fas = _fa as int32_t;
            (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                uint32_t,
            >(
                ::core::ptr::with_exposed_provenance_mut::<
                    uint32_t,
                >(
                    ((*__gamepkg_tls_g_esp) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                ),
            );
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
            (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
            return;
        }
        (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esi)
                    .wrapping_mul(4 as uint32_t)
                    .wrapping_add(0x3c1584 as uint32_t) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
            uint32_t,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                uint32_t,
            >(
                ((*__gamepkg_tls_g_esp) as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
        return;
    };
}
#[no_mangle]
pub unsafe extern "C" fn sub_001FA200() {
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
        uint32_t,
    >(
        ::core::ptr::with_exposed_provenance_mut::<
            uint32_t,
        >(
            ((*__gamepkg_tls_g_eax)
                .wrapping_mul(4 as uint32_t)
                .wrapping_add(0x3c1584 as uint32_t) as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_001FA210() {
    let __gamepkg_tls_g_df = unsafe { gamepkg_tls_g_df() };
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebx = unsafe { gamepkg_tls_g_ebx() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _flags: ::core::ffi::c_int = 0;
    let mut _fa: uint32_t = 0;
    let mut _fb: uint32_t = 0;
    let mut _fas: int32_t = 0;
    let mut _fbs: int32_t = 0;
    let mut _cf: ::core::ffi::c_int = 0;
    let mut _pv: uint32_t = 0;
    let mut _pv_0: uint32_t = 0;
    let mut _pv_1: uint32_t = 0;
    let mut _pv_2: uint32_t = 0;
    let mut _pv_3: uint32_t = 0;
    let mut _pv_4: uint32_t = 0;
    let mut _pv_5: uint32_t = 0;
    let mut _pv_6: uint32_t = 0;
    let mut _pv_7: uint32_t = 0;
    let mut _pv_8: uint32_t = 0;
    let mut _pv_9: uint32_t = 0;
    let mut _pv_10: uint32_t = 0;
    let mut _pv_11: uint32_t = 0;
    let mut _pv_12: uint32_t = 0;
    let mut _pv_13: uint32_t = 0;
    let mut _pv_14: uint32_t = 0;
    let mut _pv_15: uint32_t = 0;
    let mut _pv_16: uint32_t = 0;
    let mut _pv_17: uint32_t = 0;
    let mut _pv_18: uint32_t = 0;
    let mut _pv_19: uint32_t = 0;
    let mut _pv_20: uint32_t = 0;
    let mut _pv_21: uint32_t = 0;
    let mut _pv_22: uint32_t = 0;
    let mut _pv_23: uint32_t = 0;
    let mut _pv_24: uint32_t = 0;
    let mut _pv_25: uint32_t = 0;
    let mut _pv_26: uint32_t = 0;
    let mut _pv_27: uint32_t = 0;
    let mut _pv_28: uint32_t = 0;
    let mut _pv_29: uint32_t = 0;
    let mut _pv_30: uint32_t = 0;
    let mut _pv_31: uint32_t = 0;
    let mut _d: *mut uint8_t = ::core::ptr::null_mut::<uint8_t>();
    let mut _s: *mut uint8_t = ::core::ptr::null_mut::<uint8_t>();
    let mut _n: uint32_t = 0;
    let mut _i: uint32_t = 0;
    let mut _i_0: uint32_t = 0;
    let mut _pv_32: uint32_t = 0;
    let mut _pv_33: uint32_t = 0;
    let mut _pv_34: uint32_t = 0;
    let mut _pv_35: uint32_t = 0;
    let mut _dividend: uint64_t = 0;
    let mut _pv_36: uint32_t = 0;
    let mut _pv_37: uint32_t = 0;
    let mut _dividend_0: uint64_t = 0;
    enum C2Rust_Block_49 {
        S_0,
        S_2,
        S_4,
        S_14,
        S_20,
        S_22,
        S_24,
        S_26,
        S_28,
        S_30,
        S_36,
        S_38,
        S_40,
        S_46,
        S_48,
        S_54,
        S_56,
        S_58,
        S_68,
        S_70,
        S_72,
        S_82,
        S_84,
        S_86,
        S_92,
        S_98,
        S_100,
        S_102,
        S_104,
        S_106,
        S_108,
        S_110,
        S_112,
        S_114,
        S_116,
        S_118,
        S_120,
        S_129,
        S_135,
        S_137,
        S_139,
        S_149,
        S_151,
        S_153,
        S_163,
        S_165,
        S_167,
        S_173,
        S_179,
        S_181,
        S_183,
        S_185,
        S_187,
        S_189,
        S_191,
        S_193,
        S_195,
        S_197,
        S_199,
        S_201,
        S_210,
        S_216,
        S_218,
        S_224,
        S_226,
        S_228,
        S_230,
        S_232,
        S_234,
        S_236,
        S_238,
        S_244,
        S_250,
        S_252,
        S_254,
        S_264,
        S_266,
        S_268,
        S_278,
        S_280,
        S_282,
        S_288,
        S_294,
        S_296,
        S_298,
        S_300,
        S_302,
        S_304,
        S_306,
        S_308,
        S_310,
        S_312,
        S_314,
        S_316,
        S_325,
        S_331,
        S_333,
        S_339,
        S_341,
        S_343,
        S_345,
        S_347,
        S_349,
        S_351,
        S_353,
        S_359,
        S_365,
        S_367,
        S_369,
        S_379,
        S_381,
        S_383,
        S_393,
        S_395,
        S_397,
        S_403,
        S_409,
        S_411,
        S_413,
        S_415,
        S_417,
        S_419,
        S_421,
        S_423,
        S_425,
        S_427,
        S_429,
        S_431,
        S_440,
        S_446,
        S_448,
        S_454,
        S_456,
        S_458,
        S_460,
        S_462,
        S_464,
        S_466,
        S_468,
        S_474,
        S_480,
        S_482,
        S_484,
        S_494,
        S_496,
        S_498,
        S_508,
        S_510,
        S_512,
        S_518,
        S_524,
        S_526,
        S_528,
        S_530,
        S_532,
        S_534,
        S_536,
        S_538,
        S_540,
        S_542,
        S_544,
        S_546,
        S_555,
        S_561,
        S_563,
        S_569,
        S_571,
        S_573,
        S_575,
        S_577,
        S_579,
        S_581,
        S_583,
        S_589,
        S_595,
        S_597,
        S_599,
        S_609,
        S_611,
        S_613,
        S_623,
        S_625,
        S_627,
        S_633,
        S_639,
        S_641,
        S_643,
        S_645,
        S_647,
        S_649,
        S_651,
        S_653,
        S_655,
        S_657,
        S_659,
        S_661,
        S_670,
        S_676,
        S_678,
        S_680,
        S_690,
        S_692,
        S_694,
        S_704,
        S_706,
        S_708,
        S_714,
        S_720,
        S_722,
        S_724,
        S_726,
        S_728,
        S_730,
        S_732,
        S_734,
        S_736,
        S_738,
        S_740,
        S_742,
        S_751,
        S_757,
        S_759,
        S_761,
        S_771,
        S_773,
        S_775,
        S_785,
        S_787,
        S_789,
        S_795,
        S_801,
        S_803,
        S_805,
        S_807,
        S_809,
        S_811,
        S_813,
        S_815,
        S_817,
        S_819,
        S_821,
        S_823,
        S_832,
        S_838,
        S_840,
        S_842,
        S_852,
        S_854,
        S_856,
        S_866,
        S_868,
        S_870,
        S_876,
        S_882,
        S_884,
        S_886,
        S_888,
        S_890,
        S_892,
        S_894,
        S_896,
        S_898,
        S_900,
        S_902,
        S_904,
        S_913,
        S_919,
        S_921,
        S_923,
        S_933,
        S_935,
        S_937,
        S_947,
        S_949,
        S_951,
        S_957,
        S_963,
        S_965,
        S_967,
        S_969,
        S_971,
        S_973,
        S_975,
        S_977,
        S_979,
        S_981,
        S_983,
        S_985,
        S_987,
        S_989,
        S_991,
        S_993,
        S_995,
        S_1001,
        S_1003,
        S_1009,
        S_1011,
        S_1013,
        S_1015,
        S_1017,
        S_1019,
        S_1021,
        S_1023,
        S_1029,
        S_1035,
        S_1037,
        S_1043,
        S_1045,
        S_1047,
        S_1049,
        S_1051,
        S_1053,
        S_1055,
        S_1057,
        S_1063,
        S_1065,
        S_1067,
        S_1069,
        S_1071,
        S_1073,
        S_1075,
        S_1077,
        S_1086,
        S_1092,
        S_1094,
        S_1100,
        S_1102,
        S_1104,
        S_1106,
        S_1108,
        S_1110,
        S_1112,
        S_1114,
        S_1124,
        S_1126,
        S_1128,
        S_1138,
        S_1140,
        S_1142,
        S_1148,
        S_1150,
        S_1152,
        S_1154,
        S_1158,
        S_1160,
        S_1162,
        S_1164,
        S_1168,
        S_1171,
        S_1172,
        S_1173,
        S_1174,
        S_1185,
        S_1187,
        S_1192,
        S_1195,
        S_1196,
        S_1197,
        S_1198,
        S_1205,
        S_1207,
        S_1213,
        S_1219,
        S_1221,
        S_1223,
        S_1229,
        S_1235,
        S_1237,
        S_1239,
        S_1245,
        S_1251,
        S_1257,
        S_1259,
        S_1261,
        S_1267,
        S_1273,
        S_1275,
        S_1277,
        S_1283,
        S_1289,
        S_1291,
        S_1293,
        S_1295,
        S_1298,
        S_1300,
        S_1302,
        S_1306,
        S_1312,
        S_1314,
        S_1316,
        S_1322,
        S_1328,
        S_1330,
        S_1332,
        S_1338,
        S_1344,
        S_1346,
        S_1348,
        S_1350,
        S_1352,
        S_1354,
        S_1356,
        S_1358,
        S_1360,
        S_1362,
        S_1368,
        S_1370,
        S_1377,
        S_1379,
        S_1381,
        S_1389,
        S_1391,
        S_1401,
        S_1403,
        S_1409,
        S_1411,
        S_1413,
        S_1415,
        S_1417,
        S_1419,
        S_1421,
        S_1423,
    }
    let mut c2rust_current_block_49: C2Rust_Block_49;
    c2rust_current_block_49 = C2Rust_Block_49::S_0;
    loop {
        match c2rust_current_block_49 {
            C2Rust_Block_49::S_0 => {
                _flags = 0 as ::core::ffi::c_int;
                c2rust_current_block_49 = C2Rust_Block_49::S_2;
            }
            C2Rust_Block_49::S_2 => {
                _fa = 0 as uint32_t;
                _fb = 0 as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_4;
            }
            C2Rust_Block_49::S_4 => {
                _fas = 0 as int32_t;
                _fbs = 0 as int32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_14;
            }
            C2Rust_Block_49::S_14 => {
                _cf = 0 as ::core::ffi::c_int;
                c2rust_current_block_49 = C2Rust_Block_49::S_20;
            }
            C2Rust_Block_49::S_20 => {
                _fb = 0x1c as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_22;
            }
            C2Rust_Block_49::S_22 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_24;
            }
            C2Rust_Block_49::S_24 => {
                _cf = ((*__gamepkg_tls_g_esp) < 0x1c as ::core::ffi::c_int as uint32_t)
                    as ::core::ffi::c_int;
                c2rust_current_block_49 = C2Rust_Block_49::S_26;
            }
            C2Rust_Block_49::S_26 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(0x1c as uint32_t);
                c2rust_current_block_49 = C2Rust_Block_49::S_28;
            }
            C2Rust_Block_49::S_28 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_30;
            }
            C2Rust_Block_49::S_30 => {
                _fas = _fa as int32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_36;
            }
            C2Rust_Block_49::S_36 => {
                _pv = (*__gamepkg_tls_g_ebx);
                c2rust_current_block_49 = C2Rust_Block_49::S_38;
            }
            C2Rust_Block_49::S_38 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_49 = C2Rust_Block_49::S_40;
            }
            C2Rust_Block_49::S_40 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv,
                );
                c2rust_current_block_49 = C2Rust_Block_49::S_46;
            }
            C2Rust_Block_49::S_46 => {
                (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x24 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_49 = C2Rust_Block_49::S_48;
            }
            C2Rust_Block_49::S_48 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ebx).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_49 = C2Rust_Block_49::S_54;
            }
            C2Rust_Block_49::S_54 => {
                _pv_0 = 0x36dbe8 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_56;
            }
            C2Rust_Block_49::S_56 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_49 = C2Rust_Block_49::S_58;
            }
            C2Rust_Block_49::S_58 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_0,
                );
                c2rust_current_block_49 = C2Rust_Block_49::S_68;
            }
            C2Rust_Block_49::S_68 => {
                _pv_1 = (*__gamepkg_tls_g_eax);
                c2rust_current_block_49 = C2Rust_Block_49::S_70;
            }
            C2Rust_Block_49::S_70 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_49 = C2Rust_Block_49::S_72;
            }
            C2Rust_Block_49::S_72 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_1,
                );
                c2rust_current_block_49 = C2Rust_Block_49::S_82;
            }
            C2Rust_Block_49::S_82 => {
                _pv_2 = 0x1fa226 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_84;
            }
            C2Rust_Block_49::S_84 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_49 = C2Rust_Block_49::S_86;
            }
            C2Rust_Block_49::S_86 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_2,
                );
                c2rust_current_block_49 = C2Rust_Block_49::S_92;
            }
            C2Rust_Block_49::S_92 => {
                sub_001FE270();
                c2rust_current_block_49 = C2Rust_Block_49::S_98;
            }
            C2Rust_Block_49::S_98 => {
                _fb = 8 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_100;
            }
            C2Rust_Block_49::S_100 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_102;
            }
            C2Rust_Block_49::S_102 => {
                _cf = (((*__gamepkg_tls_g_esp) as uint64_t)
                    .wrapping_add(8 as ::core::ffi::c_int as uint64_t)
                    >> 32 as ::core::ffi::c_int & 1 as uint64_t) as ::core::ffi::c_int;
                c2rust_current_block_49 = C2Rust_Block_49::S_104;
            }
            C2Rust_Block_49::S_104 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(8 as uint32_t);
                c2rust_current_block_49 = C2Rust_Block_49::S_106;
            }
            C2Rust_Block_49::S_106 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_108;
            }
            C2Rust_Block_49::S_108 => {
                _fas = _fa as int32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_110;
            }
            C2Rust_Block_49::S_110 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_112;
            }
            C2Rust_Block_49::S_112 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_114;
            }
            C2Rust_Block_49::S_114 => {
                _fas = _fa as int32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_116;
            }
            C2Rust_Block_49::S_116 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_118;
            }
            C2Rust_Block_49::S_118 => {
                _cf = 0 as ::core::ffi::c_int;
                c2rust_current_block_49 = C2Rust_Block_49::S_120;
            }
            C2Rust_Block_49::S_120 => {
                if _fa == _fb {
                    c2rust_current_block_49 = C2Rust_Block_49::S_325;
                } else {
                    c2rust_current_block_49 = C2Rust_Block_49::S_129;
                }
            }
            C2Rust_Block_49::S_129 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ebx).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_49 = C2Rust_Block_49::S_135;
            }
            C2Rust_Block_49::S_135 => {
                _pv_3 = 0x36dbd8 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_137;
            }
            C2Rust_Block_49::S_137 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_49 = C2Rust_Block_49::S_139;
            }
            C2Rust_Block_49::S_139 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_3,
                );
                c2rust_current_block_49 = C2Rust_Block_49::S_149;
            }
            C2Rust_Block_49::S_149 => {
                _pv_4 = (*__gamepkg_tls_g_ecx);
                c2rust_current_block_49 = C2Rust_Block_49::S_151;
            }
            C2Rust_Block_49::S_151 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_49 = C2Rust_Block_49::S_153;
            }
            C2Rust_Block_49::S_153 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_4,
                );
                c2rust_current_block_49 = C2Rust_Block_49::S_163;
            }
            C2Rust_Block_49::S_163 => {
                _pv_5 = 0x1fa23b as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_165;
            }
            C2Rust_Block_49::S_165 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_49 = C2Rust_Block_49::S_167;
            }
            C2Rust_Block_49::S_167 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_5,
                );
                c2rust_current_block_49 = C2Rust_Block_49::S_173;
            }
            C2Rust_Block_49::S_173 => {
                sub_001FE270();
                c2rust_current_block_49 = C2Rust_Block_49::S_179;
            }
            C2Rust_Block_49::S_179 => {
                _fb = 8 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_181;
            }
            C2Rust_Block_49::S_181 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_183;
            }
            C2Rust_Block_49::S_183 => {
                _cf = (((*__gamepkg_tls_g_esp) as uint64_t)
                    .wrapping_add(8 as ::core::ffi::c_int as uint64_t)
                    >> 32 as ::core::ffi::c_int & 1 as uint64_t) as ::core::ffi::c_int;
                c2rust_current_block_49 = C2Rust_Block_49::S_185;
            }
            C2Rust_Block_49::S_185 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(8 as uint32_t);
                c2rust_current_block_49 = C2Rust_Block_49::S_187;
            }
            C2Rust_Block_49::S_187 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_189;
            }
            C2Rust_Block_49::S_189 => {
                _fas = _fa as int32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_191;
            }
            C2Rust_Block_49::S_191 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_193;
            }
            C2Rust_Block_49::S_193 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_195;
            }
            C2Rust_Block_49::S_195 => {
                _fas = _fa as int32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_197;
            }
            C2Rust_Block_49::S_197 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_199;
            }
            C2Rust_Block_49::S_199 => {
                _cf = 0 as ::core::ffi::c_int;
                c2rust_current_block_49 = C2Rust_Block_49::S_201;
            }
            C2Rust_Block_49::S_201 => {
                if _fa != _fb {
                    c2rust_current_block_49 = C2Rust_Block_49::S_244;
                } else {
                    c2rust_current_block_49 = C2Rust_Block_49::S_210;
                }
            }
            C2Rust_Block_49::S_210 => {
                (*__gamepkg_tls_g_eax) = 0x1c as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_216;
            }
            C2Rust_Block_49::S_216 => {
                (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_49 = C2Rust_Block_49::S_218;
            }
            C2Rust_Block_49::S_218 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_49 = C2Rust_Block_49::S_224;
            }
            C2Rust_Block_49::S_224 => {
                _fb = 0x1c as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_226;
            }
            C2Rust_Block_49::S_226 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_228;
            }
            C2Rust_Block_49::S_228 => {
                _cf = (((*__gamepkg_tls_g_esp) as uint64_t)
                    .wrapping_add(0x1c as ::core::ffi::c_int as uint64_t)
                    >> 32 as ::core::ffi::c_int & 1 as uint64_t) as ::core::ffi::c_int;
                c2rust_current_block_49 = C2Rust_Block_49::S_230;
            }
            C2Rust_Block_49::S_230 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(0x1c as uint32_t);
                c2rust_current_block_49 = C2Rust_Block_49::S_232;
            }
            C2Rust_Block_49::S_232 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_234;
            }
            C2Rust_Block_49::S_234 => {
                _fas = _fa as int32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_236;
            }
            C2Rust_Block_49::S_236 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_49 = C2Rust_Block_49::S_238;
            }
            C2Rust_Block_49::S_238 => return,
            C2Rust_Block_49::S_244 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ebx).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_49 = C2Rust_Block_49::S_250;
            }
            C2Rust_Block_49::S_250 => {
                _pv_6 = 0x36dbf8 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_252;
            }
            C2Rust_Block_49::S_252 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_49 = C2Rust_Block_49::S_254;
            }
            C2Rust_Block_49::S_254 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_6,
                );
                c2rust_current_block_49 = C2Rust_Block_49::S_264;
            }
            C2Rust_Block_49::S_264 => {
                _pv_7 = (*__gamepkg_tls_g_edx);
                c2rust_current_block_49 = C2Rust_Block_49::S_266;
            }
            C2Rust_Block_49::S_266 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_49 = C2Rust_Block_49::S_268;
            }
            C2Rust_Block_49::S_268 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_7,
                );
                c2rust_current_block_49 = C2Rust_Block_49::S_278;
            }
            C2Rust_Block_49::S_278 => {
                _pv_8 = 0x1fa25a as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_280;
            }
            C2Rust_Block_49::S_280 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_49 = C2Rust_Block_49::S_282;
            }
            C2Rust_Block_49::S_282 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_8,
                );
                c2rust_current_block_49 = C2Rust_Block_49::S_288;
            }
            C2Rust_Block_49::S_288 => {
                sub_001FE270();
                c2rust_current_block_49 = C2Rust_Block_49::S_294;
            }
            C2Rust_Block_49::S_294 => {
                _fb = 8 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_296;
            }
            C2Rust_Block_49::S_296 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_298;
            }
            C2Rust_Block_49::S_298 => {
                _cf = (((*__gamepkg_tls_g_esp) as uint64_t)
                    .wrapping_add(8 as ::core::ffi::c_int as uint64_t)
                    >> 32 as ::core::ffi::c_int & 1 as uint64_t) as ::core::ffi::c_int;
                c2rust_current_block_49 = C2Rust_Block_49::S_300;
            }
            C2Rust_Block_49::S_300 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(8 as uint32_t);
                c2rust_current_block_49 = C2Rust_Block_49::S_302;
            }
            C2Rust_Block_49::S_302 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_304;
            }
            C2Rust_Block_49::S_304 => {
                _fas = _fa as int32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_306;
            }
            C2Rust_Block_49::S_306 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_308;
            }
            C2Rust_Block_49::S_308 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_310;
            }
            C2Rust_Block_49::S_310 => {
                _fas = _fa as int32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_312;
            }
            C2Rust_Block_49::S_312 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_314;
            }
            C2Rust_Block_49::S_314 => {
                _cf = 0 as ::core::ffi::c_int;
                c2rust_current_block_49 = C2Rust_Block_49::S_316;
            }
            C2Rust_Block_49::S_316 => {
                if _fa != _fb {
                    c2rust_current_block_49 = C2Rust_Block_49::S_359;
                } else {
                    c2rust_current_block_49 = C2Rust_Block_49::S_325;
                }
            }
            C2Rust_Block_49::S_325 => {
                (*__gamepkg_tls_g_eax) = 1 as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_331;
            }
            C2Rust_Block_49::S_331 => {
                (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_49 = C2Rust_Block_49::S_333;
            }
            C2Rust_Block_49::S_333 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_49 = C2Rust_Block_49::S_339;
            }
            C2Rust_Block_49::S_339 => {
                _fb = 0x1c as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_341;
            }
            C2Rust_Block_49::S_341 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_343;
            }
            C2Rust_Block_49::S_343 => {
                _cf = (((*__gamepkg_tls_g_esp) as uint64_t)
                    .wrapping_add(0x1c as ::core::ffi::c_int as uint64_t)
                    >> 32 as ::core::ffi::c_int & 1 as uint64_t) as ::core::ffi::c_int;
                c2rust_current_block_49 = C2Rust_Block_49::S_345;
            }
            C2Rust_Block_49::S_345 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(0x1c as uint32_t);
                c2rust_current_block_49 = C2Rust_Block_49::S_347;
            }
            C2Rust_Block_49::S_347 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_349;
            }
            C2Rust_Block_49::S_349 => {
                _fas = _fa as int32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_351;
            }
            C2Rust_Block_49::S_351 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_49 = C2Rust_Block_49::S_353;
            }
            C2Rust_Block_49::S_353 => return,
            C2Rust_Block_49::S_359 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ebx).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_49 = C2Rust_Block_49::S_365;
            }
            C2Rust_Block_49::S_365 => {
                _pv_9 = 0x36dc68 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_367;
            }
            C2Rust_Block_49::S_367 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_49 = C2Rust_Block_49::S_369;
            }
            C2Rust_Block_49::S_369 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_9,
                );
                c2rust_current_block_49 = C2Rust_Block_49::S_379;
            }
            C2Rust_Block_49::S_379 => {
                _pv_10 = (*__gamepkg_tls_g_eax);
                c2rust_current_block_49 = C2Rust_Block_49::S_381;
            }
            C2Rust_Block_49::S_381 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_49 = C2Rust_Block_49::S_383;
            }
            C2Rust_Block_49::S_383 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_10,
                );
                c2rust_current_block_49 = C2Rust_Block_49::S_393;
            }
            C2Rust_Block_49::S_393 => {
                _pv_11 = 0x1fa279 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_395;
            }
            C2Rust_Block_49::S_395 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_49 = C2Rust_Block_49::S_397;
            }
            C2Rust_Block_49::S_397 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_11,
                );
                c2rust_current_block_49 = C2Rust_Block_49::S_403;
            }
            C2Rust_Block_49::S_403 => {
                sub_001FE270();
                c2rust_current_block_49 = C2Rust_Block_49::S_409;
            }
            C2Rust_Block_49::S_409 => {
                _fb = 8 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_411;
            }
            C2Rust_Block_49::S_411 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_413;
            }
            C2Rust_Block_49::S_413 => {
                _cf = (((*__gamepkg_tls_g_esp) as uint64_t)
                    .wrapping_add(8 as ::core::ffi::c_int as uint64_t)
                    >> 32 as ::core::ffi::c_int & 1 as uint64_t) as ::core::ffi::c_int;
                c2rust_current_block_49 = C2Rust_Block_49::S_415;
            }
            C2Rust_Block_49::S_415 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(8 as uint32_t);
                c2rust_current_block_49 = C2Rust_Block_49::S_417;
            }
            C2Rust_Block_49::S_417 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_419;
            }
            C2Rust_Block_49::S_419 => {
                _fas = _fa as int32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_421;
            }
            C2Rust_Block_49::S_421 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_423;
            }
            C2Rust_Block_49::S_423 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_425;
            }
            C2Rust_Block_49::S_425 => {
                _fas = _fa as int32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_427;
            }
            C2Rust_Block_49::S_427 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_429;
            }
            C2Rust_Block_49::S_429 => {
                _cf = 0 as ::core::ffi::c_int;
                c2rust_current_block_49 = C2Rust_Block_49::S_431;
            }
            C2Rust_Block_49::S_431 => {
                if _fa != _fb {
                    c2rust_current_block_49 = C2Rust_Block_49::S_474;
                } else {
                    c2rust_current_block_49 = C2Rust_Block_49::S_440;
                }
            }
            C2Rust_Block_49::S_440 => {
                (*__gamepkg_tls_g_eax) = 0x600 as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_446;
            }
            C2Rust_Block_49::S_446 => {
                (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_49 = C2Rust_Block_49::S_448;
            }
            C2Rust_Block_49::S_448 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_49 = C2Rust_Block_49::S_454;
            }
            C2Rust_Block_49::S_454 => {
                _fb = 0x1c as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_456;
            }
            C2Rust_Block_49::S_456 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_458;
            }
            C2Rust_Block_49::S_458 => {
                _cf = (((*__gamepkg_tls_g_esp) as uint64_t)
                    .wrapping_add(0x1c as ::core::ffi::c_int as uint64_t)
                    >> 32 as ::core::ffi::c_int & 1 as uint64_t) as ::core::ffi::c_int;
                c2rust_current_block_49 = C2Rust_Block_49::S_460;
            }
            C2Rust_Block_49::S_460 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(0x1c as uint32_t);
                c2rust_current_block_49 = C2Rust_Block_49::S_462;
            }
            C2Rust_Block_49::S_462 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_464;
            }
            C2Rust_Block_49::S_464 => {
                _fas = _fa as int32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_466;
            }
            C2Rust_Block_49::S_466 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_49 = C2Rust_Block_49::S_468;
            }
            C2Rust_Block_49::S_468 => return,
            C2Rust_Block_49::S_474 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ebx).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_49 = C2Rust_Block_49::S_480;
            }
            C2Rust_Block_49::S_480 => {
                _pv_12 = 0x36dc08 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_482;
            }
            C2Rust_Block_49::S_482 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_49 = C2Rust_Block_49::S_484;
            }
            C2Rust_Block_49::S_484 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_12,
                );
                c2rust_current_block_49 = C2Rust_Block_49::S_494;
            }
            C2Rust_Block_49::S_494 => {
                _pv_13 = (*__gamepkg_tls_g_ecx);
                c2rust_current_block_49 = C2Rust_Block_49::S_496;
            }
            C2Rust_Block_49::S_496 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_49 = C2Rust_Block_49::S_498;
            }
            C2Rust_Block_49::S_498 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_13,
                );
                c2rust_current_block_49 = C2Rust_Block_49::S_508;
            }
            C2Rust_Block_49::S_508 => {
                _pv_14 = 0x1fa298 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_510;
            }
            C2Rust_Block_49::S_510 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_49 = C2Rust_Block_49::S_512;
            }
            C2Rust_Block_49::S_512 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_14,
                );
                c2rust_current_block_49 = C2Rust_Block_49::S_518;
            }
            C2Rust_Block_49::S_518 => {
                sub_001FE270();
                c2rust_current_block_49 = C2Rust_Block_49::S_524;
            }
            C2Rust_Block_49::S_524 => {
                _fb = 8 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_526;
            }
            C2Rust_Block_49::S_526 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_528;
            }
            C2Rust_Block_49::S_528 => {
                _cf = (((*__gamepkg_tls_g_esp) as uint64_t)
                    .wrapping_add(8 as ::core::ffi::c_int as uint64_t)
                    >> 32 as ::core::ffi::c_int & 1 as uint64_t) as ::core::ffi::c_int;
                c2rust_current_block_49 = C2Rust_Block_49::S_530;
            }
            C2Rust_Block_49::S_530 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(8 as uint32_t);
                c2rust_current_block_49 = C2Rust_Block_49::S_532;
            }
            C2Rust_Block_49::S_532 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_534;
            }
            C2Rust_Block_49::S_534 => {
                _fas = _fa as int32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_536;
            }
            C2Rust_Block_49::S_536 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_538;
            }
            C2Rust_Block_49::S_538 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_540;
            }
            C2Rust_Block_49::S_540 => {
                _fas = _fa as int32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_542;
            }
            C2Rust_Block_49::S_542 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_544;
            }
            C2Rust_Block_49::S_544 => {
                _cf = 0 as ::core::ffi::c_int;
                c2rust_current_block_49 = C2Rust_Block_49::S_546;
            }
            C2Rust_Block_49::S_546 => {
                if _fa != _fb {
                    c2rust_current_block_49 = C2Rust_Block_49::S_589;
                } else {
                    c2rust_current_block_49 = C2Rust_Block_49::S_555;
                }
            }
            C2Rust_Block_49::S_555 => {
                (*__gamepkg_tls_g_eax) = 0xe as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_561;
            }
            C2Rust_Block_49::S_561 => {
                (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_49 = C2Rust_Block_49::S_563;
            }
            C2Rust_Block_49::S_563 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_49 = C2Rust_Block_49::S_569;
            }
            C2Rust_Block_49::S_569 => {
                _fb = 0x1c as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_571;
            }
            C2Rust_Block_49::S_571 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_573;
            }
            C2Rust_Block_49::S_573 => {
                _cf = (((*__gamepkg_tls_g_esp) as uint64_t)
                    .wrapping_add(0x1c as ::core::ffi::c_int as uint64_t)
                    >> 32 as ::core::ffi::c_int & 1 as uint64_t) as ::core::ffi::c_int;
                c2rust_current_block_49 = C2Rust_Block_49::S_575;
            }
            C2Rust_Block_49::S_575 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(0x1c as uint32_t);
                c2rust_current_block_49 = C2Rust_Block_49::S_577;
            }
            C2Rust_Block_49::S_577 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_579;
            }
            C2Rust_Block_49::S_579 => {
                _fas = _fa as int32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_581;
            }
            C2Rust_Block_49::S_581 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_49 = C2Rust_Block_49::S_583;
            }
            C2Rust_Block_49::S_583 => return,
            C2Rust_Block_49::S_589 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ebx).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_49 = C2Rust_Block_49::S_595;
            }
            C2Rust_Block_49::S_595 => {
                _pv_15 = 0x36dc18 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_597;
            }
            C2Rust_Block_49::S_597 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_49 = C2Rust_Block_49::S_599;
            }
            C2Rust_Block_49::S_599 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_15,
                );
                c2rust_current_block_49 = C2Rust_Block_49::S_609;
            }
            C2Rust_Block_49::S_609 => {
                _pv_16 = (*__gamepkg_tls_g_edx);
                c2rust_current_block_49 = C2Rust_Block_49::S_611;
            }
            C2Rust_Block_49::S_611 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_49 = C2Rust_Block_49::S_613;
            }
            C2Rust_Block_49::S_613 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_16,
                );
                c2rust_current_block_49 = C2Rust_Block_49::S_623;
            }
            C2Rust_Block_49::S_623 => {
                _pv_17 = 0x1fa2b7 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_625;
            }
            C2Rust_Block_49::S_625 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_49 = C2Rust_Block_49::S_627;
            }
            C2Rust_Block_49::S_627 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_17,
                );
                c2rust_current_block_49 = C2Rust_Block_49::S_633;
            }
            C2Rust_Block_49::S_633 => {
                sub_001FE270();
                c2rust_current_block_49 = C2Rust_Block_49::S_639;
            }
            C2Rust_Block_49::S_639 => {
                _fb = 8 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_641;
            }
            C2Rust_Block_49::S_641 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_643;
            }
            C2Rust_Block_49::S_643 => {
                _cf = (((*__gamepkg_tls_g_esp) as uint64_t)
                    .wrapping_add(8 as ::core::ffi::c_int as uint64_t)
                    >> 32 as ::core::ffi::c_int & 1 as uint64_t) as ::core::ffi::c_int;
                c2rust_current_block_49 = C2Rust_Block_49::S_645;
            }
            C2Rust_Block_49::S_645 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(8 as uint32_t);
                c2rust_current_block_49 = C2Rust_Block_49::S_647;
            }
            C2Rust_Block_49::S_647 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_649;
            }
            C2Rust_Block_49::S_649 => {
                _fas = _fa as int32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_651;
            }
            C2Rust_Block_49::S_651 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_653;
            }
            C2Rust_Block_49::S_653 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_655;
            }
            C2Rust_Block_49::S_655 => {
                _fas = _fa as int32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_657;
            }
            C2Rust_Block_49::S_657 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_659;
            }
            C2Rust_Block_49::S_659 => {
                _cf = 0 as ::core::ffi::c_int;
                c2rust_current_block_49 = C2Rust_Block_49::S_661;
            }
            C2Rust_Block_49::S_661 => {
                if _fa == _fb {
                    c2rust_current_block_49 = C2Rust_Block_49::S_1063;
                } else {
                    c2rust_current_block_49 = C2Rust_Block_49::S_670;
                }
            }
            C2Rust_Block_49::S_670 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ebx).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_49 = C2Rust_Block_49::S_676;
            }
            C2Rust_Block_49::S_676 => {
                _pv_18 = 0x36dc78 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_678;
            }
            C2Rust_Block_49::S_678 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_49 = C2Rust_Block_49::S_680;
            }
            C2Rust_Block_49::S_680 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_18,
                );
                c2rust_current_block_49 = C2Rust_Block_49::S_690;
            }
            C2Rust_Block_49::S_690 => {
                _pv_19 = (*__gamepkg_tls_g_eax);
                c2rust_current_block_49 = C2Rust_Block_49::S_692;
            }
            C2Rust_Block_49::S_692 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_49 = C2Rust_Block_49::S_694;
            }
            C2Rust_Block_49::S_694 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_19,
                );
                c2rust_current_block_49 = C2Rust_Block_49::S_704;
            }
            C2Rust_Block_49::S_704 => {
                _pv_20 = 0x1fa2cc as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_706;
            }
            C2Rust_Block_49::S_706 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_49 = C2Rust_Block_49::S_708;
            }
            C2Rust_Block_49::S_708 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_20,
                );
                c2rust_current_block_49 = C2Rust_Block_49::S_714;
            }
            C2Rust_Block_49::S_714 => {
                sub_001FE270();
                c2rust_current_block_49 = C2Rust_Block_49::S_720;
            }
            C2Rust_Block_49::S_720 => {
                _fb = 8 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_722;
            }
            C2Rust_Block_49::S_722 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_724;
            }
            C2Rust_Block_49::S_724 => {
                _cf = (((*__gamepkg_tls_g_esp) as uint64_t)
                    .wrapping_add(8 as ::core::ffi::c_int as uint64_t)
                    >> 32 as ::core::ffi::c_int & 1 as uint64_t) as ::core::ffi::c_int;
                c2rust_current_block_49 = C2Rust_Block_49::S_726;
            }
            C2Rust_Block_49::S_726 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(8 as uint32_t);
                c2rust_current_block_49 = C2Rust_Block_49::S_728;
            }
            C2Rust_Block_49::S_728 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_730;
            }
            C2Rust_Block_49::S_730 => {
                _fas = _fa as int32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_732;
            }
            C2Rust_Block_49::S_732 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_734;
            }
            C2Rust_Block_49::S_734 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_736;
            }
            C2Rust_Block_49::S_736 => {
                _fas = _fa as int32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_738;
            }
            C2Rust_Block_49::S_738 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_740;
            }
            C2Rust_Block_49::S_740 => {
                _cf = 0 as ::core::ffi::c_int;
                c2rust_current_block_49 = C2Rust_Block_49::S_742;
            }
            C2Rust_Block_49::S_742 => {
                if _fa == _fb {
                    c2rust_current_block_49 = C2Rust_Block_49::S_1063;
                } else {
                    c2rust_current_block_49 = C2Rust_Block_49::S_751;
                }
            }
            C2Rust_Block_49::S_751 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ebx).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_49 = C2Rust_Block_49::S_757;
            }
            C2Rust_Block_49::S_757 => {
                _pv_21 = 0x36dc38 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_759;
            }
            C2Rust_Block_49::S_759 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_49 = C2Rust_Block_49::S_761;
            }
            C2Rust_Block_49::S_761 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_21,
                );
                c2rust_current_block_49 = C2Rust_Block_49::S_771;
            }
            C2Rust_Block_49::S_771 => {
                _pv_22 = (*__gamepkg_tls_g_ecx);
                c2rust_current_block_49 = C2Rust_Block_49::S_773;
            }
            C2Rust_Block_49::S_773 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_49 = C2Rust_Block_49::S_775;
            }
            C2Rust_Block_49::S_775 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_22,
                );
                c2rust_current_block_49 = C2Rust_Block_49::S_785;
            }
            C2Rust_Block_49::S_785 => {
                _pv_23 = 0x1fa2e1 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_787;
            }
            C2Rust_Block_49::S_787 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_49 = C2Rust_Block_49::S_789;
            }
            C2Rust_Block_49::S_789 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_23,
                );
                c2rust_current_block_49 = C2Rust_Block_49::S_795;
            }
            C2Rust_Block_49::S_795 => {
                sub_001FE270();
                c2rust_current_block_49 = C2Rust_Block_49::S_801;
            }
            C2Rust_Block_49::S_801 => {
                _fb = 8 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_803;
            }
            C2Rust_Block_49::S_803 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_805;
            }
            C2Rust_Block_49::S_805 => {
                _cf = (((*__gamepkg_tls_g_esp) as uint64_t)
                    .wrapping_add(8 as ::core::ffi::c_int as uint64_t)
                    >> 32 as ::core::ffi::c_int & 1 as uint64_t) as ::core::ffi::c_int;
                c2rust_current_block_49 = C2Rust_Block_49::S_807;
            }
            C2Rust_Block_49::S_807 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(8 as uint32_t);
                c2rust_current_block_49 = C2Rust_Block_49::S_809;
            }
            C2Rust_Block_49::S_809 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_811;
            }
            C2Rust_Block_49::S_811 => {
                _fas = _fa as int32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_813;
            }
            C2Rust_Block_49::S_813 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_815;
            }
            C2Rust_Block_49::S_815 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_817;
            }
            C2Rust_Block_49::S_817 => {
                _fas = _fa as int32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_819;
            }
            C2Rust_Block_49::S_819 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_821;
            }
            C2Rust_Block_49::S_821 => {
                _cf = 0 as ::core::ffi::c_int;
                c2rust_current_block_49 = C2Rust_Block_49::S_823;
            }
            C2Rust_Block_49::S_823 => {
                if _fa == _fb {
                    c2rust_current_block_49 = C2Rust_Block_49::S_1029;
                } else {
                    c2rust_current_block_49 = C2Rust_Block_49::S_832;
                }
            }
            C2Rust_Block_49::S_832 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ebx).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_49 = C2Rust_Block_49::S_838;
            }
            C2Rust_Block_49::S_838 => {
                _pv_24 = 0x36dc48 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_840;
            }
            C2Rust_Block_49::S_840 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_49 = C2Rust_Block_49::S_842;
            }
            C2Rust_Block_49::S_842 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_24,
                );
                c2rust_current_block_49 = C2Rust_Block_49::S_852;
            }
            C2Rust_Block_49::S_852 => {
                _pv_25 = (*__gamepkg_tls_g_edx);
                c2rust_current_block_49 = C2Rust_Block_49::S_854;
            }
            C2Rust_Block_49::S_854 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_49 = C2Rust_Block_49::S_856;
            }
            C2Rust_Block_49::S_856 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_25,
                );
                c2rust_current_block_49 = C2Rust_Block_49::S_866;
            }
            C2Rust_Block_49::S_866 => {
                _pv_26 = 0x1fa2f6 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_868;
            }
            C2Rust_Block_49::S_868 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_49 = C2Rust_Block_49::S_870;
            }
            C2Rust_Block_49::S_870 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_26,
                );
                c2rust_current_block_49 = C2Rust_Block_49::S_876;
            }
            C2Rust_Block_49::S_876 => {
                sub_001FE270();
                c2rust_current_block_49 = C2Rust_Block_49::S_882;
            }
            C2Rust_Block_49::S_882 => {
                _fb = 8 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_884;
            }
            C2Rust_Block_49::S_884 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_886;
            }
            C2Rust_Block_49::S_886 => {
                _cf = (((*__gamepkg_tls_g_esp) as uint64_t)
                    .wrapping_add(8 as ::core::ffi::c_int as uint64_t)
                    >> 32 as ::core::ffi::c_int & 1 as uint64_t) as ::core::ffi::c_int;
                c2rust_current_block_49 = C2Rust_Block_49::S_888;
            }
            C2Rust_Block_49::S_888 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(8 as uint32_t);
                c2rust_current_block_49 = C2Rust_Block_49::S_890;
            }
            C2Rust_Block_49::S_890 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_892;
            }
            C2Rust_Block_49::S_892 => {
                _fas = _fa as int32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_894;
            }
            C2Rust_Block_49::S_894 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_896;
            }
            C2Rust_Block_49::S_896 => {
                _fb = 0 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_898;
            }
            C2Rust_Block_49::S_898 => {
                _fas = _fa as int32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_900;
            }
            C2Rust_Block_49::S_900 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_902;
            }
            C2Rust_Block_49::S_902 => {
                _cf = 0 as ::core::ffi::c_int;
                c2rust_current_block_49 = C2Rust_Block_49::S_904;
            }
            C2Rust_Block_49::S_904 => {
                if _fa == _fb {
                    c2rust_current_block_49 = C2Rust_Block_49::S_1029;
                } else {
                    c2rust_current_block_49 = C2Rust_Block_49::S_913;
                }
            }
            C2Rust_Block_49::S_913 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_ebx).wrapping_add(4 as uint32_t) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_49 = C2Rust_Block_49::S_919;
            }
            C2Rust_Block_49::S_919 => {
                _pv_27 = 0x36dc58 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_921;
            }
            C2Rust_Block_49::S_921 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_49 = C2Rust_Block_49::S_923;
            }
            C2Rust_Block_49::S_923 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_27,
                );
                c2rust_current_block_49 = C2Rust_Block_49::S_933;
            }
            C2Rust_Block_49::S_933 => {
                _pv_28 = (*__gamepkg_tls_g_eax);
                c2rust_current_block_49 = C2Rust_Block_49::S_935;
            }
            C2Rust_Block_49::S_935 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_49 = C2Rust_Block_49::S_937;
            }
            C2Rust_Block_49::S_937 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_28,
                );
                c2rust_current_block_49 = C2Rust_Block_49::S_947;
            }
            C2Rust_Block_49::S_947 => {
                _pv_29 = 0x1fa30b as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_949;
            }
            C2Rust_Block_49::S_949 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_49 = C2Rust_Block_49::S_951;
            }
            C2Rust_Block_49::S_951 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_29,
                );
                c2rust_current_block_49 = C2Rust_Block_49::S_957;
            }
            C2Rust_Block_49::S_957 => {
                sub_001FE270();
                c2rust_current_block_49 = C2Rust_Block_49::S_963;
            }
            C2Rust_Block_49::S_963 => {
                _fb = 8 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_965;
            }
            C2Rust_Block_49::S_965 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_967;
            }
            C2Rust_Block_49::S_967 => {
                _cf = (((*__gamepkg_tls_g_esp) as uint64_t)
                    .wrapping_add(8 as ::core::ffi::c_int as uint64_t)
                    >> 32 as ::core::ffi::c_int & 1 as uint64_t) as ::core::ffi::c_int;
                c2rust_current_block_49 = C2Rust_Block_49::S_969;
            }
            C2Rust_Block_49::S_969 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(8 as uint32_t);
                c2rust_current_block_49 = C2Rust_Block_49::S_971;
            }
            C2Rust_Block_49::S_971 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_973;
            }
            C2Rust_Block_49::S_973 => {
                _fas = _fa as int32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_975;
            }
            C2Rust_Block_49::S_975 => {
                _cf = ((*__gamepkg_tls_g_eax) != 0 as uint32_t) as ::core::ffi::c_int;
                c2rust_current_block_49 = C2Rust_Block_49::S_977;
            }
            C2Rust_Block_49::S_977 => {
                (*__gamepkg_tls_g_eax) = -((*__gamepkg_tls_g_eax) as int32_t)
                    as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_979;
            }
            C2Rust_Block_49::S_979 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_981;
            }
            C2Rust_Block_49::S_981 => {
                _fas = _fa as int32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_983;
            }
            C2Rust_Block_49::S_983 => {
                (*__gamepkg_tls_g_eax) = (if _cf != 0 {
                    0xffffffff as ::core::ffi::c_uint
                } else {
                    0 as ::core::ffi::c_uint
                }) as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_985;
            }
            C2Rust_Block_49::S_985 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_987;
            }
            C2Rust_Block_49::S_987 => {
                _fas = _fa as int32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_989;
            }
            C2Rust_Block_49::S_989 => {
                _cf = 0 as ::core::ffi::c_int;
                c2rust_current_block_49 = C2Rust_Block_49::S_991;
            }
            C2Rust_Block_49::S_991 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 0x180 as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_993;
            }
            C2Rust_Block_49::S_993 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_995;
            }
            C2Rust_Block_49::S_995 => {
                _fas = _fa as int32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_1001;
            }
            C2Rust_Block_49::S_1001 => {
                (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_49 = C2Rust_Block_49::S_1003;
            }
            C2Rust_Block_49::S_1003 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_49 = C2Rust_Block_49::S_1009;
            }
            C2Rust_Block_49::S_1009 => {
                _fb = 0x1c as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_1011;
            }
            C2Rust_Block_49::S_1011 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_1013;
            }
            C2Rust_Block_49::S_1013 => {
                _cf = (((*__gamepkg_tls_g_esp) as uint64_t)
                    .wrapping_add(0x1c as ::core::ffi::c_int as uint64_t)
                    >> 32 as ::core::ffi::c_int & 1 as uint64_t) as ::core::ffi::c_int;
                c2rust_current_block_49 = C2Rust_Block_49::S_1015;
            }
            C2Rust_Block_49::S_1015 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(0x1c as uint32_t);
                c2rust_current_block_49 = C2Rust_Block_49::S_1017;
            }
            C2Rust_Block_49::S_1017 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_1019;
            }
            C2Rust_Block_49::S_1019 => {
                _fas = _fa as int32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_1021;
            }
            C2Rust_Block_49::S_1021 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_49 = C2Rust_Block_49::S_1023;
            }
            C2Rust_Block_49::S_1023 => return,
            C2Rust_Block_49::S_1029 => {
                (*__gamepkg_tls_g_eax) = 0x480 as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_1035;
            }
            C2Rust_Block_49::S_1035 => {
                (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_49 = C2Rust_Block_49::S_1037;
            }
            C2Rust_Block_49::S_1037 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_49 = C2Rust_Block_49::S_1043;
            }
            C2Rust_Block_49::S_1043 => {
                _fb = 0x1c as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_1045;
            }
            C2Rust_Block_49::S_1045 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_1047;
            }
            C2Rust_Block_49::S_1047 => {
                _cf = (((*__gamepkg_tls_g_esp) as uint64_t)
                    .wrapping_add(0x1c as ::core::ffi::c_int as uint64_t)
                    >> 32 as ::core::ffi::c_int & 1 as uint64_t) as ::core::ffi::c_int;
                c2rust_current_block_49 = C2Rust_Block_49::S_1049;
            }
            C2Rust_Block_49::S_1049 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(0x1c as uint32_t);
                c2rust_current_block_49 = C2Rust_Block_49::S_1051;
            }
            C2Rust_Block_49::S_1051 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_1053;
            }
            C2Rust_Block_49::S_1053 => {
                _fas = _fa as int32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_1055;
            }
            C2Rust_Block_49::S_1055 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_49 = C2Rust_Block_49::S_1057;
            }
            C2Rust_Block_49::S_1057 => return,
            C2Rust_Block_49::S_1063 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx) & 0xffffff00 as uint32_t
                    | ::core::ptr::read_volatile::<
                        uint8_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            ((*__gamepkg_tls_g_ebx).wrapping_add(0xd as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ) as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_1065;
            }
            C2Rust_Block_49::S_1065 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 0xffffff00 as uint32_t
                    | 1 as ::core::ffi::c_int as uint8_t as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_1067;
            }
            C2Rust_Block_49::S_1067 => {
                _fa = ((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t as uint32_t
                    & 0xff as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_1069;
            }
            C2Rust_Block_49::S_1069 => {
                _fb = ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t as uint32_t
                    & 0xff as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_1071;
            }
            C2Rust_Block_49::S_1071 => {
                _fas = _fa as int8_t as int32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_1073;
            }
            C2Rust_Block_49::S_1073 => {
                _fbs = _fb as int8_t as int32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_1075;
            }
            C2Rust_Block_49::S_1075 => {
                _cf = (_fa < _fb) as ::core::ffi::c_int;
                c2rust_current_block_49 = C2Rust_Block_49::S_1077;
            }
            C2Rust_Block_49::S_1077 => {
                if _fa != _fb {
                    c2rust_current_block_49 = C2Rust_Block_49::S_1124;
                } else {
                    c2rust_current_block_49 = C2Rust_Block_49::S_1086;
                }
            }
            C2Rust_Block_49::S_1086 => {
                (*__gamepkg_tls_g_eax) = 0x40 as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_1092;
            }
            C2Rust_Block_49::S_1092 => {
                (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_49 = C2Rust_Block_49::S_1094;
            }
            C2Rust_Block_49::S_1094 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_49 = C2Rust_Block_49::S_1100;
            }
            C2Rust_Block_49::S_1100 => {
                _fb = 0x1c as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_1102;
            }
            C2Rust_Block_49::S_1102 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_1104;
            }
            C2Rust_Block_49::S_1104 => {
                _cf = (((*__gamepkg_tls_g_esp) as uint64_t)
                    .wrapping_add(0x1c as ::core::ffi::c_int as uint64_t)
                    >> 32 as ::core::ffi::c_int & 1 as uint64_t) as ::core::ffi::c_int;
                c2rust_current_block_49 = C2Rust_Block_49::S_1106;
            }
            C2Rust_Block_49::S_1106 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(0x1c as uint32_t);
                c2rust_current_block_49 = C2Rust_Block_49::S_1108;
            }
            C2Rust_Block_49::S_1108 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_1110;
            }
            C2Rust_Block_49::S_1110 => {
                _fas = _fa as int32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_1112;
            }
            C2Rust_Block_49::S_1112 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_49 = C2Rust_Block_49::S_1114;
            }
            C2Rust_Block_49::S_1114 => return,
            C2Rust_Block_49::S_1124 => {
                _pv_30 = (*__gamepkg_tls_g_esi);
                c2rust_current_block_49 = C2Rust_Block_49::S_1126;
            }
            C2Rust_Block_49::S_1126 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_49 = C2Rust_Block_49::S_1128;
            }
            C2Rust_Block_49::S_1128 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_30,
                );
                c2rust_current_block_49 = C2Rust_Block_49::S_1138;
            }
            C2Rust_Block_49::S_1138 => {
                _pv_31 = (*__gamepkg_tls_g_edi);
                c2rust_current_block_49 = C2Rust_Block_49::S_1140;
            }
            C2Rust_Block_49::S_1140 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_49 = C2Rust_Block_49::S_1142;
            }
            C2Rust_Block_49::S_1142 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_31,
                );
                c2rust_current_block_49 = C2Rust_Block_49::S_1148;
            }
            C2Rust_Block_49::S_1148 => {
                (*__gamepkg_tls_g_ecx) = 7 as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_1150;
            }
            C2Rust_Block_49::S_1150 => {
                (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_ebx);
                c2rust_current_block_49 = C2Rust_Block_49::S_1152;
            }
            C2Rust_Block_49::S_1152 => {
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(0xc as uint32_t);
                c2rust_current_block_49 = C2Rust_Block_49::S_1154;
            }
            C2Rust_Block_49::S_1154 => {
                if (*__gamepkg_tls_g_df) == 0 {
                    c2rust_current_block_49 = C2Rust_Block_49::S_1158;
                } else {
                    c2rust_current_block_49 = C2Rust_Block_49::S_1192;
                }
            }
            C2Rust_Block_49::S_1158 => {
                _d = ::core::ptr::with_exposed_provenance_mut::<
                    uint8_t,
                >(
                    ((*__gamepkg_tls_g_edi) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                );
                _s = ::core::ptr::with_exposed_provenance_mut::<
                    uint8_t,
                >(
                    ((*__gamepkg_tls_g_esi) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                );
                c2rust_current_block_49 = C2Rust_Block_49::S_1160;
            }
            C2Rust_Block_49::S_1160 => {
                _n = (*__gamepkg_tls_g_ecx).wrapping_mul(4 as uint32_t);
                c2rust_current_block_49 = C2Rust_Block_49::S_1162;
            }
            C2Rust_Block_49::S_1162 => {
                if _d.offset(_n as isize) <= _s || _s.offset(_n as isize) <= _d {
                    c2rust_current_block_49 = C2Rust_Block_49::S_1164;
                } else {
                    c2rust_current_block_49 = C2Rust_Block_49::S_1168;
                }
            }
            C2Rust_Block_49::S_1164 => {
                memcpy(
                    _d as *mut ::core::ffi::c_void,
                    _s as *const ::core::ffi::c_void,
                    _n as size_t,
                );
                c2rust_current_block_49 = C2Rust_Block_49::S_1185;
            }
            C2Rust_Block_49::S_1168 => {
                _i = 0;
                c2rust_current_block_49 = C2Rust_Block_49::S_1171;
            }
            C2Rust_Block_49::S_1171 => {
                _i = 0 as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_1172;
            }
            C2Rust_Block_49::S_1172 => {
                if _i < (*__gamepkg_tls_g_ecx) {
                    c2rust_current_block_49 = C2Rust_Block_49::S_1173;
                } else {
                    c2rust_current_block_49 = C2Rust_Block_49::S_1185;
                }
            }
            C2Rust_Block_49::S_1173 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edi)
                            .wrapping_add(_i.wrapping_mul(4 as uint32_t)) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esi)
                                .wrapping_add(_i.wrapping_mul(4 as uint32_t)) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ),
                );
                c2rust_current_block_49 = C2Rust_Block_49::S_1174;
            }
            C2Rust_Block_49::S_1174 => {
                _i = _i.wrapping_add(1);
                c2rust_current_block_49 = C2Rust_Block_49::S_1172;
            }
            C2Rust_Block_49::S_1185 => {
                (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi)
                    .wrapping_add((*__gamepkg_tls_g_ecx).wrapping_mul(4 as uint32_t));
                c2rust_current_block_49 = C2Rust_Block_49::S_1187;
            }
            C2Rust_Block_49::S_1187 => {
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
                    .wrapping_add((*__gamepkg_tls_g_ecx).wrapping_mul(4 as uint32_t));
                c2rust_current_block_49 = C2Rust_Block_49::S_1213;
            }
            C2Rust_Block_49::S_1192 => {
                _i_0 = 0;
                c2rust_current_block_49 = C2Rust_Block_49::S_1195;
            }
            C2Rust_Block_49::S_1195 => {
                _i_0 = 0 as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_1196;
            }
            C2Rust_Block_49::S_1196 => {
                if _i_0 < (*__gamepkg_tls_g_ecx) {
                    c2rust_current_block_49 = C2Rust_Block_49::S_1197;
                } else {
                    c2rust_current_block_49 = C2Rust_Block_49::S_1205;
                }
            }
            C2Rust_Block_49::S_1197 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edi)
                            .wrapping_sub(_i_0.wrapping_mul(4 as uint32_t)) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esi)
                                .wrapping_sub(_i_0.wrapping_mul(4 as uint32_t))
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ),
                );
                c2rust_current_block_49 = C2Rust_Block_49::S_1198;
            }
            C2Rust_Block_49::S_1198 => {
                _i_0 = _i_0.wrapping_add(1);
                c2rust_current_block_49 = C2Rust_Block_49::S_1196;
            }
            C2Rust_Block_49::S_1205 => {
                (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi)
                    .wrapping_sub((*__gamepkg_tls_g_ecx).wrapping_mul(4 as uint32_t));
                c2rust_current_block_49 = C2Rust_Block_49::S_1207;
            }
            C2Rust_Block_49::S_1207 => {
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
                    .wrapping_sub((*__gamepkg_tls_g_ecx).wrapping_mul(4 as uint32_t));
                c2rust_current_block_49 = C2Rust_Block_49::S_1213;
            }
            C2Rust_Block_49::S_1213 => {
                (*__gamepkg_tls_g_ecx) = 0 as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_1219;
            }
            C2Rust_Block_49::S_1219 => {
                _pv_32 = (*__gamepkg_tls_g_ebx);
                c2rust_current_block_49 = C2Rust_Block_49::S_1221;
            }
            C2Rust_Block_49::S_1221 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_49 = C2Rust_Block_49::S_1223;
            }
            C2Rust_Block_49::S_1223 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_32,
                );
                c2rust_current_block_49 = C2Rust_Block_49::S_1229;
            }
            C2Rust_Block_49::S_1229 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint8_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x1d as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t,
                );
                c2rust_current_block_49 = C2Rust_Block_49::S_1235;
            }
            C2Rust_Block_49::S_1235 => {
                _pv_33 = 0x1fa352 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_1237;
            }
            C2Rust_Block_49::S_1237 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_49 = C2Rust_Block_49::S_1239;
            }
            C2Rust_Block_49::S_1239 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_33,
                );
                c2rust_current_block_49 = C2Rust_Block_49::S_1245;
            }
            C2Rust_Block_49::S_1245 => {
                sub_001F9DE0();
                c2rust_current_block_49 = C2Rust_Block_49::S_1251;
            }
            C2Rust_Block_49::S_1251 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(0x10 as uint32_t);
                c2rust_current_block_49 = C2Rust_Block_49::S_1257;
            }
            C2Rust_Block_49::S_1257 => {
                _pv_34 = (*__gamepkg_tls_g_ecx);
                c2rust_current_block_49 = C2Rust_Block_49::S_1259;
            }
            C2Rust_Block_49::S_1259 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_49 = C2Rust_Block_49::S_1261;
            }
            C2Rust_Block_49::S_1261 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_34,
                );
                c2rust_current_block_49 = C2Rust_Block_49::S_1267;
            }
            C2Rust_Block_49::S_1267 => {
                (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_eax);
                c2rust_current_block_49 = C2Rust_Block_49::S_1273;
            }
            C2Rust_Block_49::S_1273 => {
                _pv_35 = 0x1fa35e as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_1275;
            }
            C2Rust_Block_49::S_1275 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_49 = C2Rust_Block_49::S_1277;
            }
            C2Rust_Block_49::S_1277 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_35,
                );
                c2rust_current_block_49 = C2Rust_Block_49::S_1283;
            }
            C2Rust_Block_49::S_1283 => {
                sub_001F9DE0();
                c2rust_current_block_49 = C2Rust_Block_49::S_1289;
            }
            C2Rust_Block_49::S_1289 => {
                _cf = 0 as ::core::ffi::c_int;
                c2rust_current_block_49 = C2Rust_Block_49::S_1291;
            }
            C2Rust_Block_49::S_1291 => {
                (*__gamepkg_tls_g_edx) = 0 as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_1293;
            }
            C2Rust_Block_49::S_1293 => {
                _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_1295;
            }
            C2Rust_Block_49::S_1295 => {
                _fas = _fa as int32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_1298;
            }
            C2Rust_Block_49::S_1298 => {
                _dividend = ((*__gamepkg_tls_g_edx) as uint64_t)
                    << 32 as ::core::ffi::c_int | (*__gamepkg_tls_g_eax) as uint64_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_1300;
            }
            C2Rust_Block_49::S_1300 => {
                (*__gamepkg_tls_g_eax) = _dividend
                    .wrapping_div((*__gamepkg_tls_g_esi) as uint64_t) as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_1302;
            }
            C2Rust_Block_49::S_1302 => {
                (*__gamepkg_tls_g_edx) = _dividend
                    .wrapping_rem((*__gamepkg_tls_g_esi) as uint64_t) as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_1306;
            }
            C2Rust_Block_49::S_1306 => {
                (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(0x14 as uint32_t);
                c2rust_current_block_49 = C2Rust_Block_49::S_1312;
            }
            C2Rust_Block_49::S_1312 => {
                _pv_36 = (*__gamepkg_tls_g_edx);
                c2rust_current_block_49 = C2Rust_Block_49::S_1314;
            }
            C2Rust_Block_49::S_1314 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_49 = C2Rust_Block_49::S_1316;
            }
            C2Rust_Block_49::S_1316 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_36,
                );
                c2rust_current_block_49 = C2Rust_Block_49::S_1322;
            }
            C2Rust_Block_49::S_1322 => {
                (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_eax);
                c2rust_current_block_49 = C2Rust_Block_49::S_1328;
            }
            C2Rust_Block_49::S_1328 => {
                _pv_37 = 0x1fa36e as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_1330;
            }
            C2Rust_Block_49::S_1330 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_49 = C2Rust_Block_49::S_1332;
            }
            C2Rust_Block_49::S_1332 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_37,
                );
                c2rust_current_block_49 = C2Rust_Block_49::S_1338;
            }
            C2Rust_Block_49::S_1338 => {
                sub_001FA210();
                c2rust_current_block_49 = C2Rust_Block_49::S_1344;
            }
            C2Rust_Block_49::S_1344 => {
                _fb = 0xc as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_1346;
            }
            C2Rust_Block_49::S_1346 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_1348;
            }
            C2Rust_Block_49::S_1348 => {
                _cf = (((*__gamepkg_tls_g_esp) as uint64_t)
                    .wrapping_add(0xc as ::core::ffi::c_int as uint64_t)
                    >> 32 as ::core::ffi::c_int & 1 as uint64_t) as ::core::ffi::c_int;
                c2rust_current_block_49 = C2Rust_Block_49::S_1350;
            }
            C2Rust_Block_49::S_1350 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(0xc as uint32_t);
                c2rust_current_block_49 = C2Rust_Block_49::S_1352;
            }
            C2Rust_Block_49::S_1352 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_1354;
            }
            C2Rust_Block_49::S_1354 => {
                _fas = _fa as int32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_1356;
            }
            C2Rust_Block_49::S_1356 => {
                _cf = 0 as ::core::ffi::c_int;
                c2rust_current_block_49 = C2Rust_Block_49::S_1358;
            }
            C2Rust_Block_49::S_1358 => {
                (*__gamepkg_tls_g_edx) = 0 as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_1360;
            }
            C2Rust_Block_49::S_1360 => {
                _fa = (*__gamepkg_tls_g_edx) & 0xffffffff as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_1362;
            }
            C2Rust_Block_49::S_1362 => {
                _fas = _fa as int32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_1368;
            }
            C2Rust_Block_49::S_1368 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_49 = C2Rust_Block_49::S_1370;
            }
            C2Rust_Block_49::S_1370 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_49 = C2Rust_Block_49::S_1377;
            }
            C2Rust_Block_49::S_1377 => {
                _dividend_0 = ((*__gamepkg_tls_g_edx) as uint64_t)
                    << 32 as ::core::ffi::c_int | (*__gamepkg_tls_g_eax) as uint64_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_1379;
            }
            C2Rust_Block_49::S_1379 => {
                (*__gamepkg_tls_g_eax) = _dividend_0
                    .wrapping_div((*__gamepkg_tls_g_esi) as uint64_t) as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_1381;
            }
            C2Rust_Block_49::S_1381 => {
                (*__gamepkg_tls_g_edx) = _dividend_0
                    .wrapping_rem((*__gamepkg_tls_g_esi) as uint64_t) as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_1389;
            }
            C2Rust_Block_49::S_1389 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_49 = C2Rust_Block_49::S_1391;
            }
            C2Rust_Block_49::S_1391 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_49 = C2Rust_Block_49::S_1401;
            }
            C2Rust_Block_49::S_1401 => {
                (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_49 = C2Rust_Block_49::S_1403;
            }
            C2Rust_Block_49::S_1403 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_49 = C2Rust_Block_49::S_1409;
            }
            C2Rust_Block_49::S_1409 => {
                _fb = 0x1c as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_1411;
            }
            C2Rust_Block_49::S_1411 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_1413;
            }
            C2Rust_Block_49::S_1413 => {
                _cf = (((*__gamepkg_tls_g_esp) as uint64_t)
                    .wrapping_add(0x1c as ::core::ffi::c_int as uint64_t)
                    >> 32 as ::core::ffi::c_int & 1 as uint64_t) as ::core::ffi::c_int;
                c2rust_current_block_49 = C2Rust_Block_49::S_1415;
            }
            C2Rust_Block_49::S_1415 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(0x1c as uint32_t);
                c2rust_current_block_49 = C2Rust_Block_49::S_1417;
            }
            C2Rust_Block_49::S_1417 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_1419;
            }
            C2Rust_Block_49::S_1419 => {
                _fas = _fa as int32_t;
                c2rust_current_block_49 = C2Rust_Block_49::S_1421;
            }
            C2Rust_Block_49::S_1421 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_49 = C2Rust_Block_49::S_1423;
            }
            C2Rust_Block_49::S_1423 => return,
        }
    };
}
#[no_mangle]
pub unsafe extern "C" fn sub_001FA380() {
    let __gamepkg_tls_g_df = unsafe { gamepkg_tls_g_df() };
    let __gamepkg_tls_g_eax = unsafe { gamepkg_tls_g_eax() };
    let __gamepkg_tls_g_ebx = unsafe { gamepkg_tls_g_ebx() };
    let __gamepkg_tls_g_ecx = unsafe { gamepkg_tls_g_ecx() };
    let __gamepkg_tls_g_edi = unsafe { gamepkg_tls_g_edi() };
    let __gamepkg_tls_g_edx = unsafe { gamepkg_tls_g_edx() };
    let __gamepkg_tls_g_esi = unsafe { gamepkg_tls_g_esi() };
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let mut _fa: uint32_t = 0;
    let mut _fb: uint32_t = 0;
    let mut _fas: int32_t = 0;
    let mut _fbs: int32_t = 0;
    let mut _pv: uint32_t = 0;
    let mut _pv_0: uint32_t = 0;
    let mut _pv_1: uint32_t = 0;
    let mut _pv_2: uint32_t = 0;
    let mut _pv_3: uint32_t = 0;
    let mut _pv_4: uint32_t = 0;
    let mut _pv_5: uint32_t = 0;
    let mut _pv_6: uint32_t = 0;
    let mut _pv_7: uint32_t = 0;
    let mut _pv_8: uint32_t = 0;
    let mut _pv_9: uint32_t = 0;
    let mut _pv_10: uint32_t = 0;
    let mut _pv_11: uint32_t = 0;
    let mut _pv_12: uint32_t = 0;
    let mut _pv_13: uint32_t = 0;
    let mut _pv_14: uint32_t = 0;
    let mut _pv_15: uint32_t = 0;
    let mut _pv_16: uint32_t = 0;
    let mut _pv_17: uint32_t = 0;
    let mut _pv_18: uint32_t = 0;
    let mut _pv_19: uint32_t = 0;
    let mut _pv_20: uint32_t = 0;
    let mut _pv_21: uint32_t = 0;
    let mut _d: *mut uint8_t = ::core::ptr::null_mut::<uint8_t>();
    let mut _s: *mut uint8_t = ::core::ptr::null_mut::<uint8_t>();
    let mut _n: uint32_t = 0;
    let mut _i: uint32_t = 0;
    let mut _i_0: uint32_t = 0;
    enum C2Rust_Block_50 {
        S_0,
        S_2,
        S_16,
        S_18,
        S_20,
        S_22,
        S_24,
        S_30,
        S_32,
        S_34,
        S_40,
        S_46,
        S_48,
        S_50,
        S_60,
        S_62,
        S_64,
        S_74,
        S_76,
        S_78,
        S_84,
        S_86,
        S_92,
        S_94,
        S_96,
        S_106,
        S_108,
        S_110,
        S_116,
        S_122,
        S_124,
        S_126,
        S_132,
        S_142,
        S_144,
        S_146,
        S_152,
        S_158,
        S_160,
        S_162,
        S_168,
        S_174,
        S_176,
        S_178,
        S_188,
        S_190,
        S_192,
        S_198,
        S_208,
        S_210,
        S_212,
        S_218,
        S_224,
        S_226,
        S_228,
        S_234,
        S_240,
        S_242,
        S_244,
        S_254,
        S_256,
        S_258,
        S_264,
        S_270,
        S_272,
        S_274,
        S_276,
        S_278,
        S_280,
        S_282,
        S_284,
        S_286,
        S_288,
        S_290,
        S_292,
        S_294,
        S_296,
        S_298,
        S_300,
        S_302,
        S_304,
        S_306,
        S_308,
        S_310,
        S_312,
        S_314,
        S_316,
        S_318,
        S_320,
        S_322,
        S_324,
        S_326,
        S_328,
        S_330,
        S_336,
        S_338,
        S_340,
        S_346,
        S_352,
        S_354,
        S_356,
        S_362,
        S_368,
        S_370,
        S_372,
        S_382,
        S_384,
        S_386,
        S_392,
        S_402,
        S_404,
        S_406,
        S_412,
        S_418,
        S_420,
        S_422,
        S_428,
        S_434,
        S_436,
        S_438,
        S_448,
        S_450,
        S_452,
        S_458,
        S_464,
        S_466,
        S_468,
        S_470,
        S_472,
        S_474,
        S_476,
        S_478,
        S_480,
        S_482,
        S_484,
        S_486,
        S_490,
        S_492,
        S_494,
        S_496,
        S_500,
        S_503,
        S_504,
        S_505,
        S_506,
        S_517,
        S_519,
        S_524,
        S_527,
        S_528,
        S_529,
        S_530,
        S_537,
        S_539,
        S_545,
        S_551,
        S_553,
        S_563,
        S_565,
        S_571,
        S_577,
        S_579,
        S_585,
        S_587,
        S_589,
        S_591,
        S_593,
        S_595,
        S_597,
    }
    let mut c2rust_current_block_50: C2Rust_Block_50;
    c2rust_current_block_50 = C2Rust_Block_50::S_0;
    loop {
        match c2rust_current_block_50 {
            C2Rust_Block_50::S_0 => {
                _fa = 0 as uint32_t;
                _fb = 0 as uint32_t;
                c2rust_current_block_50 = C2Rust_Block_50::S_2;
            }
            C2Rust_Block_50::S_2 => {
                _fas = 0 as int32_t;
                _fbs = 0 as int32_t;
                c2rust_current_block_50 = C2Rust_Block_50::S_16;
            }
            C2Rust_Block_50::S_16 => {
                _fb = 0x20 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_50 = C2Rust_Block_50::S_18;
            }
            C2Rust_Block_50::S_18 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_50 = C2Rust_Block_50::S_20;
            }
            C2Rust_Block_50::S_20 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(0x20 as uint32_t);
                c2rust_current_block_50 = C2Rust_Block_50::S_22;
            }
            C2Rust_Block_50::S_22 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_50 = C2Rust_Block_50::S_24;
            }
            C2Rust_Block_50::S_24 => {
                _fas = _fa as int32_t;
                c2rust_current_block_50 = C2Rust_Block_50::S_30;
            }
            C2Rust_Block_50::S_30 => {
                _pv = (*__gamepkg_tls_g_ebx);
                c2rust_current_block_50 = C2Rust_Block_50::S_32;
            }
            C2Rust_Block_50::S_32 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_50 = C2Rust_Block_50::S_34;
            }
            C2Rust_Block_50::S_34 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv,
                );
                c2rust_current_block_50 = C2Rust_Block_50::S_40;
            }
            C2Rust_Block_50::S_40 => {
                (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x28 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_50 = C2Rust_Block_50::S_46;
            }
            C2Rust_Block_50::S_46 => {
                _pv_0 = (*__gamepkg_tls_g_esi);
                c2rust_current_block_50 = C2Rust_Block_50::S_48;
            }
            C2Rust_Block_50::S_48 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_50 = C2Rust_Block_50::S_50;
            }
            C2Rust_Block_50::S_50 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_0,
                );
                c2rust_current_block_50 = C2Rust_Block_50::S_60;
            }
            C2Rust_Block_50::S_60 => {
                _pv_1 = (*__gamepkg_tls_g_edi);
                c2rust_current_block_50 = C2Rust_Block_50::S_62;
            }
            C2Rust_Block_50::S_62 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_50 = C2Rust_Block_50::S_64;
            }
            C2Rust_Block_50::S_64 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_1,
                );
                c2rust_current_block_50 = C2Rust_Block_50::S_74;
            }
            C2Rust_Block_50::S_74 => {
                _pv_2 = 4 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_50 = C2Rust_Block_50::S_76;
            }
            C2Rust_Block_50::S_76 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_50 = C2Rust_Block_50::S_78;
            }
            C2Rust_Block_50::S_78 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_2,
                );
                c2rust_current_block_50 = C2Rust_Block_50::S_84;
            }
            C2Rust_Block_50::S_84 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(0x10 as uint32_t);
                c2rust_current_block_50 = C2Rust_Block_50::S_86;
            }
            C2Rust_Block_50::S_86 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(0x14 as uint32_t);
                c2rust_current_block_50 = C2Rust_Block_50::S_92;
            }
            C2Rust_Block_50::S_92 => {
                _pv_3 = (*__gamepkg_tls_g_ebx);
                c2rust_current_block_50 = C2Rust_Block_50::S_94;
            }
            C2Rust_Block_50::S_94 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_50 = C2Rust_Block_50::S_96;
            }
            C2Rust_Block_50::S_96 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_3,
                );
                c2rust_current_block_50 = C2Rust_Block_50::S_106;
            }
            C2Rust_Block_50::S_106 => {
                _pv_4 = (*__gamepkg_tls_g_ecx);
                c2rust_current_block_50 = C2Rust_Block_50::S_108;
            }
            C2Rust_Block_50::S_108 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_50 = C2Rust_Block_50::S_110;
            }
            C2Rust_Block_50::S_110 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_4,
                );
                c2rust_current_block_50 = C2Rust_Block_50::S_116;
            }
            C2Rust_Block_50::S_116 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x18 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_50 = C2Rust_Block_50::S_122;
            }
            C2Rust_Block_50::S_122 => {
                _pv_5 = 0x1fa39f as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_50 = C2Rust_Block_50::S_124;
            }
            C2Rust_Block_50::S_124 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_50 = C2Rust_Block_50::S_126;
            }
            C2Rust_Block_50::S_126 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_5,
                );
                c2rust_current_block_50 = C2Rust_Block_50::S_132;
            }
            C2Rust_Block_50::S_132 => {
                sub_001FFD80();
                c2rust_current_block_50 = C2Rust_Block_50::S_142;
            }
            C2Rust_Block_50::S_142 => {
                _pv_6 = 4 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_50 = C2Rust_Block_50::S_144;
            }
            C2Rust_Block_50::S_144 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_50 = C2Rust_Block_50::S_146;
            }
            C2Rust_Block_50::S_146 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_6,
                );
                c2rust_current_block_50 = C2Rust_Block_50::S_152;
            }
            C2Rust_Block_50::S_152 => {
                (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_ebx)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_50 = C2Rust_Block_50::S_158;
            }
            C2Rust_Block_50::S_158 => {
                _pv_7 = (*__gamepkg_tls_g_edx);
                c2rust_current_block_50 = C2Rust_Block_50::S_160;
            }
            C2Rust_Block_50::S_160 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_50 = C2Rust_Block_50::S_162;
            }
            C2Rust_Block_50::S_162 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_7,
                );
                c2rust_current_block_50 = C2Rust_Block_50::S_168;
            }
            C2Rust_Block_50::S_168 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(0x20 as uint32_t);
                c2rust_current_block_50 = C2Rust_Block_50::S_174;
            }
            C2Rust_Block_50::S_174 => {
                _pv_8 = (*__gamepkg_tls_g_eax);
                c2rust_current_block_50 = C2Rust_Block_50::S_176;
            }
            C2Rust_Block_50::S_176 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_50 = C2Rust_Block_50::S_178;
            }
            C2Rust_Block_50::S_178 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_8,
                );
                c2rust_current_block_50 = C2Rust_Block_50::S_188;
            }
            C2Rust_Block_50::S_188 => {
                _pv_9 = 0x1fa3af as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_50 = C2Rust_Block_50::S_190;
            }
            C2Rust_Block_50::S_190 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_50 = C2Rust_Block_50::S_192;
            }
            C2Rust_Block_50::S_192 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_9,
                );
                c2rust_current_block_50 = C2Rust_Block_50::S_198;
            }
            C2Rust_Block_50::S_198 => {
                sub_001FFD80();
                c2rust_current_block_50 = C2Rust_Block_50::S_208;
            }
            C2Rust_Block_50::S_208 => {
                _pv_10 = 4 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_50 = C2Rust_Block_50::S_210;
            }
            C2Rust_Block_50::S_210 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_50 = C2Rust_Block_50::S_212;
            }
            C2Rust_Block_50::S_212 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_10,
                );
                c2rust_current_block_50 = C2Rust_Block_50::S_218;
            }
            C2Rust_Block_50::S_218 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ebx)
                    .wrapping_add(8 as uint32_t);
                c2rust_current_block_50 = C2Rust_Block_50::S_224;
            }
            C2Rust_Block_50::S_224 => {
                _pv_11 = (*__gamepkg_tls_g_ecx);
                c2rust_current_block_50 = C2Rust_Block_50::S_226;
            }
            C2Rust_Block_50::S_226 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_50 = C2Rust_Block_50::S_228;
            }
            C2Rust_Block_50::S_228 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_11,
                );
                c2rust_current_block_50 = C2Rust_Block_50::S_234;
            }
            C2Rust_Block_50::S_234 => {
                (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(0x2c as uint32_t);
                c2rust_current_block_50 = C2Rust_Block_50::S_240;
            }
            C2Rust_Block_50::S_240 => {
                _pv_12 = (*__gamepkg_tls_g_edx);
                c2rust_current_block_50 = C2Rust_Block_50::S_242;
            }
            C2Rust_Block_50::S_242 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_50 = C2Rust_Block_50::S_244;
            }
            C2Rust_Block_50::S_244 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_12,
                );
                c2rust_current_block_50 = C2Rust_Block_50::S_254;
            }
            C2Rust_Block_50::S_254 => {
                _pv_13 = 0x1fa3bf as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_50 = C2Rust_Block_50::S_256;
            }
            C2Rust_Block_50::S_256 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_50 = C2Rust_Block_50::S_258;
            }
            C2Rust_Block_50::S_258 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_13,
                );
                c2rust_current_block_50 = C2Rust_Block_50::S_264;
            }
            C2Rust_Block_50::S_264 => {
                sub_001FFD80();
                c2rust_current_block_50 = C2Rust_Block_50::S_270;
            }
            C2Rust_Block_50::S_270 => {
                (*__gamepkg_tls_g_ecx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x30 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_50 = C2Rust_Block_50::S_272;
            }
            C2Rust_Block_50::S_272 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax) & 0xffffff00 as uint32_t
                    | ::core::ptr::read_volatile::<
                        uint8_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            ((*__gamepkg_tls_g_ebx).wrapping_add(0xc as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ) as uint32_t;
                c2rust_current_block_50 = C2Rust_Block_50::S_274;
            }
            C2Rust_Block_50::S_274 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint8_t,
                    >(
                        ((*__gamepkg_tls_g_ecx) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ((*__gamepkg_tls_g_eax) & 0xff as uint32_t) as uint8_t,
                );
                c2rust_current_block_50 = C2Rust_Block_50::S_276;
            }
            C2Rust_Block_50::S_276 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x30 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_50 = C2Rust_Block_50::S_278;
            }
            C2Rust_Block_50::S_278 => {
                (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_edx) & 0xffffff00 as uint32_t
                    | ::core::ptr::read_volatile::<
                        uint8_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            ((*__gamepkg_tls_g_ebx).wrapping_add(0xd as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ) as uint32_t;
                c2rust_current_block_50 = C2Rust_Block_50::S_280;
            }
            C2Rust_Block_50::S_280 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax).wrapping_add(1);
                c2rust_current_block_50 = C2Rust_Block_50::S_282;
            }
            C2Rust_Block_50::S_282 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_50 = C2Rust_Block_50::S_284;
            }
            C2Rust_Block_50::S_284 => {
                _fas = _fa as int32_t;
                c2rust_current_block_50 = C2Rust_Block_50::S_286;
            }
            C2Rust_Block_50::S_286 => {
                _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_50 = C2Rust_Block_50::S_288;
            }
            C2Rust_Block_50::S_288 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x30 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_50 = C2Rust_Block_50::S_290;
            }
            C2Rust_Block_50::S_290 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint8_t,
                    >(
                        ((*__gamepkg_tls_g_eax) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ((*__gamepkg_tls_g_edx) & 0xff as uint32_t) as uint8_t,
                );
                c2rust_current_block_50 = C2Rust_Block_50::S_292;
            }
            C2Rust_Block_50::S_292 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x30 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_50 = C2Rust_Block_50::S_294;
            }
            C2Rust_Block_50::S_294 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx) & 0xffffff00 as uint32_t
                    | ::core::ptr::read_volatile::<
                        uint8_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            ((*__gamepkg_tls_g_ebx).wrapping_add(0xe as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ) as uint32_t;
                c2rust_current_block_50 = C2Rust_Block_50::S_296;
            }
            C2Rust_Block_50::S_296 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax).wrapping_add(1);
                c2rust_current_block_50 = C2Rust_Block_50::S_298;
            }
            C2Rust_Block_50::S_298 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_50 = C2Rust_Block_50::S_300;
            }
            C2Rust_Block_50::S_300 => {
                _fas = _fa as int32_t;
                c2rust_current_block_50 = C2Rust_Block_50::S_302;
            }
            C2Rust_Block_50::S_302 => {
                _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_50 = C2Rust_Block_50::S_304;
            }
            C2Rust_Block_50::S_304 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x30 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_50 = C2Rust_Block_50::S_306;
            }
            C2Rust_Block_50::S_306 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint8_t,
                    >(
                        ((*__gamepkg_tls_g_eax) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t,
                );
                c2rust_current_block_50 = C2Rust_Block_50::S_308;
            }
            C2Rust_Block_50::S_308 => {
                (*__gamepkg_tls_g_eax) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x30 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_50 = C2Rust_Block_50::S_310;
            }
            C2Rust_Block_50::S_310 => {
                (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_edx) & 0xffffff00 as uint32_t
                    | ::core::ptr::read_volatile::<
                        uint8_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            ((*__gamepkg_tls_g_ebx).wrapping_add(0xf as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ) as uint32_t;
                c2rust_current_block_50 = C2Rust_Block_50::S_312;
            }
            C2Rust_Block_50::S_312 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_eax).wrapping_add(1);
                c2rust_current_block_50 = C2Rust_Block_50::S_314;
            }
            C2Rust_Block_50::S_314 => {
                _fa = (*__gamepkg_tls_g_eax) & 0xffffffff as uint32_t;
                c2rust_current_block_50 = C2Rust_Block_50::S_316;
            }
            C2Rust_Block_50::S_316 => {
                _fas = _fa as int32_t;
                c2rust_current_block_50 = C2Rust_Block_50::S_318;
            }
            C2Rust_Block_50::S_318 => {
                _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_50 = C2Rust_Block_50::S_320;
            }
            C2Rust_Block_50::S_320 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x30 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    (*__gamepkg_tls_g_eax),
                );
                c2rust_current_block_50 = C2Rust_Block_50::S_322;
            }
            C2Rust_Block_50::S_322 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint8_t,
                    >(
                        ((*__gamepkg_tls_g_eax) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ((*__gamepkg_tls_g_edx) & 0xff as uint32_t) as uint8_t,
                );
                c2rust_current_block_50 = C2Rust_Block_50::S_324;
            }
            C2Rust_Block_50::S_324 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x30 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                            ::core::ptr::with_exposed_provenance_mut::<
                                uint32_t,
                            >(
                                ((*__gamepkg_tls_g_esp).wrapping_add(0x30 as uint32_t)
                                    as uintptr_t)
                                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                            ),
                        )
                        .wrapping_add(1 as uint32_t),
                );
                c2rust_current_block_50 = C2Rust_Block_50::S_326;
            }
            C2Rust_Block_50::S_326 => {
                _fa = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x30 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                ) & 0xffffffff as uint32_t;
                c2rust_current_block_50 = C2Rust_Block_50::S_328;
            }
            C2Rust_Block_50::S_328 => {
                _fas = _fa as int32_t;
                c2rust_current_block_50 = C2Rust_Block_50::S_330;
            }
            C2Rust_Block_50::S_330 => {
                _fb = (_fa == 0x80000000 as uint32_t) as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_50 = C2Rust_Block_50::S_336;
            }
            C2Rust_Block_50::S_336 => {
                _pv_14 = 4 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_50 = C2Rust_Block_50::S_338;
            }
            C2Rust_Block_50::S_338 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_50 = C2Rust_Block_50::S_340;
            }
            C2Rust_Block_50::S_340 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_14,
                );
                c2rust_current_block_50 = C2Rust_Block_50::S_346;
            }
            C2Rust_Block_50::S_346 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_ebx)
                    .wrapping_add(0x10 as uint32_t);
                c2rust_current_block_50 = C2Rust_Block_50::S_352;
            }
            C2Rust_Block_50::S_352 => {
                _pv_15 = (*__gamepkg_tls_g_eax);
                c2rust_current_block_50 = C2Rust_Block_50::S_354;
            }
            C2Rust_Block_50::S_354 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_50 = C2Rust_Block_50::S_356;
            }
            C2Rust_Block_50::S_356 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_15,
                );
                c2rust_current_block_50 = C2Rust_Block_50::S_362;
            }
            C2Rust_Block_50::S_362 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(0x38 as uint32_t);
                c2rust_current_block_50 = C2Rust_Block_50::S_368;
            }
            C2Rust_Block_50::S_368 => {
                _pv_16 = (*__gamepkg_tls_g_ecx);
                c2rust_current_block_50 = C2Rust_Block_50::S_370;
            }
            C2Rust_Block_50::S_370 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_50 = C2Rust_Block_50::S_372;
            }
            C2Rust_Block_50::S_372 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_16,
                );
                c2rust_current_block_50 = C2Rust_Block_50::S_382;
            }
            C2Rust_Block_50::S_382 => {
                _pv_17 = 0x1fa406 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_50 = C2Rust_Block_50::S_384;
            }
            C2Rust_Block_50::S_384 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_50 = C2Rust_Block_50::S_386;
            }
            C2Rust_Block_50::S_386 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_17,
                );
                c2rust_current_block_50 = C2Rust_Block_50::S_392;
            }
            C2Rust_Block_50::S_392 => {
                sub_001FFD80();
                c2rust_current_block_50 = C2Rust_Block_50::S_402;
            }
            C2Rust_Block_50::S_402 => {
                _pv_18 = 4 as ::core::ffi::c_int as uint32_t;
                c2rust_current_block_50 = C2Rust_Block_50::S_404;
            }
            C2Rust_Block_50::S_404 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_50 = C2Rust_Block_50::S_406;
            }
            C2Rust_Block_50::S_406 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_18,
                );
                c2rust_current_block_50 = C2Rust_Block_50::S_412;
            }
            C2Rust_Block_50::S_412 => {
                (*__gamepkg_tls_g_edx) = (*__gamepkg_tls_g_ebx)
                    .wrapping_add(0x14 as uint32_t);
                c2rust_current_block_50 = C2Rust_Block_50::S_418;
            }
            C2Rust_Block_50::S_418 => {
                _pv_19 = (*__gamepkg_tls_g_edx);
                c2rust_current_block_50 = C2Rust_Block_50::S_420;
            }
            C2Rust_Block_50::S_420 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_50 = C2Rust_Block_50::S_422;
            }
            C2Rust_Block_50::S_422 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_19,
                );
                c2rust_current_block_50 = C2Rust_Block_50::S_428;
            }
            C2Rust_Block_50::S_428 => {
                (*__gamepkg_tls_g_eax) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(0x44 as uint32_t);
                c2rust_current_block_50 = C2Rust_Block_50::S_434;
            }
            C2Rust_Block_50::S_434 => {
                _pv_20 = (*__gamepkg_tls_g_eax);
                c2rust_current_block_50 = C2Rust_Block_50::S_436;
            }
            C2Rust_Block_50::S_436 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_50 = C2Rust_Block_50::S_438;
            }
            C2Rust_Block_50::S_438 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_20,
                );
                c2rust_current_block_50 = C2Rust_Block_50::S_448;
            }
            C2Rust_Block_50::S_448 => {
                _pv_21 = 0x1fa416 as ::core::ffi::c_uint as uint32_t;
                c2rust_current_block_50 = C2Rust_Block_50::S_450;
            }
            C2Rust_Block_50::S_450 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_sub(4 as uint32_t);
                c2rust_current_block_50 = C2Rust_Block_50::S_452;
            }
            C2Rust_Block_50::S_452 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    _pv_21,
                );
                c2rust_current_block_50 = C2Rust_Block_50::S_458;
            }
            C2Rust_Block_50::S_458 => {
                sub_001FFD80();
                c2rust_current_block_50 = C2Rust_Block_50::S_464;
            }
            C2Rust_Block_50::S_464 => {
                (*__gamepkg_tls_g_ecx) = (*__gamepkg_tls_g_ecx) & 0xffffff00 as uint32_t
                    | ::core::ptr::read_volatile::<
                        uint8_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint8_t,
                        >(
                            ((*__gamepkg_tls_g_ebx).wrapping_add(0x18 as uint32_t)
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ) as uint32_t;
                c2rust_current_block_50 = C2Rust_Block_50::S_466;
            }
            C2Rust_Block_50::S_466 => {
                (*__gamepkg_tls_g_edx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp).wrapping_add(0x48 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_50 = C2Rust_Block_50::S_468;
            }
            C2Rust_Block_50::S_468 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint8_t,
                    >(
                        ((*__gamepkg_tls_g_edx) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ((*__gamepkg_tls_g_ecx) & 0xff as uint32_t) as uint8_t,
                );
                c2rust_current_block_50 = C2Rust_Block_50::S_470;
            }
            C2Rust_Block_50::S_470 => {
                _fb = 0x3c as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_50 = C2Rust_Block_50::S_472;
            }
            C2Rust_Block_50::S_472 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_50 = C2Rust_Block_50::S_474;
            }
            C2Rust_Block_50::S_474 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(0x3c as uint32_t);
                c2rust_current_block_50 = C2Rust_Block_50::S_476;
            }
            C2Rust_Block_50::S_476 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_50 = C2Rust_Block_50::S_478;
            }
            C2Rust_Block_50::S_478 => {
                _fas = _fa as int32_t;
                c2rust_current_block_50 = C2Rust_Block_50::S_480;
            }
            C2Rust_Block_50::S_480 => {
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_ebx);
                c2rust_current_block_50 = C2Rust_Block_50::S_482;
            }
            C2Rust_Block_50::S_482 => {
                (*__gamepkg_tls_g_ecx) = 7 as uint32_t;
                c2rust_current_block_50 = C2Rust_Block_50::S_484;
            }
            C2Rust_Block_50::S_484 => {
                (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(0x10 as uint32_t);
                c2rust_current_block_50 = C2Rust_Block_50::S_486;
            }
            C2Rust_Block_50::S_486 => {
                if (*__gamepkg_tls_g_df) == 0 {
                    c2rust_current_block_50 = C2Rust_Block_50::S_490;
                } else {
                    c2rust_current_block_50 = C2Rust_Block_50::S_524;
                }
            }
            C2Rust_Block_50::S_490 => {
                _d = ::core::ptr::with_exposed_provenance_mut::<
                    uint8_t,
                >(
                    ((*__gamepkg_tls_g_edi) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                );
                _s = ::core::ptr::with_exposed_provenance_mut::<
                    uint8_t,
                >(
                    ((*__gamepkg_tls_g_esi) as uintptr_t)
                        .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                );
                c2rust_current_block_50 = C2Rust_Block_50::S_492;
            }
            C2Rust_Block_50::S_492 => {
                _n = (*__gamepkg_tls_g_ecx).wrapping_mul(4 as uint32_t);
                c2rust_current_block_50 = C2Rust_Block_50::S_494;
            }
            C2Rust_Block_50::S_494 => {
                if _d.offset(_n as isize) <= _s || _s.offset(_n as isize) <= _d {
                    c2rust_current_block_50 = C2Rust_Block_50::S_496;
                } else {
                    c2rust_current_block_50 = C2Rust_Block_50::S_500;
                }
            }
            C2Rust_Block_50::S_496 => {
                memcpy(
                    _d as *mut ::core::ffi::c_void,
                    _s as *const ::core::ffi::c_void,
                    _n as size_t,
                );
                c2rust_current_block_50 = C2Rust_Block_50::S_517;
            }
            C2Rust_Block_50::S_500 => {
                _i = 0;
                c2rust_current_block_50 = C2Rust_Block_50::S_503;
            }
            C2Rust_Block_50::S_503 => {
                _i = 0 as uint32_t;
                c2rust_current_block_50 = C2Rust_Block_50::S_504;
            }
            C2Rust_Block_50::S_504 => {
                if _i < (*__gamepkg_tls_g_ecx) {
                    c2rust_current_block_50 = C2Rust_Block_50::S_505;
                } else {
                    c2rust_current_block_50 = C2Rust_Block_50::S_517;
                }
            }
            C2Rust_Block_50::S_505 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edi)
                            .wrapping_add(_i.wrapping_mul(4 as uint32_t)) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esi)
                                .wrapping_add(_i.wrapping_mul(4 as uint32_t)) as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ),
                );
                c2rust_current_block_50 = C2Rust_Block_50::S_506;
            }
            C2Rust_Block_50::S_506 => {
                _i = _i.wrapping_add(1);
                c2rust_current_block_50 = C2Rust_Block_50::S_504;
            }
            C2Rust_Block_50::S_517 => {
                (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi)
                    .wrapping_add((*__gamepkg_tls_g_ecx).wrapping_mul(4 as uint32_t));
                c2rust_current_block_50 = C2Rust_Block_50::S_519;
            }
            C2Rust_Block_50::S_519 => {
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
                    .wrapping_add((*__gamepkg_tls_g_ecx).wrapping_mul(4 as uint32_t));
                c2rust_current_block_50 = C2Rust_Block_50::S_545;
            }
            C2Rust_Block_50::S_524 => {
                _i_0 = 0;
                c2rust_current_block_50 = C2Rust_Block_50::S_527;
            }
            C2Rust_Block_50::S_527 => {
                _i_0 = 0 as uint32_t;
                c2rust_current_block_50 = C2Rust_Block_50::S_528;
            }
            C2Rust_Block_50::S_528 => {
                if _i_0 < (*__gamepkg_tls_g_ecx) {
                    c2rust_current_block_50 = C2Rust_Block_50::S_529;
                } else {
                    c2rust_current_block_50 = C2Rust_Block_50::S_537;
                }
            }
            C2Rust_Block_50::S_529 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_edi)
                            .wrapping_sub(_i_0.wrapping_mul(4 as uint32_t)) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    ::core::ptr::read_volatile::<
                        uint32_t,
                    >(
                        ::core::ptr::with_exposed_provenance_mut::<
                            uint32_t,
                        >(
                            ((*__gamepkg_tls_g_esi)
                                .wrapping_sub(_i_0.wrapping_mul(4 as uint32_t))
                                as uintptr_t)
                                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                        ),
                    ),
                );
                c2rust_current_block_50 = C2Rust_Block_50::S_530;
            }
            C2Rust_Block_50::S_530 => {
                _i_0 = _i_0.wrapping_add(1);
                c2rust_current_block_50 = C2Rust_Block_50::S_528;
            }
            C2Rust_Block_50::S_537 => {
                (*__gamepkg_tls_g_esi) = (*__gamepkg_tls_g_esi)
                    .wrapping_sub((*__gamepkg_tls_g_ecx).wrapping_mul(4 as uint32_t));
                c2rust_current_block_50 = C2Rust_Block_50::S_539;
            }
            C2Rust_Block_50::S_539 => {
                (*__gamepkg_tls_g_edi) = (*__gamepkg_tls_g_edi)
                    .wrapping_sub((*__gamepkg_tls_g_ecx).wrapping_mul(4 as uint32_t));
                c2rust_current_block_50 = C2Rust_Block_50::S_545;
            }
            C2Rust_Block_50::S_545 => {
                (*__gamepkg_tls_g_ecx) = 0 as uint32_t;
                c2rust_current_block_50 = C2Rust_Block_50::S_551;
            }
            C2Rust_Block_50::S_551 => {
                (*__gamepkg_tls_g_edi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_50 = C2Rust_Block_50::S_553;
            }
            C2Rust_Block_50::S_553 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_50 = C2Rust_Block_50::S_563;
            }
            C2Rust_Block_50::S_563 => {
                (*__gamepkg_tls_g_esi) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_50 = C2Rust_Block_50::S_565;
            }
            C2Rust_Block_50::S_565 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_50 = C2Rust_Block_50::S_571;
            }
            C2Rust_Block_50::S_571 => {
                ::core::ptr::write_volatile(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint8_t,
                    >(
                        ((*__gamepkg_tls_g_ebx).wrapping_add(0x19 as uint32_t)
                            as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                    0 as uint8_t,
                );
                c2rust_current_block_50 = C2Rust_Block_50::S_577;
            }
            C2Rust_Block_50::S_577 => {
                (*__gamepkg_tls_g_ebx) = ::core::ptr::read_volatile::<
                    uint32_t,
                >(
                    ::core::ptr::with_exposed_provenance_mut::<
                        uint32_t,
                    >(
                        ((*__gamepkg_tls_g_esp) as uintptr_t)
                            .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
                    ),
                );
                c2rust_current_block_50 = C2Rust_Block_50::S_579;
            }
            C2Rust_Block_50::S_579 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_50 = C2Rust_Block_50::S_585;
            }
            C2Rust_Block_50::S_585 => {
                _fb = 0x20 as ::core::ffi::c_int as uint32_t & 0xffffffff as uint32_t;
                c2rust_current_block_50 = C2Rust_Block_50::S_587;
            }
            C2Rust_Block_50::S_587 => {
                _fbs = _fb as int32_t;
                c2rust_current_block_50 = C2Rust_Block_50::S_589;
            }
            C2Rust_Block_50::S_589 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(0x20 as uint32_t);
                c2rust_current_block_50 = C2Rust_Block_50::S_591;
            }
            C2Rust_Block_50::S_591 => {
                _fa = (*__gamepkg_tls_g_esp) & 0xffffffff as uint32_t;
                c2rust_current_block_50 = C2Rust_Block_50::S_593;
            }
            C2Rust_Block_50::S_593 => {
                _fas = _fa as int32_t;
                c2rust_current_block_50 = C2Rust_Block_50::S_595;
            }
            C2Rust_Block_50::S_595 => {
                (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp)
                    .wrapping_add(4 as uint32_t);
                c2rust_current_block_50 = C2Rust_Block_50::S_597;
            }
            C2Rust_Block_50::S_597 => return,
        }
    };
}
