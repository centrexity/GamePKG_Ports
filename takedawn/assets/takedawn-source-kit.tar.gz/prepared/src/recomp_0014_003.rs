extern "C" {
    static mut g_xbox_mem_offset: ptrdiff_t;
    fn gamepkg_tls_g_esp() -> *mut uint32_t;
    fn gamepkg_tls_g_xmm0() -> *mut RecompXmm;
}
pub type int32_t = i32;
pub type uint32_t = u32;
pub type uint64_t = u64;
pub type uintptr_t = usize;
pub type ptrdiff_t = isize;
#[derive(Copy, Clone)]
#[repr(C)]
pub union RecompXmm {
    pub f: [::core::ffi::c_float; 4],
    pub d: [::core::ffi::c_double; 2],
    pub u: [uint32_t; 4],
    pub i: [int32_t; 4],
    pub q: [uint64_t; 2],
}
#[inline]
unsafe extern "C" fn XMM_ZERO() -> RecompXmm {
    let mut r: RecompXmm = RecompXmm { f: [0.; 4] };
    r.q[0usize] = 0 as uint64_t;
    r.q[1usize] = 0 as uint64_t;
    return r;
}
#[inline]
unsafe extern "C" fn XMM_SCALAR(mut v: ::core::ffi::c_float) -> RecompXmm {
    let mut r: RecompXmm = XMM_ZERO();
    r.f[0usize] = v;
    return r;
}
#[no_mangle]
pub unsafe extern "C" fn sub_0028DC40() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b2108 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56bf18 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0028DC60() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b210c as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56bef0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0028DC80() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b2110 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56bea8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0028DCA0() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1f00 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56bf00 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0028DCC0() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1eec as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56bec4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0028DCE0() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x56bf00 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        - ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3a7964 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56bf38 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0028DD00() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x56bec4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        - ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x388f08 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56bf20 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0028DD20() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1ca8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56bf50 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0028DD40() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3897a8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56bf3c as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0028DD60() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x56bf3c as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56bf4c as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0028DD80() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1ca8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56beb0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0028DDA0() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x56bec4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        * ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1728 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56bf44 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0028DDC0() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x56bec4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        * ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x39922c as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56beec as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0028DDE0() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x56bec4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        - ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x56beec as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56becc as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0028DE00() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1694 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56bf14 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0028DE20() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b16d0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56bec8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0028DE40() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1f00 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56bed8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0028DE60() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1eec as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56bf2c as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0028DE80() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x396eb0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56bf10 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0028DEA0() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x398cc0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56bec0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0028DEC0() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x56bed8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        - ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3a7964 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56beb4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0028DEE0() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x56bf2c as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        - ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x388f08 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56bef8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0028DF00() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x56beb4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        - ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3a7964 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56bf08 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0028DF20() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3a2d50 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56beac as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0028DF40() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3a2d50 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56bedc as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0028DF60() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x56bed8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        + ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3980f8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56bee8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0028DF80() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x56bf2c as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        + ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3980f8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56bf30 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0028DFA0() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x56bee8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        * ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1c34 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56bf1c as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0028DFC0() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x56bf30 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        * ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1c34 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56bf40 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0028DFE0() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1c34 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56beb8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0028E000() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x56bed8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        * ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1c34 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        * ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1a90 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56bf28 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0028E030() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x56bf2c as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        * ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1c34 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        * ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1c30 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56bed0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0028E060() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x56bed8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        * ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1c34 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56bed4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0028E080() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x56bf2c as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        * ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1c34 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56bf34 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0028E0A0() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x35bf1c as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56bebc as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0028E0C0() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b17c8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56bee4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0028E0E0() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x56bebc as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56bf48 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0028E100() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x56bf2c as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        - ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x56bebc as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56bf0c as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0028E120() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x56bf0c as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        - ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x56bee4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56bf04 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0028E140() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x56bf34 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        - ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1690 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56bef4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0028E160() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1690 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56bee0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0028E180() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x56bef4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        - ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1688 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56bf24 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0028E1A0() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b191c as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56bfa8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0028E1C0() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b2108 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56bfc4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0028E1E0() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b210c as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56bf9c as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0028E200() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b2110 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56bf54 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0028E220() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1f00 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56bfac as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0028E240() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1eec as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56bf70 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0028E260() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x56bfac as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        - ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3a7964 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56bfe4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0028E280() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x56bf70 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        - ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x388f08 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56bfcc as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
