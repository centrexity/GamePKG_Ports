extern "C" {
    static mut g_xbox_mem_offset: ptrdiff_t;
    fn gamepkg_tls_g_esp() -> *mut uint32_t;
    fn gamepkg_tls_g_xmm0() -> *mut RecompXmm;
}
pub type int32_t = i32;
pub type uint32_t = u32;
pub type uint64_t = u64;
pub type uintptr_t = usize;
pub type ptrdiff_t = isize;
#[derive(Copy, Clone)]
#[repr(C)]
pub union RecompXmm {
    pub f: [::core::ffi::c_float; 4],
    pub d: [::core::ffi::c_double; 2],
    pub u: [uint32_t; 4],
    pub i: [int32_t; 4],
    pub q: [uint64_t; 2],
}
#[inline]
unsafe extern "C" fn XMM_ZERO() -> RecompXmm {
    let mut r: RecompXmm = RecompXmm { f: [0.; 4] };
    r.q[0usize] = 0 as uint64_t;
    r.q[1usize] = 0 as uint64_t;
    return r;
}
#[inline]
unsafe extern "C" fn XMM_SCALAR(mut v: ::core::ffi::c_float) -> RecompXmm {
    let mut r: RecompXmm = XMM_ZERO();
    r.f[0usize] = v;
    return r;
}
#[no_mangle]
pub unsafe extern "C" fn sub_0027FD10() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b210c as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56a3a8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0027FD30() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b2110 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56a360 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0027FD50() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1f00 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56a3b8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0027FD70() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1eec as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56a37c as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0027FD90() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x56a3b8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        - ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3a7964 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56a3f0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0027FDB0() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x56a37c as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        - ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x388f08 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56a3d8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0027FDD0() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1ca8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56a408 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0027FDF0() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3897a8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56a3f4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0027FE10() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x56a3f4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56a404 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0027FE30() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1ca8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56a368 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0027FE50() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x56a37c as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        * ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1728 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56a3fc as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0027FE70() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x56a37c as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        * ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x39922c as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56a3a4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0027FE90() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x56a37c as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        - ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x56a3a4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56a384 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0027FEB0() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1694 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56a3cc as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0027FED0() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b16d0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56a380 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0027FEF0() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1f00 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56a390 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0027FF10() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1eec as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56a3e4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0027FF30() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x396eb0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56a3c8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0027FF50() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x398cc0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56a378 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0027FF70() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x56a390 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        - ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3a7964 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56a36c as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0027FF90() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x56a3e4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        - ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x388f08 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56a3b0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0027FFB0() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x56a36c as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        - ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3a7964 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56a3c0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0027FFD0() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3a2d50 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56a364 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_0027FFF0() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3a2d50 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56a394 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00280010() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x56a390 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        + ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3980f8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56a3a0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00280020() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56a3a0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00280028() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00280030() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x56a3e4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        + ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3980f8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56a3e8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00280050() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x56a3a0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        * ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1c34 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56a3d4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00280068() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00280070() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x56a3e8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        * ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1c34 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56a3f8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00280090() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1c34 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56a370 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_002800B0() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x56a390 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        * ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1c34 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        * ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1a90 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56a3e0 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_002800E0() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x56a3e4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        * ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1c34 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        * ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1c30 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56a388 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00280110() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x56a390 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        * ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1c34 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56a38c as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00280130() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x56a3e4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        * ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1c34 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56a3ec as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00280150() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x35bf1c as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56a374 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00280170() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b17c8 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56a39c as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00280190() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x56a374 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56a400 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_002801B0() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x56a3e4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        - ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x56a374 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56a3c4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_002801D0() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x56a3c4 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        - ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x56a39c as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56a3bc as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_002801F0() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x56a3ec as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        - ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1690 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56a3ac as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00280210() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1690 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56a398 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00280230() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x56a3ac as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    (*__gamepkg_tls_g_xmm0).f[0usize] = (*__gamepkg_tls_g_xmm0).f[0usize]
        - ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1688 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56a3dc as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00280250() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b191c as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56a460 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00280270() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b2108 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56a47c as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_00280290() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b210c as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56a454 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_002802B0() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b2110 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56a40c as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_002802D0() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1f00 as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56a464 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
#[no_mangle]
pub unsafe extern "C" fn sub_002802F0() {
    let __gamepkg_tls_g_esp = unsafe { gamepkg_tls_g_esp() };
    let __gamepkg_tls_g_xmm0 = unsafe { gamepkg_tls_g_xmm0() };
    (*__gamepkg_tls_g_xmm0) = XMM_SCALAR(
        ::core::ptr::read_volatile::<
            ::core::ffi::c_float,
        >(
            ::core::ptr::with_exposed_provenance_mut::<
                ::core::ffi::c_float,
            >(
                (0x3b1eec as ::core::ffi::c_int as uint32_t as uintptr_t)
                    .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
            ),
        ),
    );
    ::core::ptr::write_volatile(
        ::core::ptr::with_exposed_provenance_mut::<
            ::core::ffi::c_float,
        >(
            (0x56a428 as ::core::ffi::c_int as uint32_t as uintptr_t)
                .wrapping_add(g_xbox_mem_offset as uintptr_t) as usize,
        ),
        (*__gamepkg_tls_g_xmm0).f[0usize],
    );
    (*__gamepkg_tls_g_esp) = (*__gamepkg_tls_g_esp).wrapping_add(4 as uint32_t);
}
