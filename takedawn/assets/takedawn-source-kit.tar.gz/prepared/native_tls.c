#define RECOMP_GENERATED_CODE
#include "recomp_types.h"
void *gamepkg_tls_g_df(void) { return (void *)&g_df; }
void *gamepkg_tls_g_eax(void) { return (void *)&g_eax; }
void *gamepkg_tls_g_ebp(void) { return (void *)&g_ebp; }
void *gamepkg_tls_g_ebx(void) { return (void *)&g_ebx; }
void *gamepkg_tls_g_ecx(void) { return (void *)&g_ecx; }
void *gamepkg_tls_g_edi(void) { return (void *)&g_edi; }
void *gamepkg_tls_g_edx(void) { return (void *)&g_edx; }
void *gamepkg_tls_g_eflags(void) { return (void *)&g_eflags; }
void *gamepkg_tls_g_esi(void) { return (void *)&g_esi; }
void *gamepkg_tls_g_esp(void) { return (void *)&g_esp; }
void *gamepkg_tls_g_fp_cc(void) { return (void *)&g_fp_cc; }
void *gamepkg_tls_g_fp_cmp(void) { return (void *)&g_fp_cmp; }
void *gamepkg_tls_g_fp_control_word(void) { return (void *)&g_fp_control_word; }
void *gamepkg_tls_g_fp_stack(void) { return (void *)&g_fp_stack; }
void *gamepkg_tls_g_fp_top(void) { return (void *)&g_fp_top; }
void *gamepkg_tls_g_fs_base(void) { return (void *)&g_fs_base; }
void *gamepkg_tls_g_mm0(void) { return (void *)&g_mm0; }
void *gamepkg_tls_g_mm1(void) { return (void *)&g_mm1; }
void *gamepkg_tls_g_mm2(void) { return (void *)&g_mm2; }
void *gamepkg_tls_g_mm3(void) { return (void *)&g_mm3; }
void *gamepkg_tls_g_mm4(void) { return (void *)&g_mm4; }
void *gamepkg_tls_g_mm5(void) { return (void *)&g_mm5; }
void *gamepkg_tls_g_mm6(void) { return (void *)&g_mm6; }
void *gamepkg_tls_g_mm7(void) { return (void *)&g_mm7; }
void *gamepkg_tls_g_seh_ebp(void) { return (void *)&g_seh_ebp; }
void *gamepkg_tls_g_xmm0(void) { return (void *)&g_xmm0; }
void *gamepkg_tls_g_xmm1(void) { return (void *)&g_xmm1; }
void *gamepkg_tls_g_xmm2(void) { return (void *)&g_xmm2; }
void *gamepkg_tls_g_xmm3(void) { return (void *)&g_xmm3; }
void *gamepkg_tls_g_xmm4(void) { return (void *)&g_xmm4; }
void *gamepkg_tls_g_xmm5(void) { return (void *)&g_xmm5; }
void *gamepkg_tls_g_xmm6(void) { return (void *)&g_xmm6; }
void *gamepkg_tls_g_xmm7(void) { return (void *)&g_xmm7; }
void *gamepkg_native_stderr(void) { return (void *)stderr; }
#include <stdarg.h>
int gamepkg_native_fflush(void *stream) { return fflush((FILE *)stream); }
int gamepkg_native_fprintf(void *stream, const char *format, ...) { va_list args; va_start(args, format); int result = vfprintf((FILE *)stream, format, args); va_end(args); return result; }
